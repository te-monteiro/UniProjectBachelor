"use strict";

var canvas;
var gl;
var startPosition;
var endPosition;

var vertices = [];
//var total = Math.random()* 10;
var maxNumTriangles = 200;
var maxNumVertices  = 3 * maxNumTriangles; 
var index = 0;

var dragging = false;
var mousedown = false;
//var drawing = true; = mousedown





//var redraw = false;

var colors = [
    vec4( 0.0, 0.0, 0.0, 1.0 ),  // black
    vec4( 1.0, 0.0, 0.0, 1.0 ),  // red
    vec4( 1.0, 1.0, 0.0, 1.0 ),  // yellow
    vec4( 0.0, 1.0, 0.0, 1.0 ),  // green
    vec4( 0.0, 0.0, 1.0, 1.0 ),  // blue
    vec4( 1.0, 0.0, 1.0, 1.0 ),  // magenta
    vec4( 0.0, 1.0, 1.0, 1.0 )   // cyan
];


window.onload = function init() {
    
    
    canvas = document.getElementById( "gl-canvas" );

    gl = WebGLUtils.setupWebGL( canvas );
    if ( !gl ) { alert( "WebGL isn't available" ); }
    
    generateRandomPoints();
    

    // Configure WebGL
    gl.viewport( 0, 0, canvas.width, canvas.height );
    gl.clearColor( 0.0, 0.0, 0.0, 1.0 );
    
    //  Load shaders and initialize attribute buffers
    var program = initShaders( gl, "vertex-shader", "fragment-shader" );
    gl.useProgram(program);
    
    // Load the data into the GPU
    var bufferId = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, bufferId);
    gl.bufferData( gl.ARRAY_BUFFER, 8*maxNumVertices, gl.DYNAMIC_DRAW );
    console.log("tamanho " + 8*maxNumVertices);

    // Associate our shader variables with our data buffer
    var vPosition = gl.getAttribLocation(program, "vPosition");
    gl.vertexAttribPointer(vPosition, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);

    

   //Vertices
    canvas.onmousedown = function(e){
        if(e.which == 1){ //left mouse button clicked
            mousedown = true;
            startPosition = vec2(-1 + 2*(e.offsetX/canvas.width), -1 + 2* (canvas.height -e.offsetY)/canvas.height);
            console.log("startPosition: " + startPosition);
            
            
            
            gl.bufferSubData(gl.ARRAY_BUFFER, 0, flatten(startPosition));
            gl.bufferSubData(gl.ARRAY_BUFFER, sizeof['vec2'], flatten(startPosition));
        }
        
    };
    canvas.onmousemove = function(e){
        if(mousedown){ //left mouse button clicked
            console.log("Mouse moving");

            dragging = true;
            var draw = vec2(-1 + 2*(e.offsetX/canvas.width), -1 + 2* (canvas.height -e.offsetY)/canvas.height);
            gl.bufferSubData(gl.ARRAY_BUFFER, sizeof['vec2'], flatten(draw));
            
        
        }
    };
    
    
    canvas.onmouseup = function(e){
        if(e.which == 1){ //left mouse button clicked
            console.log("Mouse released");
            mousedown = false;
            dragging = true;
            endPosition = vec2(-1 + 2*(e.offsetX/canvas.width), -1 + 2* (canvas.height -event.offsetY)/canvas.height);
            gl.bufferSubData(gl.ARRAY_BUFFER, sizeof['vec2'], flatten(endPosition));
                        console.log("endPosition:" + endPosition);

        }
    };

/**
    //canvas.addEventListener("mousedown", function(){
    canvas.addEventListener("mousemove", function(event){

        if(redraw) {
          gl.bindBuffer( gl.ARRAY_BUFFER, vBuffer );
          var t = vec2(2*event.clientX/canvas.width-1,
           2*(canvas.height-event.clientY)/canvas.height-1);
        gl.bufferSubData(gl.ARRAY_BUFFER, 8*index, flatten(t));

        gl.bindBuffer(gl.ARRAY_BUFFER, cBuffer);
        t = vec4(colors[(index)%7]);
        gl.bufferSubData(gl.ARRAY_BUFFER, 16*index, flatten(t));
        index++;
      }

    } );*/

/**

    var cBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, cBuffer );
    gl.bufferData( gl.ARRAY_BUFFER, 16*maxNumVertices, gl.STATIC_DRAW );

    var vColor = gl.getAttribLocation( program, "vColor" );
    gl.vertexAttribPointer( vColor, 4, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( vColor );
*/
    render();

}


function generateRandomPoints(){
    var v1 = [], v2=[], v3=[];
	v1.x = Math.random()*2-1;
	v1.y = Math.random()*2-1;
	v2.x = v1.x + 0.1*(Math.random()*2-0.5);
	v2.y = v1.y + 0.1*(Math.random()*2-0.5);
	

	vertices.push( vec2(v1.x,v1.y));
	vertices.push( vec2(v2.x,v2.y));
	
}


function getAlpha(){
    var vector = endPos - startPos;
    velocity = Math.sqrt(Math.pow(2, vector.x) + Math.pow(2, vector.y));
    return Math.atan2(vector.y, vector.x);
}

function getMaxHeight(){
    return Math.pow(2, velocity)*Math.pow(Math.sin(getAlpha()))/20;
}

function getMaxReach(){
    return Math.pow(2, velocity)*Math.sin(getAlpha()*2)/10;
}

function getMaxTime(){
    return (Math.sin(getAlpha()) * velocity)/10;
}

function render() {

    gl.clear( gl.COLOR_BUFFER_BIT );
    //cor do ponto
	var color = vec4(1.0, 0.0, 0.0, 1.0);
	var colorLoc = gl.getUniformLocation(program, "color" );
	gl.uniform4fv(colorLoc, color);
    
    //desenhar o ponto
    gl.drawArrays( gl.POINTS, 0, index );
    if(dragging){
        gl.drawArrays(gl.LINE_STRIP, 0, 2);
    }

    window.requestAnimFrame(render);

}


	
	
	
/**	
	for(j = 0; j < 20 ; j++){
		if( vertices.length / 3 > 500){
			vertices.shift();vertices.shift();vertices.shift();
			
		}
	}*/
