var gl;
var primitives = [];
var mModel_list;

//var de projecoes
var mProjection;
var mObliquo; 
var mView;

var mModelLoc;
var mViewLoc;
var mProjectionLoc;

//qual a projecao
var isAxometrica = true;
var isObliqua = false;
var isOrtogonal = false;
var isPerspective = false;

var angle = 30;
var l = 0.5;
var tx = 0, ty = 0, tz = 0, rx = 0, ry = 0, rz = 0, sx = 1, sy = 1, sz = 1;
var program;


//dimensoes janela/visor
var width;
var height;


window.onload = function init() {
    var canvas = document.getElementById("gl-canvas");
    gl = WebGLUtils.setupWebGL(canvas);
    if(!gl) { alert("WebGL isn't available"); }
    
      
    // Configure WebGL  viewport original 
    gl.viewport(0,0,canvas.width, canvas.height);
   // width = canvas.width
    //height = canvas.height;
    gl.clearColor(0.0, 0.0, 0.0, 1.0);
    
    // Load shaders and initialize attribute buffers
    program = initShaders(gl, "vertex-shader", "fragment-shader");
    gl.useProgram(program);
    
    mModel_list = [];
    var eye = [1, 1, 1];
    var at = [0, 0, 0];
    var up = [0, 1, 0];
    
    mView = lookAt(eye, at, up);
    mProjection = ortho(-2,2,-2,2,10,-10);
        
    cubeInit(gl);
    sphereInit(gl);
    bunnyInit(gl);
    cylinderInit(gl);
    torusInit(gl);
        
    gl.enable(gl.DEPTH_TEST);
  
    
    
  /*  // alteracao das dimensões da janela podem ser acedidas 
    window.onresize = function() {    
        height = window.innerHeight;    
        width = window.innerWidth;     
        var s = Math.min(width, height);     
        canvas.width = s;     
        canvas.height = s;    
        gl.viewport(0,0,s,s); 
    }*/
    
    
    
    mObliquo = mat4(1, 0 , -l*Math.cos(angle), 0,
                    0, 1, -l*Math.sin(angle), 0,
                    0, 0, 0, 0, 
                    0, 0, 0, 1);
    
    
    mModelLoc = gl.getUniformLocation(program, "mModel")
    mViewLoc = gl.getUniformLocation(program, "mView");
    mProjectionLoc = gl.getUniformLocation(program, "mProjection");
    
    gl.uniformMatrix4fv(mViewLoc, false, flatten(mView));
    gl.uniformMatrix4fv(mProjectionLoc, false, flatten(mProjection));
  
    
    callback();
   
   
    render();
}


function callback(){
    
    
     //translacao
    document.getElementById("tx").addEventListener("input", function(e){
        tx = e.target.value
        ctm_calculate();
    });
    
    document.getElementById("ty").addEventListener("input", function(e){
        ty = e.target.value
        ctm_calculate();
    });
    document.getElementById("tz").addEventListener("input", function(e){
        tz = e.target.value
        ctm_calculate();
    });
    
    //rotacao
    document.getElementById("rx").addEventListener("input", function(e){
        rx = e.target.value
        ctm_calculate();
    });
    document.getElementById("ry").addEventListener("input", function(e){
        ry = e.target.value
        ctm_calculate();
    });
    document.getElementById("rz").addEventListener("input", function(e){
        rz = e.target.value
        ctm_calculate();
    });
    
    //escala
    document.getElementById("sx").addEventListener("input", function(e){
        sx = e.target.value
        ctm_calculate();
    });
    document.getElementById("sy").addEventListener("input", function(e){
        sy = e.target.value
        ctm_calculate();
    });
    document.getElementById("sz").addEventListener("input", function(e){
        sz = e.target.value
        ctm_calculate();
    });
    
    
    //buttons
    document.getElementById("Save").addEventListener("click", function(e){
        mModel_list.push(mat4());
        reset();
    });
    
    document.getElementById("reset").addEventListener("click", function(e){
        reset();
    });
    
    document.getElementById("Cube").addEventListener("click", function(e){
        push_primitive("Cube");
    });
    
    document.getElementById("Sphere").addEventListener("click", function(e){
        push_primitive("Sphere");
    });
    
    document.getElementById("Cylinder").addEventListener("click", function(e){
        push_primitive("Cylinder");
    });
    
    document.getElementById("Torus").addEventListener("click", function(e){
        push_primitive("Torus");
    });
    
    document.getElementById("Bunny").addEventListener("click", function(e){
        push_primitive("Bunny");
    });
    
    //Projecoes
    
    document.getElementById("AxoP").addEventListener("click", function(e){
        mView = mObliquo;
        mProjection = ortho(-2,2,-2,2,10,-10);
        isAxometrica = true;
        isObliqua = false;
        isOrtogonal = false;
        isPerspective = false;
    });
    
    
    
    //teclas f e w para escolher modo de visualizacao
    
     

}

function modeVisualization(){
    window.onkeypress = function(e){
        console.log(e.keyCode);
        if (e.keyCode == 87 || e.keyCode == 119){ //letra W ou w --malha
            cubeDrawWireFrame(gl, program);
        } 
        if(e.keyCode == 70 || e.keyCode == 102){// tecla F ou f  para preencher
            cubeDrawFilled(gl, program);
        }            
      };
}


function ctm_calculate(){
    
    var t = translate(tx,ty,tz);
    var rotx = rotateX(rx); 
    var roty = rotateY(ry);
    var rotz = rotateZ(rz);
    var s = scalem(sx, sy,  sz);
        
    mModel_list[mModel_list.length - 1] = mult(t, mult(rotz, mult(roty, mult(rotx, s))));         
}

 function reset(){
       tx = 0, ty = 0, tz = 0;
       rx = 0, ry = 0, rz = 0;    
       sx = 1, sy = 1, sz = 1;
}

function push_primitive(name)
{
    primitives.push(name);
    mModel_list.push(mat4());
    tx = 0;
    ty = 0;
    tz = 0;
    rx = 0;
    ry = 0;
    rz = 0;
    sx = 1;
    sy = 1;
    sz = 1;
    
    updateSliders();
}

function updateSliders(){
    document.getElementById("tx").value = tx;
    document.getElementById("ty").value = ty;
    document.getElementById("tz").value = tz;
    document.getElementById("rx").value = rx;
    document.getElementById("ry").value = ry;
    document.getElementById("rz").value = rz;
    document.getElementById("sx").value = sx;
    document.getElementById("sy").value = sy;
    document.getElementById("sz").value = sz;
}


function render() {
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT );

    if(primitives.length != 0){
        for(i in primitives){
                        
            mModel = mModel_list[i];
            gl.uniformMatrix4fv(mModelLoc, false, flatten(mModel));

            if(primitives[i] == "Cube"){
                cubeDrawWireFrame(gl, program);
            } else if(primitives[i] == "Sphere"){
                sphereDrawWireFrame(gl, program);
            }else if(primitives[i] == "Cylinder"){
                cylinderDrawWireFrame(gl, program);
            }else if(primitives[i] == "Torus"){
                torusDrawWireFrame(gl, program);
            }else if(primitives[i] == "Bunny"){
                bunnyDrawWireFrame(gl, program);
            }
        }
    }
    //mode de visualizacao se e preenchido ou nao
    modeVisualization();
            
    requestAnimFrame(render);
       
}
