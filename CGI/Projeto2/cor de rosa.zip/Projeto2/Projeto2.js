var gl;
var program;

//html
var mModelView;
var mModelViewLoc;
var mProjectionLoc;
var mProjection;

//objetos
var object;

//para a projecao axonometrica
var projectionAxo;
var theta;
var gamma;
var A = 42;
var B = 7;
var thetaRadians;
var gammaRadians;

//para a projecao obliqua
var mObliquo; 
var projetionObli;
var l = 0;
var alpha = 45;

//para a projecao ortogonal
var mOrtogonal;
var projectionOrto;

//para a projecao perspetiva
var mPerspetiva;
var d = 1;

//dimensoes janela/visor
var width;
var height;

//para pintar   
var filled = false;

//remocao de superficies
var ativarZ = false;
var ativarBF = false;

//zoom
var zoom = 1;


window.onload = function init() {
    var canvas = document.getElementById("gl-canvas");
    gl = WebGLUtils.setupWebGL(canvas);
    if(!gl) { alert("WebGL isn't available"); }
    
   
    // alteracao das dimensões da janela podem ser acedidas
    height = window.innerHeight;
    width = window.innerWidth;
    var s = Math.min(width, height);
    canvas.width = s;
    canvas.height = s;
    gl.viewport(0,0,s,s);
    gl.clearColor(0.0, 0.0, 0.0, 1.0);
    
    //objectos
    cubeInit(gl);
    sphereInit(gl);
    bunnyInit(gl);
    cylinderInit(gl);
    torusInit(gl);
    
    //Necessário para ativação do Z-Buffer (Hidden Surface Removal)
 //   gl.enable(gl.DEPTH_TEST);
    
    // Configure WebGL  viewport original 
    gl.viewport(0,0,canvas.width, canvas.height);
    gl.clearColor(0.0, 0.0, 0.0, 1.0);
    
    // Load shaders and initialize attribute buffers
    program = initShaders(gl, "vertex-shader", "fragment-shader");
    gl.useProgram(program);
  
    
    mProjection = ortho(-2,2,-2,2,10,-10);
       
    mModelViewLoc = gl.getUniformLocation(program, "mModelView");
    mProjectionLoc = gl.getUniformLocation(program, "mProjection");
    //inicial
    object = "Cube";
    projectionAxo = "Dimetrica";
    fProjectionAxo();
    //ativarZ = false;
    //ativarCF = false;
         
    callback(); 
    
    render();
}


function callback(){
    
    
    document.getElementById("zoom").addEventListener("input", function(e){
        zoom = e.target.value;
 
    });
    
  
     //z bufer e back face culling
  /**   document.body.onkeyup = function(e){
        console.log(e.which);
        if (e.which == 90 || e.which == 122){ //letra z -- z buffer//letra W  para malha
            ativarZ = true;
            ativarBF = false;
            gl.disable(gl.CULL_FACE);
            console.log("z buffer "); 
        } 
        if(e.which == 66 || e.which == 98){// tecla B  -- back face culling
            ativarBF = true;
            ativarZ = false;
            gl.disable(gl.DEPTH_TEST);
            console.log("back face ")
        }            
    };*/
    
    //teclas f e w para escolher modo de visualizacao dps de escolher o obejto
    document.body.onkeyup = function(e){
            console.log(e.which);
            if (e.which == 87 || e.which == 119){ //letra W  para malha
                filled = false;
                console.log("malha ");
            } 
            if(e.which == 102 || e.which == 70){// tecla F   para preencher
                filled = true;
                console.log("preenchido");
               
            }            
    };
    //valores a modificar pelo user
    document.getElementById("A").addEventListener("input", function(e){
        A = e.target.value;
        fProjectionAxo();
    });
    
    document.getElementById("B").addEventListener("input", function(e){
        A = e.target.value;
        fProjectionAxo();
    });
    
    document.getElementById("l").addEventListener("input", function(e){
        l = e.target.value;
        fProjectionObliqua();
    });
    document.getElementById("d").addEventListener("input", function(e){
        d = e.target.value;
        fProjectionPerspetive();
    });
    
    //buttons
    document.getElementById("Cube").addEventListener("click", function(e){
        object = "Cube";
    });
    
    document.getElementById("Sphere").addEventListener("click", function(e){
        object = "Sphere";
    });
    
    document.getElementById("Cylinder").addEventListener("click", function(e){
        object = "Cylinder";
    });
    
    document.getElementById("Torus").addEventListener("click", function(e){
        object = "Torus";
    });
    
    document.getElementById("Bunny").addEventListener("click", function(e){
        object = "Bunny";
    });
    document.getElementById("Superquadric").addEventListener("click", function(e){
        object = "Superquadric";
    });
    
    //Projecoes
    //projecao ortogonal
    document.getElementById("AlcadoPrin").addEventListener("click", function(e){
        projectionOrto = "AlcadoPrin";
        fProjectionOrto();
    });
    
    document.getElementById("Planta").addEventListener("click", function(e){
        projectionOrto = "Planta";
        fProjectionOrto();
    });
    
    document.getElementById("LateralD").addEventListener("click", function(e){
        projectionOrto = "LateralD";
        fProjectionOrto();
    
    });
    
    //projecao Axonometrica
    document.getElementById("Isometrica").addEventListener("click", function(e){
        projectionAxo = "Isometrica";
        fProjectionAxo();
             
    });
    
    document.getElementById("Dimetrica").addEventListener("click", function(e){
        projectionAxo = "Dimetrica";
        fProjectionAxo();
           
    });
    
    document.getElementById("Trimetrica").addEventListener("click", function(e){
        projectionAxo = "Trimetrica";
        fProjectionAxo();
          
    });
    
    document.getElementById("AxoLivre").addEventListener("click", function(e){
        projectionAxo = "AxoLivre";
        fProjectionAxo();

         
    });  
    
    //projecao obliqua
    document.getElementById("Cavaleira").addEventListener("click", function(e){
        projetionObli = "Cavaleira";
        fProjectionObliqua();

    });
    
    document.getElementById("Gabinete").addEventListener("click", function(e){
        
        projetionObli = "Gabinete";
        fProjectionObliqua();
          
        
    });
    
    document.getElementById("ObliLivre").addEventListener("click", function(e){
        projetionObli = "ObliLivre";
        fProjectionObliqua();        
    });
    
    //projecao perspetiva
    document.getElementById("PersP").addEventListener("click", function(e){ 
        fProjectionPerspetive();
    });

}

function calculoProjectPerspetive(){
    //projecao perspetiva
  //  console.log("valor do d " + d);
    //(0,0,d)
     mPerspetiva = mat4(1, 0 , 0 , 0,
                    0, 1, 0, 0,
                    0, 0, 0, 0, 
                    0, 0, 1/d, 1); 
  //  console.log("mPerspetiva " + mPerspetiva);
}

function fProjectionPerspetive(){
    calculoProjectPerspetive();
    mModelView = mPerspetiva;
}

function calculoProjectionOrto(){
    switch(projectionOrto){
        case "AlcadoPrin":
            // plano z = 0;
            mOrtogonal = mat4(1, 0 , 0, 0,
                    0, 1, 0, 0,
                    0, 0, 1, 0, 
                    0, 0, 0, 1);        
            break;
        case "Planta":
             // plano z = 0;
            //console.log("rotacao em x " + rotateZ(90));
            mOrtogonal = mult(rotateX(90), mat4(1, 0 , 0, 0,
                    0, 0, -1, 0,
                    0, 0, 1, 0, 
                    0, 0, 0, 1));
            break;
        case "LateralD":
            // plano z = 0;
            //90 porque queremos rodar para a direita
            mOrtogonal = mult(rotateZ(90), mat4(1, 0 , 0, 0,
                    0, 0, -1, 0,
                    0, 0, 1, 0, 
                    0, 0, 0, 1));
            
            break;
    }
}

function fProjectionOrto(){
    calculoProjectionOrto();
    mModelView = mOrtogonal;
 //   console.log("modelView orto " + mModelView);
}

function degrees(radians){
    return radians * 180 /Math.PI;
}

function calculoProjAxo(){
        switch(projectionAxo){
                case "Isometrica":
                
                    A = 30;
                    B = 30;

                    thetaRadians = Math.atan(Math.sqrt(Math.tan(radians(A)) / Math.tan(radians(B)))) - (Math.PI/2);
                        
                    gammaRadians = Math.asin(Math.sqrt(Math.tan(radians(A))*Math.tan(radians(B))));
      
                    //conversao de radianos para graus
                    theta = degrees(thetaRadians);
                    gamma = degrees(gammaRadians); 
                    
                break;
    
                case "Dimetrica":
                    A = 42;
                    B = 7;
                    console.log("entrei dimetrica");
      
                    thetaRadians = Math.atan(Math.sqrt(Math.tan(radians(A)) / Math.tan(radians(B)))) - (Math.PI/2);
        
                    console.log("A: " + A);
                    console.log("B: " + B);
                
                    gammaRadians = Math.asin(Math.sqrt(Math.tan(radians(A))*Math.tan(radians(B))));
                    console.log("gamma radians " + gammaRadians);
                    console.log("theta radians " + thetaRadians);
      
                    //conversao de radianos para graus
                    theta = degrees(thetaRadians);
                    gamma = degrees(gammaRadians); 
                    console.log("gamma graus " + gamma);
                    console.log("theta " + theta);

                    break;
    
                case "Trimetrica":
                    A = 54;
                    B = 23;

                    thetaRadians = Math.atan(Math.sqrt(Math.tan(radians(A)) / Math.tan(radians(B)))) - (Math.PI/2);
                    gammaRadians = Math.asin(Math.sqrt(Math.tan(radians(A))*Math.tan(radians(B))));
                    
                    //conversao de radianos para graus
                    theta = degrees(thetaRadians);
                    gamma = degrees(gammaRadians); 
                    
                    
                    break;

                case "AxoLivre":
                
                    console.log("entrei axoLivre");
      
                    thetaRadians = Math.atan(Math.sqrt(Math.tan(radians(A)) / Math.tan(radians(B)))) - (Math.PI/2);
        
                    console.log("A: " + A);
                    console.log("B: " + B);
                
                    gammaRadians = Math.asin(Math.sqrt(Math.tan(radians(A))*Math.tan(radians(B))));
                    console.log("gamma radians " + gammaRadians);
                    console.log("theta radians " + thetaRadians);
      
                    //conversao de radianos para graus
                    theta = degrees(thetaRadians);
                    gamma = degrees(gammaRadians); 
                    console.log("gamma graus " + gamma);
                    console.log("theta " + theta);
                    
                     
                    break;
        }
}


function fProjectionAxo(){
   // console.log("olaa entrei axo");
    
    calculoProjAxo();
    
    mModelView = mult(rotateX(gamma), rotateY(theta)); 
    
   // console.log("eu sou o gamma " + gamma);
//console.log("eu sou o theta " + theta);
//console.log(mModelView);
}

function calculoProjectionObliqua(){
    switch(projetionObli){
        case "Cavaleira":
            l = 1;
            mObliquo = mat4(1, 0 , -l*Math.cos(radians(alpha)), 0,
                    0, 1, -l*Math.sin(radians(alpha)), 0,
                    0, 0, 0, 0, 
                    0, 0, 0, 1);             
            break;
        case "Gabinete":
            l = 0.5;
            
            mObliquo = mat4(1, 0 , -l*Math.cos(radians(alpha)), 0,
                    0, 1, -l*Math.sin(radians(alpha)), 0,
                    0, 0, 0, 0, 
                    0, 0, 0, 1); 
            
            break;
        case "ObliLivre":
           // console.log("valor de l " + l);
            mObliquo = mat4(1, 0 , -l*Math.cos(radians(alpha)), 0,
                    0, 1, -l*Math.sin(radians(alpha)), 0,
                    0, 0, 0, 0, 
                    0, 0, 0, 1);
            
            break;
    }
    
    
}

function fProjectionObliqua(){
    calculoProjectionObliqua();
    mModelView = mObliquo;
}

//escolha do objeto que inicialmente vai ter a forma de arame
function chooseObject(){
    switch(object){
        case "Cube":
            cubeDraw(gl, program, filled);
          /*  if(ativarZ){
                gl.enable(gl.DEPTH_TEST);
            } if(ativarBF){
                gl.enable(gl.GL_CULL_FACE);
            }*/
            break;
        case "Sphere":
            sphereDraw(gl, program, filled);
            break;
        case "Cylinder":
            cylinderDraw(gl, program, filled);
            break;
        case "Bunny":
            bunnyDraw(gl, program, filled);
            break;
        case "Torus":
            torusDraw(gl, program, filled);
            break;
        case "SuperQuadric":
            break;
    }
}

function render() {
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT );
    
    gl.uniformMatrix4fv(mProjectionLoc, false, flatten(mProjection));
    gl.uniformMatrix4fv(mModelViewLoc, false, flatten(mModelView));
    chooseObject();            
    requestAnimFrame(render);
       
}