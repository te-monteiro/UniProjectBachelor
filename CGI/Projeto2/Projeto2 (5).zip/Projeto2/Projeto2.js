var gl;
var primitives = [];
var mModel_list;


//html
var mModelView;
var mModelViewLoc;
var mProjectionLoc;
var mProjection;

//para a projecao axonometrica

var theta;
var gamma;
var A;
var B;

//para a projecao obliqua
var mObliquo; 
var l;
var alpha = 45;


//para a projecao ortogonal
var mOrtogonal;
var d;

//para a projecao perspetiva
var mPerspetiva;

var tx = 0, ty = 0, tz = 0, rx = 0, ry = 0, rz = 0, sx = 1, sy = 1, sz = 1;
var program;


//dimensoes janela/visor
var width;
var height;


window.onload = function init() {
    var canvas = document.getElementById("gl-canvas");
    gl = WebGLUtils.setupWebGL(canvas);
    if(!gl) { alert("WebGL isn't available"); }
    
    // alteracao das dimensões da janela podem ser acedidas 
   /** window.onresize = function() {    
        height = window.innerHeight;    
        width = window.innerWidth;     
        var s = Math.min(width, height);     
        canvas.width = s;     
        canvas.height = s;    
        gl.viewport(0,0,s,s); 
        }
    if(!gl) { alert("WebGL isn't available");}*/

    cubeInit(gl);
    sphereInit(gl);
    bunnyInit(gl);
    cylinderInit(gl);
    torusInit(gl);
    
    //Necessário para ativação do Z-Buffer (Hidden Surface Removal)
    gl.enable(gl.DEPTH_TEST);
    
    // Configure WebGL  viewport original 
    gl.viewport(0,0,canvas.width, canvas.height);
    gl.clearColor(0.0, 0.0, 0.0, 1.0);
    
    // Load shaders and initialize attribute buffers
    program = initShaders(gl, "vertex-shader", "fragment-shader");
    gl.useProgram(program);
    
    mModel_list = [];
    var eye = [1, 1, 1];
    var at = [0, 0, 0];
    var up = [0, 1, 0];
    
    mModelView = lookAt(eye, at, up);
    mProjection = ortho(-2,2,-2,2,10,-10);
        
    
      
    mModelViewLoc = gl.getUniformLocation(program, "mModelView");
    mProjectionLoc = gl.getUniformLocation(program, "mProjection");
    
   // gl.uniformMatrix4fv(mModelViewLoc, false, flatten(mModelView));
    //gl.uniformMatrix4fv(mProjectionLoc, false, flatten(mProjection));
    
    callback();
    render();
}


function callback(){
    
    
     //translacao
    document.getElementById("tx").addEventListener("input", function(e){
        tx = e.target.value
        ctm_calculate();
    });
    
    document.getElementById("ty").addEventListener("input", function(e){
        ty = e.target.value
        ctm_calculate();
    });
    document.getElementById("tz").addEventListener("input", function(e){
        tz = e.target.value
        ctm_calculate();
    });
    
    //rotacao
    document.getElementById("rx").addEventListener("input", function(e){
        rx = e.target.value
        ctm_calculate();
    });
    document.getElementById("ry").addEventListener("input", function(e){
        ry = e.target.value
        ctm_calculate();
    });
    document.getElementById("rz").addEventListener("input", function(e){
        rz = e.target.value
        ctm_calculate();
    });
    
    //escala
    document.getElementById("sx").addEventListener("input", function(e){
        sx = e.target.value
        ctm_calculate();
    });
    document.getElementById("sy").addEventListener("input", function(e){
        sy = e.target.value
        ctm_calculate();
    });
    document.getElementById("sz").addEventListener("input", function(e){
        sz = e.target.value
        ctm_calculate();
    });
    
    document.getElementById("A").addEventListener("input", function(e){
        A = e.target.value
    });
    
    document.getElementById("B").addEventListener("input", function(e){
        A = e.target.value
    });
    
    document.getElementById("l").addEventListener("input", function(e){
        l = e.target.value
    });
    
    //buttons
    document.getElementById("Save").addEventListener("click", function(e){
        mModel_list.push(mat4());
        reset();
    });
    
    document.getElementById("reset").addEventListener("click", function(e){
        reset();
    });
    
    document.getElementById("Cube").addEventListener("click", function(e){
        push_primitive("Cube");
    });
    
    document.getElementById("Sphere").addEventListener("click", function(e){
        push_primitive("Sphere");
    });
    
    document.getElementById("Cylinder").addEventListener("click", function(e){
        push_primitive("Cylinder");
    });
    
    document.getElementById("Torus").addEventListener("click", function(e){
        push_primitive("Torus");
    });
    
    document.getElementById("Bunny").addEventListener("click", function(e){
        push_primitive("Bunny");
    });
    document.getElementById("Superquadric").addEventListener("click", function(e){
        push_primitive("Superquadric");
    });
    
    //Projecoes
    //ortogonal
    document.getElementById("Frontal").addEventListener("click", function(e){
      // plano z = 0;
        mOrtogonal = mat4(1, 0 , 0, 0,
                    0, 1, 0, 0,
                    0, 0, 0, 0, 
                    0, 0, 0, 1);
        mModelView = mOrtogonal;
    });
    
    document.getElementById("Planta").addEventListener("click", function(e){
      // plano z = 0;
        mOrtogonal = rotateZ(90) * mat4(1, 0 , 0, 0,
                    0, 0, -1, 0,
                    0, 0, 0, 0, 
                    0, 0, 0, 1);
        mModelView = mOrtogonal;

    });
    
    document.getElementById("LateralD").addEventListener("click", function(e){
      // plano z = 0;
        //90 porque queremos rodar para a direita
        mOrtogonal = rotateX(90) * mat4(1, 0 , 0, 0,
                    0, 0, -1, 0,
                    0, 0, 0, 0, 
                    0, 0, 0, 1);
        mModelView = mOrtogonal;

    });
    
    //Axonometrica
    document.getElementById("Isometrica").addEventListener("click", function(e){
        A = 30;
        B = 30;
        
        theta = Math.atan(Math.sqrt(Math.tan(A)/Math.tan(B))) - (Math.PI);
        
        gamma = Math.asin(Math.sqrt(Math.tan(A)*Math.tan(B)));
        
        //conversao de radianos para graus
        var thetaGraus = theta*180/Math.PI;
        var gammaGraus = gamma*180/Math.PI;
        //Max= Mort*Rx(gamma)*Ry(theta)
        mModelView = mult(rotateX(gammaGraus), rotateY(thetaGraus));     
    });
    
    document.getElementById("Dimetrica").addEventListener("click", function(e){
        A = 42;
        B = 7;
        
        theta = Math.atan(Math.sqrt(Math.tan(A)/Math.tan(B))) - (Math.PI);
        
        gamma = Math.asin(Math.sqrt(Math.tan(A)*Math.tan(B)));
        
      
        //conversao de radianos para graus
        var thetaGraus = theta*180/Math.PI;
        var gammaGraus = gamma*180/Math.PI;
        //Max= Mort*Rx(gamma)*Ry(theta)
        mModelView = mult(rotateX(gammaGraus), rotateY(thetaGraus));      
    });
    
    document.getElementById("Trimetrica").addEventListener("click", function(e){
        A = 54;
        B = 23;
        
        theta = Math.atan(Math.sqrt(Math.tan(A)/Math.tan(B))) - (Math.PI);
        
        gamma = Math.asin(Math.sqrt(Math.tan(A)*Math.tan(B)));
        
        //conversao de radianos para graus
        var thetaGraus = theta*180/Math.PI;
        var gammaGraus = gamma*180/Math.PI;
        //Max= Mort*Rx(gamma)*Ry(theta)
        mModelView = mult(rotateX(gammaGraus), rotateY(thetaGraus));      
    });
    
    document.getElementById("AxoLivre").addEventListener("click", function(e){
        
        theta = Math.atan(Math.sqrt(Math.tan(A)/Math.tan(B))) - (Math.PI);
        
        gamma = Math.asin(Math.sqrt(Math.tan(A)*Math.tan(B)));
        
        //conversao de radianos para graus
        var thetaGraus = theta*180/Math.PI;
        var gammaGraus = gamma*180/Math.PI;
        //Max= Mort*Rx(gamma)*Ry(theta)
        mModelView = mult(rotateX(gammaGraus), rotateY(thetaGraus));    
    });
        
    
    //projecao obliqua
    document.getElementById("Cavaleira").addEventListener("click", function(e){
        l = 1;
        
        mObliquo = mat4(1, 0 , -l*Math.cos(alpha), 0,
                    0, 1, -l*Math.sin(alpha), 0,
                    0, 0, 0, 0, 
                    0, 0, 0, 1);   
        
        mModelView = mObliquo;
    });
    
    document.getElementById("Gabinete").addEventListener("click", function(e){
        l = 0.5;
        
        mObliquo = mat4(1, 0 , -l*Math.cos(alpha), 0,
                    0, 1, -l*Math.sin(alpha), 0,
                    0, 0, 0, 0, 
                    0, 0, 0, 1);   
        
        mModelView = mObliquo;
    });
    
    document.getElementById("ObliLivre").addEventListener("click", function(e){
        mObliquo = mat4(1, 0 , -l*Math.cos(alpha), 0,
                    0, 1, -l*Math.sin(alpha), 0,
                    0, 0, 0, 0, 
                    0, 0, 0, 1);   
        
        mModelView = mObliquo;
    });
    
    //projecao perspetiva
    document.getElementById("PersP").addEventListener("click", function(e){
        d = 2; //decidi por dois porque nao sei calcular o d, sei mas preciso do angulo pp
        mPerspetiva = mat4(1, 0 , 0 , 0,
                    0, 1, 0, 0,
                    0, 0, 0, 0, 
                    0, 0, -1/d, 1);   
        
        mModelView = mPerspetiva;
    });

}

 //teclas f e w para escolher modo de visualizacao
function modeVisualization(){
    window.onkeypress = function(e){
        console.log(e.keyCode);
        if (e.keyCode == 87 || e.keyCode == 119){ //letra W ou w --malha
            cubeDrawWireFrame(gl, program);
        } 
        if(e.keyCode == 70 || e.keyCode == 102){// tecla F ou f  para preencher
            cubeDrawFilled(gl, program);
        }            
      };
}


function ctm_calculate(){
    
    var t = translate(tx,ty,tz);
    var rotx = rotateX(rx); 
    var roty = rotateY(ry);
    var rotz = rotateZ(rz);
    var s = scalem(sx, sy,  sz);
        
    mModel_list[mModel_list.length - 1] = mult(t, mult(rotz, mult(roty, mult(rotx, s))));         
}

 function reset(){
       tx = 0, ty = 0, tz = 0;
       rx = 0, ry = 0, rz = 0;    
       sx = 1, sy = 1, sz = 1;
}

function push_primitive(name){
    primitives.push(name);
    mModel_list.push(mat4());
    tx = 0;
    ty = 0;
    tz = 0;
    rx = 0;
    ry = 0;
    rz = 0;
    sx = 1;
    sy = 1;
    sz = 1;
    
    updateSliders();
}

function updateSliders(){
    document.getElementById("tx").value = tx;
    document.getElementById("ty").value = ty;
    document.getElementById("tz").value = tz;
    document.getElementById("rx").value = rx;
    document.getElementById("ry").value = ry;
    document.getElementById("rz").value = rz;
    document.getElementById("sx").value = sx;
    document.getElementById("sy").value = sy;
    document.getElementById("sz").value = sz;
}


function render() {
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT );
    
    //inicialmente
  //  gl.uniformMatrix4fv(mModelViewLoc, false, flatten(mModelView));
   // gl.uniformMatrix4fv(mProjectionLoc, false, flatten(mProjection));
  //  cubeDrawWireFrame(gl, program);
    
    

    if(primitives.length != 0){
        for(i in primitives){
                        
            mModelViewl = mModel_list[i];
            gl.uniformMatrix4fv(mModelViewLoc, false, flatten(mModelView));
            gl.uniformMatrix4fv(mProjectionLoc, false, flatten(mProjection));


            if(primitives[i] == "Cube"){
                cubeDrawWireFrame(gl, program);

               // modeVisualization();
            }/** else if(primitives[i] == "Sphere"){
                modeVisualization();
            }else if(primitives[i] == "Cylinder"){
                modeVisualization();
            }else if(primitives[i] == "Torus"){
                modeVisualization();
            }else if(primitives[i] == "Bunny"){
                modeVisualization();
            }*/
        }
    }
    //mode de visualizacao se e preenchido ou nao
   // modeVisualization();
            
    requestAnimFrame(render);
       
}