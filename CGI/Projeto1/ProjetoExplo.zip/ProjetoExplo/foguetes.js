var gl;
var dragging = false;
var mousedown = false;
var endPos;
var startPos;
var time = 0.0;
var programLine;
var programParticle;
var timePassed;
var pPosition;
var velocity;
var timeLaunched;
var launched;
var lPosition;
var lineBuffer;
var pointBuffer;
var over = 0;
var counter = 0;
var vel;
var explodeVelocity;
var pressed = false;
//var color = [0.0, 0.0, 0.0];


    window.onload = function init() {
    var canvas = document.getElementById("gl-canvas");
    gl = WebGLUtils.setupWebGL(canvas);
    if(!gl) { alert("WebGL isn't available"); }

    gl.viewport(0,0,canvas.width, canvas.height);
    gl.clearColor(0.0, 0.0, 0.0, 1.0);

    programParticle = initShaders(gl, "vertex-shader-particle", "fragment-shader");
    programLine = initShaders(gl, "vertex-shader-line", "fragment-shader");

    timePassed = gl.getUniformLocation(programParticle, "timePassed");
    explodeVelocity = gl.getUniformLocation(programParticle, "explodeVelocity");

    gl.useProgram(programLine);
    lineBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, lineBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, sizeof['vec2']*2, gl.DYNAMIC_DRAW);

    lPosition = gl.getAttribLocation(programLine, "lPosition");
    gl.vertexAttribPointer(lPosition, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(lPosition);

    gl.useProgram(programParticle);
    pointBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, pointBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, (3*sizeof['vec2'] + 4)*65000, gl.DYNAMIC_DRAW);

    pPosition = gl.getAttribLocation(programParticle, "pPosition");
    gl.vertexAttribPointer(pPosition, 2, gl.FLOAT, false, 3*sizeof['vec2']+4, 0);
    gl.enableVertexAttribArray(pPosition);

    velocity = gl.getAttribLocation(programParticle, "velocity");
    gl.vertexAttribPointer(velocity, 2, gl.FLOAT, false, 3*sizeof['vec2']+4, sizeof['vec2']);
    gl.enableVertexAttribArray(velocity);

    explodeVelocity = gl.getAttribLocation(programParticle, "explodeVelocity");
    gl.vertexAttribPointer(explodeVelocity, 2, gl.FLOAT, false, 3*sizeof['vec2']+4, 2*sizeof['vec2']);
    gl.enableVertexAttribArray(explodeVelocity);

    timeLaunched = gl.getAttribLocation(programParticle, "timeLaunched");
    gl.vertexAttribPointer(timeLaunched, 1, gl.FLOAT, false, 3*sizeof['vec2']+4, 3**sizeof['vec2']);
    gl.enableVertexAttribArray(timeLaunched);


  document.body.onkeyup = function(e){
    if(e.keyCode == 32){
     pressed = !pressed;
    }
  }


    canvas.onmousedown = function(e) {
        if(e.which == 1) {
          mousedown = true;
          var draw = getFrameworkCoords(e, canvas);
          startPos = draw;
          changeToLineBuffer();
          gl.bufferSubData(gl.ARRAY_BUFFER, 0, new Float32Array([draw[0], draw[1]]));
        }
    };

    canvas.onmousemove = function(e) {
      if(mousedown){
        over = 1;
        dragging = true;
        changeToLineBuffer();
        var draw = getFrameworkCoords(e, canvas);
        gl.bufferSubData(gl.ARRAY_BUFFER, sizeof['vec2'], new Float32Array([draw[0], draw[1]]));
      }
    };

    canvas.onmouseup = function(e) {
      mousedown = false;
      dragging = false;
      over += 1;
      var draw = getFrameworkCoords(e, canvas);
      endPos = draw;
      changeToLineBuffer();
      gl.bufferSubData(gl.ARRAY_BUFFER, sizeof['vec2'], new Float32Array([draw[0], draw[1]]));
      changetoPointBuffer();
      vel = vec2((endPos[0]-startPos[0])*6, (endPos[1]-startPos[1])*6);
      for(var i = 0; i < 250; i++){
        var angle = 0.02513274 * i;
        gl.bufferSubData(gl.ARRAY_BUFFER, 7000*counter + 28*i, new Float32Array([startPos[0], startPos[1], vel[0], vel[1], (Math.random() * (2.0 + 2.0) -2.0) * Math.cos(angle), (Math.random() * (2.0 + 2.0) -2.0) * Math.sin(angle), time]));
      }
      counter += 1;
    };

    render();
    }

    function getRandomPointLaunched(){
      startPos = vec2(Math.random() * (0.5 + 0.5) - 0.5, Math.random() * (0.5 + 0.5) - 0.5);
      endPos = vec2(Math.random() * (0.5 + 0.5) - 0.5, Math.random() * (0.5 + 0.5) - 0.5);
      vel = vec2((endPos[0]-startPos[0])*6, (endPos[1]-startPos[1])*6);

      changetoPointBuffer();

      for(var i = 0; i < 250; i++){
        var angle = 0.02513274 * i;
        gl.bufferSubData(gl.ARRAY_BUFFER, 7000*counter + 28*i, new Float32Array([startPos[0], startPos[1], vel[0], vel[1], (Math.random() * (2.0 + 2.0) -2.0) * Math.cos(angle), (Math.random() * (2.0 + 2.0) -2.0) * Math.sin(angle), time]));
      }
      over = 2;
      counter++;
    }


  function getFrameworkCoords(event, canvas) {
    return vec2(-1 + 2 * event.offsetX/canvas.width, -1 + 2 * (canvas.height - event.offsetY)/canvas.height);
}

  function getExplodeTime(){
      return vel[1] / 6.0;
    }

  function changetoPointBuffer(){
    gl.useProgram(programParticle);
    gl.bindBuffer(gl.ARRAY_BUFFER, pointBuffer);

    gl.vertexAttribPointer(pPosition, 2, gl.FLOAT, false, (3*sizeof['vec2']+4), 0);
    gl.enableVertexAttribArray(pPosition);

    gl.vertexAttribPointer(velocity, 2, gl.FLOAT, false, (3*sizeof['vec2']+4), sizeof['vec2']);
    gl.enableVertexAttribArray(velocity);

    gl.vertexAttribPointer(explodeVelocity, 2, gl.FLOAT, false, 3*sizeof['vec2']+4, 2*sizeof['vec2']);
    gl.enableVertexAttribArray(explodeVelocity);

    gl.vertexAttribPointer(timeLaunched, 1, gl.FLOAT, false, (3*sizeof['vec2']+4), 3*sizeof['vec2']);
    gl.enableVertexAttribArray(timeLaunched);

  }

  function changeToLineBuffer(){
    gl.useProgram(programLine);
    gl.bindBuffer(gl.ARRAY_BUFFER, lineBuffer);
    gl.vertexAttribPointer(lPosition, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(lPosition);
  }

  function render() {
    gl.clear(gl.COLOR_BUFFER_BIT);
    if(counter == 6499)
    counter = 0;
    time += 0.01;
    changetoPointBuffer();
    gl.uniform1f(timePassed, time);
    var red = Math.random();
    var blue = Math.random();
    var green = Math.random();
    var transp = Math.random();
    var colorData = [red, blue, green, transp];
    if(pressed){
      setInterval(getRandomPointLaunched(), 7000);
    }

    if(mousedown){
      changeToLineBuffer();
      gl.drawArrays(gl.POINTS, 0, 1);
    }
    if(dragging){
      changeToLineBuffer();
      var colorLine = gl.getUniformLocation(programLine, "color");
      gl.uniform4fv(colorLine, colorData);
      gl.drawArrays(gl.LINES, 0, 2);
    }
    if(over == 2 && counter == 0){

      changetoPointBuffer();
      var color = gl.getUniformLocation(programParticle, "color");
      gl.uniform4fv(color, colorData);
      gl.drawArrays(gl.POINTS, 0, 250);

    }
    if(counter > 0){
      changetoPointBuffer();
      var color = gl.getUniformLocation(programParticle, "color");
      gl.uniform4fv(color, colorData);
      gl.drawArrays(gl.POINTS, 0, 250*counter);
    }
    requestAnimFrame(render);
    }
