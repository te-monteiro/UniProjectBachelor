var gl,
    lineProgram,
    pointsProgram,
    time,
    bufferId,
    lineBuffer,
    current = 0,
    offset = 0,
    start = 0,
    startTimeP,
    nVertices = 0,
    vPosition,
    vPosition1,
    vStart,
    vTStart,
    vColor,
    vFrag,
    vFrag2,
    timeLoc,
    vTExplosion,
    vTExplosion2,
    expInterval;
var startPos = (endPos = v0 = vec2(0, 0));
var isDrawing = false,
    autoStatus = false;
var color = [0.0, 0.0, 0.0, 1.0],
    fire = [1.0, 0.498, 0.0, 1.0];
const maxParticles = 65000,
    floatSize = 4,
    stride = 4 * sizeof["vec2"] + 3 * floatSize + sizeof["vec4"];

window.onload = function init() {
    var canvas = document.getElementById("gl-canvas");
    gl = WebGLUtils.setupWebGL(canvas);
    if (!gl) {
        alert("WebGL isn't available");
    }
    gl.blendFuncSeparate(gl.SRC_ALPHA, gl.DST_ALPHA, gl.ONE, gl.ONE);
    gl.enable(gl.BLEND);

    startTimeP = new Date().getTime() / 1000;

    bufferId = gl.createBuffer();
    lineBuffer = gl.createBuffer();

    // Load shaders and initialize attribute buffers
    lineProgram = initShaders(gl, "vertex-shader", "fragment-shader");
    pointsProgram = initShaders(gl, "vertex-shader2", "fragment-shader2");

    // Configure WebGL
    gl.viewport(0, 0, canvas.width, canvas.height);
    //gl.clearColor(0.0, 0.0, 0.0, 1.0);

    vPosition = gl.getAttribLocation(lineProgram, "vPosition");
    vPosition1 = gl.getAttribLocation(pointsProgram, "vPosition1");
    vStart = gl.getAttribLocation(pointsProgram, "vStart");
    vFrag = gl.getAttribLocation(pointsProgram, "vFrag");
    vFrag2 = gl.getAttribLocation(pointsProgram, "vFrag2");
    vTStart = gl.getAttribLocation(pointsProgram, "vTStart");
    vTExplosion = gl.getAttribLocation(pointsProgram, "vTExplosion");
    vTExplosion2 = gl.getAttribLocation(pointsProgram, "vTExplosion2");
    vColor = gl.getAttribLocation(pointsProgram, "vColor");
    timeLoc = gl.getUniformLocation(pointsProgram, "time");

    gl.bindBuffer(gl.ARRAY_BUFFER, bufferId);
    gl.bufferData(gl.ARRAY_BUFFER, stride * maxParticles, gl.STATIC_DRAW);
    gl.bindBuffer(gl.ARRAY_BUFFER, lineBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, 2 * sizeof["vec2"], gl.STATIC_DRAW);

    //document or window
    window.addEventListener("keypress", e => {
        //Space bar e.keyCode == 32
        if (e.key == " ") {
            //Toggle auto-mode
            autoStatus = !autoStatus;
            if (autoStatus) {
                //Timeout
                expInterval = setInterval(() => {
                    //Random pos
                    var startP = vec2(getRandomNumber(-0.95, 0.4), getRandomNumber(-0.95, 0.95));
                    //Random v0
                    var vel = vec2(getRandomNumber(-0.3, 0.3), getRandomNumber(0, 0.8));
                    //Generate explosion
                    explode(startP, vel);
                }, 300);
            } else clearInterval(expInterval);
        }
    });

    canvas.addEventListener("mousedown", function(e) {
        isDrawing = true;
        //segmento de reta de tamanho zero
        startPos = endPos = get_mouse_pos(canvas, e);
        gl.bindBuffer(gl.ARRAY_BUFFER, lineBuffer);
        gl.bufferSubData(gl.ARRAY_BUFFER, 0, flatten([startPos, endPos]));
    });

    canvas.addEventListener("mousemove", function(e) {
        if (!isDrawing) return;
        endPos = get_mouse_pos(canvas, e);
        gl.bindBuffer(gl.ARRAY_BUFFER, lineBuffer);
        gl.bufferSubData(gl.ARRAY_BUFFER, sizeof["vec2"], flatten(endPos));
    });

    canvas.addEventListener("mouseup", function(e) {
        isDrawing = false;
        endPos = get_mouse_pos(canvas, e);
        v0 = vec2(6 * (endPos[0] - startPos[0]), 6 * (endPos[1] - startPos[1]));
        explode(startPos, v0);
    });

    function explode(pos, vel) {
        start = new Date().getTime() / 1000.0 - startTimeP;
        color = [0.0, 0.0, 0.0, 1.0];
        while (equal(color, [0.0, 0.0, 0.0, 1.0]))
            color = flatten([Math.round(Math.random()), Math.round(Math.random()), Math.round(Math.random()), 1.0]);
        generateExplosion1(pos, vel);
    }

    function generateTrail(pos, vel, v1, v2) {
        for (var w = 0; w < 100; w++) {
            if (current == stride * maxParticles) current = 0;
            gl.bindBuffer(gl.ARRAY_BUFFER, bufferId);
            var beginTrail = getRandomNumber(0, vel[1] / 0.5);
            var theta = getRandomNumber(1.22173, 1.919862);
            var radius = Math.random();
            var array = flatten([
                pos[0] + vel[0] * beginTrail,
                pos[1] + vel[1] * beginTrail - (0.5 / 2.0) * beginTrail * beginTrail,
                -vel[0] * Math.cos(theta) * radius,
                -vel[1] * Math.sin(theta) * radius,
                v1[0],
                v1[1],
                v2[0],
                v2[1],
                start,
                vel[1] / 0.5,
                -beginTrail,
                fire[0],
                fire[1],
                fire[2],
                fire[3]
            ]);
            gl.bufferSubData(gl.ARRAY_BUFFER, current, array);
            nVertices++;
            current += stride;
        }
    }

    function generateExplosion1(pos, vel) {
        var nFragmentos = Math.floor(Math.random() * (250 - 10 + 1) + 10);
        for (var i = 0; i < nFragmentos; i++) {
            if (current == stride * maxParticles) current = 0;
            var radius = getRandomNumber(-0.3, 0.3);
            var theta = getRandomNumber(0, 2 * 3.14);
            var v1 = vec2(Math.cos(theta) * radius, Math.sin(theta) * radius);
            if (radius <= -0.2 || radius >= 0.2) {
                color[3] = 0.7;
            }
            radius = getRandomNumber(-0.3, 0.3);
            theta = getRandomNumber(0, 2 * 3.14);
            var v2 = vec2(Math.cos(theta) * radius, Math.sin(theta) * radius);
            gl.bindBuffer(gl.ARRAY_BUFFER, bufferId);
            var array = flatten([
                pos[0],
                pos[1],
                vel[0],
                vel[1],
                v1[0],
                v1[1],
                v2[0],
                v2[1],
                start,
                vel[1] / 0.5,
                100000,
                color[0],
                color[1],
                color[2],
                color[3]
            ]);
            gl.bufferSubData(gl.ARRAY_BUFFER, current, array);
            if (Math.random() > 0.3) {
                generateExplosion2(pos, vel, v1, v2);
            } else {
                nVertices++;
                current += stride;
            }
        }
        if (vel[1] / 0.5 > 0 && Math.random() >= 0.5) generateTrail(pos, vel, v1, v2);
    }

    function generateExplosion2(pos, vel, v1, v2) {
        var nFragmentos1 = Math.floor(getRandomNumber(5, 10));
        for (var j = 0; j < nFragmentos1; j++) {
            if (current == stride * maxParticles) current = 0;
            var radius = getRandomNumber(-0.3, 0.3);
            var theta = getRandomNumber(0, 2 * 3.14);
            v2 = vec2(Math.cos(theta) * radius, Math.sin(theta) * radius);
            gl.bindBuffer(gl.ARRAY_BUFFER, bufferId);
            gl.bufferSubData(gl.ARRAY_BUFFER, current, flatten(pos));
            gl.bufferSubData(gl.ARRAY_BUFFER, current + sizeof["vec2"], flatten(vel));
            gl.bufferSubData(gl.ARRAY_BUFFER, current + 2 * sizeof["vec2"], flatten(v1));
            gl.bufferSubData(gl.ARRAY_BUFFER, current + 3 * sizeof["vec2"], flatten(v2));
            gl.bufferSubData(gl.ARRAY_BUFFER, current + 4 * sizeof["vec2"], flatten([start]));
            gl.bufferSubData(gl.ARRAY_BUFFER, current + 4 * sizeof["vec2"] + floatSize, flatten([vel[1] / 0.5]));
            gl.bufferSubData(gl.ARRAY_BUFFER, current + 4 * sizeof["vec2"] + 2 * floatSize, flatten([vel[1] / 0.5 + 0.4]));
            gl.bufferSubData(gl.ARRAY_BUFFER, current + 4 * sizeof["vec2"] + 3 * floatSize, flatten(color));
            nVertices++;
            current += stride;
        }
    }

    function get_mouse_pos(canvas, e) {
        return vec2(-1 + 2 * (e.offsetX / canvas.width), -1 + (2 * (canvas.height - e.offsetY)) / canvas.height);
    }

    function getRandomNumber(min, max) {
        return Math.random() * (max - min) + min;
    }

    render();
};

function render() {
    gl.clear(gl.COLOR_BUFFER_BIT);

    if (autoStatus) document.getElementById("divMode").innerText = "ON";
    else document.getElementById("divMode").innerText = "OFF";

    time = new Date().getTime() / 1000;
    document.getElementById("divTime").innerText = Math.floor(time - startTimeP);
    gl.useProgram(pointsProgram);
    gl.uniform1f(timeLoc, time - startTimeP);

    if (isDrawing) {
        gl.useProgram(lineProgram);
        gl.bindBuffer(gl.ARRAY_BUFFER, lineBuffer);
        gl.vertexAttribPointer(vPosition, 2, gl.FLOAT, false, 0, 0);
        gl.enableVertexAttribArray(vPosition);
        gl.drawArrays(gl.LINES, 0, 2);
        gl.drawArrays(gl.POINTS, 0, 1);
    }

    gl.useProgram(pointsProgram);

    gl.bindBuffer(gl.ARRAY_BUFFER, bufferId);
    gl.vertexAttribPointer(vPosition1, 2, gl.FLOAT, false, stride, 0);
    gl.enableVertexAttribArray(vPosition1);

    gl.vertexAttribPointer(vStart, 2, gl.FLOAT, false, stride, sizeof["vec2"]);
    gl.enableVertexAttribArray(vStart);

    gl.vertexAttribPointer(vFrag, 2, gl.FLOAT, false, stride, 2 * sizeof["vec2"]);
    gl.enableVertexAttribArray(vFrag);

    gl.vertexAttribPointer(vFrag2, 2, gl.FLOAT, false, stride, 3 * sizeof["vec2"]);
    gl.enableVertexAttribArray(vFrag2);

    gl.vertexAttribPointer(vTStart, 1, gl.FLOAT, false, stride, 4 * sizeof["vec2"]);
    gl.enableVertexAttribArray(vTStart);

    gl.vertexAttribPointer(vTExplosion, 1, gl.FLOAT, false, stride, 4 * sizeof["vec2"] + floatSize);
    gl.enableVertexAttribArray(vTExplosion);

    gl.vertexAttribPointer(vTExplosion2, 1, gl.FLOAT, false, stride, 4 * sizeof["vec2"] + 2 * floatSize);
    gl.enableVertexAttribArray(vTExplosion2);

    gl.vertexAttribPointer(vColor, 4, gl.FLOAT, false, stride, 4 * sizeof["vec2"] + 3 * floatSize);
    gl.enableVertexAttribArray(vColor);

    nVertices = Math.min(nVertices, maxParticles);
    gl.drawArrays(gl.POINTS, 0, nVertices);

    window.requestAnimationFrame(render);
}
