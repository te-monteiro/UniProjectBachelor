var gl;
var numVertices;
var mProjection;
var mNormals;
var mModel;
var mView;
var mModelView;
var mModelViewLoc;
var mProjection;
var mProjectionLoc;
var mNormals;
var mNormalsLoc;

var program;

function get_projection_prespective(angle, ratio, zmin, zmax) {
  var f = 1.0 / Math.tan(angle / 2);
  var rangeInv = 1 / (zmin - zmax);

  return [
    f / ratio, 0, 0, 0,
    0, f, 0, 0,
    0, 0, (zmin + zmax) * rangeInv, -1,
    0, 0, zmin * zmax * rangeInv * 2, 0
  ];
}
window.onload = function init() {
  var canvas = document.getElementById("gl-canvas");
  gl = WebGLUtils.setupWebGL(canvas);
  if (!gl) {
    alert("WebGL isn't available");
  }

  // Configure WebGL
  gl.viewport(0, 0, canvas.width, canvas.height);
  gl.clearColor(0.2, 0.2, 0.2, 1.0);

  //ligar zBuffer
  gl.enable(gl.DEPTH_TEST);

  // Load shaders and initialize attribute buffers
  program = initShaders(gl, "vertex-shader", "fragment-shader");
  gl.useProgram(program);

  mModelViewLoc = gl.getUniformLocation(program, "mModelView");
  mProjectionLoc = gl.getUniformLocation(program, "mProjection");
  mNormalsLoc = gl.getUniformLocation(program, "mNormals");

  // document.getElementById("shapeProjections").onchange = function() {
  //   var index = event.srcElement.value;
  //   if (index == 1.0) { //Alcado Principal
  //     mProjection = ortho(xxxx);
  //     mModelView = mat4();
  //   } else if (index = 2.0) { //Alcado Lateral
  //     mProjection = ortho(xxxx);
  //   } else if (index = 3.0) { //Planta
  //     mProjection = ortho(xxxx);
  //   } else if (index = 4.0) { //Projecao Axonometrica
  //     mProjection = ortho(xxxx);
  //   } else if (index = 5.0) { //Projecao Obliqua
  //     mProjection = ortho(xxx).concat( /*matriz de projeção das teoricas*/ );
  //     mModelView = mat4();
  //   } else { //Projecao Prespetiva
  //     //mProjection = ortho(xxx).concat(/*matriz de projeção das teoricas*/);
  //
  //     mProjection = get_projection_prespective(40, canvas.width / canvas.height, 1, 100);
  //     mModelView = mat4();
  //   }
  //   // if proj obliqua e prespetiva --> mNormals = matriz identidade
  //   //mModelView = //dadas no ennunciado
  //   //se obliqua and prespetiva mProjection= concat (ortho(), matriz proj)
  //   //else mProjection = ortho();
  // };
  //
  //
  // document.getElementById("shapeForms").onchange = function() {
  //   mNormals = transpose(inverse(mModelView));
  //   var index = event.srcElement.value;
  //   if (index == 1.0) {
  //
  //   } else if (index = 2.0) {
  //
  //   } else if (index = 3.0) {
  //
  //   } else if (index = 4.0) {
  //
  //   } else if (index = 5.0) {
  //
  //   } else {
  //
  //   }
  //
  // };

  // mProjection = get_projection_prespective(40, canvas.width / canvas.height, 1, 100);
  var aspect = canvas.width / canvas.height;
  mProjection = perspective(40.0, aspect, 1.0, 100.0);
  //mModelView = mat4();

  var eye = vec3(2.0, 3.0, 5.0);
  var at = vec3(0.0, 0.0, 0.0);
  var up = vec3(0.0, 1.0, 0.0);
  mModelView = lookAt(eye, at, up);

  coneInit(gl);

  render();

  //desligar zBuffer;
  gl.disable(gl.DEPTH_TEST);
}

function render() {
  gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  // gl.drawElements(gl.TRIANGLES, numVertices, gl.UNSIGNED_BYTE, 0);
  gl.uniformMatrix4fv(mModelViewLoc, false, flatten(mModelView));
  gl.uniformMatrix4fv(mProjectionLoc, false, flatten(mProjection));
  // gl.uniformMatrix4fv(mNormalsLoc, false, flatten(mNormals));

  // pyramidDrawFilled(gl, program);
  coneDrawWireFrame(gl, program)

  requestAnimFrame(render);
}
