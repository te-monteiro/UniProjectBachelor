var gl;
var clicked = false;
var lastx, lasty, dx, dy, totalDx, totalDy;

window.onload = function init() {
    var canvas = document.getElementById("gl-canvas");
    gl = WebGLUtils.setupWebGL(canvas);
    if(!gl) { alert("WebGL isn't available"); }
    
    // Three vertices
    var vertices = [
        vec2(-1.0,1.0),
        vec2(-1.0,-1.0),
        vec2(1.0,1.0),
        vec2(1.0,-1.0)
    ];
    
    // Configure WebGL
    gl.viewport(0,0,canvas.width, canvas.height);
    gl.clearColor(1.0, 1.0, 1.0, 1.0);
    
    // Load shaders and initialize attribute buffers
    var program = initShaders(gl, "vertex-shader", "fragment-shader");
    gl.useProgram(program);

    // Load the data into the GPU
    var bufferId = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, bufferId);
    gl.bufferData(gl.ARRAY_BUFFER, flatten(vertices), gl.STATIC_DRAW);

        
     totalDx=0;
     totalDy=0;
    //apanha o evento de mover o rato
    canvas.onmousemove = function(event){
        if(clicked) {
            var desloc = gl.getUniformLocation(program, "fDesloc");  
            
            var x = event.clientX;
            var y = event.clientY;
            dx = x - lastx;
            dy = y - lasty;
            dx=(2*dx/canvas.width);
            dy=(2*dy/canvas.height);
            var t = vec2( dx+ totalDx,dy + totalDy);
            
            gl.uniform2fv(desloc, t);   
        }
        else return;
    }
    
    //apanhar o evento de carregar no botao
    canvas.onmousedown = function(event){
        clicked = true;
        lastx = event.ClientX;
        lasty = event.ClientY;
    }
    
    //apanhar o evento de largar o botao
    canvas.onmouseup = function (event){
        clicked = false;
        totalDx += dx;
        totalDy +=dy;
    }
    
    // Associate our shader variables with our data buffer
    var vPosition = gl.getAttribLocation(program, "vPosition");
    gl.vertexAttribPointer(vPosition, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);
    render();
}

function render() {
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    requestAnimationFrame(render);
}
