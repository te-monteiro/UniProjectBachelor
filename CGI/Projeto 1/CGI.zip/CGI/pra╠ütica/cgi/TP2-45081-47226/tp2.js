var gl;
var canvas;

var ratio;
var indexProj = 1.0;

var mIdentity = mat4(
  1, 0, 0, 0,
  0, 1, 0, 0,
  0, 0, 1, 0,
  0, 0, 0, 1);

var mModelView = mat4();
var mModelViewLoc;

var mProjection = mat4();
var mProjectionLoc;

var mNormals = mat4();
var mNormalsLoc;

var gamma = 19.40;
var theta = -20.30;

var alpha = 45;

var centerZ = 1.0;

var wireFrame = true;
var filled = false;

var shape = 1.0;

var program;

window.onload = function init() {
  canvas = document.getElementById("gl-canvas");
  gl = WebGLUtils.setupWebGL(canvas);
  if (!gl) {
    alert("WebGL isn't available");
  }

  //Init Shapes
  cubeInit(gl);
  pyramidInit(gl);
  sphereInit(gl);
  torusInit(gl);
  cylinderInit(gl);
  coneInit(gl);

  // Configure WebGL
  gl.viewport(0, 0, canvas.width, canvas.height);
  gl.clearColor(0.2, 0.2, 0.2, 1.0);


  // Load shaders and initialize attribute buffers
  program = initShaders(gl, "vertex-shader", "fragment-shader");
  gl.useProgram(program);

  mModelViewLoc = gl.getUniformLocation(program, "mModelView");
  mProjectionLoc = gl.getUniformLocation(program, "mProjection");
  mNormalsLoc = gl.getUniformLocation(program, "mNormals");

  //GAMMA E THETA SLIDERS
  document.getElementById("gamma").onchange = function() {
    gamma = event.srcElement.value;
    ratio = canvas.width / canvas.height;
    if (indexProj == 4.0)
      viewProAx(ratio);
  }
  document.getElementById("theta").onchange = function() {
    theta = event.srcElement.value;
    ratio = canvas.width / canvas.height;
    if (indexProj == 4.0)
      viewProAx(ratio);
  }

  // ALPHA SLIDER
  document.getElementById("alpha").onchange = function() {
    alpha = event.srcElement.value;
    ratio = canvas.width / canvas.height;
    if (indexProj == 5.0)
      viewProObj(ratio);
  }

  //(0,0,CENTRO) SLIDER
  document.getElementById("centerz").onchange = function() {
    centerZ = event.srcElement.value;
    ratio = canvas.width / canvas.height;
    if (indexProj == 6.0)
      viewProPres(ratio);
  }

  function updateSliders() {
    document.getElementById("theta").value = -20.30;
    document.getElementById("gamma").value = 19.40;
    document.getElementById("alpha").value = 45;
    document.getElementById("centerz").value = 1.0;
  }

  //Alcado Principal
  function viewAP(ratio) {
    mProjection = ortho(-((1 + ratio) / 2), ((1 + ratio) / 2), -(((1 + ratio) / ratio) / 2), ((1 + ratio) / ratio) / 2, 1, -1); //mais width q height
    mModelView = mIdentity;
  }

  //Alcado Lateral
  function viewAL(ratio) {
    mProjection = ortho(-((1 + ratio) / 2), ((1 + ratio) / 2), -(((1 + ratio) / ratio) / 2), ((1 + ratio) / ratio) / 2, 1, -1);
    mModelView = rotateY(90);
  }

  //Planta
  function viewP(ratio) {
    mProjection = ortho(-((1 + ratio) / 2), ((1 + ratio) / 2), -(((1 + ratio) / ratio) / 2), ((1 + ratio) / ratio) / 2, 1, -1);
    mModelView = rotateX(90);
  }

  //ProjAxonometrica
  function viewProAx(ratio) {
    mProjection = ortho(-((1 + ratio) / 2), ((1 + ratio) / 2), -(((1 + ratio) / ratio) / 2), ((1 + ratio) / ratio) / 2, 1, -1);
    mModelView = mult(rotateX(gamma), rotateY(theta));
  }

  //ProjObliqua
  function viewProObj(ratio) {
    var projectOBL = mat4(
      1.0, 0.0, -1 * Math.cos(alpha), 0.0,
      0.0, 1.0, -1 * Math.sin(alpha), 0.0,
      0.0, 0.0, 1.0, 0.0,
      0.0, 0.0, 0.0, 1.0
    );
    mProjection = mult(ortho(-((1 + ratio) / 2), ((1 + ratio) / 2), -(((1 + ratio) / ratio) / 2), ((1 + ratio) / ratio) / 2, 1, -1), projectOBL);
    mModelView = mIdentity;
  }

  //ProjPresp
  function viewProPres(ratio) {
    var projectPRES = mat4(
      1.0, 0.0, 0.0, 0.0,
      0.0, 1.0, 0.0, 0.0,
      0.0, 0.0, 1.0, 0.0,
      0.0, 0.0, -1.0 / centerZ, 1.0
    );
    mProjection = mult(projectPRES, ortho(-((1 + ratio) / 2), ((1 + ratio) / 2), -(((1 + ratio) / ratio) / 2), ((1 + ratio) / ratio) / 2, 1, -1));
    mModelView = mIdentity;
  }

  projections = function() {
    ratio = canvas.width / canvas.height;
    if (indexProj == 1.0) {
      viewAP(ratio);
    } else if (indexProj == 2.0) {
      viewAL(ratio);
    } else if (indexProj == 3.0) {
      viewP(ratio);
    } else if (indexProj == 4.0) {
      viewProAx(ratio);
    } else if (indexProj == 5.0) {
      viewProObj(ratio);
    } else {
      viewProPres(ratio);
    }
    mNormals = transpose(inverse(mModelView));
    updateSliders();
  }

  //PROJECOES
  document.getElementById("shapeProjections").onchange = function() {
    indexProj = event.srcElement.value;
    projections();
  };


  //FORMAS
  document.getElementById("shapeForms").onchange = function() {
    var index = event.srcElement.value;
    shape = index;
  };

  //WIREDFILLED
  document.getElementById("wiredfiled").onchange = function() {
    var index = event.srcElement.value;
    if (index == 1.0) {
      wireFrame = true;
      filled = false;
    } else if (index == 2.0) {
      wireFrame = false;
      filled = true;
    } else {
      wireFrame = false;
      filled = false;
    }
  };

  //DRAWSHAPES
  drawShape = function() {
    if (wireFrame) {
      if (shape == 1.0) {
        cubeDrawWireFrame(gl, program);
      } else if (shape == 2.0) {
        pyramidDrawWireFrame(gl, program);
      } else if (shape == 3.0) {
        sphereDrawWireFrame(gl, program);
      } else if (shape == 4.0) {
        torusDrawWireFrame(gl, program);
      } else if (shape == 5.0) {
        cylinderDrawWireFrame(gl, program);
      } else {
        coneDrawWireFrame(gl, program);
      }
    }
    if (filled) {
      if (shape == 1.0) {
        cubeDrawFilled(gl, program);
      } else if (shape == 2.0) {
        pyramidDrawFilled(gl, program);
      } else if (shape == 3.0) {
        sphereDrawFilled(gl, program);
      } else if (shape == 4.0) {
        torusDrawFilled(gl, program);
      } else if (shape == 5.0) {
        cylinderDrawFilled(gl, program);
      } else {
        coneDrawFilled(gl, program);
      }
    }
  }

  render();
}

window.onresize = function() {
  var windowx = window.innerWidth;
  var windowy = window.innerHeight;
  canvas.width = (2 * windowx) / 3;
  canvas.height = (2 * windowy) / 3;
  projections();

  gl.viewport(0, 0, canvas.width, canvas.height);
}

function render() {

  zbufferButton.onchange = function() {
    if (zbufferButton.checked) {
      gl.enable(gl.DEPTH_TEST);
      gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    } else {
      gl.disable(gl.DEPTH_TEST);
    }
  }
  cullingButton.onchange = function() {
    if (cullingButton.checked) {
      gl.enable(gl.CULL_FACE);
    } else {
      gl.disable(gl.CULL_FACE);
    }
  }

  gl.uniformMatrix4fv(mModelViewLoc, false, flatten(mModelView));
  gl.uniformMatrix4fv(mProjectionLoc, false, flatten(mProjection));
  gl.uniformMatrix4fv(mNormalsLoc, false, flatten(mNormals));
  drawShape();

  requestAnimFrame(render);
}