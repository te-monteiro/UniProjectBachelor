var gl;
var preview;
var counter = 0;
var time = 0;
var theta = 0.0;
var timeLoc;
var variation = 0.0;
var variationLoc;
var color;
var red = 255;
var green = 0;
var blue = 0;
var alpha = 1.0;
var index = 1.0;
var clicked = false;

window.onload = function init() {
    var canvas = document.getElementById("gl-canvas");
    gl = WebGLUtils.setupWebGL(canvas);
    if (!gl) { alert("WebGL isn't available"); }
   
    // Configure WebGL
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.clearColor(0.2, 0.2, 0.2, 1.0);
    
    var previewColor = document.getElementById("choice");
    var preview = previewColor.getContext("2d");
    
    // Load shaders and initialize attribute buffers
    var program = initShaders(gl, "vertex-shader", "fragment-shader");
    gl.useProgram(program);

    timeLoc = gl.getUniformLocation(program, "time");
    
    variationLoc = gl.getUniformLocation(program, "variation");
   
    function showColor() {
        preview.fillStyle = 'rgba(' + Math.round(red).toString() + ',' + Math.round(green).toString() + ',' + Math.round(blue).toString() + ',' +((Math.round(alpha))*255.0).toString() + ')';
        preview.fillRect(0,0, 100, 30);
    }
    
    document.getElementById("slideRed").onchange = function () {
        red = event.srcElement.value;
        showColor();
    };  
    document.getElementById("slideGreen").onchange = function () {  
        green = event.srcElement.value; 
         showColor();
    };  
    document.getElementById("slideBlue").onchange = function () {  
        blue = event.srcElement.value;   
        showColor();
    }; 
    document.getElementById("slideAlpha").onchange = function () {  
        alpha = event.srcElement.value; 
         showColor();
    }; 
    
    document.getElementById("shapeIndex").onchange = function() {  
        index= event.srcElement.value;
    }; 

    // Load the data into the GPU
    var vertex_indexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vertex_indexBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, 200*4, gl.STATIC_DRAW);
    
    var vertex_posBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vertex_posBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, 200*4*2, gl.STATIC_DRAW);

    var vertex_sizeBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vertex_sizeBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, 200*4, gl.STATIC_DRAW);

    var vertex_colorBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vertex_colorBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, 200*4*4, gl.STATIC_DRAW);

    var vertex_thetaBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vertex_thetaBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, 200*4, gl.STATIC_DRAW);

    function updateShapes(){
        var pos = vec2((Math.random() * 2.0) - 1.0 ,(Math.random() * 2.0) - 1.0);
        var size =(Math.random() * 60) + 5;
            var theta = Math.random()*3;
        //POSIÇÃO
         gl.bindBuffer(gl.ARRAY_BUFFER, vertex_posBuffer);
          gl.bufferSubData(gl.ARRAY_BUFFER, counter*4*2, flatten(pos));
        //FORMA
        gl.bindBuffer(gl.ARRAY_BUFFER, vertex_indexBuffer);
          gl.bufferSubData(gl.ARRAY_BUFFER, counter*4, flatten([index]));
        //TAMANHO
          gl.bindBuffer(gl.ARRAY_BUFFER, vertex_sizeBuffer);
          gl.bufferSubData(gl.ARRAY_BUFFER, counter*4, flatten([size]));
        //COR
          gl.bindBuffer(gl.ARRAY_BUFFER, vertex_colorBuffer);
          gl.bufferSubData(gl.ARRAY_BUFFER, counter*4*4, flatten([red/255, green/255,blue/255,alpha]));
        //ANGULO
          gl.bindBuffer(gl.ARRAY_BUFFER, vertex_thetaBuffer);
          gl.bufferSubData(gl.ARRAY_BUFFER, counter*4, flatten([theta]));
          counter++;
    }
    
    runAutoMode = function(){
        clicked = true;
        auto = setInterval(updateShapes, 500);
    }
    
    stopAutoMode = function(){
        clicked = false;
        clearInterval(auto);
    }
    
    canvas.onmousedown = function(event){
        var pos= vec2(-1 + 2*event.offsetX/canvas.width,
          -1 + 2*(canvas.height-event.offsetY)/canvas.height);
          var size =(Math.random() * 60) + 5;
          var theta = Math.random()*3;
        //POSIÇÃO
         gl.bindBuffer(gl.ARRAY_BUFFER, vertex_posBuffer);
          gl.bufferSubData(gl.ARRAY_BUFFER, counter*4*2, flatten(pos));
        //FORMA
        gl.bindBuffer(gl.ARRAY_BUFFER, vertex_indexBuffer);
          gl.bufferSubData(gl.ARRAY_BUFFER, counter*4, flatten([index]));
        //TAMANHO
          gl.bindBuffer(gl.ARRAY_BUFFER, vertex_sizeBuffer);
          gl.bufferSubData(gl.ARRAY_BUFFER, counter*4, flatten([size]));
        //COR
          gl.bindBuffer(gl.ARRAY_BUFFER, vertex_colorBuffer);
          gl.bufferSubData(gl.ARRAY_BUFFER, counter*4*4, flatten([red/255, green/255,blue/255,alpha]));
        //ANGULO
          gl.bindBuffer(gl.ARRAY_BUFFER, vertex_thetaBuffer);
          gl.bufferSubData(gl.ARRAY_BUFFER, counter*4, flatten([theta]));
          counter++;
    }
    
    //FORMA
    gl.bindBuffer(gl.ARRAY_BUFFER,vertex_indexBuffer);
    var vIndex = gl.getAttribLocation(program, "vIndex");
    gl.vertexAttribPointer(vIndex, 1, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vIndex);

    gl.bindBuffer(gl.ARRAY_BUFFER, vertex_posBuffer);
    var vPosition = gl.getAttribLocation(program, "vPosition");
    gl.vertexAttribPointer(vPosition, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);

    gl.bindBuffer(gl.ARRAY_BUFFER, vertex_sizeBuffer);
    var vSize = gl.getAttribLocation(program, "vSize");
    gl.vertexAttribPointer(vSize, 1, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vSize);

    gl.bindBuffer(gl.ARRAY_BUFFER, vertex_colorBuffer);
    var vColor = gl.getAttribLocation(program, "vColor");
    gl.vertexAttribPointer(vColor, 4, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vColor);

    gl.bindBuffer(gl.ARRAY_BUFFER, vertex_thetaBuffer);
    var vTheta = gl.getAttribLocation(program, "vTheta");
    gl.vertexAttribPointer(vTheta, 1, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vTheta);

    render();
  }

function render() {
    gl.clear(gl.COLOR_BUFFER_BIT);
    time += 0.05
    gl.uniform1f(timeLoc, time);
    variation += 0.03;
    gl.uniform1f(variationLoc, variation);
    gl.drawArrays(gl.POINTS, 0, counter);
    requestAnimFrame(render);
}
