var gl;

window.onload = function init() {
    var canvas = document.getElementById("gl-canvas");
    gl = WebGLUtils.setupWebGL(canvas);
    if(!gl) { alert("WebGL isn't available"); }
    
    // Three vertices
    var vertices = [
        vec2(-0.5,-0.5),
        vec2(0.5,-0.5),
        vec2(0,0.5)
    ];
    
     var colors = [
        vec4( 1, 0, 0, 1),
        vec4( 0, 1, 0, 1),
        vec4( 0, 0, 1, 1)
    ];
    
    // Configure WebGL
    gl.viewport(0,0,canvas.width, canvas.height);
    gl.clearColor(1.0, 1.0, 1.0, 1.0);
    
    // Load shaders and initialize attribute buffers
    var program = initShaders(gl, "vertex-shader", "fragment-shader");
    gl.useProgram(program);

    // Load the data into the GPU
    var bufferId = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, bufferId);
    //3 vertices, 6 compomentes (2 posições + 4 coisinhas das cores) e o 4 que é o temanho dos floats
    gl.bufferData(gl.ARRAY_BUFFER, 3*6*4, gl.STATIC_DRAW);
    //0 é o offset
    gl.bufferSubData(gl.ARRAY_BUFFER, 0, flatten(vertices));
    gl.bufferSubData(gl.ARRAY_BUFFER, 3*2*4, flatten(colors));

    // Associate our shader variables with our data buffer
    var vPosition = gl.getAttribLocation(program, "vPosition");
    gl.vertexAttribPointer(vPosition, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);
    
    //já metemos 3 vertices, cada um a ocupar 2 posiçoes e são floats, portanto o ofset será 3*2*4
 
    
    var vcolor = gl.getAttribLocation(program, "vcolor");
    gl.vertexAttribPointer(vcolor, 4, gl.FLOAT, false, 0, 3*2*4);
    gl.enableVertexAttribArray(vcolor);
    
    render();
}

function render() {
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
}
