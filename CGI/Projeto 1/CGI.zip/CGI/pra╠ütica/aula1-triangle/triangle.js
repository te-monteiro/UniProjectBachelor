var gl;

//inicialização do programa
window.onload = function init() {
    
     //vai-se buscar a canvas criada antes no html
    var canvas = document.getElementById("gl-canvas");
    //inicializa o webgl de forma que o output gráfico seja dirigido para a área ocupada pelo canvas
    gl = WebGLUtils.setupWebGL(canvas);
    //verifica-se se ocorre ou não algum erro
    if(!gl) { alert("WebGL isn't available"); }
    
    // os 3 vértices do triângulo
    var vertices = [
        vec2(-0.5,-0.5),
        vec2(0.5,-0.5),
        vec2(0,0.5)
    ];
    
    // define a zona retangular onde o output gráfico será mostrado (pode usar-se só uma parte do canvas)
    gl.viewport(0,0,canvas.width, canvas.height);
    //limpa o canvas
    gl.clearColor(1.0, 1.0, 1.0, 1.0);
    
    // Load shaders and initialize attribute buffers
    //vertex shadeer - responsável por processar cada vértice das primitivas gráficas que forem usadas
    //fragment shader - invocado para estabelecer a cor de cada pixel a ser desenhado no ecrã
    //vertex shader é chamado para processar cada um dos vértices do triângulo
    //fragment shader é invocado para cada pixel do interior
    //initShaders devolve o programa GLSL formado pelos dois shaders
    var program = initShaders(gl, "vertex-shader", "fragment-shader");
    gl.useProgram(program);

    // Load the data into the GPU
    //trata de enviar as coordenadas dos vértices do triângulo para a memória do processador gráfico
    //criação de um buffer no GPU, ativação do mesmo e o seu preenchimento com dados
    var bufferId = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, bufferId);
    gl.bufferData(gl.ARRAY_BUFFER, flatten(vertices), gl.STATIC_DRAW);

    // Associate our shader variables with our data buffer
    //ligar os dados às variáveis referidas no programa GLSL (em todos os shaders)
    var vPosition = gl.getAttribLocation(program, "vPosition");
    gl.vertexAttribPointer(vPosition, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);
    render();
};

function render() {
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
}
