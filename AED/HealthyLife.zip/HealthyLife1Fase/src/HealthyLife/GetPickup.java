package HealthyLife;

import java.io.Serializable;

/**
 * 
 * @author Teresa Falcao de Campos Monteiro (52597)
 *         tfd.monteiro@campus.fct.unl.pt
 * @author Ana Filipa Santos Pereira Fernandes da Silva (52787)
 *         afsp.silva@campus.fct.unl.pt
 * 
 *
 */

public interface GetPickup extends Serializable {

	/**
	 * Method that gets the duration of the pickup
	 * 
	 * @return - int: duration of the pickups
	 */

	int getMinutes();

	/**
	 * Method that gets the delay of the pickup
	 * 
	 * @return - int: delay of the pickup
	 */

	int getDelay();

	/**
	 * Method that gets the value that the user needs to pay According to the number
	 * of delay
	 * 
	 * @return - int: value that has to be paid
	 */

	int getValue();

	/**
	 * Method that gets the id of the final park
	 * 
	 * @return - String: id of the final park
	 */
	String getFinalIdPark();

	/**
	 * Method that gets the id of the user
	 * 
	 * @return - String: id of the user
	 */
	String getIdUser();

	/**
	 * Method that gets the id of the initial park
	 * 
	 * @return - String: id of the initial park
	 */
	String getInitialIdPark();

	/**
	 * Method that gets the id of the bike
	 * 
	 * @return - String: id of the bike
	 */
	String getIdBike();

	/**
	 * Method that returns the user of the pickup
	 * @return - GetUser
	 */
	GetUser getUser();
      
	
}
