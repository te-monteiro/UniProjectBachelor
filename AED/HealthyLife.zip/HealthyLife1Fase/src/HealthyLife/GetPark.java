package HealthyLife;

import java.io.Serializable;

/**
 * 
 * @author Teresa Falcao de Campos Monteiro (52597)
 *         tfd.monteiro@campus.fct.unl.pt
 * @author Ana Filipa Santos Pereira Fernandes da Silva (52787)
 *         afsp.silva@campus.fct.unl.pt
 * 
 *
 */

public interface GetPark extends Serializable {

	/**
	 * Method that returns the id of the park
	 * 
	 * @return - String: id of the park
	 */
	String getIdPark();

	/**
	 * Method that returns the name of the park
	 * 
	 * @return - String: name of the park
	 */
	String getName();

	/**
	 * Method that returns the address of the park
	 * 
	 * @return - String: address of the park
	 */
	String getAddress();

	/**
	 * Method that returns how many bikes are in the park
	 * 
	 * @return - int: number of bikes in the park
	 */
	int getBikeNumber();

	/**
	 * Method that returns how many pickups were done at the park
	 * 
	 * @return - int : number of pickups that were done at the park
	 */
	int getNumPickup();

}
