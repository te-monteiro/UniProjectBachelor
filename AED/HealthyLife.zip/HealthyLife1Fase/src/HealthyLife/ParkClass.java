package HealthyLife;

/**
 * 
 * @author Teresa Falcao de Campos Monteiro (52597)
 *         tfd.monteiro@campus.fct.unl.pt
 * @author Ana Filipa Santos Pereira Fernandes da Silva (52787)
 *         afsp.silva@campus.fct.unl.pt
 * 
 *
 */

class ParkClass implements SetPark {

	private static final int ZERO = 0;

	private static final long serialVersionUID = 1L;

	private String idPark, name, address;

	private GetBike bike;
	private int numPickup;

	public ParkClass(String idPark, String name, String address) {
		this.idPark = idPark;
		this.name = name;
		this.address = address;
		numPickup = ZERO;
		bike = null;
	}

	@Override
	public String getIdPark() {
		return idPark;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public String getAddress() {
		return address;
	}

	@Override
	public int getBikeNumber() {
		if (bike == null)
			return 0;
		return 1;
	}

	@Override
	public void addBike(SetBike bike) {
		this.bike = bike;
	}

	@Override
	public void removeBike() {
		bike = null;

	}

	@Override
	public int getNumPickup() {
		return numPickup;
	}

	@Override
	public void pickupChanges() {
		bike = null;
		numPickup++;

	}

}
