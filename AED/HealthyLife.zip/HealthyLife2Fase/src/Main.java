
import java.util.Scanner;

import java.io.*;
import dataStructures.*;

import HealthyLife.Exceptions.*;
import HealthyLife.GetPark;
import HealthyLife.GetPickup;
import HealthyLife.GetUser;
import HealthyLife.HealthyLife;
import HealthyLife.HealthyLifeClass;

/**
 * 
 * @author Teresa Falcao de Campos Monteiro (52597)
 *         tfd.monteiro@campus.fct.unl.pt
 * @author Ana Filipa Santos Pereira Fernandes da Silva (52787)
 *         afsp.silva@campus.fct.unl.pt
 * 
 *
 */

public class Main {

	private static final String GETUSERINFO_FORMAT = "%s: %s, %s, %s, %s, %d, %d\n";
	private static final String PICKDOWN_FORMAT = "Pickdown com sucesso: %s euros, %s pontos\n";
	private static final String CHARGE_USER_FORMAT = "Saldo: %d euros\n";
	private static final String USER_PICKUP_FORMAT = "%s %s %s %d %d %d\n";
	private static final String FAVORITE_PARK_FORMAT = "%s: %s, %d\n";
	private static final String FAVORITEPARKS = "FAVORITEPARKS";
	private static final String LISTDELAYED = "LISTDELAYED";
	private static final String PARKEDBIKE = "PARKEDBIKE";
	private static final String USERPICKUPS = "USERPICKUPS";
	private static final String BIKEPICKUPS = "BIKEPICKUPS";
	private static final String GETPARKINFO = "GETPARKINFO";
	private static final String REMOVEBIKE = "REMOVEBIKE";
	private static final String PICKDOWN = "PICKDOWN";
	private static final String PICKUP = "PICKUP";
	private static final String CHARGEUSER = "CHARGEUSER";
	private static final String ADDBIKE = "ADDBIKE";
	private static final String ADDPARK = "ADDPARK";
	private static final String GETUSERINFO = "GETUSERINFO";
	private static final String REMOVEUSER = "REMOVEUSER";
	private static final String ADDUSER = "ADDUSER";
	private static final String DESCONHECIDO = "DESCONHECIDO";
	private static final String FILE_DAT = "file.dat7";
	/**
	 * Pickups Messages
	 */
	private static final String SUCCESSED_PICKUP = "PickUp com sucesso.";
	private static final String NO_PICKUPS_DONE = "Nao foram efetuados pickups.";

	/**
	 * Money Messages
	 */
	private static final String NO_MONEY = "Saldo insuficiente.";

	/**
	 * Data Messages
	 */
	private static final String INVALID_DATA = "Dados invalidos.";

	/**
	 * Delays Message
	 */
	private static final String NO_DELAYS = "Nao se registaram atrasos.";

	/**
	 * Bike Messages
	 */
	private static final String BIKE_IS_NOT_PARKED = "Bicicleta nao esta em parque.";
	private static final String MOVING_BIKE = "Bicicleta em movimento.";
	private static final String BIKE_IS_PARKED = "Bicicleta estacionada no parque.";
	private static final String BIKE_NOT_USED = "Bicicleta nao foi utilizada.";
	private static final String FIRST_PICKUP_MOVING = "Bicicleta em movimento em primeiro pickup.";
	private static final String STOP_BIKE = "Bicicleta parada.";
	private static final String BIKE_NO_EXISTS = "Bicicleta inexistente.";
	private static final String BIKE_WITH_PICKUPS = "Bicicleta ja foi utilizada.";
	private static final String BIKE_REMOVED_WITH_SUCESS = "Bicicleta removida com sucesso.";
	private static final String BIKE_ADDS_WITH_SUCESS = "Bicicleta adicionada com sucesso.";
	private static final String EXISTS_BIKE = "Bicicleta existente.";

	/**
	 * User Messages
	 */
	private static final String MOVING_USER = "Utilizador em movimento.";
	private static final String USER_DID_NOT_USED_SYSTEM = "Utilizador nao utilizou o sistema.";
	private static final String FIRST_PICKUP = "Utilizador em primeiro PickUp.";
	private static final String USER_REMOVE_WITH_SUCCESS = "Utilizador removido com sucesso.";
	private static final String USER_USED_ALREADY_SYSTEM = "Utilizador ja utilizou o sistema.";
	private static final String USER_INSERT_WITH_SUCCESS = "Insercao de utilizador com sucesso.";
	private static final String USER_NO_EXISTS = "Utilizador inexistente.";
	private static final String EXISTS_USER = "Utilizador existente.";

	/**
	 * Park Messages
	 */
	private static final String PARK_NO_EXISTS = "Parque inexistente.";
	private static final String PARK_ADDS_WITH_SUCESS = "Parque adicionado com sucesso.";
	private static final String EXISTS_PARK = "Parque existente.";

	/**
	 * System Messages
	 */
	private static final String SAVED_FINISHED = "Gravando e terminando...\n";
	private static final String XS = "XS";

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);

		HealthyLife h = load();

		String comm = getCommand(in);

		while (!comm.equals(XS)) {
			switch (comm) {
			case ADDUSER:
				addUser(in, h);
				break;
			case REMOVEUSER:
				removeUser(in, h);
				break;
			case GETUSERINFO:
				getUserInfo(in, h);
				break;
			case ADDPARK:
				addPark(in, h);
				break;
			case ADDBIKE:
				addBike(in, h);
				break;
			case CHARGEUSER:
				chargeUser(in, h);
				break;
			case PICKUP:
				pickUp(in, h);
				break;
			case PICKDOWN:
				pickDown(in, h);
				break;
			case REMOVEBIKE:
				removeBike(in, h);
				break;
			case GETPARKINFO:
				getParkInfo(in, h);
				break;
			case BIKEPICKUPS:
				bikePickUps(in, h);
				break;
			case USERPICKUPS:
				userPickUps(in, h);
				break;
			case PARKEDBIKE:
				parkedBike(in, h);
				break;
			case LISTDELAYED:
				listDelayed(h);
				break;
			case FAVORITEPARKS:
				favoriteParks(h);
				break;
			default:
				System.out.println(DESCONHECIDO);
			}
			System.out.println();
			comm = getCommand(in);
		}
		save(h);
		System.out.println(SAVED_FINISHED);
		in.close();

	}

	private static void save(HealthyLife h) {
		try {
			ObjectOutputStream file = new ObjectOutputStream(new FileOutputStream(FILE_DAT));
			file.writeObject(h);
			file.flush();
			file.close();
		} catch (IOException e) {
		}
	}

	private static HealthyLife load() {
		HealthyLife h = null;

		try {
			ObjectInputStream file = new ObjectInputStream(new FileInputStream(FILE_DAT));
			h = (HealthyLife) file.readObject();
			file.close();
		} catch (IOException e) {
			h = new HealthyLifeClass();
		} catch (ClassNotFoundException e) {
			h = new HealthyLifeClass();
		}

		return h;
	}

	/**
	 * Method that lists all the favorite parks
	 * 
	 * @param h
	 */
	private static void favoriteParks(HealthyLife h) throws NoParkException, NoPickupsException {

		try {
			GetPark p = h.getParkIfHasPickups();
			System.out.printf(FAVORITE_PARK_FORMAT, p.getName(), p.getAddress(), p.getNumPickup());
		}

		catch (NoPickupsException e) {

			System.out.println(NO_PICKUPS_DONE);
		}

	}

	/**
	 * Method that lists all the delays. In this case, only a println is done, this
	 * because there are no delays in this particular phase of the project
	 * 
	 * @param h
	 */
	private static void listDelayed(HealthyLife h) {
		System.out.println(NO_DELAYS);

	}

	/**
	 * Method that indicates if a particular bike is parked at a particular park
	 * 
	 * @param in
	 * @param h
	 */
	private static void parkedBike(Scanner in, HealthyLife h)
			throws NoBikeException, NoParkException, BikeIsNotAtParkException {

		String idBike = in.next();
		String idPark = in.nextLine().trim();

		try {
			h.parkedBike(idBike, idPark);
			System.out.println(BIKE_IS_PARKED);
		}

		catch (NoBikeException e) {
			System.out.println(BIKE_NO_EXISTS);
		}

		catch (NoParkException e) {
			System.out.println(PARK_NO_EXISTS);
		}

		catch (BikeIsNotAtParkException e) {
			System.out.println(BIKE_IS_NOT_PARKED);
		}
	}

	/**
	 * Method that lists all the pickups done by an user
	 * 
	 * @param in
	 * @param h
	 */

	private static void userPickUps(Scanner in, HealthyLife h)
			throws NoUserException, NoPickupsException, FirstPickupStillMovingException {

		String idUser = in.nextLine().trim();

		try {
			Iterator<GetPickup> it = h.getUserPickupsIterator(idUser);
			while (it.hasNext()) {
				GetPickup p = it.next();
				System.out.printf(USER_PICKUP_FORMAT, p.getIdBike(), p.getInitialIdPark(), p.getFinalIdPark(),
						p.getMinutes(), p.getDelay(), p.getValue());
			}
		}

		catch (NoUserException e) {
			System.out.println(USER_NO_EXISTS);
		}

		catch (NoPickupsException e) {
			System.out.println(USER_DID_NOT_USED_SYSTEM);
		} catch (FirstPickupStillMovingException e) {
			System.out.println(FIRST_PICKUP);
		}

	}

	/**
	 * Method that lists all the pickups done by a particular bike
	 * 
	 * @param in
	 * @param h
	 */

	private static void bikePickUps(Scanner in, HealthyLife h)
			throws NoBikeException, NoPickupsException, FirstPickupStillMovingException {

		String idBike = in.nextLine().trim();

		try {
			Iterator<GetPickup> it = h.getBikePickupsIterator(idBike);
			while (it.hasNext()) {
				GetPickup p = it.next();
				System.out.printf(USER_PICKUP_FORMAT, p.getIdUser(), p.getInitialIdPark(), p.getFinalIdPark(),
						p.getMinutes(), p.getDelay(), p.getValue());
			}
		}

		catch (NoBikeException e) {
			System.out.println(BIKE_NO_EXISTS);
		}

		catch (NoPickupsException e) {
			System.out.println(BIKE_NOT_USED);
		} catch (FirstPickupStillMovingException e) {
			System.out.println(FIRST_PICKUP_MOVING);
		}

	}

	/**
	 * Method that gets the information of a park
	 * 
	 * @param in
	 * @param h
	 */
	private static void getParkInfo(Scanner in, HealthyLife h) throws NoParkException {
		String idPark = in.nextLine().trim();
		try {
			GetPark park = h.getPark(idPark);
			System.out.printf(FAVORITE_PARK_FORMAT, park.getName(), park.getAddress(), park.getBikeNumber());

		} catch (NoParkException e) {
			System.out.println(PARK_NO_EXISTS);
		}
	}

	/**
	 * Method that removes a bike
	 * 
	 * @param in
	 * @param h
	 */
	private static void removeBike(Scanner in, HealthyLife h) throws PickupsAlreadyDoneException, NoBikeException {
		String idBike = in.nextLine().trim();
		try {
			h.removeBike(idBike);
			System.out.println(BIKE_REMOVED_WITH_SUCESS);
		} catch (PickupsAlreadyDoneException e) {
			System.out.println(BIKE_WITH_PICKUPS);
		} catch (NoBikeException e) {
			System.out.println(BIKE_NO_EXISTS);
		}

	}

	/**
	 * Method that updates the balance of the user
	 * 
	 * @param in
	 * @param h
	 */
	private static void chargeUser(Scanner in, HealthyLife h) throws NoUserException, NegativeValueException {
		String idUser = in.next();
		int value = in.nextInt();
		in.nextLine();
		try {
			h.chargeUser(idUser, value);
			GetUser user = h.getUser(idUser);
			System.out.printf(CHARGE_USER_FORMAT, user.getBalance());
		} catch (NoUserException e) {
			System.out.println(USER_NO_EXISTS);
		} catch (NegativeValueException e) {
			System.out.println(INVALID_DATA);
		}
	}

	/**
	 * Method that does a pickDown
	 * 
	 * @param in
	 * @param h
	 */
	private static void pickDown(Scanner in, HealthyLife h)
			throws NoBikeException, BikeStopException, NoParkException, InvalidDataException {
		String idBike = in.next();
		String idPark = in.next();
		int minutes = in.nextInt();
		in.nextLine();
		try {

			GetUser user = h.pickdown(idBike, idPark, minutes);
			System.out.printf(PICKDOWN_FORMAT, user.getBalance(), user.getPoints());
		} catch (NoBikeException e) {
			System.out.println(BIKE_NO_EXISTS);
		} catch (BikeStopException e) {
			System.out.println(STOP_BIKE);
		} catch (NoParkException e) {
			System.out.println(PARK_NO_EXISTS);
		} catch (InvalidDataException e) {
			System.out.println(INVALID_DATA);
		}

	}

	/**
	 * Method that does a pickUp
	 * 
	 * @param in
	 * @param h
	 */
	private static void pickUp(Scanner in, HealthyLife h)
			throws NoUserException, NoBikeException, MovingBikeException, NoMoneyException, MovingUserException {

		String idBike = in.next();
		String idUser = in.nextLine().trim();

		try {
			h.pickup(idBike, idUser);
			System.out.println(SUCCESSED_PICKUP);
		}

		catch (NoBikeException e) {
			System.out.println(BIKE_NO_EXISTS);
		}

		catch (MovingBikeException e) {
			System.out.println(MOVING_BIKE);
		}

		catch (NoUserException e) {
			System.out.println(USER_NO_EXISTS);
		}

		catch (MovingUserException e) {
			System.out.println(MOVING_USER);
		}

		catch (NoMoneyException e) {
			System.out.println(NO_MONEY);
		}

	}

	/**
	 * Method that adds a bike
	 * 
	 * @param in
	 * @param h
	 */
	private static void addBike(Scanner in, HealthyLife h) throws BikeAlreadyExistsException, NoParkException {
		String idBike = in.next();
		String idPark = in.next();
		String plate = in.nextLine().trim();
		try {
			h.addBike(idBike, idPark, plate);
			System.out.println(BIKE_ADDS_WITH_SUCESS);
		} catch (BikeAlreadyExistsException e) {
			System.out.println(EXISTS_BIKE);
		} catch (NoParkException e) {
			System.out.println(PARK_NO_EXISTS);
		}

	}

	/**
	 * Method that adds a park
	 * 
	 * @param in
	 * @param h
	 */

	private static void addPark(Scanner in, HealthyLife h) throws ParkAlreadyExistsException {
		String idPark = in.next();
		String name = in.nextLine().trim();
		String address = in.nextLine().trim();
		try {
			h.addPark(idPark, name, address);
			System.out.println(PARK_ADDS_WITH_SUCESS);
		} catch (ParkAlreadyExistsException e) {
			System.out.println(EXISTS_PARK);
		}

	}

	/**
	 * Method that lists the information of the users
	 * 
	 * @param in
	 * @param h
	 */
	private static void getUserInfo(Scanner in, HealthyLife h) throws NoUserException {
		String idUser = in.nextLine().trim();
		try {
			GetUser user = h.getUser(idUser);
			System.out.printf(GETUSERINFO_FORMAT, user.getName(), user.getNif(), user.getAddress(), user.getEmail(),
					user.getPhone(), user.getBalance(), user.getPoints());

		} catch (NoUserException e) {
			System.out.println(USER_NO_EXISTS);
		}

	}

	/**
	 * Method that removes an user
	 * 
	 * @param in
	 * @param h
	 */
	private static void removeUser(Scanner in, HealthyLife h) throws NoUserException, PickupsAlreadyDoneException {
		String idUser = in.next().trim();
		try {
			h.removeUser(idUser);
			System.out.println(USER_REMOVE_WITH_SUCCESS);
		} catch (NoUserException e) {
			System.out.println(USER_NO_EXISTS);
		} catch (PickupsAlreadyDoneException e) {
			System.out.println(USER_USED_ALREADY_SYSTEM);
		}

	}

	/**
	 * Method that adds an user
	 * 
	 * @param in
	 * @param h
	 */
	private static void addUser(Scanner in, HealthyLife h) throws UserAlreadyExistsException {
		String idUser = in.next();
		String nif = in.next();
		String email = in.next();
		String phone = in.next();
		String name = in.nextLine().trim();
		String address = in.nextLine().trim();

		try {
			h.addUser(idUser, nif, email, phone, name, address);
			System.out.println(USER_INSERT_WITH_SUCCESS);
		} catch (UserAlreadyExistsException e) {
			System.out.println(EXISTS_USER);
		}

	}

	/**
	 * Method that returns the input
	 * 
	 * @param in
	 * @return
	 */
	private static String getCommand(Scanner in) {
		String input = in.next().toUpperCase();
		return input;
	}

}
