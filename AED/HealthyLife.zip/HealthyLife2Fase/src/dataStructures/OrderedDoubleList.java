package dataStructures;

/**
 * 
 * @author Teresa Falcao de Campos Monteiro (52597)
 *         tfd.monteiro@campus.fct.unl.pt
 * @author Ana Filipa Santos Pereira Fernandes da Silva (52787)
 *         afsp.silva@campus.fct.unl.pt
 * 
 *
 */

public class OrderedDoubleList<K extends Comparable<K>, V> implements OrderedDictionary<K, V> {

	private static final long serialVersionUID = 1L;

	protected DListNode<Entry<K, V>> head;
	protected DListNode<Entry<K, V>> tail;
	protected int currentSize;

	public OrderedDoubleList() {
		head = null;
		tail = null;
		currentSize = 0;

	}

	/**
	 * 
	 */
	@Override
	public boolean isEmpty() {
		return currentSize == 0;
	}

	@Override
	public int size() {
		return currentSize;
	}

	@Override
	public V find(K key) {
		DListNode<Entry<K, V>> node = head;

		while (node != null && node.getElement().getKey().compareTo(key) != 0) {
			node = node.getNext();
		}
		if (node == null)
			return null;
		return node.getElement().getValue();

	}

	@Override
	public V insert(K key, V value) {
		if (this.isEmpty()) {
			DListNode<Entry<K, V>> newNode = new DListNode<Entry<K, V>>(new EntryClass<K, V>(key, value), null, null);
			head = newNode;
			tail = newNode;
			currentSize++;
			return null;
		}
		DListNode<Entry<K, V>> node = this.findNode(key);

		if (node == null) {
			insertLast(key, value);
		} else if (node.getElement().getKey().compareTo(key) == 0) {
			return this.replace(key, value);
		} else if (node == head)
			insertFirst(key, value);
		else {
			insertMiddle(key, value);

		}
		currentSize++;
		return null;
	}

	/**
	 * Method that inserts a node at the middle
	 * 
	 * @param key
	 *            - K: key of the node
	 * @param value
	 *            - V: value of the node
	 */
	private void insertMiddle(K key, V value) {
		Entry<K, V> entry = new EntryClass<K, V>(key, value);
		DListNode<Entry<K, V>> node = this.findNode(key);

		DListNode<Entry<K, V>> previous = node.getPrevious();
		DListNode<Entry<K, V>> newNode = new DListNode<Entry<K, V>>(entry, previous, node);
		node.getPrevious().setNext(newNode);
		node.setPrevious(newNode);

	}

	/**
	 * Method that replaces the node with a new entry and the returns the value of
	 * the old one
	 * 
	 * @param key
	 *            - K: key of the node
	 * @param value
	 *            - V: value of the node
	 * @return - V
	 */
	private V replace(K key, V value) {
		Entry<K, V> entry = new EntryClass<K, V>(key, value);
		DListNode<Entry<K, V>> node = this.findNode(key);

		V oldValue = node.getElement().getValue();
		node.setElement(entry);
		return oldValue;
	}

	/**
	 * Method that inserts the node at the tail
	 * 
	 * @param key
	 *            - K: key of the node
	 * @param value
	 *            - V: value of the node
	 */
	private void insertLast(K key, V value) {
		Entry<K, V> entry = new EntryClass<K, V>(key, value);
		DListNode<Entry<K, V>> newNode = new DListNode<Entry<K, V>>(entry, tail, null);

		tail.setNext(newNode);
		tail = newNode;

	}

	/**
	 * Method that inserts the node at the head
	 * 
	 * @param key
	 *            - K: key of the node
	 * @param value
	 *            - V: value of the node
	 */
	private void insertFirst(K key, V value) {
		Entry<K, V> entry = new EntryClass<K, V>(key, value);
		DListNode<Entry<K, V>> newNode = new DListNode<Entry<K, V>>(entry, null, head);

		head.setPrevious(newNode);
		head = newNode;

	}

	@Override
	public V remove(K key) {
		if (this.isEmpty())
			return null;

		DListNode<Entry<K, V>> node = this.findNode(key);

		if (node == null || node.getElement().getKey().compareTo(key) != 0)
			return null;

		if (this.size() == 1) {
			head = null;
			tail = null;
		} else if (node == head) {
			removeFirst();
		} else if (node == tail) {
			removeLast();
		} else {
			removeMiddle(node);
		}
		currentSize--;
		return node.getElement().getValue();

	}

	/**
	 * Method that removes the middle node
	 * 
	 * @param node
	 *            - DListNode<Entry<K, V>>: node going to be removed
	 */
	private void removeMiddle(DListNode<Entry<K, V>> node) {
		DListNode<Entry<K, V>> previous = node.getPrevious();
		DListNode<Entry<K, V>> next = node.getNext();
		previous.setNext(next);
		next.setPrevious(previous);
	}

	/**
	 * Method that removes the tail node
	 */
	private void removeLast() {
		tail = tail.getPrevious();
		tail.setNext(null);
	}

	/**
	 * Method that removes the head node
	 */
	private void removeFirst() {
		head = head.getNext();
		head.setPrevious(null);

	}

	@Override
	public Iterator<Entry<K, V>> iterator() {
		return new DoublyLLIterator<Entry<K, V>>(head, tail);
	}

	@Override
	public Entry<K, V> minEntry() throws EmptyDictionaryException {
		if (this.isEmpty())
			throw new EmptyDictionaryException();

		return head.getElement();
	}

	@Override
	public Entry<K, V> maxEntry() throws EmptyDictionaryException {
		if (this.isEmpty())
			throw new EmptyDictionaryException();

		return tail.getElement();
	}

	/**
	 * Method that returns the node with an equal or higher key
	 * 
	 * @param key
	 *            - K: key of the entry
	 * @return DListNode<Entry<K, V>
	 */
	private DListNode<Entry<K, V>> findNode(K key) {
		DListNode<Entry<K, V>> current = head;

		while (current != null && current.getElement().getKey().compareTo(key) < 0) {

			current = current.getNext();

		}
		return current;

	}
}
