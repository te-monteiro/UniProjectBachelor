package dataStructures;

public interface Node<E> {
	//returns the element stored at this node
	E getElement();

}
