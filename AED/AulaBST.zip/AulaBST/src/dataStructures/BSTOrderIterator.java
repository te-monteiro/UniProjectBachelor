package dataStructures;

public class BSTOrderIterator<K, V> implements Iterator<Entry<K, V>> {

	private Stack<BTNode<Entry<K, V>>> stack;
	private BTNode<Entry<K, V>> root;

	public BSTOrderIterator(Node<Entry<K, V>> root) {
		// TODO Auto-generated constructor stub
		this.root = (BTNode<Entry<K, V>>) root;

		this.rewind();
	}

	@Override
	public boolean hasNext() {
		// TODO Auto-generated method stub
		return !stack.isEmpty();
	}

	@Override
	public Entry<K, V> next() throws NoSuchElementException {

		if (!this.hasNext()) {
			throw new NoSuchElementException();
		} else {

			BTNode<Entry<K, V>> node = stack.pop();
			BTNode<Entry<K, V>> nodeRight = (BTNode<Entry<K, V>>) node.getRight();
			if (nodeRight != null) {
				stack.push(nodeRight);
				percorrer(nodeRight);
			}
			return node.getElement();
			
		}
	}

	private void percorrer(BTNode<Entry<K, V>> nodeRight) {
		BTNode<Entry<K, V>> nodeLeft = (BTNode<Entry<K, V>>) nodeRight.getLeft();
		while (nodeLeft != null) {
			stack.push(nodeLeft);
			nodeLeft = (BTNode<Entry<K, V>>) nodeLeft.getLeft();
		}
	}

	@Override
	public void rewind() {
		// TODO Auto-generated method stub
		stack = new StackInList<BTNode<Entry<K,V>>>();
		this.percorrer(root);


	}

}
