package sd1920.trab1.server.resources;

import javax.ws.rs.core.MediaType;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.logging.Logger;

import javax.inject.Singleton;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.glassfish.jersey.client.ClientConfig;

import sd1920.trab1.api.Message;
import sd1920.trab1.api.User;
import sd1920.trab1.api.rest.MessageService;
import sd1920.trab1.api.rest.UserService;
import sd1920.trab1.clients.utils.MessageUtills;
import sd1920.trab1.server.Discovery;

@Singleton

public class MessageResource implements MessageService {

	private Random randomNumberGenerator;

	private final Map<Long, Message> allMessages = new HashMap<Long, Message>();
	private final Map<String, Set<Long>> userInboxs = new HashMap<String, Set<Long>>();

	private final String domain;
	private final Discovery d;

	private static Logger Log = Logger.getLogger(MessageResource.class.getName());

	public MessageResource(String domain, Discovery d) {
		this.randomNumberGenerator = new Random(System.currentTimeMillis());
		this.domain = domain;
		this.d = d;
	}

	@Override
	public long postMessage(String pwd, Message msg) {
		// TODO Auto-generated method stub

		Log.info("Received request to register a new message (Sender: " + msg.getSender() + "; Subject: "
				+ msg.getSubject() + ")");

		User u = getUser(msg.getSender().split("@")[0], pwd);

		// Check if message is valid, if not return HTTP CONFLICT (409)
		synchronized (this) {

			if (!userInboxs.containsKey(msg.getSender())) {
				Log.info("Message was rejected due to invalid or inexistent password or user. ");
				throw new WebApplicationException(Status.FORBIDDEN);

			}
		}

		if (u == null || msg.getDestination() == null || msg.getDestination().size() == 0) {
			Log.info("Message was rejected due to lack of recepients.");
			throw new WebApplicationException(Status.CONFLICT);
		}

		// Generate a new id for the message, that is not in use yet
		long newID = 0;
		synchronized (this) {
			newID = Math.abs(randomNumberGenerator.nextLong());
			while (allMessages.containsKey(newID)) {
				newID = Math.abs(randomNumberGenerator.nextLong());
			}
		}

		msg.setSender(String.format("%s <%s@%s>", u.getDisplayName(), u.getName(), u.getDomain()));

		msg.setId(newID);
		synchronized (this) {

			allMessages.put(newID, msg);
			Log.info("Created new message with id: " + newID);
			MessageUtills.printMessage(allMessages.get(newID));
		}

		// Add the message (identifier) to the inbox of each recipient
		for (String recipient : msg.getDestination()) {
			if (!recipient.split("@")[1].equals(domain)) {
				Set<String> dist = new HashSet<String>(1);
				dist.add(recipient);
				msg.setDestination(dist);
				postMessageOutside(recipient.split("@")[1], pwd, msg);

			}
			synchronized (this) {
				if (!userInboxs.containsKey(recipient)) {
					userInboxs.put(recipient, new HashSet<Long>());
				}
				userInboxs.get(recipient).add(newID);
			}
		}

		// Return the id of the registered message to the client (in the body of a HTTP
		// Response with 200)
		Log.info("Recorded message with identifier: " + newID);

		return newID;
	}

	@Override
	public Message getMessage(String user, long mid, String pwd) {
		// TODO Auto-generated method stub

		User u = getUser(user, pwd);

		if (u == null) {
			Log.info("Request was rejected due to invalid or inexistent password or user. ");
			throw new WebApplicationException(Status.FORBIDDEN);
		}

		Log.info("Received request for message with id: " + mid + ".");

		synchronized (this) {

			if (!allMessages.containsKey(mid)) { // check if message exists
				Log.info("Requested message does not exists.");
				throw new WebApplicationException(Status.NOT_FOUND); // if not send HTTP 404 back to
			}
		}

		Log.info("Returning requested message to user.");
		return allMessages.get(mid); // Return message to the client with code HTTP 200 }

	}

	@Override
	public List<Long> getMessages(String user, String pwd) {
		// TODO Auto-generated method stub

		Log.info("Received request for messages with optional user parameter set to: '" + user + "'");

		List<Long> messages = new ArrayList<Long>();

		User u = getUser(user, pwd);

		if (u == null) {
			Log.info("Request was rejected due to invalid or inexistent password or user. ");
			throw new WebApplicationException(Status.FORBIDDEN);
		}

		Log.info("Collecting all messages in server for user " + user);

		Set<Long> mids = null;
		synchronized (this) {

			mids = userInboxs.getOrDefault(user, Collections.emptySet());
		}
		for (Long l : mids) {

			messages.add(l);
		}

		Log.info("Returning message list to user with " + messages.size() + " messages.");

		return messages;

	}

	@Override
	public void removeFromUserInbox(String user, long mid, String pwd) {
		// TODO Auto-generated method stub

		Log.info("Received request to delete the message with id: " + mid + ", from the invox of the user: " + user
				+ ".");

		User u = getUser(user, pwd);

		if (u == null) {
			Log.info("Request was rejected due to invalid or inexistent password or user. ");
			throw new WebApplicationException(Status.FORBIDDEN);
		}

		Set<Long> msgs = null;
		synchronized (this) {

			msgs = userInboxs.get(user);
		}
		if (msgs != null && msgs.contains(mid)) {
			msgs.remove(mid);
			synchronized (this) {

				userInboxs.put(user, msgs);
			}
		} else
			throw new WebApplicationException(Status.NOT_FOUND);

	}

	@Override
	public void deleteMessage(String user, long mid, String pwd) {
		// TODO Auto-generated method stub

		Log.info("Received request to delete the message with id: " + mid + ".");

		User u = getUser(user, pwd);

		if (u == null) {
			Log.info("Request was rejected due to invalid or inexistent password or user. ");
			throw new WebApplicationException(Status.FORBIDDEN);
		}
		synchronized (this) {

			for (String dst : allMessages.get(mid).getDestination())
				if (!dst.split("@")[1].equals(domain))
					deleteMessageOutside(dst.split("@")[1], dst.split("@")[0], pwd, mid);
		}
		if (allMessages.containsKey(mid))
			allMessages.remove(mid);

	}

	private User getUser(String name, String pwd) {
		// execute a rest request to ourselves
		ClientConfig config = new ClientConfig();
		Client client = ClientBuilder.newClient(config);

		WebTarget target = client.target(domain).path(UserService.PATH);

		Response r = target.path(name).path(pwd).request().get();

		User u = null;

		if (r.getStatus() == Status.OK.getStatusCode() && r.hasEntity())
			u = r.readEntity(User.class);
		else
			System.out.println("FALHOU AO OBTER O USER");
		return u;
	}

	private void postMessageOutside(String domain, String pwd, Message msg) {
		ClientConfig config = new ClientConfig();
		Client client = ClientBuilder.newClient(config);

		WebTarget target = client.target(getServer(domain)).path(MessageService.PATH);

		Response r = target.path(pwd).request().accept(MediaType.APPLICATION_JSON)
				.post(Entity.entity(msg, MediaType.APPLICATION_JSON));

		if (r.getStatus() == Status.OK.getStatusCode() && r.hasEntity())
			System.out.println("Success, message posted with id: " + r.readEntity(Long.class));
		else
			System.out.println("Error, HTTP error status: " + r.getStatus());

	}

	private void deleteMessageOutside(String domain, String user, String pwd, long mid) {
		ClientConfig config = new ClientConfig();
		Client client = ClientBuilder.newClient(config);

		WebTarget target = client.target(getServer(domain)).path(MessageService.PATH);

		Response r = target.path("msg").path(user).path("" + mid + "").path(pwd).request()
				.accept(MediaType.APPLICATION_JSON).delete();

		if (r.getStatus() == Status.OK.getStatusCode() && r.hasEntity())
			System.out.println("Success, message posted with id: " + r.readEntity(Long.class));
		else
			System.out.println("Error, HTTP error status: " + r.getStatus());

	}

	private String getServer(String domain) {
		URI[] uris = d.knownUrisOf(domain);
		return uris[uris.length - 1].toString();

	}

}
