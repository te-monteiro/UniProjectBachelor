package sd1920.trab1.server.resources;

import java.util.HashMap;

import java.util.Map;
import java.util.logging.Logger;

import javax.inject.Singleton;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response.Status;

import sd1920.trab1.server.resources.MessageResource;
import sd1920.trab1.api.User;
import sd1920.trab1.api.rest.UserService;

@Singleton
public class UserResource implements UserService {

	private final Map<String, User> users = new HashMap<String, User>();

	private static Logger Log = Logger.getLogger(MessageResource.class.getName());

	private final String domain;

	public UserResource(String domain) {
		// TODO Auto-generated constructor stub
		this.domain = domain;
	}

	@Override
	public String postUser(User user) {
		// TODO Auto-generated method stub

		if (user.getName() == null || user.getPwd() == null || user.getDomain() == null) {
			Log.info("Message was rejected due to lack of recepients.\")");
			throw new WebApplicationException(Status.CONFLICT);
		}

		if (user.getDomain().equals(domain)) {
			Log.info("the domain in the user does not match the domain of the server");
			throw new WebApplicationException(Status.FORBIDDEN);

		}
		synchronized (this) {

			users.put(user.getName(), user);
		}
		return user.getName() + "@" + user.getDomain();
	}

	@Override
	public User getUser(String name, String pwd) {
		// TODO Auto-generated method stub
		User u = null;
		synchronized (this) {
			u = users.get(name);

		}

		if (u == null || pwd == null || !u.getPwd().equals(pwd)) {
			Log.info("Message was rejected due to lack of recepients.\")");
			throw new WebApplicationException(Status.CONFLICT);
		}

		return u;
	}

	@Override
	public User updateUser(String name, String pwd, User user) {
		// TODO Auto-generated method stub
		User u = null;
		synchronized (this) {
			u = users.get(name);
		}

		if (u == null || pwd == null || !u.getPwd().equals(pwd)) {
			Log.info("Message was rejected due to lack of recepients.\")");
			throw new WebApplicationException(Status.CONFLICT);
		}

		if (user.getDisplayName() != null)
			u.setDisplayName(user.getDisplayName());

		if (user.getDomain() != null)
			u.setDomain(user.getDisplayName());

		if (user.getPwd() != null)
			u.setPwd(user.getPwd());

		// nao sei se e necessario
		synchronized (this) {
			users.put(name, u);
		}

		return u;
	}

	@Override
	public User deleteUser(String user, String pwd) {
		// TODO Auto-generated method stub
		User u = null;
		
		synchronized (this) {
			u = users.get(user);
		}
		if (u == null || pwd == null || !u.getPwd().equals(pwd)) {
			Log.info("Message was rejected due to lack of recepients.\")");
			throw new WebApplicationException(Status.CONFLICT);
		}
		synchronized (this) {

			return users.remove(user);
		}
	}

}
