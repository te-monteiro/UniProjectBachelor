package caoss.simulator.os;

public class File {

}
