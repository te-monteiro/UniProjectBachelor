#include <strings.h>

#include "UDP-common.c"

#define BUFFER_SIZE	80

int main(int argc, char *argv[]) {
   struct sockaddr_in addrSnd, addrRcv;

   int sd = UDP_Open(20000);

   // servidor a correr no mesmo computador
   int rc = UDP_FillSockAddr(&addrSnd, "localhost", 10000);

   // servidor a correr noutro computador: actualizar /etc/hosts com o nome e IP
   //int rc = UDP_FillSockAddr(&addrSnd, "fso-vm64", 10000);

   char message[BUFFER_SIZE]; sprintf(message, "HELLLO world");

   rc = UDP_Write(sd, &addrSnd, message, BUFFER_SIZE);
   if (rc > 0) {
     bzero(message,80);
     rc = UDP_Read(sd, &addrRcv, message, BUFFER_SIZE);
     if (rc > 0) printf("From server: %s\n",message);
   }

   return 0;
}
