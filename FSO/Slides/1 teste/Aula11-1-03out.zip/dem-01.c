#include <stdio.h>
#include <pthread.h>

#define N	32
#define CHEIO	(slotsCheios==N)
#define VAZIO	(slotsVazios==N)

char buffer[N];

int slotsCheios=0, slotsVazios= N;
int c=0, p= 0;

pthread_cond_t cndC= PTHREAD_COND_INITIALIZER;
pthread_cond_t cndP= PTHREAD_COND_INITIALIZER;
pthread_mutex_t mtx= PTHREAD_MUTEX_INITIALIZER;


void putInBuffer(char chr) {
  buffer[p]= chr;
  p= (p+1)%N;
  slotsCheios++; slotsVazios--;
}

void getFromBuffer(char *chr) {
  *chr= buffer[c];
  c= (c+1)%N;
  slotsVazios++; slotsCheios--;
}

void produz(char c) {
  pthread_mutex_lock(&mtx);
    while CHEIO pthread_cond_wait(&cndP, &mtx);
      putInBuffer(c);
      pthread_cond_signal(&cndC);
  pthread_mutex_unlock(&mtx);
}

void *produtor(void * args) {
  for (int i= 0; i < 24; i++) produz('A'+i);
  return NULL;
}


void consome(char *chr) {
  pthread_mutex_lock(&mtx);
    while VAZIO pthread_cond_wait(&cndC, &mtx);
      getFromBuffer(chr);
      pthread_cond_signal(&cndP);
  pthread_mutex_unlock(&mtx);
}

void *consumidor(void * args) {
  char chr;
  for (int i= 0; i < 24; i++) 
    { consome(&chr); printf("%c ",chr); fflush(stdout);}
  return NULL;
}


int main(int argc, char *argv[]) {
  pthread_t p1, p2;

  pthread_create(&p1, NULL, consumidor, NULL);
  pthread_create(&p2, NULL, produtor, NULL);

  pthread_join(p1, NULL);
  pthread_join(p2, NULL);
  return 0;
}
