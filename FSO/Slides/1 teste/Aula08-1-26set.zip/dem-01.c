#include <stdio.h>

#include <unistd.h>

#include <stdlib.h>

#include <sys/types.h>
#include <sys/wait.h>

#include <sys/stat.h>
#include <fcntl.h>


int main(int argc, char *argv[]) {

 int p[2];

  if (fork()) {
    printf("A –pseudo-shell- em WAIT\n");  wait(NULL);
  } else {
    printf("A'\n");
    pipe(p);

    if (fork()) {
      close(0); dup(p[0]);
      close(p[0]); close(p[1]);

      execlp("wc", "wc", "-l", NULL);
    } else {
      printf("A''\n");
      close(1); dup(p[1]);
      close(p[0]); close(p[1]);

      execlp("ls", "ls", NULL);
    }
  }
 
  return 0;
}

