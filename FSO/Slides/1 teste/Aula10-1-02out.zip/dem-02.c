#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#include "common.h"
#include "common_threads.h"

// shared global variables
int haDados= 0;
char dado;

pthread_mutex_t mtx=  PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cnd = PTHREAD_COND_INITIALIZER;


void produz(char v) {
  pthread_mutex_lock(&mtx);
    while (haDados) pthread_cond_wait(&cnd,&mtx);
    dado= v; haDados= 1;
    pthread_cond_signal(&cnd);
  pthread_mutex_unlock(&mtx);
}


void consome(char *v) {
  pthread_mutex_lock(&mtx);
    while (!haDados) pthread_cond_wait(&cnd,&mtx);
    *v= dado; haDados= 0;
    pthread_cond_signal(&cnd);
  pthread_mutex_unlock(&mtx);
}


void *mythreadC(void *arg) {
  char v;

  for (int i = 0; i < 24; i++) {
    consome(&v);
    printf("%c ", v); fflush(stdout);
  }

  return NULL;
}


void *mythreadP(void *arg) {
  char c;

  for (int i = 0; i < 24; i++) {
    c= 'A'+i;
    produz(c);
  }
  return NULL;
}
                                                                             
int main(int argc, char *argv[]) {                    

    pthread_t p1, p2, p3;
    Pthread_create(&p1, NULL, mythreadC, NULL); 
    Pthread_create(&p2, NULL, mythreadC, NULL);
    Pthread_create(&p3, NULL, mythreadP, NULL);
    // join waits for the threads to finish
    Pthread_join(p1, NULL); 
    Pthread_join(p2, NULL); 
    Pthread_join(p3, NULL); 
    return 0;
}
