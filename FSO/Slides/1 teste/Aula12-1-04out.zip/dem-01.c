#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>

#define N	7

char buffer[N];

sem_t slotsCheios, slotsVazios;
//sem_t mtx;

int c=0, p= 0;


void putInBuffer(char chr) {
//  sem_wait(&mtx);
    buffer[p]= chr;
    p= (p+1)%N;
//  sem_post(&mtx);
}

void getFromBuffer(char *chr) {
//  sem_wait(&mtx);
    *chr= buffer[c];
    c= (c+1)%N;
//  sem_post(&mtx);
}

void produz(char c) {
  sem_wait(&slotsVazios);
    putInBuffer(c);
  sem_post(&slotsCheios);
}

void *produtor(void * args) {
  for (int i= 0; i < 24; i++) produz('A'+i);
  return NULL;
}


void consome(char *chr) {
  sem_wait(&slotsCheios);
    getFromBuffer(chr);
  sem_post(&slotsVazios);
}

void *consumidor(void * args) {
  char chr;
  for (int i= 0; i < 24; i++) 
    { consome(&chr); printf("%c ",chr); fflush(stdout);}
  return NULL;
}


int main(int argc, char *argv[]) {
  pthread_t p1, p2;

  sem_init(&slotsCheios, 0, 0);
  sem_init(&slotsVazios, 0, N);
//  sem_init(&mtx, 0, 1);

  pthread_create(&p1, NULL, consumidor, NULL);
  pthread_create(&p2, NULL, produtor, NULL);

  pthread_join(p1, NULL);
  pthread_join(p2, NULL);
  return 0;
}
