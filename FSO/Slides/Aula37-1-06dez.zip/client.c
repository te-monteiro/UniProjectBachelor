#include <strings.h>

#include "UDP-common.c"

#define BUFFER_SIZE	80

int main(int argc, char *argv[]) {
   struct sockaddr_in addrSnd, addrRcv;

   int sd = UDP_Open(20000);
   int rc = UDP_FillSockAddr(&addrSnd, "server", 10000);

   char message[BUFFER_SIZE]; sprintf(message, "hello world");

   rc = UDP_Write(sd, &addrSnd, message, BUFFER_SIZE);
   if (rc > 0) {
     bzero(message,80);
     int rc = UDP_Read(sd, &addrRcv, message, BUFFER_SIZE);
     printf("From server: %s\n",message);
   }

   return 0;
}
