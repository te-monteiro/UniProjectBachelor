int fs_delete(char *name) {

    if (superB.magic != FS_MAGIC) {
        printf("disc not mounted\n");
        return -1;
    }
    char fname[FNAMESZ];
    strEncode(fname, name, FNAMESZ);

    // TODO: delete file: free it's dirent, extents and data blocks

    struct fs_dirent dirent;

    int idx = readFileEntry(fname, 0, &dirent);

    if(idx == -1)
	    return -1;

    int numExs = dirent.ex;
     
    //Enquanto dirent.ex != 0
    while(numExs >= 0) {

	    union fs_block extBlock;
	    struct fs_dirent extDirent;
        int idxExt = readFileEntry(fname, numExs, &extDirent);

	    if(idxExt == -1)
		    return -1;
	
	    int extPos = 0;
        int extNumBlock = superB.dir[getDirentBlock(idxExt, &extPos)];

	    disk_read(extNumBlock, extBlock.data);	
        extBlock.dirent[extPos].st = TEMPTY;
        extBlock.dirent[extPos].ex = 0;
        extBlock.dirent[extPos].ss = 0;
        for(int j = 0; j < FBLOCKS && extBlock.dirent[extPos].blocks[j]; j++)
		    freeBlock(extBlock.dirent[extPos].blocks[j]);
        cleanDirentBlocks(&dirent);
	    disk_write(extNumBlock, extBlock.data);
        numExs--;

    }
     return 0;
}
