#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>
#include<string.h>

void syserror( char *err) {
	perror ( err );
	exit(1);
}

int main(int argc, char *argv[]) {
	char *dir;	

	if(argc == 1) dir = ".";
	else if (argc == 2) dir = argv[1];
	else {	fprintf(stderr, "usage: myls [dir]\n"); exit(1); }	
	DIR *dp = opendir(dir);
	if(dp == NULL){
		syserror(dir);
	}
	struct dirent *d; //apontador para estrutura retornada pelo readdir
	while ((d = readdir(dp)) != NULL){
		struct stat statbuf;
		struct stat *st = &statbuf; 	
		stat(d->d_name, st); //apontador para a variavel
		char *type = "";
		if(S_ISDIR(st->st_mode)){ type = "(dir)";}
		else if (S_ISREG(st->st_mode)){ type = "(file)";}
		else type = "(other)";
		char *time = ctime(&st->st_mtime);
		time[strlen(time) - 1] = NULL;
		printf ("%lu: %d %s %s %s\n", (unsigned long) d->d_ino, st->st_uid, time, d->d_name, type); // ou statbuf.st_uid
	}
	closedir(dp);
	return 0;
	
}
