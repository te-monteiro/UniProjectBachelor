if(startingPoint){
                disk_read(dirent.blocks[startingBlock], auxData);
                if((length + startingPoint) < 1024){
                    memcpy(auxData + startingPoint, data, length);
                    nextRound = nextRound + length;
                    length = 0;
                }
                else{
                    memcpy(auxData + startingPoint, data, 1024 - startingPoint);
                    nextRound = nextRound + (1024 - startingPoint);
                    length = length - (1024 - startingPoint);
                }
                disk_write(dirent.blocks[startingBlock], data);
                startingPoint = 0;
            }
            else if(length >= 1024){
                memcpy(auxData, data + nextRound, 1024);
                length = length - 1024;
                nextRound = nextRound + 1024;
            }
            else{
                disk_read(dirent.blocks[startingBlock], auxData);
                memcpy(auxData, data + nextRound, length);
                nextRound = nextRound + length;
                length = 0;
            }
