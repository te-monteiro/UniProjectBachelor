while(length && dirent.blocks[startingBlock]){
            char auxData[1024];
            disk_read(dirent.blocks[startingBlock], auxData);
            if(startingPoint){
                if((length + startingPoint) < 1024){
                    memcpy(data, auxData + startingPoint, length);
                    nextRound = nextRound + length;
                    length = 0;
                }
                else{
                    memcpy(data, auxData + startingPoint, 1024 - startingPoint);
                    nextRound = nextRound + (1024 - startingPoint);
                    length = length - (1024 - startingPoint);
                }
                startingPoint = 0;
            }
            else if(length >= 1024){
                memcpy(data + nextRound, auxData, 1024);
                length = length - 1024;
                nextRound = nextRound + 1024;
            }
            else{
                memcpy(data + nextRound, auxData, length);
                nextRound = nextRound + length;
                length = 0;
            }
            startingBlock++;
        }
