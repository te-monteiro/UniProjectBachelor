
#include "fso_phaser.h"

#include <assert.h>

#include <stdlib.h>

#include <stdio.h>

#include <string.h>

#include "pthread_to_pos.h"

int fso_phaser_init(fso_phaser_t *phaser, int number_threads)
{

	assert(number_threads > 0);

	int result;
	if ((result = pthread_mutex_init(&phaser->mutex, NULL)) < 0)
		return result;

	if ((result = pthread_cond_init(&phaser->cond, NULL)) < 0)
	{
		pthread_mutex_destroy(&phaser->mutex);
		return result;
	}

	phaser->number_threads = number_threads;
	phaser->phases = (int *)malloc(sizeof(int) * number_threads);
	memset(phaser->phases, 0, sizeof(int) * number_threads);
	return 0;
}

int fso_phaser_current(fso_phaser_t *phaser)
{
	int result = phaser->phases[0];
	for (int i = 1; i < phaser->number_threads; i++)
	{
		//pthread_mutex_lock(&phaser->mutex);
		if (phaser->phases[i] < result)
		{
			result = phaser->phases[i];
		}
		//pthread_mutex_unlock(&phaser->mutex);
	}

	return result;
}

//Increments the thread's phase in the phaser and waits until the remainder threads have also reached the
//same phase, i.e.blocks the thread while the current phase of the phaser is lower to the thread’s phase.
//If successful, fso_phaser_advance_and_await returns zero, otherwise it returns - 1 to indicate the error
int fso_phaser_advance_and_await(fso_phaser_t *phaser)
{
	int index_in_phase_array = pthread_to_pos(pthread_self());
	if (index_in_phase_array >= 0)
	{
		pthread_mutex_lock(&phaser->mutex);
		phaser->phases[index_in_phase_array]++;
		while (fso_phaser_current(phaser) < phaser->phases[index_in_phase_array])
		{
			pthread_cond_wait(&phaser->cond, &phaser->mutex);
		}
		pthread_mutex_unlock(&phaser->mutex);
		return 0;
	}

	return -1;
}

int fso_phaser_advance(fso_phaser_t *phaser)
{

	int index_in_phase_array = pthread_to_pos(pthread_self());
	if (index_in_phase_array >= 0)
	{
		pthread_mutex_lock(&phaser->mutex);
		phaser->phases[index_in_phase_array]++;
		pthread_cond_signal(&phaser->cond);
		pthread_mutex_unlock(&phaser->mutex);
		return 0;
	}
	return -1;
}

int fso_phaser_destroy(fso_phaser_t *phaser)
{

	int result;
	if ((result = pthread_mutex_destroy(&phaser->mutex)) < 0)
		return result;

	if ((result = pthread_cond_destroy(&phaser->cond)) < 0)
		return result;

	free(phaser->phases);
	return 0;
}
