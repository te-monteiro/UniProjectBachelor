
/* myutil.h
 * interface to libmyutil
 */
extern void util_file();
extern void util_net();
extern void util_math();

