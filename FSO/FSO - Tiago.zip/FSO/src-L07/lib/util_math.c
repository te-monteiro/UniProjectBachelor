#include <stdio.h>
void util_math()
{
    printf("Inside util_math()\n");
}

