#include <stdio.h>
void util_net()
{
    printf("Inside util_net()\n");
}

