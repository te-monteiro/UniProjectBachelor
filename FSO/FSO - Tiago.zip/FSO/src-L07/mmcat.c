#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>

void fatal_error(char *str){
  perror(str);
  exit(1);
}

/* mmapcopy - uses mmap to copy file fd to stdout 
 */
void mmapcopy(int fd, int fd2, int size, int bsize) {
    char *bufp; /* ptr to memory mapped VM area */
    char *bufl; 
	int offset = 0;
	ftruncate(fd2, size); // obrigar o tamanho do ficheiro a ser o tamanho do ficheiro que vai ser copiado
	// -----LOOOP-----
	while(offset < size){

    	bufp = mmap(NULL, bsize, PROT_READ, MAP_PRIVATE, fd, offset); //0 representa o deslocamento dentro do ficheiro
    	if( bufp == MAP_FAILED) fatal_error("mmap");
    
    	bufl = mmap(NULL, bsize, PROT_READ|PROT_WRITE, MAP_SHARED, fd2, offset); //mmap devolve o endereco da memoria onde foi colocado
		if( bufl == MAP_FAILED) fatal_error("mmap 2");
		
		if(offset + bsize > size) bsize = size - offset;
    	memcpy(bufl, bufp, bsize); //funcao da biblioteca do C para copiar memoria (da forma mais eficiente para a arquitetura usada)
    	munmap(bufp, bsize);  //desmapear para reaproveitar os enderecos
    	munmap(bufl, bsize);  //desmapear para reaproveitar os enderecos
    	offset += bsize;
    }
    //---END LOOP----
}

int main(int argc, char *argv[]) {
    struct stat stat;
    int fd;
    int fd2;
    int bsize = atoi(argv[1]);

    /* check for required command line argument */
    if (argc != 4) {
	printf("usage: %s <bsize, filename, filename2>\n", argv[0]);
	exit(1);
    }

    /* copy the input argument to stdout */
    fd = open(argv[2], O_RDONLY);
    if( fd < 0) fatal_error("open");

    if( fstat(fd, &stat) != 0) fatal_error("fstat");
	
	fd2 = open(argv[3], O_RDWR|O_CREAT|O_TRUNC, 0600);  //0600 representa leitura a user e escrita a user
	if( fd2 < 0) fatal_error("open2");
	if(bsize != 0 && (bsize % sysconf(_SC_PAGE_SIZE)) != 0){ bsize += (sysconf(_SC_PAGE_SIZE)-(bsize % sysconf(_SC_PAGE_SIZE))); }
    mmapcopy(fd, fd2, stat.st_size, bsize);
    return 0;
}

