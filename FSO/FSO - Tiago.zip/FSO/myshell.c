#include <string.h> 
#include <stdio.h> 
#include <stdlib.h>
#include <fcntl.h>


#define ARGVMAX 100  //Máximo de argumentos de input na shell
#define LINESIZE 1024 


int makeargv(char *s, char* argv[ARGVMAX]) {
  // in: s points a text string with words
  // out: argv[] points to all words in the string s (*s is modified!)
  // pre: argv is predefined as char *argv[ARGVMAX]
  // return: number of words pointed to by the elements in argv (or -1 in case of error) 

  int ntokens;
	
  if ( s==NULL || argv==NULL || ARGVMAX==0) 
    return -1;

  ntokens = 0;
  argv[ntokens]=strtok(s, " \t\n");
  while ( (argv[ntokens]!= NULL) && (ntokens<ARGVMAX) ) {
    ntokens++;
    argv[ntokens]=strtok(NULL, " \t\n"); // breaks 's' inline at separators
  }
  argv[ntokens] = NULL; // it must terminate with NULL
  return ntokens; 
}

void waitloop(int pid){
  int p, stat;
  while((p=wait(&stat))!= pid && p>0)
   printf("Process %d terminated with status %d \n", p, WEXITSTATUS(stat)); //Wait for child exit
  if (p==-1) 
    perror("wait");
}

void redirectInput( char *fname) {
  close(0);
  if(open(fname, O_RDONLY)!=0){
    perror(fname);
    exit(1);
  }
}


void redirectOutput (char *fname) {
  close(1);
  if (open (fname, O_WRONLY|O_CREAT|O_TRUNC, S_IRUSR|S_IWUSR) !=1) {
    perror(fname);
    exit(1);
  }
}



void runcommand(int argc, char* argv[]) {
  static int lastpid;
  int bg=0;
  int pid;

  if (strcmp(argv[0], "exit")==0) {       //Exit cmd
    printf("Exiting...\n");
    fflush(stdout);
    exit(0);
    } 

  if ( strcmp(argv[argc-1], "&")==0) {    //Background a command
    argv[argc-1] = NULL;
    bg=1;
  }

  if (strcmp(argv[0], "fg")==0) {        //Foreground the last cmd
    if(argv[1]!=NULL) waitloop(atoi(argv[1]));
    else waitloop(lastpid);
    return;
  } 

  switch ( pid=fork() ) {             //Fork to a command
    case -1: perror("fork"); exit(1);
    case 0:
      if(argc >2 && strcmp(argv[argc-2],"<")==0){
        redirectInput(argv[argc-1]);
        argv[argc-2]=NULL;
      } else if(argc > 2 && strcmp(argv[argc-2], ">")==0) {
        redirectOutput(argv[argc-1]);
        argv[argc-2]=NULL;
      }

      execvp(argv[0], argv);
      perror(argv[0]);
      exit(1);
    default:
      if(bg) printf("process %d in background\n", pid);  
      else wait(NULL); // wait for child exit
    }
}

void dowaits(){
  int status;
  int p;

  while( (p= waitpid(-1,&status, WNOHANG))>0){
    printf("process %d terminated with status %d\n", p, WEXITSTATUS(status));
  };
}


void runOneCommand(char *cmd) {
  char *av[ARGVMAX];
  int ac;
  if((ac=makeargv(cmd,av))>0) runcommand(ac,av);
}


int main() {
  char line[LINESIZE];

  printf("> ");
  fflush(stdout); //writes the prompt on the standard output 
  while ( fgets( line, LINESIZE, stdin ) != NULL ) {
    char  *start = line;    //actual line
    char *end;              //end line
    do {
      end = strchr(start, ';');   //strchr goes from start until a ";" is found
      if(end !=NULL) *end= '\0';  //Caso não encontre ";", o end fica no final de frase  
      runOneCommand(start);       //
      if (end != NULL) start = end +1;
    } while (end !=NULL);
    printf("> ");
    fflush(stdout);
  }

  return 0;
}

