#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int *a;

void do_something( long int trials, long int numpag ) {
	int jump;
	jump = getpagesize()/sizeof(int);
	for (int j=0; j <= trials; j++){
		for(int i=0; i<numpag*jump; i+=jump){
			a[i] += 1;
		}
	}
}


int main(int argc, char *argv[]) {
    int i, p;
    long elapsed;
    struct timeval t1,t2;

	if ( argc!=3 ) {
		fprintf(stderr, "usage: %s trials pages\n", argv[0]);
		exit(1);
	}

	long int trials = atol(argv[1]);
	long int numpag = atol(argv[2]);
	// int a[ numpag*getpagesize()/sizeof(int) ]; --> pode rebentar a pilha ou
	// compilador pode nao aceitar
	a = malloc( numpag*getpagesize() ); //argumento do malloc e' bytes 
									    //(nao e' preciso dividir pelo sizeof(int)
	if (a == NULL)
		printf("Nao ha espaco suficiente."); //Caso o tamanho pedido seja absurdo (mt grande)
											 // ou nao haja espaco para alocar
    gettimeofday(&t1, NULL);
	do_something( trials, numpag );
    gettimeofday(&t2, NULL);
    elapsed = ((long)t2.tv_sec - t1.tv_sec) * 1000000L + (t2.tv_usec - t1.tv_usec);
    printf("%ld  %g\n", numpag, (double)elapsed/(double)(trials*numpag));
	free(a); //libertar o espaco ocupado pelo vetor
    return 0;
}


