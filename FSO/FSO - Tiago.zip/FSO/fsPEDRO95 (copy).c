#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <assert.h>

#include "disk.h"
#include "fs.h"

#define MIN(X, Y) ((X) > (Y) ? (Y) : (X))

/*******
 * FSO OFS layout (there is no bootBlock)
 * FS block size = disk block size (1KB)
 * block#	| content
 * 0		| super block (with list of dir blocks)
 * 1		| first data block (usualy with 1st block of dir entries)
 * ...      | other dir blocks and files data blocks
 */

#define BLOCKSZ (DISK_BLOCK_SIZE)
#define SBLOCK 0          // superblock is at disk block 0
#define FS_MAGIC (0xf0f0) // for OFS
#define FNAMESZ 11        // file name size
#define LABELSZ 12        // disk label size
#define MAXDIRSZ 504      // max entries in the directory (1024-4-LABELSZ)/2

#define DIRENTS_PER_BLOCK (BLOCKSZ / sizeof(struct fs_dirent))
#define FBLOCKS 8 // 8 block indexes in each dirent

/* dirent .st field values: */
#define TFILE 0x10  // is file dirent
#define TEMPTY 0x00 // not used/free
#define TEXT 0xff   // is extent

#define FALSE 0
#define TRUE 1

#define FREE 0
#define NOT_FREE 1

/*** FSO Old/Our FileSystem disk layout ***/

struct fs_dirent
{ // a directory entry (dirent/extent)
    uint8_t st;
    char name[FNAMESZ];
    uint16_t ex; // numb of extra extents or id of this extent
    uint16_t ss; // number of bytes in the last extent (can be this dirent)
    uint16_t
        blocks[FBLOCKS]; // disk blocks with file content (zero value = empty)
};

struct fs_sblock
{ // the super block
    uint16_t magic;
    uint16_t fssize;        // total number of blocks (including this sblock)
    char label[LABELSZ];    // disk label
    uint16_t dir[MAXDIRSZ]; // directory blocks (zero value = empty)
};

/**
 * Nota: considerando o numero de ordem dos dirent em todos os blocos da
 * directoria um ficheiro pode ser identificado pelo numero do seu dirent. Tal
 * e' usado pelo open, create, read e write.
 */

union fs_block { // generic fs block. Can be seen with all these formats
    struct fs_sblock super;
    struct fs_dirent dirent[DIRENTS_PER_BLOCK];
    char data[BLOCKSZ];
};

/*******************************************/

struct fs_sblock superB; // superblock of the mounted disk

uint8_t *blockBitMap; // Map of used blocks (not a real bitMap, more a byteMap)
                      // this is build by mount operation, reading all the directory

/*******************************************/
/* The following functions may be usefull
 * change these and implement others that you need
 */

/**
 * allocBlock: allocate a new disk block
 * return: block number
 */
int allocBlock()
{
    int i;

    for (i = 0; i < superB.fssize && blockBitMap[i] == NOT_FREE; i++)
        ;
    if (i < superB.fssize)
    {
        blockBitMap[i] = NOT_FREE;
        return i;
    }
    else
        return -1; // no disk space
}

/**
 */
void freeBlock(int nblock)
{
    blockBitMap[nblock] = FREE;
}

/**
 * copy str to dst, converting from C string to FS string:
 *   - uppercase letters and ending with spaces
 * dst and str must exist with at least len chars
 */
void strEncode(char *dst, char *str, int len)
{
    int i;
    for (i = 0; i < len && str[i] != '\0'; i++)
        if (isalpha(str[i]))
            dst[i] = toupper(str[i]);
        else if (isdigit(str[i]) || str[i] == '_' || str[i] == '.')
            dst[i] = str[i];
        else
            dst[i] = '?'; // invalid char?
    for (; i < len; i++)
        dst[i] = ' '; // fill with space
}

/**
 * copy str to dst, converting from FS string to C string
 * dst must exist with at least len+1 chars
 */
void strDecode(char *dst, char *str, int len)
{
    int i;
    for (i = len - 1; i > 0 && str[i] == ' '; i--)
        ;
    dst[i + 1] = '\0';
    for (; i >= 0; i--)
        dst[i] = str[i];
}

/**
 * returns the block where the dirent with the respective idx is
 * fills pos with the position of the dirent in the block
 */
int getDirentBlock(int idx, int *pos)
{
    int auxpos = 0;
    while (idx % 32)
    {
        idx--;
        auxpos++;
    }
    *pos = auxpos;
    idx = idx / 32;

    return idx;
}

/**
 * returns dirent's number
 */
int getDirentNumber(int dirBlk, int dir)
{

    return ((dirBlk + 1) * 32 - (31 - dir)) - 1;
}

/**
 * returns dirent's size
 */
int getDirentSize(struct fs_dirent dirent)
{

    return dirent.ex * FBLOCKS * 1024 + dirent.ss;
}

/**
 * print super block content to stdout (for debug)
 */
void dumpSB()
{
    union fs_block block;
    char label[LABELSZ + 1];

    disk_read(SBLOCK, block.data);
    printf("superblock:\n");
    printf("    magic = %x\n", block.super.magic);
    printf("    %d blocks\n", block.super.fssize);
    printf("    dir_size: %d\n", MAXDIRSZ);
    printf("    first dir block: %d\n", block.super.dir[0]);
    strDecode(label, block.super.label, LABELSZ);
    printf("    disk label: %s\n", label);

    printf("dir blocks: ");
    for (int i = 0; block.super.dir[i] != 0; i++)
        printf("%d ", block.super.dir[i]);
    putchar('\n');
}

/**
 * search and read file dirent/extent:
 * 	if ext==0: find 1st entry (with .st=TFILE)
 * 	if ext>0:  find extent (with .st=TEXT) and .ex==ext
 *  if ent!=NULL fill it with a copy of the dirent/extent
 *  return dirent index in the directory (or -1 if not found)
 */
int readFileEntry(char *name, uint16_t ext, struct fs_dirent *ent)
{
    union fs_block block;

    for (int dirblk = 0; dirblk < MAXDIRSZ && superB.dir[dirblk]; dirblk++)
    {
        int b = superB.dir[dirblk];
        disk_read(b, block.data);
        for (int j = 0; j < DIRENTS_PER_BLOCK; j++)
        {
            if ((((ext == 0 && block.dirent[j].st == TFILE)) &&
                 strncmp(block.dirent[j].name, name, FNAMESZ) == 0) ||
                (((block.dirent[j].st == TEXT && block.dirent[j].ex == ext)) &&
                 strncmp(block.dirent[j].name, name, FNAMESZ) == 0))
            {
                if (ent != NULL)
                    *ent = block.dirent[j];
                return dirblk * DIRENTS_PER_BLOCK + j; // this dirent index
            }
        }
    }

    return -1;
}

/**
 * update dirent at idx with 'entry' or, if idx==-1, add a new dirent to
 * directory with 'entry' content.
 * return: idx used/allocated, -1 if error (no space in directory)
 */
int writeFileEntry(int idx, int ext, struct fs_dirent entry)
{

    // TODO: (if needed)

    // update dirent idx or allocate a new one
    // and write to directory on disk

    // notice: directory may need to grow!!

    //Primeira fase!!

    union fs_block block;
    int numDirectories = 0;

    if (idx == -1)
    {
        for (int dirBlk = 0; dirBlk < MAXDIRSZ && idx == -1; dirBlk++)
        {
            int b = superB.dir[dirBlk];
            disk_read(b, block.data);
            if (b)
            {
                numDirectories++;
                for (int dir = 0; dir < DIRENTS_PER_BLOCK; dir++)
                {
                    if (block.dirent[dir].st == TEMPTY)
                    {
                        for (int i = 0; i < FBLOCKS; i++)
                            block.dirent[dir].blocks[i] = 0;
                        if (ext == 0)
                            entry.st = TFILE;
                        else
                            entry.st = TEXT;
                        entry.ex = ext;
                        block.dirent[dir] = entry;
                        disk_write(b, block.data);
                        return dirBlk * DIRENTS_PER_BLOCK + dir;
                    }
                }
            }
            else
            {
                int blockIndex = allocBlock();
                if (blockIndex == -1)
                    return -1;
                superB.dir[numDirectories] = blockIndex;
                dirBlk--;
            }
        }
    }
    else
    {
        int pos = 0;
        int numBlock = superB.dir[getDirentBlock(idx, &pos)];

        disk_read(numBlock, block.data);
        block.dirent[pos] = entry;
        disk_write(numBlock, block.data);

        return idx;
    }

    return -1;
}

/**
 * sets the correct sizes of the file and its dirents
 */
void setDirentSize(int numExtsNeeded, struct fs_dirent *dirent, int totalSize, char *fname)
{
    struct fs_dirent entry;

    int idx = readFileEntry(fname, 0, &entry);

    if (totalSize % 1024)
        entry.ss = totalSize - numExtsNeeded * FBLOCKS * 1024;
    else
        entry.ss = 1024;

    entry.ex = numExtsNeeded;

    writeFileEntry(idx, 0, entry);

    for (int i = 1; i < numExtsNeeded; i++)
    {
        idx = readFileEntry(fname, i, &entry);
        entry.ss = 1024 * FBLOCKS;
        entry.ex = i;
        writeFileEntry(idx, i, entry);
    }

    idx = readFileEntry(fname, numExtsNeeded, &entry);
    entry.ss = totalSize - numExtsNeeded * FBLOCKS * 1024;
    entry.ex = numExtsNeeded;

    *dirent = entry;
}

/****************************************************************/

int fs_delete(char *name)
{

    if (superB.magic != FS_MAGIC)
    {
        printf("disc not mounted\n");
        return -1;
    }
    char fname[FNAMESZ];
    strEncode(fname, name, FNAMESZ);

    // TODO: delete file: free it's dirent, extents and data blocks

    struct fs_dirent dirent;

    int idx = readFileEntry(fname, 0, &dirent);

    if (idx == -1)
        return -1;

    int numExs = dirent.ex;

    //Enquanto dirent.ex != 0
    while (numExs >= 0)
    {

        union fs_block extBlock;
        struct fs_dirent extDirent;
        int idxExt = readFileEntry(fname, numExs, &extDirent);

        if (idxExt == -1)
            return -1;

        int extPos = 0;
        int extNumBlock = superB.dir[getDirentBlock(idxExt, &extPos)];

        disk_read(extNumBlock, extBlock.data);
        extBlock.dirent[extPos].st = TEMPTY;
        extBlock.dirent[extPos].ex = 0;
        extBlock.dirent[extPos].ss = 0;
        for (int j = 0; j < FBLOCKS && extBlock.dirent[extPos].blocks[j]; j++)
            freeBlock(extBlock.dirent[extPos].blocks[j]);

        memset(&dirent, 0, sizeof(dirent));
        disk_write(extNumBlock, extBlock.data);
        numExs--;
    }
    return 0;
}

/*****************************************************/

void fs_dir()
{

    if (superB.magic != FS_MAGIC)
    {
        printf("disc not mounted\n");
        return;
    }

    // TODO: list files
    // printf( "%u: %s, size: %u bytes\n", dirent_number, file_name, file_size)

    union fs_block block;
    char decodedName[FNAMESZ];

    for (int dirBlk = 0; dirBlk < MAXDIRSZ && superB.dir[dirBlk]; dirBlk++)
    {
        int b = superB.dir[dirBlk];
        disk_read(b, block.data);
        for (int dir = 0; dir < DIRENTS_PER_BLOCK; dir++)
        {
            if (block.dirent[dir].st == TFILE)
            {
                strDecode(decodedName, block.dirent[dir].name, FNAMESZ);
                printf("%u: %s, size: %u bytes\n", getDirentNumber(dirBlk, dir), decodedName, getDirentSize(block.dirent[dir]));
            }
        }
    }
}

/*****************************************************/

void fs_debug()
{
    union fs_block block;

    disk_read(SBLOCK, block.data);

    if (block.super.magic != FS_MAGIC)
    {
        printf("disk unformatted !\n");
        return;
    }
    dumpSB();

    printf("**************************************\n");
    if (superB.magic == FS_MAGIC)
    {
        printf("Used blocks: ");
        for (int i = 0; i < superB.fssize; i++)
        {
            if (blockBitMap[i] == NOT_FREE)
                printf(" %d", i);
        }
        puts("\nFiles:\n");
        fs_dir();
    }
    printf("**************************************\n");
}

/*****************************************************/

int fs_format(char *disklabel)
{
    union fs_block block;
    int nblocks;

    assert(sizeof(struct fs_dirent) == 32);
    assert(sizeof(union fs_block) == BLOCKSZ);

    if (superB.magic == FS_MAGIC)
    {
        printf("Cannot format a mounted disk!\n");
        return 0;
    }
    if (sizeof(block) != DISK_BLOCK_SIZE)
    {
        printf("Disk block and FS block mismatch\n");
        return 0;
    }
    memset(&block, 0, sizeof(block));
    disk_write(1, block.data); // write 1st dir block all zeros

    nblocks = disk_size();
    block.super.magic = FS_MAGIC;
    block.super.fssize = nblocks;
    strEncode(block.super.label, disklabel, LABELSZ);
    block.super.dir[0] = 1; // block 1 is first dir block

    disk_write(0, block.data); // write superblock
    dumpSB();                  // debug

    return 1;
}

/*****************************************************************/

int fs_mount()
{
    union fs_block block;

    if (superB.magic == FS_MAGIC)
    {
        printf("One disc is already mounted!\n");
        return 0;
    }
    disk_read(0, block.data);
    superB = block.super;

    if (superB.magic != FS_MAGIC)
    {
        printf("cannot mount an unformatted disc!\n");
        return 0;
    }
    if (superB.fssize != disk_size())
    {
        printf("file system size and disk size differ!\n");
        return 0;
    }

    // build used blocks map
    blockBitMap = malloc(superB.fssize * sizeof(uint16_t));
    memset(blockBitMap, FREE, superB.fssize * sizeof(uint16_t));
    blockBitMap[0] = NOT_FREE; // 0 is used by superblock

    // TODO: blockBitMap[i]=NOT_FREE if block i is in use
    //       check all directory

    union fs_block otherBlock;

    for (int dirBlk = 0; dirBlk < MAXDIRSZ && superB.dir[dirBlk]; dirBlk++)
    {
        int b = superB.dir[dirBlk];
        blockBitMap[b] = NOT_FREE;
        disk_read(b, otherBlock.data);
        for (int dir = 0; dir < DIRENTS_PER_BLOCK; dir++)
        {
            if (otherBlock.dirent[dir].st == TFILE || otherBlock.dirent[dir].st == TEXT)
            {
                for (int j = 0; j < FBLOCKS && otherBlock.dirent[dir].blocks[j]; j++)
                    blockBitMap[otherBlock.dirent[dir].blocks[j]] = NOT_FREE;
            }
        }
    }

    return 1;
}

/************************************************************/
int fs_read(char *name, char *data, int length, int offset)
{

    if (superB.magic != FS_MAGIC)
    {
        printf("disc not mounted\n");
        return -1;
    }
    char fname[FNAMESZ];
    strEncode(fname, name, FNAMESZ);

    // TODO: read file data

    //Primeira fase!!!
    struct fs_dirent dirent;

    int startingBlock = offset / 1024;
    int startingPoint = offset % 1024;
    int direntSize = 0;
    int nextRound = 0;
    char auxData[1024];
    int numExts = 0;
    int numExtsReaded = 0;

    if (readFileEntry(fname, 0, &dirent) != -1)
    {
        direntSize = getDirentSize(dirent);
        numExts = dirent.ex;
        numExtsReaded = (startingBlock / FBLOCKS);

        if (offset > direntSize)
            return -1;

        if (direntSize == 0)
        {
            disk_read(dirent.blocks[startingBlock], data);
            length = 0;
        }

        while (numExtsReaded <= numExts)
        {

            while ((dirent.blocks[startingBlock] || numExtsReaded <= numExts) && offset < direntSize && nextRound < length && (offset + nextRound) < direntSize)
            {

                if ((offset + nextRound) == ((numExtsReaded + 1) * FBLOCKS * 1024))
                {
                    numExtsReaded++;
                    if (numExtsReaded > numExts)
                        return nextRound;
                    memset(&dirent, 0, sizeof(dirent));
                    if (readFileEntry(fname, numExtsReaded, &dirent) == -1)
                        return -1;
                }

                if (startingBlock > FBLOCKS - 1)
                {
                    startingBlock = startingBlock - (FBLOCKS * numExtsReaded);
                    if (startingBlock < 0)
                        startingBlock = 0;
                    if (readFileEntry(fname, numExtsReaded, &dirent) == -1)
                        return -1;
                }

                disk_read(dirent.blocks[startingBlock], auxData);
                if ((direntSize - offset) < 1024)
                {
                    memcpy(data, auxData + startingPoint, direntSize - offset);
                    nextRound = nextRound + (direntSize - offset);
                }
                else if ((length - nextRound) < 1024)
                {
                    memcpy(data + nextRound, auxData, length - nextRound);
                    nextRound = nextRound + (length - nextRound);
                }
                else
                {
                    memcpy(data, auxData + startingPoint, 1024 - startingPoint);
                    nextRound = nextRound + (1024 - startingPoint);
                }

                startingBlock++;
            }
            return nextRound;
        }
        return nextRound;
    }
    else
        return -1; // return read bytes or -1
}

/****************************************************************/

int fs_write(char *name, char *data, int length, int offset)
{

    if (superB.magic != FS_MAGIC)
    {
        printf("disc not mounted\n");
        return -1;
    }
    char fname[FNAMESZ];
    strEncode(fname, name, FNAMESZ);

    // TODO: write data to file

    struct fs_dirent dirent;

    int startingBlock = (offset / 1024) % FBLOCKS;
    int startingPoint = offset % 1024;
    int nextRound = 0;
    int numExtsNeeded = startingBlock / FBLOCKS;
    int idx = readFileEntry(fname, numExtsNeeded, &dirent);

    if (idx == -1)
    {
        memset(&dirent, 0, sizeof(dirent));
        strncpy(dirent.name, fname, FNAMESZ);
        dirent.blocks[startingBlock] = allocBlock();
        if (dirent.blocks[startingBlock] == -1)
            return nextRound;
    }

    if (length == 0 && offset == 0)
    {
        if (dirent.blocks[startingBlock] == 0)
        {
            dirent.blocks[startingBlock] = allocBlock();
            if (dirent.blocks[startingBlock] == -1)
                return nextRound;
        }

        writeFileEntry(idx, numExtsNeeded, dirent);
        return nextRound;
    }

    while (nextRound < length)
    {
        char auxData[1024];
        printf("DIRENT STATUS: %d %d %d\n", length, offset, nextRound);

        if ((offset + nextRound) == ((numExtsNeeded + 1) * FBLOCKS * 1024))
        {
            numExtsNeeded++;
            memset(&dirent, 0, sizeof(dirent));
            strncpy(dirent.name, fname, FNAMESZ);
            idx = -1;
        }

        if (startingBlock > FBLOCKS - 1)
        {
            startingBlock = startingBlock - (FBLOCKS * numExtsNeeded);
            if (startingBlock < 0)
                startingBlock = 0;
        }

        if (dirent.blocks[startingBlock] == 0)
        {
            dirent.blocks[startingBlock] = allocBlock();
            if (dirent.blocks[startingBlock] == -1)
                return nextRound;
        }

        if (dirent.blocks[startingBlock] > superB.fssize)
        {
            dirent.ss = dirent.ss + nextRound;
            int totalSize = numExtsNeeded * FBLOCKS * 1024 + (startingBlock * 1024) + nextRound + startingPoint;
            setDirentSize(numExtsNeeded, &dirent, totalSize, fname);
            return nextRound;
        }

        printf("AQUIDENTRO %d %d %d %d\n", nextRound, startingBlock, length, startingPoint);
        disk_read(dirent.blocks[startingBlock], auxData);

        if ((1024 - startingPoint) > length)
        {
            memcpy(auxData + startingPoint, data, length);
            nextRound = length;
        }
        else if ((length - nextRound) < 1024)
        {
            memcpy(auxData, data + nextRound, length - nextRound);
            nextRound = nextRound + (length - nextRound);
        }
        else
        {
            memcpy(auxData + startingPoint, data, 1024 - startingPoint);
            nextRound = nextRound + (1024 - startingPoint);
        }

        disk_write(dirent.blocks[startingBlock], auxData);

        startingBlock++;
    }

    if (nextRound)
    {
        dirent.ss = dirent.ss + nextRound;
        if ((nextRound - length) == 0 && nextRound <= 1024)
        {
            int totalSize = numExtsNeeded * FBLOCKS * 1024 + ((startingBlock - 1) * 1024) + nextRound + startingPoint;
            setDirentSize(numExtsNeeded, &dirent, totalSize, fname);
        }
        writeFileEntry(idx, numExtsNeeded, dirent);
    }

    return nextRound;
}
