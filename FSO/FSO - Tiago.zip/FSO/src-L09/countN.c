#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>
#include <pthread.h>

#define SIZE (200 * 1024 * 1024)
#define NTHREADS 2

int *array;
int count = 0;
int tofind = 3;
int size;
pthread_mutex_t mex = PTHREAD_MUTEX_INITIALIZER;

//recebemos uma parte do array como argumento
void *docount(void *arg)
{
	int *arr = (int *)arg;
	long c = 0;
	// passamos um inicio diferente para o mesmo array.
	// era como se dividissemos o array em varios arrays
	for (int i = 0; i < size; i++)
	{
		if (arr[i] == tofind)
		{
			//com multiplos threads temos recursos partilhados
			//as variaveis que deveriam ser alteradas, estao a ser mal alteradas!
			//damos cabo do uso da cache (quando temos mais que um CPU, o que e escrito numa cache,
			//invalida a da outra, o que aumenta o tempo de execucao)
			//pthread_mutex_lock(&mex)
			c++; //como esta entre o lock e o unlock, isto e uma regiao critica. nao permite alteracoes simultaneas
				 //pthread_mutex_unlock(&mex);
		}
	}
	return (void *)c;
}

int main(int argc, char *argv[])
{
	struct timeval t1, t2;

	array = (int *)malloc(SIZE * sizeof(int));
	tofind = 3;

	srand(0);
	for (int i = 0; i < SIZE; i++)
	{
		array[i] = rand() % 4;
	}

	size = SIZE / 2;
	gettimeofday(&t1, NULL);

	pthread_t threads[NTHREADS];

	for (int i = 0; i < NTHREADS; i++)
	{
		if (i == 0)
			pthread_create(&threads[i], NULL, docount, (int *)(array));
		else
			pthread_create(&threads[i], NULL, docount, (int *)(array + size));
	}

	//temos que esperar pelo fim dos threads, de forma a que o processo do docount esteja realmente acabado
	for (int i = 0; i < NTHREADS; i++)
	{
		int cc;
		pthread_join(threads[i], (void *)&cc); // o valor retornado pela funcao à qual o thread foi chamado é guardado em <code>cc</code>
		count += cc;
	}
	pthread_mutex_destroy(&mex);

	gettimeofday(&t2, NULL);

	printf("Count of %d = %d\n", tofind, count);
	printf("Elapsed time (ms) = %lf\n",
		   ((t2.tv_sec - t1.tv_sec) * 1000000 + (t2.tv_usec - t1.tv_usec)) / 1000.0);

	return 0;
}
