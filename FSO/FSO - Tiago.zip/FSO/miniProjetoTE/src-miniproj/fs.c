
#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <assert.h>

#include "disk.h"
#include "fs.h"

#define MIN(X, Y) ((X) > (Y) ? (Y) : (X))

/*******
 * FSO OFS layout (there is no bootBlock)
 * FS block size = disk block size (1KB)
 * block#	| content
 * 0		| super block (with list of dir blocks)
 * 1		| first data block (usualy with 1st block of dir entries)
 * ...      | other dir blocks and files data blocks
 */

#define BLOCKSZ (DISK_BLOCK_SIZE)
#define SBLOCK 0          // superblock is at disk block 0
#define FS_MAGIC (0xf0f0) // for OFS
#define FNAMESZ 11        // file name size
#define LABELSZ 12        // disk label size
#define MAXDIRSZ 504      // max entries in the directory (1024-4-LABELSZ)/2

#define DIRENTS_PER_BLOCK (BLOCKSZ / sizeof(struct fs_dirent))
#define FBLOCKS 8 // 8 block indexes in each dirent

/* dirent .st field values: */
#define TFILE 0x10  // is file dirent
#define TEMPTY 0x00 // not used/free
#define TEXT 0xff   // is extent

#define FALSE 0
#define TRUE 1

#define FREE 0
#define NOT_FREE 1


//formato das estruturas


/*** FSO Old/Our FileSystem disk layout ***/

struct fs_dirent { // a directory entry (dirent/extent)
    uint8_t st; 
    char name[FNAMESZ];
    uint16_t ex; // numb of extra extents or id of this extent
    uint16_t ss; // number of bytes in the last extent (can be this dirent)
    uint16_t
        blocks[FBLOCKS]; // disk blocks with file content (zero value = empty)
};
 
struct fs_sblock { // the super block tem todos os blocos que fazem parte da diretoria
    uint16_t magic;         //that is used to verify if the file image is a OFS formatted disk
    uint16_t fssize;        // total number of blocks (including this sblock)
    char label[LABELSZ];    // disk label
    uint16_t dir[MAXDIRSZ]; // directory blocks (zero value = empty)  -- dir -- variavel que tem tds os tipos (vantagem) pode ser usado para ler qlq conteudo do bloco -- evita warnings e casts

// uint16 -- tipo de dados e a maneira que permite ter os int e ter a dimensao fixas (nao interessa se e de 16, 32, 64)
};

/**
 * Nota: considerando o numero de ordem dos dirent em todos os blocos da
 * directoria um ficheiro pode ser identificado pelo numero do seu dirent. Tal
 * e' usado pelo open, create, read e write.
 */

union fs_block { // generic fs block. Can be seen with all these formats
    struct fs_sblock super;
    struct fs_dirent dirent[DIRENTS_PER_BLOCK];
    char data[BLOCKSZ];
};

/*******************************************/

struct fs_sblock superB; // superblock of the mounted disk

uint8_t *blockBitMap; // Map of used blocks (not a real bitMap, more a byteMap)
                      // this is build by mount operation, reading all the directory  so utilizar quando for para implementar a operacao de escrita

/*******************************************/
/* The following functions may be usefull
 * change these and implement others that you need
 */

/**
 * allocBlock: allocate a new disk block
 * return: block number
 */
int allocBlock() {
    int i;

    for (i = 0; i < superB.fssize && blockBitMap[i] == NOT_FREE; i++)
        ;
    if (i < superB.fssize) {
        blockBitMap[i] = NOT_FREE;
        return i;
    } else
        return -1; // no disk space
}

/**
 */
void freeBlock(int nblock) {
    blockBitMap[nblock] = FREE;
}

/**
 * copy str to dst, converting from C string to FS string:
 *   - uppercase letters and ending with spaces
 * dst and str must exist with at least len chars
 */
void strEncode(char *dst, char *str, int len) {
    int i;
    for (i = 0; i < len && str[i] != '\0'; i++)
        if (isalpha(str[i]))
            dst[i] = toupper(str[i]);
        else if (isdigit(str[i]) || str[i] == '_' || str[i] == '.')
            dst[i] = str[i];
        else
            dst[i] = '?'; // invalid char?
    for (; i < len; i++)
        dst[i] = ' '; // fill with space
}//guarda os nomes, guardamos os caracteres -- converter de c para ficheiros-- este metodo faz isso 

/**
 * copy str to dst, converting from FS string to C string
 * dst must exist with at least len+1 chars
 */
void strDecode(char *dst, char *str, int len) {
    int i;
    for (i = len - 1; i > 0 && str[i] == ' '; i--)
        ;
    dst[i + 1] = '\0';
    for (; i >= 0; i--)
        dst[i] = str[i];
}

/**
 * print super block content to stdout (for debug)
 */
void dumpSB() {  //funcao usada pelo debug -- ler o bloco do disco, ver a informacao que la esta
    union fs_block block;
    char label[LABELSZ + 1];

    disk_read(SBLOCK, block.data);
    printf("superblock:\n");
    printf("    magic = %x\n", block.super.magic);
    printf("    %d blocks\n", block.super.fssize);
    printf("    dir_size: %d\n", MAXDIRSZ);
    printf("    first dir block: %d\n", block.super.dir[0]);
    strDecode(label, block.super.label, LABELSZ);
    printf("    disk label: %s\n", label);

    printf("dir blocks: ");
    for (int i = 0; block.super.dir[i] != 0; i++)
        printf("%d ", block.super.dir[i]);
    putchar('\n');
}

/**
 * search and read file dirent/extent:
 *  if ext==0: find 1st entry (with .st=TFILE)
 *  if ext>0:  find extent (with .st=TEXT) and .ex==ext
 *  if ent!=NULL fill it with a copy of the dirent/extent
 *  return dirent index in the directory (or -1 if not found)
 */
int readFileEntry(char *name, uint16_t ext, struct fs_dirent *ent) { // devolve um numero do dirente
    union fs_block block;

    for (int dirblk = 0; dirblk < MAXDIRSZ && superB.dir[dirblk]; dirblk++) { //!=0
        int b = superB.dir[dirblk];
        disk_read(b, block.data);
        for (int j = 0; j < DIRENTS_PER_BLOCK; j++)
            if ((((ext == 0 && block.dirent[j].st == TFILE)) &&
                 strncmp(block.dirent[j].name, name, FNAMESZ) == 0) ||
                (((block.dirent[j].st == TEXT && block.dirent[j].ex == ext)) &&
                 strncmp(block.dirent[j].name, name, FNAMESZ) == 0)) {
                if (ent != NULL)
                    *ent = block.dirent[j];
                return dirblk * DIRENTS_PER_BLOCK + j; // this dirent index
            }
    }

    return -1;
}


/**
 * update dirent at idx with 'entry' or, if idx==-1, add a new dirent to
 * directory with 'entry' content.
 * return: idx used/allocated, -1 if error (no space in directory)
 */
int writeFileEntry(int idx, struct fs_dirent entry) {

    // TODO: (if needed)

    // update dirent idx or allocate a new one
    // and write to directory on disk

    // notice: directory may need to grow!!


    return idx;
}

/****************************************************************/

int fs_delete(char *name) {

    if (superB.magic != FS_MAGIC) {
        printf("disc not mounted\n");
        return -1;
    }
    char fname[FNAMESZ];
    strEncode(fname, name, FNAMESZ);
    union fs_block block; 

    // TODO: delete file: free it's dirent, extents and data blocks

   for (int dirblk = 0; dirblk < MAXDIRSZ && superB.dir[dirblk]; dirblk++) { 
        int b = superB.dir[dirblk]; 
        disk_read(b, block.data);
        for (int j = 0; j < DIRENTS_PER_BLOCK; j++){
             if ((((block.dirent[j].ex == 0 && block.dirent[j].st == TFILE)) &&
                 strncmp(block.dirent[j].name, fname, FNAMESZ) == 0)){
                block.dirent[j].st = TEMPTY;
                for(int i = 0; i < FBLOCKS && block.dirent[j].blocks[i]; i++){
                    freeBlock(block.dirent[j].blocks[i]);
                }
                disk_write(b, block.data);
                return 0;
            }      
        }
    }    
   return -1;

}

/*****************************************************/

void fs_dir() {

    if (superB.magic != FS_MAGIC) {
        printf("disc not mounted\n");
        return;
    }

union fs_block block;
    // TODO: list files
    // printf( "%u: %s, size: %u bytes\n", dirent_number, file_name, file_size)

 for (int dirblk = 0; dirblk < MAXDIRSZ && superB.dir[dirblk]; dirblk++) { 
        int b = superB.dir[dirblk];
        disk_read(b, block.data);
        for (int j = 0; j < DIRENTS_PER_BLOCK; j++){
            if (block.dirent[j].st == TFILE) {
                char name [FNAMESZ];
                strDecode(name ,block.dirent[j].name,  FNAMESZ );
                printf( "%u: %s, size: %u bytes\n", (unsigned int) (dirblk * DIRENTS_PER_BLOCK + j), name, block.dirent[j].ex * FBLOCKS * 1024 + block.dirent[j].ss);
            }               
		}
	}
}
//imprimir os nomes de todos os blocos dirents




/*****************************************************/

void fs_debug() {
    union fs_block block;

    disk_read(SBLOCK, block.data);

    if (block.super.magic != FS_MAGIC) {
        printf("disk unformatted !\n");
        return;
    }
    dumpSB();

    printf("**************************************\n");
    if (superB.magic == FS_MAGIC) {
        printf("Used blocks: ");
        for (int i = 0; i < superB.fssize; i++) {
            if (blockBitMap[i] == NOT_FREE)
                printf(" %d", i);
        }
        puts("\nFiles:\n");
        fs_dir();
    }
    printf("**************************************\n");
}

/*****************************************************/

int fs_format(char *disklabel) {
    union fs_block block;
    int nblocks;

    assert(sizeof(struct fs_dirent) == 32);
    assert(sizeof(union fs_block) == BLOCKSZ);

    if (superB.magic == FS_MAGIC) {
        printf("Cannot format a mounted disk!\n");
        return 0;
    }
    if (sizeof(block) != DISK_BLOCK_SIZE) {
        printf("Disk block and FS block mismatch\n");
        return 0;
    }
    memset(&block, 0, sizeof(block));
    disk_write(1, block.data); // write 1st dir block all zeros

    nblocks = disk_size();
    block.super.magic = FS_MAGIC;
    block.super.fssize = nblocks;
    strEncode(block.super.label, disklabel, LABELSZ);
    block.super.dir[0] = 1; // block 1 is first dir block

    disk_write(0, block.data);  // write superblock
    dumpSB(); // debug

    return 1;
}

/*****************************************************************/

int fs_mount() {
    union fs_block otherBlock;

    if (superB.magic == FS_MAGIC) {
        printf("One disc is already mounted!\n");
        return 0;
    }
    disk_read(0, otherBlock.data);
    superB = otherBlock.super;

    if (superB.magic != FS_MAGIC) {
        printf("cannot mount an unformatted disc!\n");
        return 0;
    }
    if (superB.fssize != disk_size()) {
        printf("file system size and disk size differ!\n");
        return 0;
    }

    // build used blocks map
    blockBitMap = malloc(superB.fssize * sizeof(uint16_t));
    memset( blockBitMap, FREE, superB.fssize*sizeof(uint16_t));
    blockBitMap[0] = NOT_FREE; // 0 is used by superblock

    // TODO: blockBitMap[i]=NOT_FREE if block i is in use
    //       check all directory

    union fs_block block;

    for (int dirblk = 0; dirblk < MAXDIRSZ && superB.dir[dirblk]; dirblk++) { 
        int b = superB.dir[dirblk];
        blockBitMap[b] = NOT_FREE; 
        disk_read(b, block.data);
        for (int j = 0; j < DIRENTS_PER_BLOCK; j++){
            if(block.dirent[j].st == TFILE || block.dirent[j].st == TEXT){
              for(int i = 0; i < FBLOCKS && block.dirent[j].blocks[i]; i++){
                  blockBitMap[block.dirent[j].blocks[i]]=NOT_FREE;
              }
            }        
        }
    }
    return 1;
}

/************************************************************/



int fs_read(char *name, char *data, int length, int offset) {

    if (superB.magic != FS_MAGIC) {
        printf("disc not mounted\n");
        return -1;
    }
    char fname[FNAMESZ];
    strEncode(fname, name, FNAMESZ);


    // TODO: read file data

    int startP = offset/ 1024;
    int offsetInsideBlock = offset % 1024;
    int frontOffset = 0;

    struct fs_dirent dirent ;

    if (readFileEntry (fname, 0, &dirent) != -1){

        if(offset > dirent.ss){
            return -1;
        }

        if((dirent.ss - offset) < length )
            length = dirent.ss - offset;


        for ( int i = startP; dirent.blocks[i] && length; i++){
            char aux[1024];
            disk_read(dirent.blocks[i], aux);

            if(offsetInsideBlock){

                if ( (offsetInsideBlock + length) < 1024){
                    memcpy(data, aux + offsetInsideBlock, length);
                    frontOffset = frontOffset + length;
                    length = 0;
                }
                else{
                    memcpy(data, aux + offsetInsideBlock, 1024 - offsetInsideBlock);
                 length = length - ( 1024 - offsetInsideBlock);
                 frontOffset = frontOffset + (1024 - offsetInsideBlock);

                }
                offsetInsideBlock = 0;
            

            }else if (length < 1024){
                memcpy(data + frontOffset, aux, length);
                frontOffset = frontOffset + length;
                length = 0;


            }else{
                memcpy (data + frontOffset, aux, 1024);
                frontOffset = frontOffset + 1024;
                length = length - 1024;

            } 

       }
            return frontOffset;           
    }
    else{
        return -1;
    }    

 // return read bytes or -1
}

/****************************************************************/




// o ficheiro tem que ser formatado antes de ser mounted , ou seja temos que verificar se e mounted e so se for mounted e que se pode criar, escrever ou ler

int fs_write(char *name, char *data, int length, int offset) {

    if (superB.magic != FS_MAGIC) {
        printf("disc not mounted\n");
        return -1;
    }
    char fname[FNAMESZ];
    strEncode(fname, name, FNAMESZ);

     struct fs_dirent dirent ;

    if (readFileEntry (fname, 0, &dirent) != -1){




    }


    return -1; // return writen bytes or -1
}
