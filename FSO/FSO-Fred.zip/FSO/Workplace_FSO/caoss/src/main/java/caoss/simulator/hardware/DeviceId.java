package caoss.simulator.hardware;

public enum DeviceId {

	TIMER,
	DUMMY
}
