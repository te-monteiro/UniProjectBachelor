//Ficheiro para tratamento dos resultados das contagens

#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/select.h>

#include "process.h"


/**
 * process the replies arraiving from all pipes
 * should read each pipe (any pipe) as soon data
 * is available in it (or if pipe is closed)
 * in: nprocs = number of workers (size of pipes array)
 *     pipes = filedescriptors for all pipes connected to workers
 * return: sum of all counters received
 */
int process_workers_reply(int nprocs, int pipes[nprocs]) {
	int count = 0;
	// TODO:
	int max = pipes[nprocs - 1] + 1;
	for(int i = 0; i < nprocs;){

		fd_set readFDs;
		FD_ZERO(&readFDs);
		for(int fd = 0; fd < nprocs; fd++){
			if(pipes[fd] != -1) 
				FD_SET(pipes[fd],&readFDs);
		}
		int numberOfReady = select(max, &readFDs,NULL,NULL,NULL);
		int fd;
		if(numberOfReady != -1){

			i += numberOfReady;
			while(numberOfReady != 0){
				for(fd = 0; fd < nprocs ;fd++){
					if (pipes[fd] != -1 && FD_ISSET(pipes[fd], &readFDs)) break;
				}
				int c;
				int nr = read(pipes[fd], &c, sizeof(int));
				 
				close(pipes[fd]);
				if( nr > 0 ){
					printf("reply received from worker %d count: %d\n", fd, c);
					count += c;
				}else 
					printf("pipe to worker %d was closed\n", fd);
				pipes[fd] = -1;
				numberOfReady--;
			}
		}

	}

	return count;
}

// for(fd = 0; FD_ISSET(pipes[fd], &readFDs) == -1;fd++);