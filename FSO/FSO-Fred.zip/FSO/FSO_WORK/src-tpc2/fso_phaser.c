
#include "fso_phaser.h"

#include <assert.h>

#include "pthread_to_pos.h"

#include <stdlib.h>

#include <stdio.h>

#include <string.h>


int fso_phaser_init(fso_phaser_t* phaser, int number_threads) {

	assert(number_threads > 0);

	int result;
	if ((result = pthread_mutex_init(&phaser->mutex, NULL)) < 0) 
		return result;

	if ((result = pthread_cond_init(&phaser->cond, NULL)) < 0) {
		pthread_mutex_destroy(&phaser->mutex);
		return result;
	}

	phaser->number_threads = number_threads;	
	phaser->phases = (int *) malloc(sizeof(int) * number_threads);
	memset(phaser->phases, 0, sizeof(int) * number_threads);
	return 0;		
}

int fso_phaser_current(fso_phaser_t* phaser) {

	int result;
	
	//TODO 
	// initialize minimum to first element in array
	result = phaser->phases[0];
	
	// for each other thread check wether there is an element / phase with a smaller value
	// than current minimum , result 
	for(int i = 1; i < phaser->number_threads ; i++){
		int threadPhase = phaser->phases[i];

		// has found minimum
		// true - updates result to new minimum value of phase
		if(threadPhase < result){
			result = threadPhase;
		}
	}

	return result;	
}

int fso_phaser_advance_and_await(fso_phaser_t* phaser) {

	int result = 0;
	// TODO
	pthread_mutex_lock(&phaser->mutex); 
		// find position in array of phaser that corresponds to thread Id
		int index_in_phase_array = pthread_to_pos(pthread_self());
		// increment phase of thread in phases array
		int phaseOfThread = phaser->phases[index_in_phase_array] += 1;
		// aknowledge other threads that this thread has reached another phase
		result = pthread_cond_broadcast(&phaser->cond);
		// wait until all threads have reached same phase
		while(fso_phaser_current(phaser) < phaseOfThread) {
			pthread_cond_wait(&phaser->cond, &phaser->mutex);
		}
		
	pthread_mutex_unlock(&phaser->mutex);
	return result;
}

int fso_phaser_advance(fso_phaser_t* phaser) {

	int result;

	// TODO

	pthread_mutex_lock(&phaser->mutex);
		// find position in array of phaser that corresponds to thread Id
		int index_in_phase_array = pthread_to_pos(pthread_self());
		// increment phase of thread in phases array
		phaser->phases[index_in_phase_array] += 1;
		// aknowledge other threads that this thread has reached another phase
		result = pthread_cond_broadcast(&phaser->cond);
	pthread_mutex_unlock(&phaser->mutex);
	
	return result;
}

int fso_phaser_destroy(fso_phaser_t* phaser) {

	int result;
	if ((result = pthread_mutex_destroy(&phaser->mutex)) < 0) 
		return result;

	if ((result = pthread_cond_destroy(&phaser->cond)) < 0) 
		return result;

	free(phaser->phases);
	return 0;	
}
