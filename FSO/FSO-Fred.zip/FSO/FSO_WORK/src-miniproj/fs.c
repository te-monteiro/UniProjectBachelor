#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <assert.h>

#include "disk.h"
#include "fs.h"

#define MIN(X, Y) ((X) > (Y) ? (Y) : (X))

/*******
 * FSO OFS layout (there is no bootBlock)
 * FS block size = disk block size (1KB)
 * block#	| content
 * 0		| super block (with list of dir blocks)
 * 1		| first data block (usualy with 1st block of dir entries)
 * ...      | other dir blocks and files data blocks
 */

#define BLOCKSZ (DISK_BLOCK_SIZE)
#define SBLOCK 0          // superblock is at disk block 0
#define FS_MAGIC (0xf0f0) // for OFS
#define FNAMESZ 11        // file name size
#define LABELSZ 12        // disk label size
#define MAXDIRSZ 504      // max entries in the directory (1024-4-LABELSZ)/2

#define DIRENTS_PER_BLOCK (BLOCKSZ / sizeof(struct fs_dirent))
#define FBLOCKS 8 // 8 block indexes in each dirent

/* dirent .st field values: */
#define TFILE 0x10  // is file dirent
#define TEMPTY 0x00 // not used/free
#define TEXT 0xff   // is extent

#define FALSE 0
#define TRUE 1

#define FREE 0
#define NOT_FREE 1

/*** FSO Old/Our FileSystem disk layout ***/

struct fs_dirent { // a directory entry (dirent/extent)
    uint8_t st;
    char name[FNAMESZ];
    uint16_t ex; // numb of extra extents or id of this extent
    uint16_t ss; // number of bytes in the last extent (can be this dirent)
    uint16_t
        blocks[FBLOCKS]; // disk blocks with file content (zero value = empty)
};

struct fs_sblock { // the super block
    uint16_t magic;
    uint16_t fssize;        // total number of blocks (including this sblock)
    char label[LABELSZ];    // disk label
    uint16_t dir[MAXDIRSZ]; // directory blocks (zero value = empty)
};

/**
 * Nota: considerando o numero de ordem dos dirent em todos os blocos da
 * directoria um ficheiro pode ser identificado pelo numero do seu dirent. Tal
 * e' usado pelo open, create, read e write.
 */

union fs_block { // generic fs block. Can be seen with all these formats
    struct fs_sblock super;
    struct fs_dirent dirent[DIRENTS_PER_BLOCK];
    char data[BLOCKSZ];
};

/*******************************************/

struct fs_sblock superB; // superblock of the mounted disk

uint8_t *blockBitMap; // Map of used blocks (not a real bitMap, more a byteMap)
                      // this is build by mount operation, reading all the directory

/*******************************************/
/* The following functions may be usefull
 * change these and implement others that you need
 */

/**
 * allocBlock: allocate a new disk block
 * return: block number
 */
int allocBlock() {
    int i;

    for (i = 0; i < superB.fssize && blockBitMap[i] == NOT_FREE; i++)
        ;
    if (i < superB.fssize) {
        blockBitMap[i] = NOT_FREE;
        return i;
    } else
        return -1; // no disk space
}

/**
 */
void freeBlock(int nblock) {
    blockBitMap[nblock] = FREE;
}

/**
 * copy str to dst, converting from C string to FS string:
 *   - uppercase letters and ending with spaces
 * dst and str must exist with at least len chars
 */
void strEncode(char *dst, char *str, int len) {
    int i;
    for (i = 0; i < len && str[i] != '\0'; i++)
        if (isalpha(str[i]))
            dst[i] = toupper(str[i]);
        else if (isdigit(str[i]) || str[i] == '_' || str[i] == '.')
            dst[i] = str[i];
        else
            dst[i] = '?'; // invalid char?
    for (; i < len; i++)
        dst[i] = ' '; // fill with space
}

/**
 * copy str to dst, converting from FS string to C string
 * dst must exist with at least len+1 chars
 */
void strDecode(char *dst, char *str, int len) {
    int i;
    for (i = len - 1; i > 0 && str[i] == ' '; i--)
        ;
    dst[i + 1] = '\0';
    for (; i >= 0; i--)
        dst[i] = str[i];
}

/**
 * print super block content to stdout (for debug)
 */
void dumpSB() {
    union fs_block block;
    char label[LABELSZ + 1];

    disk_read(SBLOCK, block.data);
    printf("superblock:\n");
    printf("    magic = %x\n", block.super.magic);
    printf("    %d blocks\n", block.super.fssize);
    printf("    dir_size: %d\n", MAXDIRSZ);
    printf("    first dir block: %d\n", block.super.dir[0]);
    strDecode(label, block.super.label, LABELSZ);
    printf("    disk label: %s\n", label);

    printf("dir blocks: ");
    for (int i = 0; block.super.dir[i] != 0; i++)
        printf("%d ", block.super.dir[i]);
    putchar('\n');
}

/**
 * search and read file dirent/extent:
 * 	if ext==0: find 1st entry (with .st=TFILE)
 * 	if ext>0:  find extent (with .st=TEXT) and .ex==ext
 *  if ent!=NULL fill it with a copy of the dirent/extent
 *  return dirent index in the directory (or -1 if not found)
 */
int readFileEntry(char *name, uint16_t ext, struct fs_dirent *ent) {
    union fs_block block;

    for (int dirblk = 0; dirblk < MAXDIRSZ && superB.dir[dirblk]; dirblk++) {
        int b = superB.dir[dirblk];
        disk_read(b, block.data);
        for (int j = 0; j < DIRENTS_PER_BLOCK; j++)
            if ((((ext == 0 && block.dirent[j].st == TFILE)) &&
                 strncmp(block.dirent[j].name, name, FNAMESZ) == 0) ||
                (((block.dirent[j].st == TEXT && block.dirent[j].ex == ext)) &&
                 strncmp(block.dirent[j].name, name, FNAMESZ) == 0)) {
                if (ent != NULL)
                    *ent = block.dirent[j];
                return dirblk * DIRENTS_PER_BLOCK + j; // this dirent index
            }
    }

    return -1;
}

/**
 * update dirent at idx with 'entry' or, if idx==-1, add a new dirent to
 * directory with 'entry' content.
 * return: idx used/allocated, -1 if error (no space in directory)
 */
int writeFileEntry(int idx, struct fs_dirent entry) {

    // TODO: (if needed)

    // update dirent idx or allocate a new one
    // and write to directory on disk

    // notice: directory may need to grow!!

    union fs_block block;
    int b;

    if (idx != -1){

        b = superB.dir[idx / DIRENTS_PER_BLOCK];
        disk_read(b, block.data);
        int indexOfDirentInBlock = idx - (idx / DIRENTS_PER_BLOCK) * DIRENTS_PER_BLOCK;
        block.dirent[ indexOfDirentInBlock ] = entry;
        disk_write(b, block.data);
        return idx;

    }
	if(entry.ex != 0) {
		for (int dirblk2 = 0; dirblk2 < MAXDIRSZ && superB.dir[dirblk2]; dirblk2++) {
                union fs_block block2;
                int c = superB.dir[dirblk2];
                disk_read(c, block2.data);
                    for (int a = 0; a < DIRENTS_PER_BLOCK; a++) {
                        if(block2.dirent[a].st != TEMPTY && strncmp(block2.dirent[a].name, entry.name, FNAMESZ) == 0)
                            block2.dirent[a].ss = 0;
                    }
                disk_write(c, block2.data);
                }
	}
	else
		entry.ss = 0;
	
			
	for(int i = 0; i < FBLOCKS; i++){
            entry.blocks[i] = 0;
	}
	
	entry.ss = 0;
	
    for (int dirblk = 0; dirblk < MAXDIRSZ && superB.dir[dirblk]; dirblk++) {
            b = superB.dir[dirblk];
            disk_read(b, block.data);
            for (int j = 0; j < DIRENTS_PER_BLOCK; j++){
                if(block.dirent[j].st == TEMPTY){
                    block.dirent[j] = entry;
                    disk_write(b, block.data);
                    return b * DIRENTS_PER_BLOCK + j;
                }
            }
    }

    int newBlock = allocBlock();
    if(newBlock == -1){
        return -1;
    }
    int dirblk = 0;
    for (; dirblk < MAXDIRSZ && superB.dir[dirblk]; dirblk++) {
            b = superB.dir[dirblk];
            if (b == 0) break;
    }
    superB.dir[dirblk] = newBlock;
    disk_read(newBlock, block.data);
    block.dirent[0] = entry;
    disk_write(newBlock, block.data);
    blockBitMap[newBlock] = NOT_FREE;
    //idx - DIRENTS_PER_BLOCK * direntBlockCounter

    return dirblk * DIRENTS_PER_BLOCK;

}

/****************************************************************/

int fs_delete(char *name) {

    if (superB.magic != FS_MAGIC) {
        printf("disc not mounted\n");
        return -1;
    }
    char fname[FNAMESZ];
    strEncode(fname, name, FNAMESZ);

    // TODO: delete file: free it's dirent, extents and data blocks

	// struct fs_dirent *dirent;
	union fs_block zero;
    union fs_block block;
	memset(&zero, 0, BLOCKSZ);

	int direntIndex = readFileEntry(fname, 0, NULL);
	if(direntIndex != -1) {

        for (int dirblk = 0; dirblk < MAXDIRSZ && superB.dir[dirblk]; dirblk++) {
            int b = superB.dir[dirblk];
            disk_read(b, block.data);
            for (int j = 0; j < DIRENTS_PER_BLOCK; j++){
                if(block.dirent[j].st != TEMPTY && strncmp(block.dirent[j].name, fname, FNAMESZ) == 0) {
                    block.dirent[j].st = TEMPTY;
                    block.dirent[j].ex = FREE;
                    block.dirent[j].ss = FREE;

                    for(int i = 0; i < FBLOCKS; i++) {
                        int blockIndex = block.dirent[j].blocks[i];
                        if(blockIndex != 0){
                            disk_write(blockIndex, zero.data);
                            block.dirent[j].blocks[i] = FREE;
                            freeBlock(blockIndex);
                        }
                    }
					disk_write(b, block.data);
                }
            }
        }
        return 0;
	}

    return 1;
}

/*****************************************************/

void fs_dir() {
 
    if (superB.magic != FS_MAGIC) {
        printf("disc not mounted\n");
        return;
    }

    // TODO: list files
	union fs_block block;

    for (int dirblk = 0; dirblk < MAXDIRSZ && superB.dir[dirblk]; dirblk++) {
        int b = superB.dir[dirblk];
        disk_read(b, block.data);
        for (int j = 0; j < DIRENTS_PER_BLOCK; j++){
    			if(block.dirent[j].st == TFILE) {
    				unsigned int dirent_number = dirblk * DIRENTS_PER_BLOCK + j;
    				char file_name[FNAMESZ];
    				strDecode(file_name, block.dirent[j].name, FNAMESZ);
    				int file_size = ((8 * BLOCKSZ) * block.dirent[j].ex) + block.dirent[j].ss;

    				printf( "%u: %s, size: %u bytes\n", dirent_number, file_name, file_size);
    			}
  		  }
	}

}

/*****************************************************/

void fs_debug() {
    union fs_block block;

    disk_read(SBLOCK, block.data);

    if (block.super.magic != FS_MAGIC) {
        printf("disk unformatted !\n");
        return;
    }
    dumpSB();

    printf("**************************************\n");
    if (superB.magic == FS_MAGIC) {
        printf("Used blocks: ");
        for (int i = 0; i < superB.fssize; i++) {
            if (blockBitMap[i] == NOT_FREE)
                printf(" %d", i);
        }
        puts("\nFiles:\n");
        fs_dir();
    }
    printf("**************************************\n");
}

/*****************************************************/

int fs_format(char *disklabel) {
    union fs_block block;
    int nblocks;

    assert(sizeof(struct fs_dirent) == 32);
    assert(sizeof(union fs_block) == BLOCKSZ);

    if (superB.magic == FS_MAGIC) {
        printf("Cannot format a mounted disk!\n");
        return 0;
    }
    if (sizeof(block) != DISK_BLOCK_SIZE) {
        printf("Disk block and FS block mismatch\n");
        return 0;
    }
    memset(&block, 0, sizeof(block));
    disk_write(1, block.data); // write 1st dir block all zeros

    nblocks = disk_size();
    block.super.magic = FS_MAGIC;
    block.super.fssize = nblocks;
    strEncode(block.super.label, disklabel, LABELSZ);
    block.super.dir[0] = 1; // block 1 is first dir block

    disk_write(0, block.data);  // write superblock
    dumpSB(); // debug

    return 1;
}

/*****************************************************************/

int fs_mount() {
    union fs_block block;

    if (superB.magic == FS_MAGIC) {
        printf("One disc is already mounted!\n");
        return 0;
    }
    disk_read(0, block.data);
    superB = block.super;

    if (superB.magic != FS_MAGIC) {
        printf("cannot mount an unformatted disc!\n");
        return 0;
    }
    if (superB.fssize != disk_size()) {
        printf("file system size and disk size differ!\n");
        return 0;
    }

    // build used blocks map
    blockBitMap = malloc(superB.fssize * sizeof(uint16_t));
	memset(blockBitMap, FREE, superB.fssize*sizeof(uint16_t));
    blockBitMap[0] = NOT_FREE; // 0 is used by superblock

    // TODO: blockBitMap[i]=NOT_FREE if block i is in use
    //       check all directory
	
    for (int dirblk = 0; dirblk < MAXDIRSZ && superB.dir[dirblk]; dirblk++) {
        int b = superB.dir[dirblk];
        disk_read(b, block.data);
        for (int j = 0; j < DIRENTS_PER_BLOCK; j++){
            if(block.dirent[j].st != TEMPTY) {
                blockBitMap[b] = NOT_FREE;
                for(int i = 0; i < FBLOCKS; i++) {
                    int blockIndex = block.dirent[j].blocks[i];
                    if(blockIndex != 0){
                        blockBitMap[blockIndex] = NOT_FREE;
                    }

                }
            }

        }

    }

    return 1;
}

/************************************************************/

int fs_read(char *name, char *data, int length, int offset) {
    if (superB.magic != FS_MAGIC) {
        printf("disc not mounted\n");
        return -1;
    }
    char fname[FNAMESZ];
    strEncode(fname, name, FNAMESZ);

    // TODO: read file data

	struct fs_dirent dirent;
	struct fs_dirent dirent0;
	int ext = offset / DISK_BLOCK_SIZE / 8;

	int direntIndex = readFileEntry(fname, ext, &dirent);
	readFileEntry(fname, 0, &dirent0);
	int indexOfBlock = (offset - ext * 8 * DISK_BLOCK_SIZE) / DISK_BLOCK_SIZE;

	if(direntIndex != -1) {
		int realIndexOfBlock = dirent.blocks[indexOfBlock];

		if(realIndexOfBlock != 0) {
			
			if(offset == dirent0.ex * DISK_BLOCK_SIZE * 8 + dirent0.ss)
				return 0;
				
			disk_read(realIndexOfBlock, data);
			if((indexOfBlock < 7 && dirent.blocks[indexOfBlock + 1] == 0) || (indexOfBlock == 7 && dirent0.ex == ext)) 
				return dirent0.ss - indexOfBlock * DISK_BLOCK_SIZE;
				
			return DISK_BLOCK_SIZE;	
			
		}
		
	}
    return -1; // return read bytes or -1
}

/****************************************************************/

int fs_write(char *name, char *data, int length, int offset) {

    if (superB.magic != FS_MAGIC) {
        printf("disc not mounted\n");
        return -1;
    }
    char fname[FNAMESZ];
    strEncode(fname, name, FNAMESZ);

    // TODO: write data to file

	struct fs_dirent dirent;
	int ext = offset / DISK_BLOCK_SIZE / 8;
    int direntIndex = readFileEntry(fname, ext, &dirent);
    int isSmallFile = 0;

    // if(direntIndex != -1 && offset == 0 && ext == 0){
    //     fs_delete(name);
    //     direntIndex = -1;
    // }
	
    if(direntIndex == -1) {

        struct fs_dirent temp;
		if(ext == 0){
			temp.st = TFILE;
            temp.ex = 0;
		}else {
			temp.st = TEXT;
			temp.ex = ext;
			
			struct fs_dirent temp2;
			int index = readFileEntry(fname, 0, &temp2);
			temp2.ex = ext;
			writeFileEntry(index, temp2);
		}
        for(int i = 0; i < FNAMESZ; i++){
            temp.name[i] = fname[i];
        }
	
        writeFileEntry(-1,temp);
        //Substituir linha debaixo apenas pela de cima
		direntIndex = readFileEntry(fname, 0, &dirent);
    }else{
        isSmallFile = 1;
        if(offset == 0){
            dirent.ss = 0;
        }
    }
	
	int indexOfBlock = (offset - ext * 8 * DISK_BLOCK_SIZE) / DISK_BLOCK_SIZE;
	
	char data3[1030];
	int bytesSent = 0;
    int flag = 0;
	
	while(bytesSent != length) {
		int realIndexOfBlock;
        int bytesWrote = 0;

		if(indexOfBlock < 8) 
			realIndexOfBlock = dirent.blocks[indexOfBlock];
		else {
			struct fs_dirent temp;
            if(readFileEntry(fname, ext + 1, &dirent) != -1){
				realIndexOfBlock = dirent.blocks[0];
            }else{
                    temp.st = TEXT;

                    for(int i = 0; i < FNAMESZ; i++){
                        temp.name[i] = fname[i];
                    }

                    temp.ex = ext + 1;
            
                    writeFileEntry(-1,temp);
                    
                    int index = readFileEntry(fname, 0, &temp);
                    temp.ex = ext + 1;
                    writeFileEntry(index, temp);

                    direntIndex = readFileEntry(fname, ext + 1, &dirent);
                    realIndexOfBlock = dirent.blocks[0];
                }
        }

		if(realIndexOfBlock == 0) {
			realIndexOfBlock = allocBlock();
            // if realIndexOfBlock = -1 this means no disk space
            if(realIndexOfBlock == -1){
                return realIndexOfBlock;
            }
			dirent.blocks[indexOfBlock] = realIndexOfBlock;
			blockBitMap[realIndexOfBlock] = NOT_FREE;
		}
		
		disk_read(realIndexOfBlock, data3);
		if(length <= DISK_BLOCK_SIZE - offset % DISK_BLOCK_SIZE) {
			memcpy(data3 + offset % DISK_BLOCK_SIZE, data, length);
			bytesSent += length;
            bytesWrote = length;
            flag = 1;
		}
		else {
			if(bytesSent == 0){
				memcpy(data3 + offset % DISK_BLOCK_SIZE, data, DISK_BLOCK_SIZE - offset % DISK_BLOCK_SIZE);
				bytesSent += DISK_BLOCK_SIZE - offset % DISK_BLOCK_SIZE;
                bytesWrote = DISK_BLOCK_SIZE - offset % DISK_BLOCK_SIZE;
			}
			else {
				memcpy(data3, data + (length - offset % DISK_BLOCK_SIZE), offset % DISK_BLOCK_SIZE); 
				bytesSent += offset % DISK_BLOCK_SIZE;
				bytesWrote = offset % DISK_BLOCK_SIZE;
			}
		}
		disk_write(realIndexOfBlock, data3);
		writeFileEntry(direntIndex, dirent);
	    //printf("%d				%d				%d\n", bytesSent, length, flag)

        if(dirent.ex != 0){
            for(int i = 0; i <= ext ; i++) {
                int index = readFileEntry(fname, i, &dirent);
                dirent.ss += bytesWrote;
                writeFileEntry(index, dirent);
            }
        }else {
            dirent.ss += bytesWrote;	
            writeFileEntry(direntIndex, dirent);
        }

        if(flag && isSmallFile){
            
            union fs_block zero;
            memset(&zero, 0, BLOCKSZ);

            indexOfBlock++;
            while(indexOfBlock < 8) {
                int realIndex = dirent.blocks[indexOfBlock];
                if(realIndex != 0) {
                    dirent.blocks[indexOfBlock] = 0;
                    disk_write(realIndex, zero.data); 
                    blockBitMap[realIndex] = FREE;
                }
                indexOfBlock++;
            }
            writeFileEntry(direntIndex, dirent);
            struct fs_dirent temp;
            int idx = readFileEntry(fname, 0, &temp);
            for(int i = ext + 1; i <= temp.ex; i++) {
                int direntN = readFileEntry(fname, i, &dirent);
                for(indexOfBlock = 0; indexOfBlock < 8; indexOfBlock++) {
                    int realIndex = dirent.blocks[indexOfBlock];
                    if(realIndex != 0) {
                        disk_write(realIndex, zero.data);
                        blockBitMap[realIndex] = FREE;
                    }
                }
                dirent.ex = 0;
                dirent.ss = 0;
                for(int j = 0; j < FNAMESZ; j++)
                    dirent.name[j] = 'a';


                dirent.st = TEMPTY;
                writeFileEntry(direntN, dirent);
            }
            temp.ex = ext;
            writeFileEntry(idx,temp);

        }
				
		offset += 1030;
		indexOfBlock++;
	}
	return length;
    return -1; // return writen bytes or -1
}
