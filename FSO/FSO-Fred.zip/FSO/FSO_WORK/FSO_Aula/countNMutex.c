#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <sys/time.h>

#define SIZE (100*1024*1024)

int *array;
int count = 0;
int tofind = 3;
int numberOfThreads = 2;
pthread_mutex_t sc;

//(void*) (&)
// *(int*)
void docount( void *index ){
	int offset = (int)index * 1024 * 1024 * 50;
	for (int i= 0; i < 1024 * 1024 * 50; i++) {
		if(array[i + offset] == tofind){
			pthread_mutex_lock(&sc);
			count++;
			pthread_mutex_unlock(&sc);
		}
	}
}

// void docount( void *index ){
// 	int offset = (int)index * 1024 * 1024;
// 	for (int i= offset; i < (1024 * 1024 * ((int)index + 1)); i++) {
// 		if(array[i] == tofind){
// 			count++;
// 		}
// 	}
// }

// void docount( void *index ){
// 	int inicio = (int)arg;
// 	for (int i= 0; i < SIZE/2; i++) {
// 		if(array[i+inicio] == tofind){
// 			count++;
// 		}
// 	}
// }

int main( int argc, char *argv[]){
	struct timeval t1,t2;

	array= (int *)malloc(SIZE*sizeof(int));
	tofind = 3;

	srand(0);
	for (int i=0; i < SIZE; i++) {
		array[i] = rand() % 4;
	}
	gettimeofday(&t1, NULL);
	for(int j = 0; j < numberOfThreads; j++){
		pthread_t p;
		pthread_mutex_init(&sc , NULL);
		pthread_create(&p,NULL, docount,j);
		pthread_join(p,NULL);
	}
	gettimeofday(&t2, NULL);


	printf("Count of %d = %d\n", tofind, count);
	printf("Elapsed time (ms) = %lf\n", 
		((t2.tv_sec - t1.tv_sec)*1000000 + (t2.tv_usec - t1.tv_usec))/1000.0 );

	return 0;
}

// func :
//int c = 0;
// for -> c++;
//-> return (void*) c;
// pthread_join(p, (void*) &r);
// count = count + r