/**
 * countNproc - Lab 10 FSO 1819  MIEI
 * DI - FCT/UNL
 */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <assert.h>
#include <sys/time.h>

int main(int argc, char const *argv[])
{
    int pipefd[2];
    pipe(pipefd);

    pid_t pid = fork();

    switch(pid){

        case -1:
            perror("fork");
            exit(1);
        case 0:
            close(pipefd[0]);
            write(pipefd[1],argv[1],sizeof(argv[1]));
            exit(0);
        default:
            wait(NULL);
            char buf[50];
            read(pipefd[0],buf,sizeof(buf));
            printf("%s\n", buf);

    }

    return 0;
}
