#include "Images.h"

Images::Images() {
	currentImage = 0;
	indice = 0;

	if (!xml.loadFile("images/olaaa.xml"))
		newMetadata();

	xml.loadFile("images/olaaa.xml");
	metadata();
};

void Images::setWindow(int width, int height) {
	this->width = width;
	this->height = height;
}

void Images::loadImages() {
	font.load("Philosopher-Regular.ttf", ((ofGetWindowWidth() * 10) / width));
	dir.listDir("images/");
	dir.allowExt("jpg");
	dir.sort(); // in linux the file system doesn't return file lists ordered in alphabetical order

	//allocate the vector to have as many ofImages as files
	if (dir.size())
		images.assign(dir.size(), ofImage());

	for (int i = 0; i < dir.size(); i++) {
		images[i].load(dir.getPath(i));
	}
}

void Images::draw(int current) {
	int c = 0, l = 0;

		for (int i = 0; i < 2 && current < images.size(); i++) {
			for (int j = 0; j < 4 && current < images.size(); j++) {
				images[current].resize((ofGetWindowWidth() * 300) / width, (ofGetWindowHeight() * 300) / height);
				images[current].draw((ofGetWindowWidth() * (50+c)) / width, (ofGetWindowHeight() * (150+l)) / height);
				c += (ofGetWindowWidth() * 500) / width;
				current++;
			}
			l += (ofGetWindowHeight() * 400) / height;
			c = 0;
		}
}

int Images::getCurrent() {
	return currentImage;
}

void Images::setCurrent(int newCurrent) {
	currentImage = newCurrent;
}

int Images::getSize() {
	return images.size();
}

int Images::getDirSize() {
	return dir.size();
}

void Images::drawImage(int indice, int y, int currentPage) {
	this->indice = indice;

	//selecionar na parte debaixo do ecra
	if (y > ofGetWindowHeight() / 2) {
		images[(indice + ((currentPage - 1) * 8)) + 4].draw((ofGetViewportWidth() / 2) - 250, (ofGetViewportHeight() / 2) - 250);
		images[(indice + ((currentPage - 1) * 8)) + 4].resize((ofGetWindowWidth() * 500) / width, (ofGetWindowHeight() * 500) / height);

	}
	else {
		images[indice + ((currentPage - 1) * 8)].draw((ofGetViewportWidth() / 2) - 250, (ofGetViewportHeight() / 2) - 250);
		images[(indice + ((currentPage - 1) * 8))].resize((ofGetWindowWidth() * 500) / width, (ofGetWindowHeight() * 500) / height);
	}

	metadata();
}

float Images::getColor() {
	ofImage img = images[indice];
	ofPixelsRef pixels = img.getPixels();
	int dimensionFrame = img.getWidth() * img.getHeight();
	int tRed = 0;
	int tGreen = 0;
	int tBlue = 0;

	for (int i = 0; i < dimensionFrame; i++) {
		tRed += pixels[i];
		tGreen += pixels[i];
		tBlue += pixels[i];
	}

	red = tRed * 1.0 / dimensionFrame;
	green = tGreen * 1.0 / dimensionFrame;
	blue = tBlue * 1.0 / dimensionFrame;
	/*
	colors.push_back(tRed*1.0 / dimensionFrame);
	red = colors[0];
	colors.push_back(tGreen*1.0 / dimensionFrame);
	green = colors[1];
	colors.push_back(tBlue*1.0 / dimensionFrame);
	blue = colors[2];*/

	return ((red + green + blue) / 3);
}

void Images::newMetadata() {
	//float color = this->getColor();
	float luminancia = 0.2125*red + 0.7154*green + 0.0721*blue;

	ofSetColor(ofColor::white);
	
	xml.addTag("metadados");
	xml.pushTag("metatados");
	
	xml.setValue("tags", indice);
	xml.setValue("luminancia", indice);
	xml.setValue("color", indice);

	xml.popTag();
	xml.saveFile("images/olaaa.xml");
}

void Images::metadata() {
	ofSetColor(ofColor::pink);
	
	xml.pushTag("metadados");
	font.drawString("Metadados: ", 5, 10);

	xml.pushTag("tags");
	string tags = xml.getValue("tags", "", indice);
	font.drawString(tags, 5, 20);
	xml.popTag();

	xml.pushTag("luminancia");
	font.drawString(xml.getValue("luminancia", "", indice), 5, 30);
	xml.popTag();

	xml.pushTag("color");
	font.drawString(xml.getValue("color", "", indice), 5, 40);
	xml.popTag();

	xml.popTag();
}