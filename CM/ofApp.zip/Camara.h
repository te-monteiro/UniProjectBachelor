#include "ofMain.h"
#include "ofxCvHaarFinder.h"

class Camara {
public: 
	Camara();

	void camSetup();
	void update();
	void show();

	int camWidth;
	int camHeight;
	ofVideoGrabber vidGrabber;
	ofxCvHaarFinder finder;  //quadrados identificacao de caras
	ofImage captureImage;
};