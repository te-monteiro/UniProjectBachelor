#pragma once
#include "ofMain.h"
#include "ofxXmlSettings.h"


class Videos {

public:
	Videos();

	//variaveis globais
	int currentVideo;
	ofDirectory dir;
	vector<ofVideoPlayer> videos;
	bool frameByframe;
	int width;
	int height;
	int indice;


	//xml
	ofxXmlSettings xml;
	string xmlText;

	//metodos
	void setWindow(int width, int height);
	void loadVideos();
	void update();
	void draw(int currentVideo);
	int getSize();
	int getCurrent();
	void setCurrent(int currentMode);
	int getDirSize();
	int getVideoWidth();
	void getOneVideo(int currentPage, int y);
	void keyPressed(int key);
	void setIndice(int indice);

	//xml
	//void newMetadata();
	//void metadata();
	float getColor();
	//cores
	int red;
	int green;
	int blue;

	ofTrueTypeFont font;
};