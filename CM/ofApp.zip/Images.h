#include "ofMain.h"
#include "ofxXmlSettings.h"

class Images {
public:
	Images();

	void setWindow(int width, int height);
	void loadImages();
	void draw(int current);
	int getCurrent();
	void setCurrent(int newCurrent);
	int getSize();
	int getDirSize();
	void drawImage(int indice, int y, int currentPage);

	float getColor();
	void newMetadata();
	void metadata();

	int currentImage;
	int width;
	int height;
	int indice;
	int red;
	int green;
	int blue;
	
	ofDirectory dir;
	vector<ofImage> images;

	ofxXmlSettings xml;
	string xmlText;
	vector<int> colors;

	ofTrueTypeFont font;
} ;