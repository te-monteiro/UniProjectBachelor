#include "Camara.h"

Camara::Camara() {
	this->camWidth = 640;
	this->camHeight = 480;
}

void Camara::camSetup() {
	vidGrabber.setup(camWidth, camHeight);
	finder.setup("haarcascade_frontalface_default.xml");
};

void Camara::update() {
	vidGrabber.update();
}

void Camara::show() {
	// draw the raw video frame with the alpha value generated above
	vidGrabber.draw(ofGetViewportWidth() / 2 - 300, ofGetViewportHeight() / 2 - 300);

	for (int i = 0; i < camWidth; i += 7) {
		for (int j = 0; j < camHeight; j += 9) {
			ofPixelsRef pixelsRef = vidGrabber.getPixels();

			// get the pixel and its lightness (lightness is the average of its RGB values)
			float lightness = pixelsRef.getColor(i, j).getLightness();

			// calculate the index of the character from our asciiCharacters array
			int character = powf(ofMap(lightness, 0, 255, 0, 1), 2.5);// *asciiCharacters.size();
		}
	}

	//capturar a imagem para fazer o reconhecimento facial
	captureImage.setFromPixels(vidGrabber.getPixels());

	finder.findHaarObjects(captureImage);
	ofNoFill();
	ofSetColor(ofColor::pink);

	for (unsigned int i = 0; i < finder.blobs.size(); i++) {
		ofRectangle cur = finder.blobs[i].boundingRect;
		ofDrawRectangle(cur.x + (ofGetViewportWidth() / 2 - 300), cur.y + (ofGetViewportHeight() / 2 - 300), cur.width, cur.height);
	}
}