#include "ofApp.h"
#include "ofxXmlSettings.h"

//--------------------------------------------------------------
void ofApp::setup(){
	search.load("search.png");

	xPos = 0;
	yPos = 0;

	//inicializacoes das variaveis globais 
	currentPage = 1;
	numPages = 0;

	//window
	width = 1920; // ofGetViewportWidth();
	height = 1001; // ofGetViewportHeight();

	//modo inicial
	mode = BEM_VINDO;
	
	//imagens
	imagem.setWindow(width, height);
	imagem.loadImages();
	
	//videos
	video.setWindow(width, height);
	video.loadVideos();

	//CAMARA:
	camara.camSetup();
	
	//XML

	//auto metadados = xml.getAttribute("metadados");

	//if (!metadados) {
	//	metadados = xml.appendChild("metadados");
	//}

	//string tags = xml.getAttribute("//tags", currentImage);

	//auto luminancia = xml.findFirst("//luminancia");

	//auto color = xml.findFirst("//color");

	//tags.appendChild("Smile");

	//luminancia.appendChild("luz");

	//color.appendChild("colors");

	ofDisableAntiAliasing();

	//cor de fundo
	ofBackground(ofColor::white);

}

//--------------------------------------------------------------
void ofApp::update() {
	switch (mode) {
	case VIDEO:
		video.update();
		break;
	case CAMARA:
		camara.update();
		break;
	case ONESELECT:
		video.update();
		break;
	default:
		cout << "Unknown status";
		}
	}

//--------------------------------------------------------------
void ofApp::draw() {
	
	font.load("Philosopher-Regular.ttf", ((ofGetWindowWidth() * 30) / width));

	ofSetColor(ofColor::black);
	font.drawString("Imagens ", ((ofGetWindowWidth() * 708) / width), ((ofGetWindowHeight() * 40) / height));
	font.drawString("Videos ", ((ofGetWindowWidth() * 930) / width), ((ofGetWindowHeight() * 40) / height));
	font.drawString("Camara ", ((ofGetWindowWidth() * 1130) / width), ((ofGetWindowHeight() * 40) / height));

	ofSetColor(ofColor::white);

	switch (mode) {
	case BEM_VINDO:
		bemVindo();
		break;
	case IMAGES:
		search.draw(50, 50);
		pages(currentPage);
		if (imagem.getSize() > 0) {
			ofSetColor(ofColor::white);
			imagem.draw(imagem.getCurrent());
		}
		break;
	case VIDEO:	
		search.draw(50, 50);
		pages(currentPage);
		if (video.getSize() > 0) {
			ofSetColor(ofColor::white);
			video.draw(video.getCurrent());
		}
		break;
	case ONESELECT:  
		oneSelect(); //seleciona uma imagem e desenha isolada
		break;

	case CAMARA:
		camara.show();
		break;
	default:
		cout << "Unknown status";
	}
}

void ofApp::oneSelect() {
	font.load("Philosopher-Regular.ttf", 10);
	ofEnableAlphaBlending();
	ofSetColor(0, 0, 0, 200);
	ofDrawRectangle(0, 0, 250, ofGetHeight());
	ofDisableAlphaBlending();
	ofSetColor(240, 240, 240);
	ofSetColor(ofColor::white);
	int indice;

	if (lastMode == IMAGES) {
		indice = xPos / (imagem.images[0].getWidth() + 250);
		imagem.drawImage(indice, yPos, currentPage);
	}
	else if (lastMode == VIDEO) {
		int indice = xPos / (video.getVideoWidth() + 250);

		video.setIndice(indice);

		if (indice > video.getSize()) {
			mode = lastMode;
		}
		video.getOneVideo(currentPage, yPos);
	}
}
void ofApp::oneImage(int x, int y) {
/*
		//extrair as cores da pagina
		ofPixels pixelsRef = images[indice].getPixels();
		//extrair as cores da pagina
		ofPixels pixelsRef = images[indice].getPixels();

		int imgWidth = images[indice].getWidth();
		int imgHeight = images[indice].getHeight();
		int dimensionFrame = imgWidth * imgHeight;

		int totalRed = 0;
		int totalGreen = 0;
		int totalBlue = 0;

		for (int i = 0; i < imgWidth*imgHeight;) {
			totalRed += pixelsRef[i++];
			totalGreen += pixelsRef[i++];
			totalBlue += pixelsRef[i++];
		}

		vector <int> colors;
		colors.push_back(totalRed* 1.0 / dimensionFrame);
		int red = colors[0];
		colors.push_back(totalGreen * 1.0 / dimensionFrame);
		int green = colors[1];
		colors.push_back(totalBlue * 1.0 / dimensionFrame);
		int blue = colors[2];


		//media da cor
		float avgColor = (red + green + blue) / 3;

		//extrair a luminancia
		float avgLuminancia = 0.0;

		avgLuminancia = 0.2125 * red + 0.7154 * green + 0.0721 * blue;

		ofLog() << "current image " << indice << "avgClor " << avgColor << "avgLuminancia " << avgLuminancia;
		ofSetColor(ofColor::white);

		xml.addTag("metadados");
		xml.pushTag("metadados");

		xml.setValue("tags", indice);

		xml.setValue("luminancia", avgLuminancia);

		xml.setValue("color", avgColor);
		xml.popTag(); //metadados
		xml.saveFile("images/ola 1.xml");
		xml.loadFile("images/ola 1.xml");
		*/
	}

//metodo para ir buscar/desenhar o numero de paginas
void ofApp::pages(int currentPage) {
	int aux = 0;
	if (mode == IMAGES) {
		numPages = imagem.getSize() / 8;
		aux = imagem.getSize();
	}
	else if (mode == VIDEO) {
		numPages = video.getSize() / 8;
		aux = video.getSize();
	}
	//falta aumentar o numero da letra
	if (aux % 8 != 0)
		numPages += 1;

	font.load("Philosopher-Regular.ttf", ((ofGetWindowWidth() * 15) / width));
	ofSetColor(ofColor::black);

	//posiciona as paginas e as setas
	font.drawString("<", (ofGetWindowWidth() / 2) - ((ofGetWindowWidth() * 100) / width), ofGetWindowHeight() - ((ofGetWindowHeight() * 100) / height));
	font.drawString(ofToString(currentPage), (ofGetWindowWidth() / 2), ofGetWindowHeight() - ((ofGetWindowHeight() * 100) / height));
	font.drawString(">", (ofGetWindowWidth() / 2) + ((ofGetWindowWidth() * 100) / width), ofGetWindowHeight() - ((ofGetWindowHeight() * 100) / height));
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button) {
	int currentMode;
	int currentDir;

	if (mode == IMAGES) {
		currentMode = imagem.getCurrent();
		currentDir = imagem.getDirSize();
	}
	else if (mode == VIDEO) {
		currentMode = video.getCurrent();
		currentDir = video.getDirSize();
	}

	//andar de pagina para a esquerda
	if (x > ((ofGetWindowWidth() * 860) / width) && x < ((ofGetWindowWidth() * 875) / width) && y >((ofGetWindowHeight() * 885) / height) && y < ((ofGetWindowHeight() * 900) / height) && button == 0) {
	
		if (currentPage > 1) {
			currentMode -= 8;

			currentMode %= currentDir;
			
			currentPage--;

			if (mode == IMAGES)
				imagem.setCurrent(currentMode);
			else if (mode == VIDEO) 
				video.setCurrent(currentMode);
		}
	}
	//andar de pagina para a direita
	else if (x > ((ofGetWindowWidth() * 1055) / width) && x < ((ofGetWindowWidth() * 1075) / width) && y >((ofGetWindowHeight() * 885) / height) && y < ((ofGetWindowHeight() * 900) / height) && button == 0) {

		if (currentPage < numPages) {
			if (currentDir > 0) {
				currentMode = currentPage * 8;

				currentMode %= currentDir;
		
				currentPage++;

				if (mode == IMAGES)
					imagem.setCurrent(currentMode);
				else if (mode == VIDEO) 
					video.setCurrent(currentMode);
			}
		}
	} 
	//mode imagens
	else if (x > ((ofGetWindowWidth() * 708) / width) && x < ((ofGetWindowWidth() * 850) / width) && y >((ofGetWindowHeight() * 15) / height) && y < ((ofGetWindowHeight() * 55) / height) && button == 0) {
		if (mode == VIDEO || mode == CAMARA) {
			imagem.setCurrent(0);
			currentPage = 1;
		}
		mode = IMAGES;
	}
	//modo de video
	else if (x > ((ofGetWindowWidth() * 933) / width) && x < ((ofGetWindowWidth() * 1050) / width) && y >((ofGetWindowHeight() * 15) / height) && y < ((ofGetWindowHeight() * 55) / height) && button == 0) {
		if (mode == IMAGES || mode == CAMARA) {
			video.setCurrent(0);
			currentPage = 1;
		}
		mode = VIDEO;
	}
	//mode camara
	else if (x > ((ofGetWindowWidth() * 1129) / width) && x < ((ofGetWindowWidth() * 1265) / width) && y >((ofGetWindowHeight() * 15) / height) && y < ((ofGetWindowHeight() * 55) / height) && button == 0) {
		mode = CAMARA;
	}
	//mode oneselect
	else if(mode != ONESELECT){
		xPos = x;
		yPos = y;
		
		if (y > ((ofGetWindowHeight() * 135) / height) && y < ((ofGetWindowHeight() * 860) / height) && x > ((ofGetWindowWidth() * 45) / width)  && x < ((ofGetWindowWidth() * 1855) / width)) {
			lastMode = mode;
			mode = ONESELECT;
		}
	}
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key) {
}
//--------------------------------------------------------------
void ofApp::keyReleased(int key) {
}
//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y) {
}
//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button) {
}
//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button) {
}
//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y) {
}
//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y) {
}
//--------------------------------------------------------------
void ofApp::windowResized(int w, int h) {
}
//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg) {
}
//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo) {
}

void ofApp::bemVindo() {
	//fonte de letra
	font.load("Philosopher-Regular.ttf", ((ofGetWindowWidth() * 60) / width));
	ofSetColor(ofColor::black);
	font.drawString("Bem vindo :) ", (ofGetViewportWidth() / 2) - ((ofGetWindowWidth() * 178) / width), (ofGetWindowHeight() / 2) - ((ofGetWindowHeight() * 30) / height));
}