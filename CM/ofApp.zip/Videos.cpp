#include "Videos.h"

Videos::Videos() {
	this->indice = 0;
	if (!xml.loadFile("movies/ola video.xml")) {
		//newMetadata();
	}

	xml.loadFile("movies/ola video.xml");
	//metadata();
}


void Videos::setWindow(int width, int height) {
	this->width = width;
	this->height = height;
}

void Videos::loadVideos() {
	currentVideo = 0;
	dir.listDir("movies/");
	dir.allowExt("mov");
	dir.sort(); // in linux the file system doesn't return file lists ordered in alphabetical order

	if (dir.size()) {
		videos.assign(dir.size(), ofVideoPlayer());
	}

	frameByframe = true;
	// you can now iterate through the files and load them into the ofImage vector
	for (int i = 0; i < videos.size(); i++) {
		videos[i].loadMovie(dir.getPath(i));

		videos[i].setPaused(frameByframe); // .play()
	}
}

void Videos::update() {
	for (int i = 0; i < videos.size(); i++)
		videos[i].update();
}


void Videos::draw(int currentVideo) {
	int c = 0, l = 0;

	for (int k = 0; k < 2 && currentVideo < videos.size(); k++) {
		for (int o = 0; o < 4 && currentVideo < videos.size(); o++) {
			videos[currentVideo].draw(((ofGetWindowWidth() * 50) / width) + c, ((ofGetWindowHeight() * 150) / height) + l);
			c += (ofGetWindowWidth() * 700) / width;
			currentVideo++;
		}
		l += (ofGetWindowHeight() * 400) / height;
		c = 0;
	}
}

int Videos::getSize() {
	return videos.size();
}
int Videos::getCurrent() {
	return currentVideo;
}

void Videos::setCurrent(int currentMode) {
	currentVideo = currentMode;
}

int Videos::getDirSize() {
	return dir.size();
}

int Videos::getVideoWidth() {
	return videos[currentVideo].getWidth();
}

void Videos::setIndice(int indice) {
	this->indice = indice;
}

void Videos::getOneVideo(int currentPage, int y) {

	frameByframe = false;
	videos[indice].setPaused(frameByframe);

	//selecionar na parte debaixo do ecra
	if (y > ofGetWindowHeight() / 2)
		videos[(indice + ((currentPage - 1) * 8)) + 4].draw((ofGetViewportWidth() / 2) - 250, (ofGetViewportHeight() / 2) - 250);

	else
		videos[indice + ((currentPage - 1) * 8)].draw((ofGetViewportWidth() / 2) - 250, (ofGetViewportHeight() / 2) - 250);
	//this->metadata();

}

void Videos::keyPressed(int key) {
	switch (key) {
	case 'f':
		frameByframe = !frameByframe;
		videos[currentVideo].setPaused(true); //true
		break;
	}
}
/*
void Videos::newMetadata() {

	float color = this->getColor();

	//extrair a luminancia
	float avgLuminancia = 0.0;
	avgLuminancia = 0.2125 * red + 0.7154 * green + 0.0721 * blue;

	ofSetColor(ofColor::white);

	xml.addTag("metadados");
	xml.pushTag("metadados");

	xml.setValue("tags", indice);

	xml.setValue("luminancia", avgLuminancia);

	xml.setValue("color", color);
	xml.popTag(); //metadados
	xml.saveFile("movies/ola video.xml");
	//	xmlStru += "    <tags>"+ indice + "<tags>\n" + "<luminancia>" + avgLuminancia + "</luminancia>\n" + "<color>" + avgColor + "</color>\n";

}

void Videos::metadata() {
	xml.pushTag("metadados");
	font.drawString("Metadados: ", 5, 10);

	xml.pushTag("tags");
	font.drawString(xml.getValue("tags", "", indice), 5, 20);
	xml.popTag();//tags

	xml.pushTag("luminancia");
	font.drawString(xml.getValue("luminancia", "", indice), 5, 30);
	xml.popTag();//luminancia

	xml.pushTag("color");
	font.drawString(xml.getValue("color", "", indice), 5, 40);
	xml.popTag();//color

	xml.popTag();//metadados
}*/

float Videos::getColor() {
	//extrair as cores da pagina
	ofPixels pixelsRef = videos[indice].getPixels();

	int imgWidth = videos[indice].getWidth();
	int imgHeight = videos[indice].getHeight();
	int dimensionFrame = imgWidth * imgHeight;

	int totalRed = 0;
	int totalGreen = 0;
	int totalBlue = 0;

	for (int i = 0; i < imgWidth*imgHeight;) {
		totalRed += pixelsRef[i++];
		totalGreen += pixelsRef[i++];
		totalBlue += pixelsRef[i++];
	}

	vector <int> colors;
	colors.push_back(totalRed* 1.0 / dimensionFrame);
	red = colors[0];
	colors.push_back(totalGreen * 1.0 / dimensionFrame);
	green = colors[1];
	colors.push_back(totalBlue * 1.0 / dimensionFrame);
	blue = colors[2];


	//media da cor
	float avgColor = (red + green + blue) / 3;

	return avgColor;
}