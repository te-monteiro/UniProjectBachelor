#pragma once

#include "ofMain.h"
#include "ofxCvHaarFinder.h"
#include "ofxXmlSettings.h"
//objects
#include "Images.h"
#include "Videos.h"
#include "Camara.h"

class ofApp : public ofBaseApp {
public:
	//metodos
	void setup();
	void update();
	void draw();

	void keyPressed(int key);
	void keyReleased(int key);
	void mouseMoved(int x, int y);
	void mouseDragged(int x, int y, int button);
	void mousePressed(int x, int y, int button);
	void mouseReleased(int x, int y, int button);
	void mouseEntered(int x, int y);
	void mouseExited(int x, int y);
	void windowResized(int w, int h);
	void dragEvent(ofDragInfo dragInfo);
	void gotMessage(ofMessage msg);

	void bemVindo();
	void pages(int currentPage);
	void oneImage(int x, int y);
	void oneSelect();


	//constantes 
	static constexpr int IMAGES = 0;
	static constexpr int VIDEO = 1;
	static constexpr int ONESELECT = 2;
	static constexpr int CAMARA = 3;
	static constexpr int BEM_VINDO = 4;

	//objects
	Images imagem;
	Videos video;
	Camara camara;

	//variaveis globais 
	int mode;
	int lastMode;
	int xPos;
	int yPos;

	//pages
	int currentPage;
	int numPages;

	//window
	int width;
	int height;

	string asciiCharacters;
	ofTrueTypeFont font;

	//XML
	ofxXmlSettings xml;
	string xmlText;
	//glm::vec3 dragPts[NUM_PTS];
	//int pointCount;
	//string xmlStru;
	
	//std::string xmlText;
	//bool xmlChanged = true;


	//search
	ofImage search;
};