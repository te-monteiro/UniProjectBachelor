import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class Promotion {

	private int nMin, nMax, nEmployeers;

	private Map<Integer, List<Integer>> predecessors;

	private Map<Integer, List<Integer>> successors;

	private int nPredecessors[];

	private int nSuccessors[];


	public Promotion(String[] pos) {
		// 1 input
		this.nMin = Integer.parseInt(pos[0]);
		// 2 input
		this.nMax = Integer.parseInt(pos[1]);
		// 3 input
		this.nEmployeers = Integer.parseInt(pos[2]);

		this.predecessors = new HashMap<Integer, List<Integer>>(nEmployeers + 1);

		this.successors = new HashMap<Integer, List<Integer>>(nEmployeers + 1);

		this.nPredecessors = new int[nEmployeers];

		this.nSuccessors = new int[nEmployeers];
	}

	public void addPrecedence(String[] relation) {

		int preview = Integer.parseInt(relation[0]);
		int next = Integer.parseInt(relation[1]);

		List<Integer> auxPre = null;
		List<Integer> auxSuc = null;

		// predecessors
		if (predecessors.get(next) == null)
			auxPre = new LinkedList<Integer>();
		else
			auxPre = predecessors.get(next);

		// successors
		if (successors.get(preview) == null)
			auxSuc = new LinkedList<Integer>();
		else
			auxSuc = successors.get(preview);

		auxPre.add(preview);
		auxSuc.add(next);

		predecessors.put(next, auxPre);
		successors.put(preview, auxSuc);

	}

	private int bfsExplore(int node, Map<Integer, List<Integer>> typeMap) {
		int numWorkedNodes = 0;

		boolean found[] = new boolean[nEmployeers];

		List<Integer> waiting = new LinkedList<Integer>();

		waiting.add(waiting.size(), node);

		found[node] = true;

		do {
			int nodeATratar = waiting.remove(0);

			List<Integer> auxList = typeMap.get(nodeATratar);

			if (auxList != null) {
				for (int i = 0; i < auxList.size(); i++) {
					int auxNode = auxList.get(i);
					if (!found[auxNode]) {
						waiting.add(waiting.size(), auxNode);
						found[auxNode] = true;
						numWorkedNodes++;
					}

				}
			}
		} while (!waiting.isEmpty());

		//Arrays.fill(found, false);

		return numWorkedNodes;
	}

	public int[] solution() {

		int[] result = new int[3];

		for (int i = 0; i < nEmployeers; i++) {
			nSuccessors[i] = bfsExplore(i, successors);
			nPredecessors[i] = bfsExplore(i, predecessors);
		}

		// n promoted for min
		result[0] = promoted(nMin);

		// n promoted for max
		result[1] = promoted(nMax);

		// n not promoted for  max
		result[2] = notPromoted();

		return result;

	}

	private int notPromoted() {
		int counterNotPromoted = 0;

		for(int i = 0; i < nPredecessors.length; i++) {

			int wkPredecessors = nPredecessors[i];

			if(nMax <=  wkPredecessors) {
				counterNotPromoted++;
			}
		}

		return counterNotPromoted;
	}

	private int promoted(int value) {
		int counterPromoted = 0;

		for(int i = 0; i < nSuccessors.length; i++) {

			int wkSuccessors = nSuccessors[i];

			if(value >= nEmployeers - wkSuccessors) {
				counterPromoted++;
			}
			else if(wkSuccessors == 0 && nEmployeers == value) {
				counterPromoted++;
			}
		}

		if(counterPromoted <= value)
			return counterPromoted;
		else 
			return 0;
	}
}
