import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) throws IOException {

		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

		String pos[] = in.readLine().split(" ");
		
		Promotion p = new Promotion(pos);

		for(int i = 0; i < Integer.parseInt(pos[3]); i++) 
			p.addPrecedence(in.readLine().split(" "));
		
		int result[] = p.solution();
		System.out.println(result[0]);
		System.out.println(result[1]);
		System.out.println(result[2]);
	}
}