#pragma once

#include "ofMain.h"
#include "ofxXmlSettings.h"
#include "ofxOpenCv.h"
#include <opencv2/features2d.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/core/core.hpp>
#include "ofxCv.h"
using namespace cv;

class Videos {
	const int SIGMA = 4;
	const int THETA = 6;
	const int FILTERS = 24;


public:
	Videos();
	//method
	vector<ofVideoPlayer> getAllVideos();
	vector<int> getVideosByEvents();

	void setWindow(int width, int height);
	void loadVideos();
	void update();

	void draw(int currentVideo);
	void drawOneVideo(int nVideo);
	int getCurrent();
	void setCurrent(int newCurrent);
	int getSize();
	int getDirSize();
	int getVideoWidth();
	string getPath(string nameVideo, string eventName);
	void keyPressedVideo(int nVideo);
	string getNameVideo(int nVideo);
	string getEventName(int nVideo);
	int getNumFrames(int nVideo);
	void metadata(int nVideo, int i, int numFace);

private:
	//variable
	int currentVideo;
	bool frameByframe;
	int width;
	int height;

	ofTrueTypeFont font;
	ofDirectory dir;
	ofPixels pixels;

	//vector that have the videos
	vector<ofVideoPlayer> videos;
	//vector representing the events associated with the images respectively	
	vector<int> videosByEvents;

	//colors
	int red;
	int green;
	int blue;
	int hue;

	//luminancia
	float luminancia;

	//xml
	ofxXmlSettings xml;
	string xmlStructureVideo;
	string videoName;
	string eventName;


	//edge distribution
	ofxCvColorImage colorImg;
	ofxCvGrayscaleImage grayscaleImg;
	vector<float> edgeDistribution;

	//texture
	vector<pair<float, float>> texture;

	//Match
	ofImage match;
	ofxCvColorImage colorMatch;
	ofxCvGrayscaleImage grayscaleMatch;
	vector<DMatch> matches;
	int nMatches;

	//metodos
	//xml
	void newMetadata(string nameVideo);
	int getEventNum(int nVideo);
	
	//colors
	void getColors(int dimensionFrame, ofPixels & pixels);

	//edge distribution
	void calcEdgeDistribution(int dimensionFrame, Mat mat);

	//texture
	void calcTexture(Mat mat);

};