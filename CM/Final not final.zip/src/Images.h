#pragma once
#include "ofMain.h"
#include "ofxXmlSettings.h"
#include "ofxOpenCv.h"
#include "ofxCv.h"
using namespace cv;

class Images {
	const int SIGMA = 4;
	const int THETA = 6;
	const int FILTERS = 24;

public:
	Images();
	//method
	void setWindow(int width, int height);
	void loadImages();

	vector<ofImage> getAllImages();
	vector<int> getImagesByEvents();

	int getSize();
	int getDirSize();
	int getCurrent();
	void setCurrent(int newCurrent);
	int getImageWidth();

	void draw(int current);
	void drawOneImage(int nImg);


private:
	//variable
	int currentImage;
	int width;
	int height;

	ofTrueTypeFont font;
	ofDirectory dir;
	//vector that have the images
	vector<ofImage> images;
	//vector representing the events associated with the images respectively	
	vector<int> imagesByEvents;

	//colors
	int red;
	int green;
	int blue;
	int hue;

	//luminancia
	float luminancia;

	//xml
	ofxXmlSettings xml;
	string xmlStructureImage;
	string imageName;
	string eventName;

	//edge distribution
	ofxCvColorImage colorImg;
	ofxCvGrayscaleImage grayscaleImg;
	vector<float> edgeDistribution;

	//texture
	vector<pair<float, float>> texture;

	//match
	ofImage match;
	ofxCvColorImage colorMatch;
	ofxCvGrayscaleImage grayscaleMatch;
	vector<DMatch> matches;
	int nMatches;

	//metodos
	//xml
	void newMetadata(string nameXml);
	void metadata(int nImg);

	string getName(int nImg);
	string getEventName(int nImg);
	int getEventNum(int nImg);
	void getColor(ofImage img);
	void calclEdgeDistribution(int dimensionImg, cv::Mat mat);
	void calcTexture(Mat mat);
	void matchImages(Mat matImg);

};