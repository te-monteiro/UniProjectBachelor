#pragma once
#include "ofMain.h"
#include "ofxCvHaarFinder.h"
#include "ofxCv.h"
#include <cmath>

class Camara {
public:
	Camara();

	//method
	void camSetup();
	void update();
	void show();
	int getNumFaces();
	bool hasObject();


private:
	//variables
	ofImage captureImage;

	int camWidth;
	int camHeight;
	int numFaces;

	ofVideoGrabber cam;
	ofxCvHaarFinder finder;

	ofxCv::RunningBackground background;
	ofImage thresholded;
	float learningTime;
	float thresholdValue;
	bool isObject;

};