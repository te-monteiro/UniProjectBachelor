#pragma once
#include "User.h"

User::User() {
	currentImage = 0;
	currentVideo = 0;
	counter = 0;
}

void User::setImages(vector<ofImage> &imagesToPlay) {
	imagesByEvent = imagesToPlay;
}

void User::setVideos(vector<ofVideoPlayer> &videosToPlay) {
	videosByEvent = videosToPlay;
	playVideo = videosByEvent.at(currentVideo);
}

void User::draw(bool & isVideo) {
	playImage = imagesByEvent.at(currentImage);

	playVideo = videosByEvent.at(currentVideo);

	if (isVideo) {
		playVideo.setPaused(false);
		ofPixels & aux = playVideo.getPixels();
		ofImage auxImage;
		auxImage.setFromPixels(playVideo.getPixels());
		auxImage.draw((ofGetWindowWidth() / 2) - 300, (ofGetWindowHeight() / 2) - 300);

		if (playVideo.getIsMovieDone() != 0 && playVideo.getCurrentFrame() >= playVideo.getTotalNumFrames()) {
			currentVideo++;
			if (currentVideo >= videosByEvent.size()) {
				currentVideo = 0;
			}
			isVideo = false;
		}
	}else {
		playImage.draw((ofGetWindowWidth() / 2) - 300, (ofGetWindowHeight() / 2) - 300);
		if (counter >= 10) {
			currentImage++;
			isVideo = true;
			counter = 0;

			if (currentImage >= imagesByEvent.size())
				currentImage = 0;
		}
		counter++;
	}
}

void User::update(bool & isVideo) {
	if (isVideo) {
		playVideo.update();		
	}
}