//
//  AdminPage.h
//  cm_1819
//
//  Created by Marta Carlos on 08/04/2019.
//
#include "ofMain.h"
#include "VideoLibrary.h"
#include "CameraFeed.h"
#include "ofxGui.h"

class AdminPage {

	//internal states
	static constexpr int DEFAULT = 0;
	static constexpr int LOAD = 1;
	static constexpr int VIDEO = 2;
	static constexpr int OBJECT = 3;
	static constexpr int ACCEPT = 4;
	static constexpr int DEBUG_MODE = 5;

	//other constants
	static constexpr int BUTTON_START = 5;
	static constexpr int BUTTON_END = 212;
	static constexpr int ARROW_SIZE = 80;
	static constexpr int EVENT_BUTTON = 480;
	static constexpr int EVENT_BUTTON_END = 528;
	static constexpr int BUTTON_DIF = 80;
	static constexpr int SAVE_BUTTON_X = 960;
	static constexpr int SAVE_BUTTON_Y = 630;
	static constexpr int SAVE_BUTTON_SIZE = 73;

public:
	AdminPage();

	//Variables
	int in_state;
	int *state;
	string videoDir;
	string imageDir;
	ofImage arrow;
	ofImage save;
	ofImage sideBar;
	ofImage loadVideo;
	ofImage debugMode;
	ofImage next;
	ofImage previous;
	ofImage draggedImage;
	ofVideoPlayer draggedVideo;
	VideoLibrary *displayedEvent;
	string displayedName;
	map<string, VideoLibrary> events;
	vector<string> tags;

	ofxXmlSettings settings;
	ofxInputField<string> tagInput;
	CameraFeed *camera;
	float lastTick;
	int faceNr;
	bool motion;
	vector<int> colorAvg;
	ofTrueTypeFont font;

	const vector<string> eventsl = { "Default", "Loner", "Group" };
	const string INPUT_MSG = "Please enter video tags";
	const string INPUT_LABEL = "TAGS:";
	const int BORDER_WIDTH = 506;
	const int BORDER_HEIGHT = 56;

	const int MIDDLE_WIDTH = 540;

	const int LABEL_X_OFFSET = 90;
	const int LABEL_Y_OFFSET = 650;

	const int TITLE_Y_OFFSET = 20;
	const int TITLE_X_OFFSET = 90;

	const int VIDEO_GRABBER_W = 940;
	const int VIDEO_GRABBER_H = 580;

	const int VIDEO_Y_OFFSET = 40;
	const int VIDEO_X_OFFSET = 90;

	const int INPUT_START_Y = 650;
	const int INPUT_X_OFFSET = 150;

	const int IN_BORDER_Y_OFFSET = 647;
	const int IN_BORDER_X_OFFSET = 147;

	const int INPUT_WIDTH = 500;
	const int INPUT_HEIGHT = 50;

	const int DEBUG_BORDER_X = 10;
	const int DEBUG_BORDER_Y = 510;

	const int DEBUG_WIDTH = 720;
	const int DEBUG_HEIGHT = 200;

	const int DEBUG_BORDER_WIDTH = 730;
	const int DEBUG_BORDER_HEIGHT = 200;

	const int DEBUG_X = 15;
	const int DEBUG_Y = 515;

	const int DEBUG_START_X = 20;
	const int DEBUG_START_Y = 550;

	const int DEBUG_OFFSET_Y = 40;
	const int DEBUG_OFFSET_X = 100;

	void setup(map<string, VideoLibrary> &myEvents, int *stat, CameraFeed *camera);
	void draw();
	void update();
	void mousePosition(int x, int y);
	void mousePressed(int x, int y, int button);
	void dragEvent(ofDragInfo dragInfo);
	void inputTagsListener(string &input);
	void drawDebugInfo();

private:
	void saveVideo(string dir);
	void switchEvent(int i);
	void saveImage(string dir, string name);
	void remDir(string * dir);
	string getExt(string dir);
	void copy(string from, string to);
	int getEventTagIndex(string eventName);
	vector<int> averagePerFrame(ofPixels & pixels);
};
