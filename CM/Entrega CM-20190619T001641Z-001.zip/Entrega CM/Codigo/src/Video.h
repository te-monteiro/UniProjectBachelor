#pragma once

#include "ofMain.h"
#include "ofxOpenCv.h"
#include "ofxCvHaarFinder.h" 
#include <opencv2/features2d.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include "ofxXmlSettings.h"


class Video
{
public:
	Video(string videoName);

	struct frameDiff {
		int index;
		float diff;
	};

	struct {
		bool operator()(frameDiff a, frameDiff b) const
		{
			return a.diff > b.diff;
		}
	} differenceOp;

	const float LUMINANCE_RED = 0.2125;
	const float LUMINANCE_GREEN = 0.7154;
	const float LUMINANCE_BLUE = 0.0721;
	const int ORIENTATION_VAR_NR = 6;
	const int RATIO_VAR_NR = 4;
	const int FILTER_SIZE = 3;
	const float OBJ_THRESH = 0.7f;
	const int MIN_MATCH = 8;

	bool hightlighted = false;

	float objAvg;

	string name;
	string extension;

	ofxXmlSettings metadata;
	ofImage thumbnail;
	vector<ofImage> movingIcons;

	cv::Ptr<cv::ORB> detect;
	cv::Mat object_descriptor;

	string getName();
	string getPath();
	ofImage getThumbnail();

	vector<ofImage> getMovingIcons();

	void writeMetadata();
	void loadMetadata();
	void update();
	bool objectDetected();
	vector<cv::DMatch> objectInFrame(cv::Mat grayMat, int width, int height);
	void addVideoTags(vector<string> tags);
	void computeObjectDescriptor();

private:

	vector<int> calcHist(int height, int width, ofPixels & frame);
	vector<int> averagePerFrame(int height, int width, int nChannels, ofPixels & frame);
	vector<pair<double, double>> getTextureInfo(cv::Mat grayMat, int height, int width);

	float calcHistDiff(vector<int>hist1, vector<int> hist2);

	float calcThreshold(vector<frameDiff> frameD, int height, int width);

	void writeGaborDescriptor(vector<pair<double, double>> descriptor);
	void writeEdgeDist(vector<float> distribution);
	void calcEdgeDist(cv::Mat grayMat, vector<float> &distribution, int width, int height);

};
