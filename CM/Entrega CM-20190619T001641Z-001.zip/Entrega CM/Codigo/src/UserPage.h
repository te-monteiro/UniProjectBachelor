#pragma once
#include "ofMain.h"
#include "CameraFeed.h"
#include "VideoLibrary.h"
#include "Video.h"

class UserPage {

	static constexpr int ARROW_SIZE = 80;

public:
	UserPage();
	const vector<string> eventsl = { "Default", "Loner", "Group" };

	void setup(map<string, VideoLibrary> &myEvents, int *state, CameraFeed *myCamera);
	void draw();
	void update();

	void mousePressed(int x, int y, int button);

	const int PLAYER_WIDTH = 1070;
	const int PLAYER_HEIGHT = 710;
	const int PLAYER_START_OFFSET = 5;
	const int MIN_MATCH = 8;

	int currentVideo;
	int *state;
	float lastTick;
	int faceNr;
	
	bool playerOn;
	ofImage arrow;
	CameraFeed *camera;
	ofVideoPlayer player;
	map<string, VideoLibrary> events;
	int next;
	ofxXmlSettings metadata;
	ofTrueTypeFont font;

	vector<Video*> toPlay;

private:
	int findColorRelated(ofPixels& pixels);
	void switchEvent(int newFaceNr);
	void switchVideo();
	vector<int> averagePerFrame(ofPixels & pixels);

};