#pragma once

#include "ofMain.h"
#include "VideoLibrary.h"
#include "AdminPage.h"
#include "MainPage.h"
#include "UserPage.h"
#include "Event.h"
#include "CameraFeed.h"
#include "ofxXmlSettings.h"

class ofApp : public ofBaseApp {

	static constexpr int MAIN_PAGE = 0;
	static constexpr int ADMIN_PAGE = 1;
	static constexpr int USER_PAGE = 2;

public:
	void setup();
	void update();
	void draw();
	void keyPressed(int key);
	void keyReleased(int key);
	void mouseMoved(int x, int y);
	void mouseDragged(int x, int y, int button);
	void mousePressed(int x, int y, int button);
	void mouseReleased(int x, int y, int button);
	void mouseEntered(int x, int y);
	void mouseExited(int x, int y);
	void windowResized(int w, int h);
	void dragEvent(ofDragInfo dragInfo);
	void gotMessage(ofMessage msg);

	//Variables
	int state;
	MainPage main;
	UserPage user;
	AdminPage admin;
	ofDirectory dir;
	ofxXmlSettings XML;
	CameraFeed camera;

private:
	void setupAdmin();
	void setupUser();
};
