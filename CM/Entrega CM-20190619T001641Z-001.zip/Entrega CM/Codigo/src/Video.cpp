#include "Video.h"


Video::Video(string videoName)
{
	name = videoName.substr(0, videoName.find("."));
	extension = videoName.substr(videoName.find("."));
	detect = cv::ORB::create();

	if (!metadata.loadFile("videos/" + name + ".xml"))
		writeMetadata();

	loadMetadata();

}

void Video::writeMetadata() {

	computeObjectDescriptor();

	ofVideoPlayer player;
	player.load("videos/" + name + extension);
	player.play();
	player.setVolume(0);
	int totalFrames = player.getTotalNumFrames();

	player.setFrame(0);
	ofPixels & frame = player.getPixels();
	int height = player.getHeight();
	int width = player.getWidth();
	int nChannels = frame.getNumChannels();

	ofxCvColorImage colored;
	colored.setFromPixels(frame);
	ofxCvGrayscaleImage grayscale;
	grayscale = colored;
	cv::Mat grayMat = cv::cvarrToMat(grayscale.getCvImage());

	vector<pair<double, double>> descriptor = getTextureInfo(grayMat, height, width);

	vector<float> edgeDist;
	edgeDist.assign(5, 0.0);
	calcEdgeDist(grayMat, edgeDist, width, height);

	vector<frameDiff> frameDiffs;

	vector<int> prevFrameHist = calcHist(height, width, grayscale.getPixels());//for histograms
	vector<int> colorAvg = averagePerFrame(height, width, nChannels, frame);

	//for color average
	int avgRed = colorAvg[0];
	int avgGreen = colorAvg[1];
	int avgBlue = colorAvg[2];

	float rhythm = 0.0;
	int counter = 1;
	int facesDetected = 0;
	int totalObjs = 0;
	
	vector<cv::DMatch> matches;
	matches = objectInFrame(grayMat, width, height);
	if (matches.size() > MIN_MATCH) totalObjs++;

	ofxCvHaarFinder finder;
	finder.setup("haarcascade_frontalface_default.xml");
	facesDetected += finder.findHaarObjects(frame);

	for (int i = 10; i < totalFrames; i += totalFrames / 50) {
		//setup 
		player.setFrame(i);
		player.update();
		int index = player.getCurrentFrame();
		frame = player.getPixels();

		//color
		colorAvg = averagePerFrame(height, width, nChannels, frame);
		avgRed += colorAvg[0];
		avgGreen += colorAvg[1];
		avgBlue += colorAvg[2];

		//histograms
		ofxCvColorImage colorImg;
		colorImg.setFromPixels(frame);
		ofxCvGrayscaleImage newGrayscale;
		newGrayscale = colorImg;

		ofPixels & pixels = newGrayscale.getPixels();

		vector<int> currFrameHist = calcHist(height, width, pixels);
		float diff = calcHistDiff(prevFrameHist, currFrameHist);
		rhythm += diff;

		frameDiff currDiff = { i, diff };
		frameDiffs.push_back(currDiff);

		prevFrameHist = currFrameHist;
		counter++;

		//face detection
		facesDetected += finder.findHaarObjects(pixels);

		//edge
		grayMat = cv::cvarrToMat(newGrayscale.getCvImage());
		calcEdgeDist(grayMat, edgeDist, width, height);

		//object detection
		matches = objectInFrame(grayMat, width, height);
		if (matches.size() > MIN_MATCH) totalObjs++;
		
	}

	float avgY = 0.0; //for luminance avg
	avgRed /= counter;
	avgGreen /= counter;
	avgBlue /= counter;
	rhythm /= counter;

	objAvg = totalObjs * 1.0f / counter;

	avgY = LUMINANCE_RED * avgRed + LUMINANCE_GREEN * avgGreen + LUMINANCE_BLUE * avgBlue;

	sort(frameDiffs.begin(), frameDiffs.end(), differenceOp);

	vector<int> frameIndex;
	int nrIcons = 5;

	if (frameDiffs.size() < 5)
		nrIcons = frameDiffs.size();

	for (int i = 0; i < nrIcons; i++)
		frameIndex.push_back(frameDiffs[i].index);

	for (int i = 0; i < edgeDist.size(); i++)
		edgeDist[i] = edgeDist[i] / counter;

	sort(frameIndex.begin(), frameIndex.end());

	calcThreshold(frameDiffs, height, width);

	metadata.addTag("VIDEO");
	metadata.pushTag("VIDEO");

	metadata.setValue("NAME", name);
	metadata.setValue("THUMBNAIL", name);
	metadata.setValue("OBJECT", objAvg);
	if(rhythm < 10000)
		metadata.setValue("RHYTHM", "Slow");
	else if (rhythm < 50000)
		metadata.setValue("RHYTHM", "Medium");
	else
		metadata.setValue("RHYTHM", "Fast");

	metadata.addTag("ICONS");
	metadata.pushTag("ICONS");

	for (int i = 0; i < frameIndex.size(); i++) {
		player.setFrame(frameIndex[i]);
		ofImage frame;
		frame.setFromPixels(player.getPixels());

		string framePath = "icons/" + name + to_string(i) + ".png";
		frame.save(framePath);
		movingIcons.push_back(frame);
		if (i == 0)
			frame.save("thumbnails/" + name + ".png");

		metadata.setValue("FRAME", framePath, i);
	}

	metadata.popTag();//ICONS

	metadata.addTag("COLOR");
	metadata.pushTag("COLOR");

	metadata.setValue("RED", avgRed);
	metadata.setValue("GREEN", avgGreen);
	metadata.setValue("BLUE", avgBlue);

	metadata.popTag();//COLOR

	metadata.setValue("LUMINANCE", avgY);
	metadata.setValue("FACES", facesDetected / counter);
	writeEdgeDist(edgeDist);

	writeGaborDescriptor(descriptor);

	metadata.popTag();//VIDEO
	metadata.saveFile("videos/" + name + ".xml");
	metadata.loadFile("videos/" + name + ".xml");

	detect->clear();
}

void Video::loadMetadata()
{
	metadata.pushTag("VIDEO");

	thumbnail.load("thumbnails/" + name + ".png");

	metadata.pushTag("ICONS");
	int numThumbnails = metadata.getNumTags("FRAME");

	//WE'LL START LOADING THE MOVING ICONS
	for (int i = 0; i < numThumbnails; i++) {
		string framePath = metadata.getValue("FRAME", "", i);
		ofImage frame;
		frame.load(framePath);
		movingIcons.push_back(frame);
	}

	metadata.popTag();//ICONS

	metadata.popTag();

}

string Video::getName() {
	return name;
}

string Video::getPath() {
	return "videos/" + name + extension;
}

ofImage Video::getThumbnail() {
	return thumbnail;
}

vector<ofImage> Video::getMovingIcons()
{
	return movingIcons;
}

void Video::update() {
	thumbnail.update();
}

bool Video::objectDetected()
{
	return objAvg != 0.0f;
}

vector<int> Video::calcHist(int height, int width, ofPixels & frame)
{
	vector<int> hist;
	hist.assign(256, 0);

	for (int i = 0; i < height*width; i++) {
		int index = frame[i];
		hist[index] += 1;
	}

	return hist;
}

float Video::calcHistDiff(vector<int>hist1, vector<int> hist2)
{
	float diff = 0.0;

	for (int i = 0; i < 256; i++) {
		if (hist1[i] != 0) {
			float power = pow(hist2[i] - hist1[i], 2)*1.0;
			diff += power / hist1[i];
		}
	}

	return diff;
}

vector<cv::DMatch> Video::objectInFrame(cv::Mat grayMat, int width, int height)
{
	//frame finding
	vector<cv::KeyPoint> frame_keypoints;
	cv::Mat frame_descriptor;

	detect->detectAndCompute(grayMat, cv::noArray(), frame_keypoints, frame_descriptor);

	cv::BFMatcher matcher(cv::NORM_HAMMING2, false);
	vector<vector<cv::DMatch>> matches;
	if(frame_descriptor.size() != cv::Size(0,0))
		matcher.knnMatch(object_descriptor, frame_descriptor, matches, 2);

	vector<cv::DMatch> bestMatches;

	for (int i = 0; i < matches.size(); i++) {
		if (matches[i][0].distance < OBJ_THRESH * matches[i][1].distance)
			bestMatches.push_back(matches[i][0]);
	}


	return bestMatches;
}

float Video::calcThreshold(vector<frameDiff> frameD, int height, int width)
{
	float MD = 0.0f;
	int N = height * width;

	for (int i = 0; i < frameD.size(); i++)
		MD += (frameD[i].diff) / N;

	float STD = 0.0f;

	for (int i = 0; i < frameD.size(); i++)
		STD += (frameD[i].diff - MD) / N;

	STD = sqrt(STD);

	float threshold = MD + STD * 8;

	return 0.0f;
}

vector<int> Video::averagePerFrame(int height, int width, int nChannels, ofPixels & frame)
{
	int sumRed = 0;
	int sumGreen = 0;
	int sumBlue = 0;

	for (int i = 0; i < width*height*nChannels;) {
		sumRed += frame[i++];
		sumGreen += frame[i++];
		sumBlue += frame[i++];
	}

	vector <int> avg;
	avg.push_back(sumRed* 1.0 / (width * height));
	avg.push_back(sumGreen * 1.0 / (width * height));
	avg.push_back(sumBlue * 1.0 / (width * height));

	return avg;
}

void Video::calcEdgeDist(cv::Mat grayMat, vector<float> &distribution, int width, int height)
{
	int nrPixels = width * height;

	cv::Mat output;
	//vertical
	cv::Mat edgeFilter = (cv::Mat_<double>(2, 2) << 1, -1, 1, -1);
	cv::filter2D(grayMat, output, -1, edgeFilter);
	int nr = cv::countNonZero(output);
	distribution[0] += (cv::countNonZero(output)*1.0) / nrPixels;

	//horizontal
	edgeFilter = (cv::Mat_<double>(2, 2) << 1, 1, -1, -1);
	cv::filter2D(grayMat, output, -1, edgeFilter);
	distribution[1] += (cv::countNonZero(output)*1.0) / nrPixels;

	//45
	edgeFilter = (cv::Mat_<double>(2, 2) << sqrt(2), 0, 0, -sqrt(2));
	cv::filter2D(grayMat, output, -1, edgeFilter);
	distribution[2] += (cv::countNonZero(output)*1.0) / nrPixels;

	//135
	edgeFilter = (cv::Mat_<double>(2, 2) << 0, sqrt(2), -sqrt(2), 0);
	cv::filter2D(grayMat, output, -1, edgeFilter);
	distribution[3] += (cv::countNonZero(output)*1.0) / nrPixels;

	//a mess
	edgeFilter = (cv::Mat_<double>(2, 2) << 2, -2, -2, 2);
	cv::filter2D(grayMat, output, -1, edgeFilter);
	distribution[4] += (cv::countNonZero(output)*1.0) / nrPixels;

}

void Video::computeObjectDescriptor()
{
	string objectPath = "objects/" + name + ".png";
	ofImage imageObj;
	imageObj.load(objectPath);
	int height = imageObj.getHeight();

	ofxCvColorImage colored;
	ofPixels & pixels = imageObj.getPixels();
	colored.setFromPixels(pixels);

	ofxCvGrayscaleImage object;
	object = colored;

	//object finding
	cv::Mat objMat = cv::cvarrToMat(object.getCvImage());
	vector<cv::KeyPoint> object_keypoints;
	detect->detectAndCompute(objMat, cv::noArray(), object_keypoints, object_descriptor);
}

vector<pair<double, double>> Video::getTextureInfo(cv::Mat grayMat, int height, int width)
{
	vector<pair<double, double>> descriptor;

	double wavelength = 5;
	double orientation = 0;
	double aspectRatio = 0.5;
	double sigma = 5.0;
	double offset = 0.02;

	double orientationVar = 30;
	double wavelentghVar = 5;

	for (int i = 0; i < RATIO_VAR_NR; i++) {
		for (int j = 0; j < ORIENTATION_VAR_NR; j++) {
			cv::Mat gaborFilter = cv::getGaborKernel(cv::Size(FILTER_SIZE, FILTER_SIZE), sigma, orientation, wavelength, aspectRatio, offset);
			cv::Mat output;

			cv::filter2D(grayMat, output, -1, gaborFilter);

			cv::Scalar mean, stdDev;
			cv::meanStdDev(output, mean, stdDev);

			double variance = pow(stdDev[0], 2.0);

			descriptor.push_back(make_pair(mean[0], variance));
			orientation += orientationVar;

		}
		orientation = 0;
		wavelength += wavelentghVar;
	}

	return descriptor;
}

void Video::addVideoTags(vector<string> tags)
{
	metadata.loadFile("videos/" + name + ".xml");

	metadata.pushTag("VIDEO");

	metadata.addTag("TAGS");
	metadata.pushTag("TAGS");
	int totalNr = tags.size();

	for (int i = 0; i < totalNr; i++) {
		metadata.setValue("TAG", tags[i], i);
	}
	
	metadata.popTag();
	metadata.popTag();

	metadata.saveFile("videos/" + name + ".xml");
	
}

void Video::writeGaborDescriptor(vector<pair<double, double>> descriptor)
{
	metadata.addTag("TEXTURE");
	metadata.pushTag("TEXTURE");

	int nrFilters = descriptor.size();

	for (int i = 0; i < nrFilters; i++) {
		int index = metadata.addTag("GABOR");
		metadata.pushTag("GABOR", index);

		metadata.setValue("MEAN", descriptor[i].first);
		metadata.setValue("VARIANCE", descriptor[i].second);

		metadata.popTag();
	}

	metadata.popTag();

}

void Video::writeEdgeDist(vector<float> distribution)
{
	metadata.addTag("EDGES");
	metadata.pushTag("EDGES");

	metadata.setValue("VERTICAL", distribution[0]);
	metadata.setValue("HORIZONTAL", distribution[1]);
	metadata.setValue("DEGREES45", distribution[2]);
	metadata.setValue("DEGREES135", distribution[3]);
	metadata.setValue("NONDIRECTION", distribution[4]);

	metadata.popTag();
}