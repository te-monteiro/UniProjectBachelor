#include "UserPage.h"

UserPage::UserPage()
{
}

void UserPage::setup(map<string, VideoLibrary> &myEvents, int *stat, CameraFeed *myCamera)
{
	arrow.load("images/arrow.png");
	state = stat;
	camera = myCamera;

	faceNr = 0;
	next = -1;
	font.load("mono.ttf", 12);
	events.insert((myEvents).begin(), (myEvents).end());
	VideoLibrary* defaultLib = &(events["Default"]);
	currentVideo = 0;

	toPlay = defaultLib->getLibVideos();

	if (toPlay.size() != 0) {
		player.load(toPlay[currentVideo]->getPath());
		player.setLoopState(OF_LOOP_NONE);
		playerOn = false;
	}
	else faceNr = -1;

	lastTick = ofGetElapsedTimef();
		
}

void UserPage::draw()
{
	ofBackground(ofColor::white);
	if (toPlay.size() != 0) {
		player.draw(PLAYER_START_OFFSET, PLAYER_START_OFFSET, PLAYER_WIDTH, PLAYER_HEIGHT);
	}
	else {
		ofEnableAlphaBlending();
		ofSetColor(255, 255, 255, 255);
		camera->draw();
		ofDisableAlphaBlending();

		ofSetColor(40, 40, 40);
		font.drawString("We're sorry, we have no videos to show you", 40, 550);
	}
	ofEnableAlphaBlending();
	ofSetColor(255, 255, 255, 255);
	arrow.draw(0, 0, ARROW_SIZE, ARROW_SIZE);
	ofDisableAlphaBlending();

}

void UserPage::update()
{
	if (!playerOn) {
		playerOn = true;
		player.play();
	}

	if (!camera->isOn()) camera->start();

	camera->update();

		player.update();

		float currentTick = ofGetElapsedTimef();

		if (currentTick - lastTick > 10) {

			ofPixels& pixels = camera->getLiveFrame();

			int newFaceNr = camera->getFacesNr();

			if (newFaceNr != faceNr) switchEvent(newFaceNr);
			cout << "nr of faces " << faceNr << endl;

			next = findColorRelated(pixels);

			bool motion = camera->motionDetected(pixels);

			if (motion) {
				cout << "MOTION DETECT \n";
				if (toPlay.size() != 0)
					next = (currentVideo + 1) % toPlay.size();
			}

			lastTick = currentTick;
		}

		if (player.getIsMovieDone()) {
			if (next != -1)
				currentVideo = next;
			else currentVideo = (currentVideo + 1) % toPlay.size();

			switchVideo();
		}
	
	

}

void UserPage::mousePressed(int x, int y, int button)
{
	if (x < ARROW_SIZE && y < ARROW_SIZE && button == 0) {
		camera->pause();
		*state = 0;
	}


}

int UserPage::findColorRelated(ofPixels & pixels)
{

	vector<int> color = averagePerFrame(pixels);


	for (int i = 0; i < toPlay.size(); i++) {
		if (currentVideo != i) {
			Video* v = toPlay[i];
			metadata.loadFile("videos/" + v->getName() + ".xml");
			metadata.pushTag("VIDEO");

			metadata.pushTag("COLOR");

			if (color[1] > color[0] && color[1] > color[2]) {
				int blue = stoi(metadata.getValue("BLUE", ""));
				cout << "GREEN IS HIGH \n";
				if (blue >= color[1])
					return i;
			}

			if (color[0] > color[1] && color[0] > color[2]) {
				int red = stoi(metadata.getValue("RED", ""));
				cout << "RED IS HIGH \n";
				if (red >= color[0])
					return i;
			}

			if (color[2] > color[1] && color[2] > color[0]) {
				int green = stoi(metadata.getValue("GREEN", ""));
				cout << "BLUE IS HIGH \n";
				if (green >= color[2])
					return i;
			}

			metadata.popTag();
			metadata.popTag();
	
		}
	}
	

	return 0;
}

void UserPage::switchEvent(int newFaceNr)
{	
	faceNr = newFaceNr;
	switch (newFaceNr) {
	case 0:
		toPlay = (&(events["Default"]))->getLibVideos();
		break;
	case 1:
		toPlay = (&(events["Loner"]))->getLibVideos();
		break;

	default:
		toPlay = (&(events["Group"]))->getLibVideos();
		break;
	}
}

void UserPage::switchVideo()
{
	if (toPlay.size() != 0) {
		cout << "switching to " << toPlay[currentVideo]->getName() << endl;
		player.stop();
		player.load(toPlay[currentVideo]->getPath());
		player.setLoopState(OF_LOOP_NONE);
		player.play();
	}
}

vector<int> UserPage::averagePerFrame(ofPixels & pixels)
{
	int sumRed = 0;
	int sumGreen = 0;
	int sumBlue = 0;
	int height = pixels.getHeight();
	int width = pixels.getWidth();

	for (int i = 0; i < width*height*pixels.getNumChannels();) {
		sumRed += pixels[i++];
		sumGreen += pixels[i++];
		sumBlue += pixels[i++];
	}

	vector <int> avg;
	avg.push_back(sumRed* 1.0 / (width * height));
	avg.push_back(sumGreen * 1.0 / (width * height));
	avg.push_back(sumBlue * 1.0 / (width * height));

	return avg;
}