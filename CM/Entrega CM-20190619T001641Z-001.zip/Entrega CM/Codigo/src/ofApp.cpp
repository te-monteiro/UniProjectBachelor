#include "ofApp.h"


//--------------------------------------------------------------
void ofApp::setup() {
	state = MAIN_PAGE;
	ofBackground(255, 255, 255);

	camera.setup();
	setupAdmin();
	main.setup(&state);
}

//--------------------------------------------------------------
void ofApp::update() {
	switch (state) {
	case MAIN_PAGE:
		main.update();
		break;
	case ADMIN_PAGE:
		admin.update();
		break;
	case USER_PAGE:
		user.update();
		break;
	default:
		cout << "Unknown status";
	}
}

//--------------------------------------------------------------
void ofApp::draw() {
	switch (state) {
	case MAIN_PAGE:
		ofEnableAlphaBlending();
		ofSetColor(255, 255, 255, 255);
		main.draw();
		ofDisableAlphaBlending();
		break;
	case ADMIN_PAGE:
		ofEnableAlphaBlending();
		ofSetColor(255, 255, 255, 255);
		admin.draw();
		ofDisableAlphaBlending();
		break;
	case USER_PAGE:
		ofEnableAlphaBlending();
		ofSetColor(255, 255, 255, 255);
		user.draw();
		ofDisableAlphaBlending();
		break;
	default:
		cout << "Unknown status";
	}
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key) {


}

//--------------------------------------------------------------
void ofApp::keyReleased(int key) {

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y) {
	switch (state) {
	case MAIN_PAGE:

		break;
	case ADMIN_PAGE:
		admin.mousePosition(x, y);
		break;
	case USER_PAGE:

		break;
	default:
		cout << "Unknown status";
	}

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button) {
	switch (state) {
	case MAIN_PAGE:
		main.mousePressed(x, y, button);
		break;
	case ADMIN_PAGE:
		admin.mousePressed(x, y, button);
		break;
	case USER_PAGE:
		user.mousePressed(x, y, button);
		break;
	default:
		cout << "Unknown status";
	}
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y) {

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y) {

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h) {

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg) {

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo) {
	if (state == ADMIN_PAGE)
		admin.dragEvent(dragInfo);
}

void ofApp::setupAdmin() {
	//we load our settings file
	//if it doesn't exist we make one
	if (XML.loadFile("mySettings.xml"))
		ofLog() << "mySettings loaded with success";
	else {
		XML.saveFile("mySettings.xml");

	}

	//events that will be reading from XML settings file
	map<string, VideoLibrary> events;

	//total number of events
	int numEvents = XML.getNumTags("EVENT");
	if (numEvents == 0) {

		XML.addTag("EVENT");

		XML.pushTag("EVENT");
		XML.setValue("NAME", "Default");

		XML.popTag();

		XML.addTag("EVENT");

		XML.pushTag("EVENT", 1);
		XML.setValue("NAME", "Loner");

		XML.popTag();
		XML.addTag("EVENT");

		XML.pushTag("EVENT", 2);
		XML.setValue("NAME", "Group");

		XML.popTag();

		XML.saveFile("mySettings.xml");

		events.insert(make_pair("Default", VideoLibrary()));
	}

	for (int i = 0; i < numEvents; i++) {

		XML.pushTag("EVENT", i);//inside a single event tag

		string eventName = XML.getValue("NAME", "");

		vector<string> videoNames;

		int videosNum = XML.getNumTags("VIDEO");

		for (int w = 0; w < videosNum; w++) {
			string name = XML.getValue("VIDEO", "",w);
			videoNames.push_back(name);
		}

		//getting out of a tag

	//with all info about videos' loc, we initiate a new video library & add it to our events map
		VideoLibrary library;
		library.setup(videoNames);

		events.insert(make_pair(eventName, library));

		//getting out of an event tag
		XML.popTag();
	}

	//initiating the adming page
	admin.setup(events, &state, &camera);
	user.setup(events, &state, &camera);
}

void ofApp::setupUser() {

	
}
