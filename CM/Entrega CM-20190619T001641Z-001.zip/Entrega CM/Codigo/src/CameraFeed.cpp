#include "CameraFeed.h"

CameraFeed::CameraFeed()
{
}

void CameraFeed::setup()
{
	finder.setup("haarcascade_frontalface_default.xml");
	faceNr = 0;

	start();

	motion = false;
	lastTick = ofGetElapsedTimef();

}

void CameraFeed::update()
{
	camera.update();

	float currentTick = ofGetElapsedTimef();

	if (currentTick - lastTick > 10) {
		if (camera.isFrameNew()) {
			ofPixels & pixels = camera.getPixels();
			currentFeed.setFromPixels(pixels);

			faceNr = finder.findHaarObjects(currentFeed, 80, 80);
			motion = motionDetected(pixels);
		
		}
		lastTick = currentTick;
		
	}


}

void CameraFeed::draw()
{
	camera.draw(CAM_START_OFFSET, CAM_START_OFFSET);

	if(motion)
		for (int i = 0; i < contourFinder.nBlobs; i++) {
			contourFinder.blobs[i].draw(0,0);

			// draw over the centroid if the blob is a hole
			ofSetColor(255);
			if (contourFinder.blobs[i].hole) {
				ofDrawBitmapString("hole",
					contourFinder.blobs[i].boundingRect.getCenter().x + 360,
					contourFinder.blobs[i].boundingRect.getCenter().y + 540);
			}
		}
	
	ofNoFill();
	for (unsigned int i = 0; i < finder.blobs.size(); i++) {
		ofRectangle cur = finder.blobs[i].boundingRect;
		ofDrawRectangle(cur.x, cur.y, cur.width, cur.height);
	}
	
}

void CameraFeed::pause()
{
	camera.close();
}

void CameraFeed::start()
{
	camera.setVerbose(true);
	camera.setDesiredFrameRate(60);
	camera.initGrabber(CAM_WIDTH, CAM_HEIGHT);

	ofPixels & pixels = camera.getPixels();
	

	ofxCvColorImage color;
	color.setFromPixels(pixels);
	previous = color;
}

bool CameraFeed::isOn()
{
	return camera.isInitialized();
}

int CameraFeed::getFacesNr()
{
	return faceNr;
}

bool CameraFeed::motionDetected(ofPixels & pixels)
{
	ofxCvColorImage color;
	color.setFromPixels(pixels);
	ofxCvGrayscaleImage grayscale;
	grayscale = color;

	ofxCvGrayscaleImage grayDiff;
	grayDiff.allocate(currentFeed.getWidth(), currentFeed.getHeight());

	// take the abs value of the difference between background and incoming and then threshold:
	int threshold = 20;
	grayDiff.absDiff(previous, grayscale);
	grayDiff.blurGaussian(9);
	grayDiff.threshold(threshold);

	cv::Mat motion = cv::cvarrToMat(grayDiff.getCvImage());
	cv::Scalar mean, stdDev;
	cv::meanStdDev(motion, mean, stdDev);

	previous = grayscale;

	contourFinder.findContours(grayDiff, 20, (pixels.getHeight() * pixels.getWidth()) / 3, 10, true);
	
	
	return stdDev[0] > 55;
}

ofPixels & CameraFeed::getLiveFrame()
{
	return camera.getPixels();
}

