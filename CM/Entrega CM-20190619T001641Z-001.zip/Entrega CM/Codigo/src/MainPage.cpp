#include <stdio.h>
#include "MainPage.h"


MainPage::MainPage()
{
}

void MainPage::setup(int *stat)
{
	state = stat;
	adm.load("images/admin.jpg");
	usr.load("images/user.jpg");
	adm_b.load("images/admin_b.png");
	usr_b.load("images/user_b.png");
	who.load("images/who.png");
	choose.load("images/choose.png");
}

void MainPage::draw()
{
	ofBackground(ofColor::white);

	adm.draw(155, 250, 299, 208);
	usr.draw(610, 200, 300, 300);
	adm_b.draw(170, 520, 260, 84);
	usr_b.draw(630, 520, 260, 84);
	who.draw(158, 10);
	choose.draw(288, 110);
}

void MainPage::update()
{
}

void MainPage::mousePressed(int x, int y, int button)
{
	if (x > 170 && x < 430 && y > 520 && y < 604 && button == 0) {
		*state = 1;
	}
	else if (x > 630 && x < 890 && y > 520 && y < 604 && button == 0) {
		*state = 2;
	}
}

