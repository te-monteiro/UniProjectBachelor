//
//  VideoLibrary.cpp
//  cm_1819
//
//player->load(video.getPath());
//player->play();
//  Created by Marta Carlos on 08/04/2019.
//

#include <stdio.h>
#include "VideoLibrary.h"


VideoLibrary::VideoLibrary() {
	page = 0;
	topVideos.insert(topVideos.begin(), videos.begin(), videos.end());

	loading = false;
	hoverVideoOn = false;
	playerOn = false;
	insideTag = 0;
	insideThumbnail = 0;
	ofBackground(ofColor::white);
}

void VideoLibrary::setup(vector<string> eventVideos) {

	
	for (int i = 0; i < eventVideos.size(); i++) {
		Video* video = new Video(eventVideos[i]);
		videos.push_back(video);
	}

	page = 0;
	topVideos.insert(topVideos.begin(), videos.begin(), videos.end());

	
	loading = false;
	hoverVideoOn = false;
	playerOn = false;
	insideTag = 0;
	insideThumbnail = 0;
	ofBackground(ofColor::white);
}

void VideoLibrary::update() {
	if (playerOn)
		videoPlayer.update();
}


void VideoLibrary::drawUI() {
	//ofSetColor(ofColor::white);
	if (!playerOn) {
		ofEnableAlphaBlending();
		ofSetColor(255, 255, 255, 255);
		if (hoverVideoOn) {
			float time = ofGetElapsedTimef();

			int y = VIDEO_TOP + insideTag * TAG_SECTION;
			int x = SIDEBAR_WIDTH + VIDEO_LEFT_SPACE + insideThumbnail * VIDEO_SPACE_WITDH;

			Video video = getVideo(insideTag, insideThumbnail);
			vector<ofImage> movingIcons = video.getMovingIcons();
			int seqSize = movingIcons.size();

			float duration = seqSize / 6.0;

			float position = fmodf(time, duration);
			int i = (position / duration * seqSize);

			movingIcons[i].draw(x, y, THUMBNAIL_WIDTH, THUMBNAIL_HEIGHT);

		}
		//player->draw(insideVideoX, insideVideoY, THUMBNAIL_WIDTH, THUMBNAIL_HEIGHT);
		vector<Video*>::iterator it = topVideos.begin();

		for (int i = 0; i < 3 && it < topVideos.end(); i++) { //by tag

			int y = VIDEO_TOP + i * TAG_SECTION;

			for (int j = 0; j < 3 && it < topVideos.end(); j++) { //by video tag
				int x = SIDEBAR_WIDTH + VIDEO_LEFT_SPACE + j * VIDEO_SPACE_WITDH;

				if (!(hoverVideoOn && i == insideTag && j == insideThumbnail))
					(topVideos[i * 3 + j]->getThumbnail()).draw(x, y, THUMBNAIL_WIDTH, THUMBNAIL_HEIGHT);
				it++;
			}
		}
		ofDisableAlphaBlending();
	}
	else {
		metadata.pushTag("VIDEO");
		
		ofEnableAlphaBlending();
		ofSetColor(255, 255, 255, 255);
		videoPlayer.draw(10, 10, 730, 490);
		ofDisableAlphaBlending();

		//border
		ofSetColor(40, 40, 40);
		ofDrawRectangle(META_BORDER_X, META_BORDER_Y, META_BORDER_WIDTH, META_BORDER_HEIGHT);
		
		//white rectangle
		ofSetColor(255, 255, 255);
		ofDrawRectangle(METADA_BG_X, METADA_BG_Y, META_WITDH, META_HEIGHT);

		font.load("mono.ttf", 12);
		ofSetColor(40, 40, 40);
		drawMetaInfo();
		drawTags();

		metadata.popTag();		
	}
}

/*
 * @pre: x > SIDEBAR_WIDTH
 */
void VideoLibrary::hoverVideo(int x, int y) {
	int library_x = (x - SIDEBAR_WIDTH) % VIDEO_SPACE_WITDH;
	int library_y = y % TAG_SECTION;
	bool leftVideo = false;

	if (library_x > VIDEO_LEFT_SPACE && library_x < VIDEO_LEFT_SPACE + THUMBNAIL_WIDTH) { //still inside a thumbnail
		if (library_y > VIDEO_TOP && library_y < VIDEO_TOP + THUMBNAIL_HEIGHT) {
			if (!hoverVideoOn) {
				int tag = y / TAG_SECTION;
				int thumbnail = (x - SIDEBAR_WIDTH) / VIDEO_SPACE_WITDH;
				try {
					insideTag = tag;
					insideThumbnail = thumbnail;;
					Video video = getVideo(tag, thumbnail);
					hoverVideoOn = true;
				}
				catch (int e) {}
			}
		}
		else leftVideo = true;
	}
	else leftVideo = true;

	if (leftVideo) {
		int tag = y / TAG_SECTION;
		int thumbnail = (x - SIDEBAR_WIDTH) / VIDEO_SPACE_WITDH;
		hoverVideoOn = false;
	}
}

Video VideoLibrary::getVideo(int tag, int thumbnail) {

	vector<Video*>::iterator it = topVideos.begin();

	for (int i = 0; i < 3 && it < topVideos.end(); i++) {
		if (i == tag) {
			for (int j = 0; j < 3 && it < topVideos.end(); j++) {
				if (j == thumbnail)
					return *topVideos[i * 3 + j];
				it++;
			}
		}
		else
			for (int n = 0; n < 3 && it < topVideos.end(); n++)
				it++;
	}
	throw - 1;
}

void VideoLibrary::drawMetaInfo()
{
	
	int height = 1;
	//metadata
	
	font.drawString("Name: ", META_START_X, META_START_Y);
	font.drawString(metadata.getValue("NAME", ""), META_START_X + 80, META_START_Y);

	font.drawString("Faces: ", META_START_X, META_START_Y + META_TEXT_OFFSET_Y);
	font.drawString(metadata.getValue("FACES", ""), META_START_X + META_TEXT_OFFSET_X, META_START_Y + height * META_TEXT_OFFSET_Y);
	height++;

	font.drawString("Luminance: ", META_START_X, META_START_Y + height * META_TEXT_OFFSET_Y);
	font.drawString(metadata.getValue("LUMINANCE", ""), META_START_X + META_TEXT_OFFSET_X + 2, META_START_Y + height * META_TEXT_OFFSET_Y);
	height++;

	font.drawString("Object: ", META_START_X, META_START_Y + height * META_TEXT_OFFSET_Y);
	font.drawString(metadata.getValue("OBJECT", ""), META_START_X + META_TEXT_OFFSET_X, META_START_Y + height * META_TEXT_OFFSET_Y);
	height++;

	font.drawString("Rhythm: ", META_START_X, META_START_Y + height * META_TEXT_OFFSET_Y);
	font.drawString(metadata.getValue("RHYTHM", ""), META_START_X + META_TEXT_OFFSET_X, META_START_Y + height * META_TEXT_OFFSET_Y);
	height++;

	metadata.pushTag("COLOR");

	font.drawString("Color ", META_START_X, META_START_Y + height * META_TEXT_OFFSET_Y);
	height++;

	font.drawString("Red: ", META_START_X + 10, META_START_Y + height * META_TEXT_OFFSET_Y);
	font.drawString(metadata.getValue("RED", ""), META_START_X + META_TEXT_OFFSET_X + 10, META_START_Y + height * META_TEXT_OFFSET_Y);
	height++;

	font.drawString("Green: ", META_START_X + 10, META_START_Y + height * META_TEXT_OFFSET_Y);
	font.drawString(metadata.getValue("GREEN", ""), META_START_X + META_TEXT_OFFSET_X + 10, META_START_Y + height * META_TEXT_OFFSET_Y);
	height++;

	font.drawString("Blue: ", META_START_X + 10, META_START_Y + height * META_TEXT_OFFSET_Y);
	font.drawString(metadata.getValue("BLUE", ""), META_START_X + META_TEXT_OFFSET_X + 10, META_START_Y + height * META_TEXT_OFFSET_Y);
	height++;

	metadata.popTag();

	metadata.pushTag("EDGES");

	font.drawString("Edges ", META_START_X, META_START_Y + height * META_TEXT_OFFSET_Y);
	height++;

	font.drawString("Vertical: ", META_START_X + 10, META_START_Y + height * META_TEXT_OFFSET_Y);
	font.drawString(metadata.getValue("VERTICAL", ""), META_START_X + META_TEXT_OFFSET_X + 15, META_START_Y + height * META_TEXT_OFFSET_Y);
	height++;

	font.drawString("Horizontal: ", META_START_X + 10, META_START_Y + height * META_TEXT_OFFSET_Y);
	font.drawString(metadata.getValue("HORIZONTAL", ""), META_START_X + META_TEXT_OFFSET_X + 20, META_START_Y + height * META_TEXT_OFFSET_Y);
	height++;

	font.drawString("45�: ", META_START_X + 10, META_START_Y + height * META_TEXT_OFFSET_Y);
	font.drawString(metadata.getValue("DEGREES45", ""), META_START_X + META_TEXT_OFFSET_X + 15, META_START_Y + height * META_TEXT_OFFSET_Y);
	height++;

	font.drawString("135�: ", META_START_X + 10, META_START_Y + height * META_TEXT_OFFSET_Y);
	font.drawString(metadata.getValue("DEGREES135", ""), META_START_X + META_TEXT_OFFSET_X + 15, META_START_Y + height * META_TEXT_OFFSET_Y);
	height++;

	font.drawString("Non-dir: ", META_START_X + 10, META_START_Y + height * META_TEXT_OFFSET_Y);
	font.drawString(metadata.getValue("NONDIRECTION", ""), META_START_X + META_TEXT_OFFSET_X + 15, META_START_Y + height * META_TEXT_OFFSET_Y);
	height++;

	metadata.popTag();
}

void VideoLibrary::drawTags()
{
	//border
	ofSetColor(40, 40, 40);
	ofDrawRectangle(TAGS_BORDER_X, TAGS_BORDER_Y, TAGS_BORDER_WITDH, TAGS_BORDER_HEIGHT);

	//white rectangle
	ofSetColor(255, 255, 255);
	ofDrawRectangle(TAGS_X, TAGS_Y, TAGS_WIDTH, TAGS_HEIGHT);

	ofSetColor(40, 40, 40);
	int tagsNr = metadata.getNumTags("TAGS");
	
	if (tagsNr > 0) {
		metadata.pushTag("TAGS");
		
		for (int i = 0; i < 3 && i < tagsNr ; i++)
			font.drawString(metadata.getValue("TAG", "", i), TAGS_START_X, (i + 1) * TAGS_START_Y);

		if (tagsNr > 3)
			font.drawString("And more..", TAGS_START_X, 4 * TAGS_START_Y);

		metadata.popTag();
	}
	else font.drawString("No tags to display", TAGS_START_X, TAGS_START_Y);

}

vector<Video*> VideoLibrary::getLibVideos()
{
	return videos;
}

int VideoLibrary::getLibSize()
{
	return videos.size();
}

bool VideoLibrary::selectVideo(int x, int y) {

	int library_x = (x - SIDEBAR_WIDTH) % VIDEO_SPACE_WITDH;
	int library_y = y % TAG_SECTION;

	if (library_x > VIDEO_LEFT_SPACE && library_x < VIDEO_LEFT_SPACE + THUMBNAIL_WIDTH) { //still inside a thumbnail
		if (library_y > VIDEO_TOP && library_y < VIDEO_TOP + THUMBNAIL_HEIGHT) {
			if (!playerOn) {
				int tag = y / TAG_SECTION;
				int thumbnail = (x - SIDEBAR_WIDTH) / VIDEO_SPACE_WITDH;
				try {
					Video video = getVideo(tag, thumbnail);
					if (metadata.loadFile("videos/" + video.getName() + ".xml"))
						cout << "cenas \n";
					playerOn = true;
					videoPlayer.load(video.getPath());
					videoPlayer.setLoopState(OF_LOOP_NORMAL);
					videoPlayer.play();
					return true;
				}
				catch (int i) {
					return false;
				}
			}
		}
	}
	return false;
}

void VideoLibrary::turnPlayerOff() {
	videoPlayer.stop();
	playerOn = false;
}

void VideoLibrary::deleteVideo() {

}

bool VideoLibrary::isPlayerOn() {
	return playerOn;
}

void VideoLibrary::addVideo(string name, vector<string> tags)
{
	Video* video = new Video(name);

	if (tags.size()) video->addVideoTags(tags);

	videos.push_back(video);
	topVideos.push_back(video);
}


void VideoLibrary::nextPage()
{
	topVideos.clear();
	if ((page + 1) * 9 < videos.size())
		page++;
	topVideos.insert(topVideos.begin(), videos.begin() + page * 9, videos.end());
}

void VideoLibrary::prevPage()
{
	topVideos.clear();
	if (page != 0)
		page--;
	topVideos.insert(topVideos.begin(), videos.begin() + page * 9, videos.end());
}
