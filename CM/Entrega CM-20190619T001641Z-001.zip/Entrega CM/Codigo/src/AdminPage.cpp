//
//  AdminPage.cpp
//  cm_1819
//
//  Created by Marta Carlos on 08/04/2019.
//

#include <stdio.h>
#include "AdminPage.h"

AdminPage::AdminPage() {

}

void AdminPage::setup(map<string, VideoLibrary> &myEvents, int *stat, CameraFeed *myCamera) {

	//Load images
	sideBar.load("images/side.png");
	arrow.load("images/arrow.png");
	save.load("images/save.png");
	loadVideo.load("images/load.png");
	debugMode.load("images/debug.png");
	next.load("images/next.png");
	previous.load("images/previous.png");

	state = stat;
	camera = myCamera;

	events.insert((myEvents).begin(), (myEvents).end());
	displayedEvent = &(events["Default"]);
	displayedName = "Default";
	in_state = DEFAULT;
	settings.loadFile("mySettings.xml");

	// font setup
	font.load("mono.ttf", 12);

	//TAG input field setup
	tagInput.setup(INPUT_MSG, "");
	tagInput.setShape(INPUT_X_OFFSET, INPUT_START_Y, INPUT_WIDTH, INPUT_HEIGHT);
	tagInput.addListener(this, &AdminPage::inputTagsListener);
	tagInput.setBackgroundColor(0xffff);
	tagInput.setBorderColor(0x0000);
	tagInput.setTextColor(0x0000);

	lastTick = ofGetElapsedTimef();
	faceNr = 0;
	colorAvg.assign(3, 0);

}

void AdminPage::update() {
	if (in_state == VIDEO)
		draggedVideo.update();
	if (in_state == DEBUG_MODE) {

		float currentTick = ofGetElapsedTimef();

		if (currentTick - lastTick > 10) {

			ofPixels& pixels = camera->getLiveFrame();

			faceNr = camera->getFacesNr();

			motion = camera->motionDetected(pixels);

			colorAvg = averagePerFrame(pixels);

			lastTick = currentTick;
		}

		camera->update();
	}

	displayedEvent->update();
}

void AdminPage::mousePosition(int x, int y) {
	displayedEvent->hoverVideo(x, y);
}

void AdminPage::draw() {

	ofBackground(ofColor::white);

	if (displayedEvent->isPlayerOn())
		displayedEvent->drawUI();
	else if (in_state == LOAD) {
		ofSetColor(40, 40, 40);
		font.drawString("Largar novo video", 200, 100);
	}
	else if (in_state == VIDEO) {
		//drawin title
		ofEnableAlphaBlending();
		ofSetColor(255, 255, 255, 255);
		draggedVideo.draw(VIDEO_X_OFFSET, VIDEO_Y_OFFSET, VIDEO_GRABBER_W, VIDEO_GRABBER_H);
		save.draw(SAVE_BUTTON_X, SAVE_BUTTON_Y, SAVE_BUTTON_SIZE, SAVE_BUTTON_SIZE);
		ofDisableAlphaBlending();

		ofSetColor(40, 40, 40);
		ofDrawRectangle(IN_BORDER_X_OFFSET, IN_BORDER_Y_OFFSET, BORDER_WIDTH, BORDER_HEIGHT);

		ofEnableAlphaBlending();
		ofSetColor(255, 255, 255, 255);
		tagInput.draw();
		ofDisableAlphaBlending();

		ofSetColor(40, 40, 40);
		font.drawString(videoDir, TITLE_X_OFFSET, TITLE_Y_OFFSET);
		font.drawString(INPUT_LABEL, LABEL_X_OFFSET, LABEL_Y_OFFSET);
	}
	else if (in_state == OBJECT) {
		ofSetColor(40, 40, 40);
		font.drawString("Largar objecto a ser analisado", 200, 100);
	}
	else if (in_state == ACCEPT) {
		draggedImage.draw(VIDEO_X_OFFSET, VIDEO_Y_OFFSET, VIDEO_GRABBER_W, VIDEO_GRABBER_H);
		save.draw(SAVE_BUTTON_X, SAVE_BUTTON_Y, SAVE_BUTTON_SIZE, SAVE_BUTTON_SIZE);
	}
	else if (in_state == DEBUG_MODE) {
		ofEnableAlphaBlending();
		ofSetColor(255, 255, 255, 255);
		
		camera->draw();
		ofDisableAlphaBlending();

		drawDebugInfo();
	}
	else {
		ofEnableAlphaBlending();
		ofSetColor(255, 255, 255, 255);

		displayedEvent->drawUI();
		sideBar.draw(0, 0,217,720);

		previous.draw(220, 680, 40, 33);
		next.draw(1040, 680, 40, 33);
		
		loadVideo.draw(BUTTON_START, EVENT_BUTTON + BUTTON_DIF+ 20);
		debugMode.draw(BUTTON_START, EVENT_BUTTON + BUTTON_DIF + BUTTON_DIF+10);
		ofDisableAlphaBlending();
		
	}

	ofEnableAlphaBlending();
	ofSetColor(255, 255, 255, 255);
	arrow.draw(0, 0, ARROW_SIZE, ARROW_SIZE);
	ofDisableAlphaBlending();
}

void AdminPage::mousePressed(int x, int y, int button)
{
	if (x < ARROW_SIZE && y < ARROW_SIZE && button == 0) {
		if (displayedEvent->isPlayerOn()) {
			displayedEvent->turnPlayerOff();
			in_state = DEFAULT;
			*state = 1;
		}
		else if (in_state == VIDEO) {
			draggedVideo.stop();
			in_state = DEFAULT;
			*state = 1;
		}
		else if (in_state == LOAD) {
			in_state = DEFAULT;
			*state = 1;
		}
		else if (in_state == OBJECT) {
			in_state = DEFAULT;
			*state = 1;
		}
		else if (in_state == ACCEPT) {
			draggedImage.clear();
			in_state = DEFAULT;
			*state = 1;
		}
		else if (in_state == DEBUG_MODE) {
			camera->pause();
			in_state = DEFAULT;
			*state = 1;
		}
		else if (in_state == DEFAULT) {
			*state = 0;
		}
	}
	else if (y > 80 && y < 320 && x < IN_BORDER_X_OFFSET) {
		int m = (y - 80) / 80;
		switchEvent(m);
	}
	else if (x > BUTTON_START && x < BUTTON_END && y > EVENT_BUTTON + BUTTON_DIF + 20 && y < EVENT_BUTTON_END + BUTTON_DIF + 10&& button == 0 && in_state == DEFAULT)
		in_state = LOAD;
	else if (x > BUTTON_START && x < BUTTON_END && y > EVENT_BUTTON + BUTTON_DIF + BUTTON_DIF + 10 && y < EVENT_BUTTON_END + BUTTON_DIF + BUTTON_DIF + 10 && button == 0 && in_state == DEFAULT) {
		in_state = DEBUG_MODE;
		if (!camera->isOn()) camera->start();
	}
	else if (x > SAVE_BUTTON_X && x < SAVE_BUTTON_X + SAVE_BUTTON_SIZE && y > SAVE_BUTTON_Y && y < SAVE_BUTTON_Y + SAVE_BUTTON_SIZE && button == 0 && in_state == VIDEO) {
		in_state = OBJECT;
		draggedVideo.stop();
	}
	else if (x > SAVE_BUTTON_X && x < SAVE_BUTTON_X + SAVE_BUTTON_SIZE && y > SAVE_BUTTON_Y && y < SAVE_BUTTON_Y + SAVE_BUTTON_SIZE && button == 0 && in_state == ACCEPT) {
		saveImage(imageDir, videoDir);
		saveVideo(videoDir);
		in_state = DEFAULT;
	}

	else if (x > 1040 && y > 680 && x < 1080 && y < 713 && in_state == DEFAULT)
		displayedEvent->nextPage();
	else if (x > 220 && y > 680 && x < 260 && y < 713 && in_state == DEFAULT)
		displayedEvent->prevPage();
	else if (in_state == DEFAULT)
		displayedEvent->selectVideo(x, y);
}

void AdminPage::dragEvent(ofDragInfo info) {

	if (info.files.size() > 0 && in_state == LOAD) {
		draggedVideo = ofVideoPlayer();
		draggedVideo.load(info.files[0]);
		draggedVideo.setLoopState(OF_LOOP_NORMAL);
		draggedVideo.play();
		in_state = VIDEO;
		videoDir = *info.files.data();
	}
	else if (info.files.size() > 0 && in_state == OBJECT) {
		draggedImage = ofImage();
		draggedImage.load(info.files[0]);
		in_state = ACCEPT;
		imageDir = *info.files.data();
	}
}

void AdminPage::inputTagsListener(string &input)
{
	if (input.size())
	{
		stringstream tagStream(input);
		string tag;

		while (getline(tagStream, tag, ','))
			tags.push_back(tag);

		tagInput.setup(INPUT_MSG, "");
		tagInput.setShape(INPUT_X_OFFSET, INPUT_START_Y, INPUT_WIDTH, INPUT_HEIGHT);
	}
}

void AdminPage::drawDebugInfo()
{
	//border
	ofSetColor(40, 40, 40);
	ofDrawRectangle(DEBUG_BORDER_X, DEBUG_BORDER_Y, DEBUG_BORDER_WIDTH, DEBUG_BORDER_HEIGHT);

	//white rectangle
	ofSetColor(255, 255, 255);
	ofDrawRectangle(DEBUG_X, DEBUG_Y, DEBUG_WIDTH, DEBUG_HEIGHT);

	ofSetColor(40, 40, 40);
	
	font.drawString("Nr of faces detected: ", DEBUG_START_X, DEBUG_START_Y);
	font.drawString(to_string(faceNr), DEBUG_START_X + 300, DEBUG_START_Y);
	int height = 1;
	if(motion)
		font.drawString("Motion was detected!", DEBUG_START_X, DEBUG_START_Y + height* DEBUG_OFFSET_Y);
	else font.drawString("No motion was detected...", DEBUG_START_X, DEBUG_START_Y + height* DEBUG_OFFSET_Y);
	height++;

	font.drawString("Color", DEBUG_START_X, DEBUG_START_Y + height * DEBUG_OFFSET_Y);
	height++;
	int width = 1;

	font.drawString("Red: ", DEBUG_START_X + 10, DEBUG_START_Y + height * DEBUG_OFFSET_Y);
	font.drawString(to_string(colorAvg[0]), DEBUG_START_X + 50, DEBUG_START_Y + height * DEBUG_OFFSET_Y);
	width++;

	font.drawString("Blue: ", DEBUG_START_X +170, DEBUG_START_Y + height * DEBUG_OFFSET_Y);
	font.drawString(to_string(colorAvg[2]), DEBUG_START_X  + 240 , DEBUG_START_Y + height * DEBUG_OFFSET_Y);
	width++;

	font.drawString("Green: ", DEBUG_START_X + 300, DEBUG_START_Y + height * DEBUG_OFFSET_Y);
	font.drawString(to_string(colorAvg[1]), DEBUG_START_X + 400, DEBUG_START_Y + height * DEBUG_OFFSET_Y);

}

void AdminPage::saveVideo(string dir) {
	const char * origin_dir = strdup(dir.c_str());

	remDir(&dir);
	copy(origin_dir, "data/videos/" + dir);

	draggedVideo.stop();
	displayedEvent->addVideo(dir, tags);

	int libSize = displayedEvent->getLibSize();

	int index = getEventTagIndex(displayedName);

	settings.pushTag("EVENT", index);
	settings.setValue("VIDEO", dir, libSize);
	settings.popTag();

	settings.saveFile("mySettings.xml");
	
}

void AdminPage::switchEvent(int i)
{
	string e = eventsl[i];
	int n = getEventTagIndex(e);
	if (n == -1) {
		events.insert(make_pair(e, VideoLibrary()));
		
	}
	displayedEvent = &(events[e]);
	displayedName = e;
}

void AdminPage::saveImage(string dir, string name)
{
	remDir(&name);
	string obj = name.substr(0, name.find("."));
	copy(strdup(dir.c_str()), ("data/objects/" + obj + getExt(dir)).c_str());
	in_state = DEFAULT;
}

int AdminPage::getEventTagIndex(string eventName)
{

	int eventsNr = settings.getNumTags("EVENT");
	for (int i = 0; i < eventsNr; i++) {
		settings.pushTag("EVENT", i);
		string name = settings.getValue("NAME", "");
		settings.popTag();
		if (name._Equal(eventName)) return i;
	}
	return -1;
}

void AdminPage::remDir(string * dir)
{
	const size_t last_slash_idx = dir->find_last_of("\\/");
	if (std::string::npos != last_slash_idx)
	{
		dir->erase(0, last_slash_idx + 1);
	}
}

string AdminPage::getExt(string dir)
{
	const size_t period_idx = dir.rfind('.');
	if (std::string::npos != period_idx)
	{
		dir.erase(0, period_idx);
	}
	return dir;
}

void AdminPage::copy(string from, string to)
{
	fstream in(from, ios::binary | ios::in);
	fstream out(to, ios::binary | ios::out);

	char c;
	while (true) {
		c = in.get();
		if (in.eof()) break;
		out.put(c);
	}
	in.close();
	out.close();
}

vector<int> AdminPage::averagePerFrame(ofPixels & pixels)
{
	int sumRed = 0;
	int sumGreen = 0;
	int sumBlue = 0;
	int height = pixels.getHeight();
	int width = pixels.getWidth();

	for (int i = 0; i < width*height*pixels.getNumChannels();) {
		sumRed += pixels[i++];
		sumGreen += pixels[i++];
		sumBlue += pixels[i++];
	}

	vector <int> avg;
	avg.push_back(sumRed* 1.0 / (width * height));
	avg.push_back(sumGreen * 1.0 / (width * height));
	avg.push_back(sumBlue * 1.0 / (width * height));

	return avg;
}