#pragma once

#include "ofMain.h"
#include "Video.h"

/*
 This class represents an admin's user video lib
 */
class VideoLibrary : public ofBaseApp {

public:
	//Constants
	VideoLibrary();

	const int THUMBNAIL_HEIGHT = 146;
	const int THUMBNAIL_WIDTH = 260;
	const int TAG_SECTION = 240;
	const int VIDEO_TOP = 40;
	const int VIDEO_LEFT_SPACE = 18;
	const int VIDEO_SPACE_WITDH = 288;
	const int SIDEBAR_WIDTH = 201;

	const int META_BORDER_X = 745;
	const int META_BORDER_Y = 10;

	const int METADA_BG_X = 750;
	const int METADA_BG_Y = 15;

	const int META_START_X = 760;
	const int META_START_Y = 40;

	const int META_TEXT_OFFSET_X = 100;
	const int META_TEXT_OFFSET_Y = 30;

	const int META_WITDH = 300;
	const int META_HEIGHT = 480;

	const int META_BORDER_WIDTH = 310;
	const int META_BORDER_HEIGHT = 490;

	const int TAGS_BORDER_WITDH = 730;
	const int TAGS_BORDER_HEIGHT = 200;

	const int TAGS_OFFSET_X = 0;
	const int TAGS_OFFSET_Y = 0;

	const int TAGS_X = 15;
	const int TAGS_Y = 515;

	const int TAGS_START_X = 20;
	const int TAGS_START_Y = 550;

	const int TAGS_WIDTH = 720;
	const int TAGS_HEIGHT = 190;

	const int TAGS_BORDER_X = 10;
	const int TAGS_BORDER_Y = 510;

	//Variables
	vector<Video*> videos;
	vector<Video*> topVideos;
	ofxXmlSettings metadata;
	ofVideoPlayer videoPlayer;
	ofTrueTypeFont font;
	//int detailedVideo;
	//string eventName;

	bool loading;
	bool hoverVideoOn;
	bool playerOn;
	int insideThumbnail;
	int insideTag;
	int page;

	//SetUp methods
	void drawUI();
	void update();

	//Video related methods
	void setup(vector<string> eventVideos);
	void hoverVideo(int x, int y);
	void turnPlayerOff();
	bool selectVideo(int x, int y);
	void deleteVideo();
	bool isPlayerOn();
	void addVideo(string name, vector<string> tags);
	void nextPage();
	void prevPage();
	vector<Video*> getLibVideos();
	int getLibSize();
	

private:
	Video getVideo(int x, int y);
	void drawMetaInfo();
	void drawTags();
};
