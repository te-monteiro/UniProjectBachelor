#include "ofMain.h"

class MainPage {

public:
	MainPage();

	//Variables
	int *state;
	ofImage adm;
	ofImage usr;
	ofImage adm_b;
	ofImage usr_b;
	ofImage who;
	ofImage choose;

	//Methods
	void setup(int *state);
	void draw();
	void update();
	void mousePressed(int x, int y, int button);


};
