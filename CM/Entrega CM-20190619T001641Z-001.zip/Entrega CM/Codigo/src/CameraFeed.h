#pragma once

#include "ofMain.h"
#include "opencv2/imgproc/imgproc.hpp"
#include <opencv2/features2d.hpp>
#include "ofxCvHaarFinder.h"


class CameraFeed
{
public:
	CameraFeed();

	//constants
	const int CAM_WIDTH = 730;
	const int CAM_HEIGHT = 490;
	const int CAM_START_OFFSET = 10;
	static constexpr int ARROW_SIZE = 80;

	//variables
	ofVideoGrabber camera;
	ofxCvHaarFinder finder;
	ofImage currentFeed;
	ofxCvGrayscaleImage previous;
	bool motion;
	float lastTick;

	ofxCvContourFinder 	contourFinder;

	int faceNr;

	//methods
	void setup();
	void update();
	void draw();
	void pause();
	void start();
	bool isOn();

	int getFacesNr();
	bool motionDetected(ofPixels & pixels);
	ofPixels& getLiveFrame();

};

