#pragma once
#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup() {
	xPos = 0;
	yPos = 0;
	index = 0;

	currentPage = 1;
	numPages = 0;

	//window
	width = 1920; 
	height = 1001;

	//modo inicial
	mode = BEM_VINDO;

	//imagens
	imagem.setWindow(width, height);
	imagem.loadImages();

	imagesSize = imagem.getSize();
	allImages = imagem.getAllImages();
	imagesByEvents = imagem.getImagesByEvents();

	//videos
	video.setWindow(width, height);
	video.loadVideos();

	videosSize = video.getSize();
	allVideos = video.getAllVideos();
	videosByEvents = video.getVideosByEvents();

	//user
	isVideo = false;

	//background color
	ofBackground(ofColor::white);
}

//--------------------------------------------------------------
void ofApp::update() {
	switch (mode) {
	case VIDEO:
		video.update();
		break;
	case CAMARA:
		camara.update();
		break;
	case ONESELECT:
		video.update();
		index++;
		break;
	case USER:
		user.update(isVideo);
	default:
		cout << "Unknown status";
	}
}

//--------------------------------------------------------------
void ofApp::draw() {
	font.load("Philosopher-Regular.ttf", ((ofGetWindowWidth() * 30) / width));

	ofSetColor(ofColor::black);
	font.drawString("Imagens ", ((ofGetWindowWidth() * 628) / width), ((ofGetWindowHeight() * 40) / height));
	font.drawString("Videos ", ((ofGetWindowWidth() * 850) / width), ((ofGetWindowHeight() * 40) / height));
	font.drawString("Camara ", ((ofGetWindowWidth() * 1050) / width), ((ofGetWindowHeight() * 40) / height));
	font.drawString("User ", ((ofGetWindowWidth() * 1255) / width), ((ofGetWindowHeight() * 40) / height));

	ofSetColor(ofColor::white);

	switch (mode) {
	case BEM_VINDO:
		bemVindo();
		break;
	case IMAGES:
		drawImages();
		break;
	case VIDEO:
		drawVideos();
		break;
	case ONESELECT:
		oneSelect(); 
		break;
	case CAMARA:
		camara.show();
		break;
	case USER:
		drawUser();
		break;
	default:
		cout << "Unknown status";
	}
}


void ofApp::bemVindo() {
	font.load("Philosopher-Regular.ttf", ((ofGetWindowWidth() * 60) / width));
	ofSetColor(ofColor::black);
	font.drawString("Bem vindo :) ", (ofGetViewportWidth() / 2) - ((ofGetWindowWidth() * 178) / width), (ofGetWindowHeight() / 2) - ((ofGetWindowHeight() * 30) / height));
}

//Method that get and draw the pages numbers
void ofApp::pages(int currentPage) {
	int aux = 0;
	if (mode == IMAGES) {
		numPages = imagesSize / 8;
		aux = imagesSize;
	}
	else if (mode == VIDEO) {
		numPages = videosSize / 8;
		aux = videosSize;
	}

	if (aux % 8 != 0)
		numPages++;

	font.load("Philosopher-Regular.ttf", ((ofGetWindowWidth() * 15) / width));
	ofSetColor(ofColor::black);

	//draw arrows
	font.drawString("<", (ofGetWindowWidth() / 2) - ((ofGetWindowWidth() * 100) / width), ofGetWindowHeight() - ((ofGetWindowHeight() * 100) / height));
	font.drawString(ofToString(currentPage), (ofGetWindowWidth() / 2), ofGetWindowHeight() - ((ofGetWindowHeight() * 100) / height));
	font.drawString(">", (ofGetWindowWidth() / 2) + ((ofGetWindowWidth() * 100) / width), ofGetWindowHeight() - ((ofGetWindowHeight() * 100) / height));
}

void ofApp::drawImages() {
	pages(currentPage);
	ofSetColor(ofColor::white);

	if (imagesSize > 0)
		imagem.draw(imagem.getCurrent());
}

void ofApp::drawVideos() {
	pages(currentPage);
	ofSetColor(ofColor::white);

	if (videosSize > 0)
		video.draw(video.getCurrent());
}

//Method that select one image or video
void ofApp::oneSelect() {
	font.load("Philosopher-Regular.ttf", 10);
	ofFill();
	ofSetColor(0, 0, 0, 200);
	//rectangle where we are writting the metadata
	ofDrawRectangle(0, 0, 250, ofGetHeight());
	ofSetColor(ofColor::white);

	int indice = 0;

	if (lastMode == IMAGES) { //Images
		indice = xPos / (imagem.getImageWidth() + 250);

		if (yPos > (ofGetViewportHeight() / 2))
			indice += 4;

		nImg = indice + ((currentPage - 1) * 8);
		imagem.drawOneImage(nImg);
	}
	else if (lastMode == VIDEO) { //videos
		int indice = xPos / (video.getVideoWidth() + 250);

		if (yPos > (ofGetViewportHeight() / 2))
			indice += 4;

		nVideo = indice + ((currentPage - 1) * 8);
		video.drawOneVideo(nVideo);

		video.metadata(nVideo, index);
	}
}

//Method that will show the galery in mode USER 
void ofApp::drawUser() {
	int numFace = camara.getNumFaces();
	int eventNum = 0;

	if (numFace == 1)
		eventNum = 1; //OnePerson
	else if (numFace == 2)
		eventNum = 2; //TwoPeople
	else if (numFace > 2)
		eventNum = 3; //People

	//eventNum = 4 is to the event motion
	bool isObject = false;
	if (camara.hasObject())
		isObject = true;

	vector<ofImage> imagesToPlay;
	for (int i = 0; i < imagesSize; i++) {
		if (imagesByEvents[i] == eventNum || (isObject && imagesByEvents[i] == 4))
			imagesToPlay.push_back(allImages[i]);
	}

	vector<ofVideoPlayer> videosToPlay;
	for (int j = 0; j < videosSize; j++) {
		if (videosByEvents[j] == eventNum || (isObject && videosByEvents[j] == 4))
			videosToPlay.push_back(allVideos[j]);
	}

	user.setVideos(videosToPlay);
	user.setImages(imagesToPlay);

	user.draw(isVideo);
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button) {
	int currentMode;
	int currentDir;

	if (mode == IMAGES) {
		currentMode = imagem.getCurrent();
		currentDir = imagem.getDirSize();
	}
	else if (mode == VIDEO) {
		currentMode = video.getCurrent();
		currentDir = video.getDirSize();
	}

	//go to the left page
	if (x > ((ofGetWindowWidth() * 860) / width) && x < ((ofGetWindowWidth() * 875) / width) && y >((ofGetWindowHeight() * 885) / height) && y < ((ofGetWindowHeight() * 900) / height) && button == 0) {

		if (currentPage > 1) {
			currentMode -= 8;

			currentMode %= currentDir;

			currentPage--;

			if (mode == IMAGES)
				imagem.setCurrent(currentMode);
			else if (mode == VIDEO)
				video.setCurrent(currentMode);
		}
	}
	//go to the right page
	else if (x > ((ofGetWindowWidth() * 1055) / width) && x < ((ofGetWindowWidth() * 1075) / width) && y >((ofGetWindowHeight() * 885) / height) && y < ((ofGetWindowHeight() * 900) / height) && button == 0) {

		if (currentPage < numPages) {
			if (currentDir > 0) {
				currentMode += 8;

				currentMode %= currentDir;

				currentPage++;

				if (mode == IMAGES)
					imagem.setCurrent(currentMode);
				else if (mode == VIDEO)
					video.setCurrent(currentMode);
			}
		}
	}
	//image mode
	else if (x > ((ofGetWindowWidth() * 628) / width) && x < ((ofGetWindowWidth() * 770) / width) && y >((ofGetWindowHeight() * 15) / height) && y < ((ofGetWindowHeight() * 55) / height) && button == 0) {
		if (mode = !ONESELECT) {
			imagem.setCurrent(0);
			currentPage = 1;
		}
		mode = IMAGES;
	}
	//video mode
	else if (x > ((ofGetWindowWidth() * 853) / width) && x < ((ofGetWindowWidth() * 970) / width) && y >((ofGetWindowHeight() * 15) / height) && y < ((ofGetWindowHeight() * 55) / height) && button == 0) {
		if (mode = !ONESELECT) {
			video.setCurrent(0);
			currentPage = 1;
		}
		mode = VIDEO;
	}
	//camara mode
	else if (x > ((ofGetWindowWidth() * 1049) / width) && x < ((ofGetWindowWidth() * 1185) / width) && y >((ofGetWindowHeight() * 15) / height) && y < ((ofGetWindowHeight() * 55) / height) && button == 0)
		mode = CAMARA;

	//user mode
	else if (x > ((ofGetWindowWidth() * 1254) / width) && x < ((ofGetWindowWidth() * 1355) / width) && y >((ofGetWindowHeight() * 15) / height) && y < ((ofGetWindowHeight() * 55) / height) && button == 0)
		mode = USER;

	//oneselect mode
	else if (mode == IMAGES || mode == VIDEO) {
		xPos = x;
		yPos = y;

		if (y > ((ofGetWindowHeight() * 135) / height) && y < ((ofGetWindowHeight() * 860) / height) && x >((ofGetWindowWidth() * 45) / width) && x < ((ofGetWindowWidth() * 1855) / width)) {
			lastMode = mode;
			mode = ONESELECT;
		}
	}
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key) {
	switch (key) {
	case 'p':
		video.keyPressedVideo(nVideo);
		break;
	default:
		cout << "Press 'p' for pause the video ";
	}
}