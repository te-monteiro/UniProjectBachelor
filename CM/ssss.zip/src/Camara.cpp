#pragma once
#include "Camara.h"

Camara::Camara() {
	this->numFaces = 0;
	this->learningTime = 1;
	this->thresholdValue = 60;
	this->isObject = false;

	cam.setup(640, 480);
	finder.setup("haarcascade_frontalface_default.xml");
}

void Camara::update() {
	cam.update();
	//count the number of faces that show up
	numFaces = finder.findHaarObjects(captureImage);
	getNumFaces();

	if (cam.isFrameNew()) {
		background.setLearningTime(learningTime);
		background.setThresholdValue(thresholdValue);
		background.update(cam, thresholded);
		thresholded.update();
	}
}

void Camara::show() {
	cam.draw(ofGetViewportWidth() / 2 - 300, ofGetViewportHeight() / 2 - 300);

	//facial recognition by capturing image
	captureImage.setFromPixels(cam.getPixels());
	ofNoFill();
	ofSetColor(ofColor::pink);

	//rectangles that identify the faces
	for (unsigned int i = 0; i < finder.blobs.size(); i++) {
		ofRectangle rec = finder.blobs[i].boundingRect;
		ofDrawRectangle(rec.x + (ofGetViewportWidth() / 2 - 300), rec.y + (ofGetViewportHeight() / 2 - 300), rec.width, rec.height);
	}

	ofPixels pix = thresholded.getPixels();
	int nPixWhite = 0;
	for (int i = 0; i < pix.size(); i++) {
		if (pix.getColor(i) == ofColor::white)
			nPixWhite++;
	}

	isObject = nPixWhite > 20;
}

int Camara::getNumFaces() {
	return numFaces;
}

bool Camara::hasObject() {
	return isObject;
}