#pragma once
#include "ofMain.h"
#include "Videos.h"
#include "Images.h"

class User {
public:
	User();
	//method
	void setVideos(vector<ofVideoPlayer> &videosToPlay);
	void setImages(vector<ofImage> &imagesToPlay);
	void draw(bool & isVideo);
	void update(bool &isVideo);

private:
	//variable
	//video
	int currentVideo;
	vector<ofVideoPlayer> videosByEvent;
	ofVideoPlayer playVideo;

	//image
	int currentImage;
	vector<ofImage> imagesByEvent;
	ofImage playImage;

	int counter;
};