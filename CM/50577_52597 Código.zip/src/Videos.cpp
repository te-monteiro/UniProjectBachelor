#include "Videos.h"

Videos::Videos() {
	currentVideo = 0;
	edgeDistribution.assign(5, float());

	match.load("Referencia/fingersImage.jpg");
	colorMatch.setFromPixels(match.getPixels().getData(), match.getWidth(), match.getHeight());
	grayscaleMatch = colorMatch;

	finder.setup("haarcascade_frontalface_default.xml");
    rhythm = 0.0; //tem a ver com a diferenca das imagens
}

void Videos::setWindow(int width, int height) {
	this->width = width;
	this->height = height;
}

void Videos::loadVideos() {
	font.load("Philosopher-Regular.ttf", ((ofGetWindowWidth() * 12) / width));
	dir.listDir("movies/");
	dir.allowExt("mov");
	// in linux the file system doesn't return file lists ordered in alphabetical order
	dir.sort(); 

	if (getDirSize()) {
		videos.assign(getDirSize(), ofVideoPlayer());
		videosByEvents.assign(dir.size(), int());
	}

	for (int i = 0; i < videos.size(); i++) {
		videos[i].load(dir.getPath(i));
		videos[i].play();
		videos[i].setPaused(true);
		videos[i].setLoopState(OF_LOOP_NONE);
		videosByEvents[i] = getEventNum(i);
	}
}

void Videos::update() {
	for (int i = 0; i < videos.size(); i++) {
		videos[i].update();
	}
}

vector<ofVideoPlayer> Videos::getAllVideos() {
	return videos;
}

vector<int> Videos::getVideosByEvents() {
	return videosByEvents;
}

int Videos::getSize() {
	return videos.size();
}

int Videos::getDirSize() {
	return dir.size();
}

int Videos::getCurrent() {
	return currentVideo;
}

void Videos::setCurrent(int newCurrent) {
	currentVideo = newCurrent;
}

int Videos::getVideoWidth() {
	return videos[currentVideo].getWidth();
}

//Method that draw all videos
void Videos::draw(int current) {
	int c = 0, l = 0;

	for (int i = 0; i < 2 && current < videos.size(); i++) {
		for (int j = 0; j < 4 && current < videos.size(); j++) {
			videos[current].draw(((ofGetWindowWidth() * (50 + c)) / width), ((ofGetWindowHeight() * (150 + l)) / height));
			c += (ofGetWindowWidth() * 700) / width;
			current++;
		}
		l += (ofGetWindowHeight() * 400) / height;
		c = 0;
	}
}

// Method that draw only one video, the video selected
void Videos::drawOneVideo(int nVideo) {
	//carregar no sitio onde nao esta preenchido
	if (nVideo > videos.size())
		nVideo = videos.size() - 1;

	videos[nVideo].setPaused(false);
	videos[nVideo].draw((ofGetViewportWidth() / 2) - 250, (ofGetViewportHeight() / 2) - 250);
}

string Videos::getNameVideo(int nVideo) {
	string name = dir.getName(nVideo);
	int index = name.find_last_of("_");
	return name.substr(0, index);
}

string Videos::getEventName(int nVideo) {
	string name = dir.getName(nVideo);
	int auxIndex = name.find_last_of(".");
	name = name.substr(0, auxIndex);
	int index = name.find_last_of("_");
	return name.substr(index + 1, auxIndex);
}

int Videos::getEventNum(int nVideo) {
	string nameEvent = getEventName(nVideo);
	int eventNum = 0;

	//by default the event is "No Event"
	if (nameEvent._Equal("OnePerson"))
		eventNum = 1;
	else if (nameEvent._Equal("TwoPeople"))
		eventNum = 2;
	else if (nameEvent._Equal("People"))
		eventNum = 3;
	else if (nameEvent._Equal("Motion"))
		eventNum = 4;

	return eventNum;
}

string Videos::getPath(string nameVideo, string eventName) {
	return "movies/" + nameVideo + "_" + eventName;
}

void Videos::keyPressedVideo(int nVideo) {
	videos[nVideo].load(dir.getPath(nVideo));
	videos[nVideo].setPaused(true);
}

void Videos::getColors(int dimensionFrame, ofPixels & pixels) {
	int tRed = 0;
	int tGreen = 0;
	int tBlue = 0;
	int tHue = 0;

	for (int i = 0; i < dimensionFrame; i++) {
		tRed += pixels.getColor(i).r;
		tGreen += pixels.getColor(i).g;
		tBlue += pixels.getColor(i).b;
		tHue += pixels.getColor(i).getHue();
	}

	red = tRed * 1.0 / dimensionFrame;
	green = tGreen * 1.0 / dimensionFrame;
	blue = tBlue * 1.0 / dimensionFrame;
	hue = tHue * 1.0 / dimensionFrame;
}

void Videos::calcEdgeDistribution(int dimensionFrame, Mat mat) {
	//matriz destin
	Mat dst; 

	//vertical
	Mat ver_egde_filter = (Mat_<float>(2, 2) << 1, -1, 1, -1);
	filter2D(mat, dst, -1, ver_egde_filter);
	float countNonZeroAux = countNonZero(dst) * 1.0;
	edgeDistribution[0] = countNonZeroAux / dimensionFrame;

	//horizontal
	Mat hor_edge_filter = (Mat_<float>(2, 2) << 1, 1, -1, -1);
	filter2D(mat, dst, -1, hor_edge_filter);
	countNonZeroAux = countNonZero(dst) * 1.0;
	edgeDistribution[1] = countNonZeroAux / dimensionFrame;

	//45
	Mat dia45_edge_filter = (cv::Mat_<float>(2, 2) << sqrt(2), -1, 1, -sqrt(2));
	filter2D(mat, dst, -1, dia45_edge_filter);
	countNonZeroAux = countNonZero(dst) * 1.0;
	edgeDistribution[2] = countNonZeroAux / dimensionFrame;

	//135
	Mat dia135_edge_filter = (Mat_<float>(2, 2) << 0, sqrt(2), -sqrt(2), 0);
	filter2D(mat, dst, -1, dia135_edge_filter);
	countNonZeroAux = countNonZero(dst) * 1.0;
	edgeDistribution[3] = countNonZeroAux / dimensionFrame;

	//nao direcional
	Mat nond_edge_filter = (Mat_<float>(2, 2) << 2, -2, -2, 2);
	filter2D(mat, dst, -1, nond_edge_filter);
	countNonZeroAux = countNonZero(dst) * 1.0;
	edgeDistribution[4] = countNonZeroAux / dimensionFrame;
}

void Videos::calcTexture(Mat mat) {
	float sigma = 10.0;
	//orientation
	float theta = 0;
	//lambda
	float wavelength = 5;
	//aspectratio
	float gamma = 0.5;
	//phi
	float offset = 0.39;
	
	float wavelentghAux = 5;
	float orientation = 0.79;

	Mat dst;
	Scalar mean, varianceS;

	for (int i = 0; i < SIGMA; i++) {
		for (int j = 0; j < THETA; j++) {
			Mat gaborFilter = getGaborKernel(Size(FILTERS, FILTERS), sigma, theta, wavelength, gamma, offset);

			filter2D(mat, dst, -1, gaborFilter);
			meanStdDev(dst, mean, varianceS);

			float variance = pow(varianceS[0], 2);

			texture.push_back(make_pair(mean[0], variance));
			theta += orientation;
		}
		theta = 0;
		wavelength += wavelentghAux;
	}
}

void Videos::newMetadata(string xmlStructureVideo) {
	xml.setValue("Tags", "");
	xml.setValue("Event", "");
	xml.setValue("Luminancia", "");
	xml.setValue("Color", "");
	xml.setValue("Number of Faces", "");

	xml.setValue("Vertical", "");
	xml.setValue("Horizontal", "");
	xml.setValue("45", "");
	xml.setValue("135", "");
	xml.setValue("NonDirection", "");

	xml.setValue("Average", "");
	xml.setValue("Variance", "");

	xml.setValue("Match", "");

	xml.setValue("Rhythm", "");

	xml.saveFile(xmlStructureVideo);
}

void Videos::metadata(int nVideo, int i) {
	//get video name by the number of video
	videoName = getNameVideo(nVideo);
	//get event name by the number of video
	eventName = getEventName(nVideo);

	xmlStructureVideo = "xmlMovies/" + videoName + ".xml";

	if (!xml.loadFile(xmlStructureVideo))
		newMetadata(xmlStructureVideo);

	xml.loadFile(xmlStructureVideo);

	ofVideoPlayer video = videos[nVideo];

	int videoWidth = video.getWidth();
	int videoHeight = video.getHeight();
	int dimensionFrame = videoWidth * videoHeight;

	video.setFrame(i);
	ofPixels & pixels = video.getPixels();

	//colors: hue, red, blue, green
	getColors(dimensionFrame, pixels);

	//luminance
	luminancia = 0.2125*red + 0.7154*green + 0.0721*blue;

	colorFrame.setFromPixels(pixels.getData(), videoWidth, videoHeight);
	grayscaleFrame = colorFrame;

	//number of faces
	numFaces = finder.findHaarObjects(grayscaleFrame);

	Mat mat = ofxCv::toCv(grayscaleFrame.getPixels());

	//edge distribution
	calcEdgeDistribution(dimensionFrame, mat);

	//texture
	calcTexture(mat);

	//match
	//deteting keypoints
	Ptr<ORB> detector = ORB::create();
	vector<KeyPoint> keypointsImg, keypointsMatch;
	Mat descriptorImg, descriptorMatch;

	//detecting keypoints && computing descriptors
	detector->detectAndCompute(mat, noArray(), keypointsImg, descriptorImg);
	detector->detectAndCompute(mat, noArray(), keypointsMatch, descriptorMatch);

	//matching descriptors
	BFMatcher matcher(cv::NORM_HAMMING, true);
	matcher.match(descriptorImg, descriptorMatch, matches);

	nMatches = matches.size();

	//rhythm
	vector<int> histogram;
	histogram.assign(255 + 1, 0);
	for (int h = 0; h < dimensionFrame; h++) {
		histogram[pixels[h]] += 1;
	}

	//calculo do histogram
	for (int k = 0; k < 256; k++) {
		rhythm += std::abs(histogram[grayscaleFrame.getPixels()[k]] - histogram[grayscaleFrame.getPixels()[k - 1]]);
	}

	//metadata
	font.drawString("Metadados:", 5, 15);

	//tags
	xml.setValue("Tags", videoName);
	string tags = xml.getValue("Tags", "");
	font.drawString("Tags: " + tags, 5, 30);

	//event
	xml.setValue("Event", eventName);
	string events = xml.getValue("Event", "");
	font.drawString("Event: " + events, 5, 50);

	//color
	xml.setValue("Color", hue);
	string colorFinal = xml.getValue("Color", "");
	font.drawString("Color:" + colorFinal, 5, 70);

	//luminance
	xml.setValue("Luminancia", luminancia);
	string luminancias = xml.getValue("Luminancia", "");
	font.drawString("Luminancia: " + luminancias, 5, 90);
	
	//number of faces
	xml.setValue("Number of Faces", numFaces);
	string numFace = xml.getValue("Number of Faces", "");
	font.drawString("Number of Faces: " + numFace, 5, 110);

	//edge
	font.drawString("Edges:", 5, 130);

	xml.setValue("Vertical", edgeDistribution[0]);
	string vertical = xml.getValue("Vertical", "");
	font.drawString("Vertical: " + vertical, 20, 150);

	xml.setValue("Horizontal", edgeDistribution[1]);
	string horizontal = xml.getValue("Horizontal", "");
	font.drawString("Horizontal: " + horizontal, 20, 170);

	xml.setValue("45", edgeDistribution[2]);
	string quarenta5 = xml.getValue("45", "");
	font.drawString("45: " + quarenta5, 20, 190);

	xml.setValue("135", edgeDistribution[3]);
	string cento35 = xml.getValue("135", "");
	font.drawString("135: " + cento35, 20, 210);

	xml.setValue("NonDirection", edgeDistribution[4]);
	string nonDirection = xml.getValue("NonDirection", "");
	font.drawString("NonDirection: " + nonDirection, 20, 230);


	//texture
	font.drawString("Texture:", 5, 250);

	float mean = 0.0;
	float variance = 0.0;
	for (int j = 0; j < texture.size(); j++) {
		mean = texture[j].first / FILTERS;
		variance = texture[j].second / FILTERS;
	}

	xml.setValue("Average", mean);
	string averageString = xml.getValue("Average", "");
	font.drawString("Average: " + averageString, 20, 270);

	xml.setValue("Variance", variance);
	string varianceString = xml.getValue("Variance", "");
	font.drawString("Variance: " + varianceString, 20, 290);

	//match
	xml.setValue("Match", nMatches);
	string matchesString = xml.getValue("Match", "");
	font.drawString("Match: " + matchesString, 5, 310);

	//rhythm
	if (rhythm < 20000) {
		xml.setValue("Rhythm", "Muda pouco");
		font.drawString("Rhythm: Muda pouco", 5, 330);
	}
	else if (rhythm < 50000) {
		xml.setValue("Rhythm", "Muda normal");
		font.drawString("Rhythm: Muda normal", 5, 330);
	}
	else {
		xml.setValue("Rhythm", "Muda muito");
		font.drawString("Rhythm: Muda muito", 5, 330);
	}

	xml.saveFile(xmlStructureVideo);
}