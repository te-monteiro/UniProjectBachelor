#pragma once
#include "Images.h"

Images::Images() {
	currentImage = 0;
	edgeDistribution.assign(5, float());

	match.load("Referencia/Match.jpg");
	colorMatch.setFromPixels(match.getPixels().getData(), match.getWidth(), match.getHeight());
	grayscaleMatch = colorMatch;

	finder.setup("haarcascade_frontalface_default.xml");
};

void Images::setWindow(int width, int height) {
	this->width = width;
	this->height = height;
}

void Images::loadImages() {
	font.load("Philosopher-Regular.ttf", ((ofGetWindowWidth() * 12) / width));
	dir.listDir("images/");
	dir.allowExt("jpg");
	// in linux the file system doesn't return file lists ordered in alphabetical order
	dir.sort(); 

	if (dir.size()) {
		images.assign(dir.size(), ofImage());
		imagesByEvents.assign(dir.size(), int());
	}

	for (int i = 0; i < dir.size(); i++) {
		images[i].load(dir.getPath(i));
		imagesByEvents[i] = this->getEventNum(i);
	}
}

vector<ofImage> Images::getAllImages() {
	return images;
}

vector<int> Images::getImagesByEvents() {
	return imagesByEvents;
}

int Images::getSize() {
	return images.size();
}

int Images::getDirSize() {
	return dir.size();
}

int Images::getCurrent() {
	return currentImage;
}

void Images::setCurrent(int newCurrent) {
	currentImage = newCurrent;
}

int Images::getImageWidth() {
	return images[currentImage].getWidth();
}

//Method that draw all images
void Images::draw(int current) {
	int c = 0, l = 0;

	for (int i = 0; i < 2 && current < images.size(); i++) {
		for (int j = 0; j < 4 && current < images.size(); j++) {
			images[current].resize((ofGetWindowWidth() * 300) / width, (ofGetWindowHeight() * 300) / height);
			images[current].draw((ofGetWindowWidth() * (50 + c)) / width, (ofGetWindowHeight() * (150 + l)) / height);
			c += (ofGetWindowWidth() * 500) / width;
			current++;
		}
		l += (ofGetWindowHeight() * 400) / height;
		c = 0;
	}
}

// Method that draw only one image, the image selected
void Images::drawOneImage(int nImg) {
	images[nImg].draw((ofGetViewportWidth() / 2) - 250, (ofGetViewportHeight() / 2) - 250);
	images[nImg].resize((ofGetWindowWidth() * 500) / width, (ofGetWindowHeight() * 500) / height);

	metadata(nImg);
}

string Images::getName(int nImg) {
	string name = dir.getName(nImg);
	int index = name.find_last_of("_");
	return name.substr(0, index);
}

string Images::getEventName(int nImg) {
	string name = dir.getName(nImg);
	int auxIndex = name.find_last_of(".");
	name = name.substr(0, auxIndex);
	int index = name.find_last_of("_");
	return name.substr(index + 1, auxIndex);
}

int Images::getEventNum(int nImg) {
	string nameEvent = this->getEventName(nImg);
	int eventNum = 0;

	//by default the event is "No Event"
	if (nameEvent._Equal("OnePerson"))
		eventNum = 1;
	else if (nameEvent._Equal("TwoPeople"))
		eventNum = 2;
	else if (nameEvent._Equal("People"))
		eventNum = 3;
	else if (nameEvent._Equal("Motion"))
		eventNum = 4;

	return eventNum;
}

void Images::getColor(ofImage img) {
	ofPixels pixels = img.getPixels();
	int dimensionFrame = img.getWidth() * img.getHeight();
	int tRed = 0;
	int tGreen = 0;
	int tBlue = 0;
	int tHue = 0;

	for (int i = 0; i < dimensionFrame; i++) {
		tRed += pixels.getColor(i).r;
		tGreen += pixels.getColor(i).g;
		tBlue += pixels.getColor(i).b;
		tHue += pixels.getColor(i).getHue();
	}

	hue = tHue * 1.0 / dimensionFrame;
	red = tRed * 1.0 / dimensionFrame;
	green = tGreen * 1.0 / dimensionFrame;
	blue = tBlue * 1.0 / dimensionFrame;
}

void Images::calclEdgeDistribution(int dimensionImg, Mat mat) {
	Mat dst; //matriz destino

	//vertical
	Mat ver_egde_filter = (Mat_<float>(2, 2) << 1, -1, 1, -1);
	filter2D(mat, dst, -1, ver_egde_filter);
	float countNonZeroAux = countNonZero(dst) * 1.0;
	edgeDistribution[0] = countNonZeroAux / dimensionImg;

	//horizontal
	Mat hor_edge_filter = (Mat_<float>(2, 2) << 1, 1, -1, -1);
	filter2D(mat, dst, -1, hor_edge_filter);
	countNonZeroAux = countNonZero(dst) * 1.0;
	edgeDistribution[1] = countNonZeroAux / dimensionImg;

	//45
	Mat dia45_edge_filter = (Mat_<float>(2, 2) << sqrt(2), -1, 1, -sqrt(2));
	filter2D(mat, dst, -1, dia45_edge_filter);
	countNonZeroAux = countNonZero(dst) * 1.0;
	edgeDistribution[2] = countNonZeroAux / dimensionImg;

	//135
	Mat dia135_edge_filter = (Mat_<float>(2, 2) << 0, sqrt(2), -sqrt(2), 0);
	filter2D(mat, dst, -1, dia135_edge_filter);
	countNonZeroAux = countNonZero(dst) * 1.0;
	edgeDistribution[3] = countNonZeroAux / dimensionImg;

	//nao direcional
	Mat nond_edge_filter = (Mat_<float>(2, 2) << 2, -2, -2, 2);
	filter2D(mat, dst, -1, nond_edge_filter);
	countNonZeroAux = countNonZero(dst) * 1.0;
	edgeDistribution[4] = countNonZeroAux / dimensionImg;
}

void Images::calcTexture(Mat mat) {
	float sigma = 10.0;
	//orientation
	float theta = 0;
	//lambda
	float wavelength = 5;
	//aspectratio
	float gamma = 0.5;
	//phi
	float offset = 0.39;

	float wavelentghAux = 5;
	float orientation = 0.79;

	Mat dst;
	Scalar mean, varianceS;

	for (int i = 0; i < SIGMA; i++) {
		for (int j = 0; j < THETA; j++) {
			Mat gaborFilter = getGaborKernel(Size(FILTERS, FILTERS), sigma, theta, wavelength, gamma, offset);

			filter2D(mat, dst, -1, gaborFilter);
			meanStdDev(dst, mean, varianceS);

			float variance = pow(varianceS[0], 2);

			texture.push_back(make_pair(mean[0], variance));
			theta += orientation;
		}
		theta = 0;
		wavelength += wavelentghAux;
	}
}

void Images::matchImages(Mat matImg) {
	Mat matMatch = ofxCv::toCv(grayscaleMatch.getPixels());

	//keypoint detection Orb
	Ptr<ORB> detector = ORB::create();
	vector<KeyPoint > keypointsImg, keypointsMatch;
	Mat descriptorImg, descriptorMatch;

	detector->detectAndCompute(matImg, noArray(), keypointsImg, descriptorImg);
	detector->detectAndCompute(matMatch, noArray(), keypointsMatch, descriptorMatch);

	//descriptor matching
	BFMatcher matcher(NORM_HAMMING, true);
	matcher.match(descriptorImg, descriptorMatch, matches);

	nMatches = matches.size();
}

void Images::newMetadata(string xmlStructureImage) {
	xml.setValue("Tags", "");
	xml.setValue("Event", "");
	xml.setValue("Luminancia", "");
	xml.setValue("Color", "");

	xml.setValue("Number of Faces", "");

	xml.setValue("Vertical", "");
	xml.setValue("Horizontal", "");
	xml.setValue("45", "");
	xml.setValue("135", "");
	xml.setValue("NonDirection", "");

	xml.setValue("Average", "");
	xml.setValue("Variance", "");

	xml.setValue("Match", "");

	xml.saveFile(xmlStructureImage);
}

void Images::metadata(int nImg) {
	//get image name by the number of image
	imageName = getName(nImg);
	//get event name by the number of image
	eventName = getEventName(nImg);

	xmlStructureImage = "xmlImages/" + imageName + ".xml";

	if (!xml.loadFile(xmlStructureImage))
		newMetadata(xmlStructureImage);
	
	xml.loadFile(xmlStructureImage);

	ofImage img = images[nImg];
	ofPixels &pixelsImg = img.getPixels();
	int widthImg = img.getWidth();
	int heightImg = img.getHeight();
	int dimensionImg = widthImg * heightImg;

	//color
	getColor(img);

	//luminance
	luminancia = 0.2125*red + 0.7154*green + 0.0721*blue;

	//number of faces
	numFaces = finder.findHaarObjects(img);

	colorImg.setFromPixels(pixelsImg.getData(), widthImg, heightImg);
	grayscaleImg = colorImg;

	Mat mat = ofxCv::toCv(grayscaleImg.getPixels());

	//edge distribution
	calclEdgeDistribution(dimensionImg, mat);

	//texture
	calcTexture(mat);

	//match
	matchImages(mat);

	//metadata
	font.drawString("Metadados:", 5, 15);

	//tags
	xml.setValue("Tags", imageName);
	string tags = xml.getValue("Tags", "");
	font.drawString("Tags: " + tags, 5, 30);

	//event
	xml.setValue("Event", eventName);
	string events = xml.getValue("Event", "");
	font.drawString("Event: " + events, 5, 50);

	//color
	xml.setValue("Color", hue);
	string colorFinal = xml.getValue("Color", "");
	font.drawString("Color: " + colorFinal, 5, 70);

	//luminance
	xml.setValue("Luminancia", luminancia);
	string luminancias = xml.getValue("Luminancia", "");
	font.drawString("Luminancia: " + luminancias, 5, 90);

	//number of faces
	xml.setValue("Number of faces", numFaces);
	string numFace = xml.getValue("Number of faces", "");
	font.drawString("Number of faces: " + numFace, 5, 110);

	//edge
	font.drawString("Edges:", 5, 130);

	xml.setValue("Vertical", edgeDistribution[0]);
	string vertical = xml.getValue("Vertical", "");
	font.drawString("Vertical: " + vertical, 20, 150);

	xml.setValue("Horizontal", edgeDistribution[1]);
	string horizontal = xml.getValue("Horizontal", "");
	font.drawString("Horizontal: " + horizontal, 20, 170);

	xml.setValue("45", edgeDistribution[2]);
	string quarenta5 = xml.getValue("45", "");
	font.drawString("45: " + quarenta5, 20, 190);

	xml.setValue("135", edgeDistribution[3]);
	string cento35 = xml.getValue("135", "");
	font.drawString("135: " + cento35, 20, 210);

	xml.setValue("NonDirection", edgeDistribution[4]);
	string nonDirection = xml.getValue("NonDirection", "");
	font.drawString("NonDirection: " + nonDirection, 20, 230);

	//texture
	font.drawString("Texture:", 5, 250);

	float mean = 0.0;
	float variance = 0.0;
	for (int j = 0; j < texture.size(); j++) {
		mean = texture[j].first / FILTERS;
		variance = texture[j].second / FILTERS;
	}
	xml.setValue("Average", mean);
	string averageString = xml.getValue("Average", "");
	font.drawString("Average: " + averageString, 20, 270);

	xml.setValue("Variance", variance);
	string varianceString = xml.getValue("Variance", "");
	font.drawString("Variance: " + varianceString, 20, 290);

	//match
	xml.setValue("Match", nMatches);
	string matchesString = xml.getValue("Match", "");
	font.drawString("Match: " + matchesString, 5, 310);

	xml.saveFile(xmlStructureImage);
}