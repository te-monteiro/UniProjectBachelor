#pragma once
#include "ofMain.h"
#include "ofxCvHaarFinder.h"
#include "ofxCv.h"

class Camara {
public:
	Camara();

	//method
	void update();
	void show();
	int getNumFaces();
	bool hasObject();

private:
	//variables
	ofImage captureImage;

	int numFaces;

	ofVideoGrabber cam;
	ofxCvHaarFinder finder;

	ofxCv::RunningBackground background;
	ofImage thresholded;
	float learningTime;
	float thresholdValue;
	bool isObject;
};