import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

import Distance.DistanceMatrix;

public class Main {
	private static String[] currentSolution;
	private static String[] bestSolution;
	private static String[] worstSolution;
	private static String[] nextNeighbor;
	private static double temperature = 10000;
	private static int nIteration = 100;
	private static String typeArrefecimento = "GEOMETRICO";
	private static int numTotalCity = 0;
	

	public static void main(String[] args) {
		DistanceMatrix solution = new DistanceMatrix("m6ljihqbaht.txt");
		
		int nBestIteration = 0;
		long time = System.currentTimeMillis();

		create_initial_solution(solution);

		bestSolution = currentSolution;

		worstSolution = currentSolution;

		inicial_temperature(solution);
		System.out.println("Temperature inicial " + temperature);
		
		System.out.println("Primeira solucao\n");
		System.out.print("[");
		for (int i = 0; i < numTotalCity - 1; i++) {
			System.out.print(currentSolution[i] + ", ");
		}
		System.out.println(currentSolution[numTotalCity - 1] + "]"); // current.lenght e o numero de cidades
		System.out.println("Distancia: " + distance(currentSolution, solution) + "\n");



		while (temperature >= 10) {
			for (int i = 1; i < nIteration; i++) {
				nextNeighbor = neighbor(currentSolution);
				int d = distance(nextNeighbor, solution) - distance(currentSolution, solution);

				if (d < 0) {
					currentSolution = nextNeighbor;
					if (distance(currentSolution, solution) < distance(bestSolution, solution)) {
						bestSolution = currentSolution;
						nBestIteration = nIteration;
					}

				} else {

					Random rand = new Random();
					double randomNumber = rand.nextDouble();

					if (randomNumber < Math.exp(-1 * d / temperature))
						currentSolution = nextNeighbor;

				}


			}
			temperature = decaimento(temperature, typeArrefecimento);
			nIteration++;
			
			//System.out.println(distance(currentSolution, solution));
		}
		

		System.out.println("Melhor solucao\n");
		System.out.print("[");
		for (int i = 0; i < numTotalCity - 1; i++) {
			System.out.print(bestSolution[i] + ", ");
		}
		System.out.println(bestSolution[numTotalCity - 1] + "]"); // current.lenght e o numero de cidades
		System.out.println("Distancia: " + distance(bestSolution, solution) + "\n");
		System.out.println("Numero da iteracao melhor " + nBestIteration);

		System.out.println("Numero de iteracoes total: " + nIteration);
		System.out.println("Temperatura final " + temperature);
		long finalTime = System.currentTimeMillis() - time;
		System.out.println("Tempo em ms " + finalTime);

	}

	private static double decaimento(double temperature, String typeArrefecimento) {
		if (typeArrefecimento.equals("GRADUAL"))
			temperature = temperature / (1 + 0.0001 * temperature);
		else if (typeArrefecimento.equals("GEOMETRICO"))
			temperature = temperature * 0.9;
		return temperature;
	}

	private static String[] neighbor(String[] percurso) {
		String[] neighbor = new String[numTotalCity];
		Random random = new Random();
		int i = random.nextInt(numTotalCity - 2);
		int j = random.nextInt(numTotalCity - i) + i;
		int t = 0;
		int l = j;

		while (t <= i) {
			neighbor[t] = percurso[t];
			t++;
		}
		while (l > i) {
			neighbor[t] = percurso[l];
			l--;
			t++;
		}
		for (t = t; t < numTotalCity; t++) {
			neighbor[t] = percurso[t];
		}
		return neighbor;
	}

	private static void inicial_temperature(DistanceMatrix solution) {
		ArrayList<String> cities = solution.getCities();
		int custo = 0;

		for (int i = 0; i < numTotalCity - 2; i++) {
			for (int j = i + 1; j < numTotalCity - 1; j++) {
				// d = d(i,j) + d(i+1,j+1) - d(i,i+1) - d(j,j+1)
				int dist1 = solution.distance(cities.get(i), cities.get(j));
				int dist2 = solution.distance(cities.get(i + 1), cities.get(j + 1));
				int dist3 = solution.distance(cities.get(i), cities.get(i + 1));
				int dist4 = solution.distance(cities.get(j), cities.get(j + 1));

				custo = custo + dist1 + dist2 - dist3 - dist4;
			}
		}

		temperature = custo / (-1 * Math.log(0.95));
	}

	private static int distance(String[] caminho, DistanceMatrix solution) {
		int totalDistance = 0;
		int i = 0;
		while( i < numTotalCity - 1) {
			totalDistance = totalDistance + solution.distance(caminho[i], caminho[i + 1]);
			i++;
		}
		totalDistance = totalDistance + solution.distance(caminho[numTotalCity - 1], caminho[0]);

		return totalDistance;
	}

	private static void create_initial_solution(DistanceMatrix solution) {
		currentSolution = new String[30];
		Iterator<String> it = solution.getCities().iterator();
		int i = 0;
		while (it.hasNext()) {
			String aux = it.next();
			if (currentSolution.length <= i)
				currentSolution = resize(currentSolution);

			else {
				currentSolution[i] = aux;
				i++;
			}

			numTotalCity = i;
		}

	}

	private static String[] resize(String[] initialSolution) {
		String[] resize = new String[initialSolution.length * 2];
		int j = 0;
		while (j < initialSolution.length) {
			initialSolution[j] = resize[j];
			j++;
		}
		return resize;
	}

}
