import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Main {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		
		//1 input
		int numLines = Integer.parseInt(in.readLine());
		
		Transcript transcript = new Transcript(numLines);

		// i =  numLinha que estamos a tratar
		for(int i = 0; i < numLines; i++) {
			String line = in.readLine();
			
			transcript.keyboard(line , i);
		}
		
		
		int points = transcript.getPoints(in.readLine(), in.readLine());
		System.out.println(points);
	}

}
