import java.util.Hashtable;
import java.util.Map;

public class Transcript {

	//character = letra e Integer = coordenadas
	private Map<Character, int[]> keyboard;

	private int top;
	private int nLines;
	private int nLetters;

	public Transcript(int numLines) {
		keyboard = new Hashtable<Character, int[]>();
		nLines = numLines; 
		nLetters = 0;
		//top = max(r,c)
		top = 0;


	}


	@SuppressWarnings("null")
	public void keyboard(String line , int xCoordinate) {
		// TODO Auto-generated method stub
		char[] chars = line.toCharArray();
		nLetters = chars.length;
		for(int j = 0; j < nLetters; j++) {

			int[] coordinates = new int[2];

			//nLine in keybord
			coordinates[0] = xCoordinate;

			//nColumn in keyboard 
			coordinates[1] = j;

			keyboard.put(chars[j], coordinates);
		}

		top = Math.max(nLines, nLetters);

	}

	public int getPoints(String origWord, String transWord) {



		return 0;
	}


	private int calcDistPoints(char origChar, char transChar) {
		int xDist = Math.abs(2-4);
		int yDist = Math.abs(2-4);
		
		int result = top - Math.max(xDist, yDist);
		
		return result;
	}

}