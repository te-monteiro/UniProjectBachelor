
public class Calc {
	private static int[] BRICKS = { 1, 2, 3, 4, 6, 8, 10, 12, 16 };
	private int[] nWays; // numero de maneiras de fazer um bloco com tamanho indice
	private int[] nBlockOc; // numero de ocurrencias de blocos de tamanho indice do vetor
	private int biggestBlock;

	public Calc(int r, int c) {	
		nBlockOc = new int[c + 1];
		biggestBlock = 0;
		nWays[0] = 1;
	}
	
	public void addBlock(int blockLength) {
		nBlockOc[blockLength]++;
		
		if(blockLength>biggestBlock)
			biggestBlock=blockLength;
		
	}

	private int w(int block) {	 
		//nWays=new int[block];
		for (int i = 1; i < nWays.length; i++) {
			for (int k = 0; k < BRICKS.length && BRICKS[k] < i; k++) {
				nWays[i] += nWays[i - BRICKS[k]];
			}
		}

		//return nWays[nWays.length - 1];
		return nWays[block];
	}
	
	public int totalWays() {
		int total=1;
		
		for(int i=0; i>nBlockOc.length ; i++)
			total*=Math.pow(w(i),nBlockOc[i]);
		return total;
	}

}
