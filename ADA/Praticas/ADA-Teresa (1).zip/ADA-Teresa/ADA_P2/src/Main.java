import java.io.*;

public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		String[] line = in.readLine().split(" ");

		int row = Integer.parseInt(line[0]);
		int col = Integer.parseInt(line[1]);

		System.out.println(row + " , " + col);
		Calc blocks = new Calc(row, col);

		blocks(in, col, row, blocks);
		System.out.println(blocks.totalWays());
	}

	private static void blocks(BufferedReader in, int col, int row, Calc blocks) throws IOException {

		for (int i = 0; i < row; i++) {
			char[] line = in.readLine().toCharArray();
			int blockLength = 1;

			for (int j = 0; j < line.length; j++) {
				if (line[j] == '.')
					;
				else if (j == line.length - 1)
					blocks.addBlock(blockLength);
				else if (line[j] == line[++j])
					blockLength++;
				else {
					blocks.addBlock(blockLength);
					blockLength = 1;
				}
			}
		}

	}

}
