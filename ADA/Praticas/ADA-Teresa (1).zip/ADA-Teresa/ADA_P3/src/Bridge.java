
public class Bridge {
	
	int bestV;
	int bestN;
	
	public Bridge() {
		
	}
	
	private void c(int north, int south) {
		for(int n=1; n<10;n++) {
			for(int s=1;s<10;s++) {
				//if()
			}
		}
	}
	
	private void best(int v1, int n1, int v2, int n2) {
		if(v1>v2 || (v1==v2&&n1<=n2)) {
			bestN=n1;
			bestV=v1;
		}else {
			bestN=n2;
			bestV=v2;
		}	
	}
	
	private void aux(int n, int s) {
		best(n,1,s,1);
	}
}
