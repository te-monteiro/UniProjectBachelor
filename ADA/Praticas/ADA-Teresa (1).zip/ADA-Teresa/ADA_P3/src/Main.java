import java.io.*;
import java.util.*;

public class Main {
	
	private static Map<String,Integer> map;
	private static int[][] tradeVals;

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		
		BufferedReader in =	new BufferedReader( new InputStreamReader(System.in) );
		int nTests = Integer.parseInt(in.readLine());
		for(int i=0;i<nTests;i++) {
			
			Bridge fun = new Bridge();
			
			tradeVals=new int[2][];
			
			int nNCitys=Integer.parseInt(in.readLine());
			map = new HashMap<>(2*nNCitys);
			addCityToMap(nNCitys, in, 0);
			
			int nSCitys=Integer.parseInt(in.readLine());
			addCityToMap(nSCitys, in, 1);
			
		}
		
	}
	
	private static void addCityToMap(int nCity, BufferedReader in, int n_s) throws IOException {
		
		tradeVals[n_s]=new int[nCity];
		for (int i = 0; i < nCity; i++) {
			String[] line = in.readLine().split(" ");
			String os = line[1];
			tradeVals[n_s][i] = Integer.parseInt(line[2]);

			int aux = map.get(os);
			if (aux == -1)
				map.put(os, map.size());
		}
	}

}
