import java.io.*;

public class Main {
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader in =	new BufferedReader( new InputStreamReader(System.in) );

		int sticks;
		int child = Integer.parseInt(in.readLine());
		int max = Integer.MIN_VALUE;
		int integ;

		for(int i=0;i<child;i++) {
			String[] line=in.readLine().split(" ");
			sticks=Integer.parseInt(line[0]);
			for(int j=1;j<=sticks;j++) {
				integ=Integer.parseInt(line[j]);
				if(integ>max)
					max=integ;
			}
		}
		System.out.println(max);

		in.close();
	}

}
