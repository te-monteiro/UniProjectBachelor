
/**
 * @author Hugo Lopes
 *
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

		String[] line = in.readLine().split(" ");
		int p = Integer.parseInt(line[0]);
		int s = Integer.parseInt(line[1]);
		int t = Integer.parseInt(line[2]);
		int n = Integer.parseInt(line[3]);

		Min_Interference mI = new Min_Interference(p, s, t, n);

		for (int i = 0; i < p; i++)
			mI.addInterference(Integer.parseInt(in.readLine()));

		int r = Integer.parseInt(in.readLine());

		for (int j = 0; j < r; j++) {
			line = in.readLine().split(" ");
			mI.addConect(Integer.parseInt(line[0]), Integer.parseInt(line[1]));
		}

		System.out.println(mI.calcInterference());
	}

}
