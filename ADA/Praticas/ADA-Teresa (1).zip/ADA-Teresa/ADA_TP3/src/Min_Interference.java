
/**
 * @author Hugo Lopes
 *
 */

import java.math.BigInteger;
import java.util.*;

public class Min_Interference {

	private int[] interferences;
	private int nPeople, from, to, degree;
	private int interIndex;
	private List<Integer>[] graph;
	private boolean[] selected;
	private BigInteger[] length;
	private Queue<Node> connected;

	@SuppressWarnings("unchecked")
	public Min_Interference(int p, int s, int t, int n) {
		nPeople = p; // number nodes
		from = s;
		to = t;
		degree = n;
		interferences = new int[nPeople];
		selected = new boolean[nPeople];

		length = new BigInteger[nPeople];

		interIndex = 0;

		graph = new List[nPeople];
		for (int i = 0; i < graph.length; i++)
			graph[i] = new LinkedList<>();

		connected = new PriorityQueue<>(nPeople, new Node());
	}

	public void addInterference(int i) {
		interferences[interIndex] = i;
		interIndex++;
	}

	public void addConect(int from, int to) {
		graph[to].add(from);
		graph[from].add(to);
	}

	public BigInteger calcInterference() {
		return dijkstra().mod(BigInteger.valueOf((long) Math.pow(2, 45)));
	}

	private BigInteger dijkstra() {
		length[from] = BigInteger.valueOf(0);
		connected.add(new Node(BigInteger.ZERO, from));

		Node node;
		do {
			node = connected.remove();
			selected[node.getNode()] = true;
			exploreNode(node);
		} while (!connected.isEmpty());

		return length[to];
	}

	private void exploreNode(Node source) {
		BigInteger newLength;
		for (int node : graph[source.getNode()]) {
			if (!selected[node]) {
				if (node == to)
					newLength = length[source.getNode()];
				else
					newLength = length[source.getNode()].multiply(BigInteger.valueOf(degree))
							.add(BigInteger.valueOf(interferences[node]));

				if (length[node]==null /*.compareTo(BigInteger.valueOf(-1)) == 0*/ || newLength.compareTo(length[node]) < 0) {
					length[node] = newLength;
					connected.add(new Node(newLength, node));
				}
			}
		}
	}
}
