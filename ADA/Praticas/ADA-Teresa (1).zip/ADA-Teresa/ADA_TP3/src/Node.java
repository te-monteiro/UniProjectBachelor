import java.math.BigInteger;
import java.util.Comparator;

public class Node implements Comparator<Node> {
	private BigInteger noise;
	private int node;
	
	public Node() {
		
	}
	
	public Node(BigInteger noise,int node) {
		this.noise=noise;
		this.node=node;
	}
	
	public BigInteger getNoise() {
		return noise;
	}
	
	public void setNoise(BigInteger noise) {
		this.noise = noise;
	}
	
	public int getNode() {
		return node;
	}
	
	public void setNode(int node) {
		this.node = node;
	}

	@Override
	public int compare(Node n, Node m) {
		// TODO Auto-generated method stub
		return n.getNoise().compareTo(m.getNoise());
	}
	
	
}
