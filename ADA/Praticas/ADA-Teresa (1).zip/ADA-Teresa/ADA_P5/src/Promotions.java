import java.util.*;

public class Promotions {

	private int emp;
	private int[] sucs;
	private int[] preds;
	private List<Integer>[] outEdges;

	@SuppressWarnings("unchecked")
	public Promotions(int e) {
		emp = e;
		outEdges = new List[emp];
		
		for(List<Integer> a : outEdges)
			a=new LinkedList<Integer>();
		
	}

	public void addPrec(int x, int y) {

	}

	public void getAnswer(int a, int b) {
		sucs = new int[emp];
		preds = new int[emp];
	}

}
