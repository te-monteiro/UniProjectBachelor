/**
 * @author Hugo Lopes 49873
 * @author Maria Jacinto 48035
 */

public class Bridges {

	private int s;
	private int[] dist;

	private int[][] matrix;

	public Bridges(int space, int[] distances) {
		s = space;
		dist = distances;
	}	
	
	
	public int cheapBridges(int p, int c) {
		int r = p + 1; //linha 0 nao utilizada
		matrix = new int[r][c];
		
		// preenchimento da primeira linha da matriz
		matrix[1][0] = dist[0];
		for (int j = 1; j < c; j++) {
			if (matrix[1][j - 1] < dist[j])
				matrix[1][j] = matrix[1][j - 1];
			else
				matrix[1][j] = dist[j];
		}
		
		int dif, a = 0;
		
		// i:linha da matriz - corresponde n pontes
		for (int i = 2; i < r; i++) { 
			
			// j:coluna da matriz
			for (int j = 0; j < c; j++) { 
				dif = s + 1;
				if (j - (i - 1) * dif >= 0) {
					a = matrix[i - 1][j - dif] + dist[j];
					if (matrix[i][j - 1] > 0 && matrix[i][j - 1] < a)
						matrix[i][j] = matrix[i][j - 1];
					else
						matrix[i][j] = a;
				}
			}
		}
		return matrix[--r][--c];
	}
}
