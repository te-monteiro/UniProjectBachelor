/**
 * @author Hugo Lopes 49873
 * @author Maria Jacinto 48035
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) throws IOException {

		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		
		String[] s = in.readLine().split(" ");
		int row = Integer.parseInt(s[0]);
		int col = Integer.parseInt(s[1]);

		s = in.readLine().split(" ");
		int bridges = Integer.parseInt(s[0]);
		int space = Integer.parseInt(s[1]);

		int[] map = new int[col];

		for (int i = 0; i < row; i++) {
			char[] line = in.readLine().toCharArray();
			for (int c = 0; c < line.length; c++)
				if (line[c] == '.')
					map[c] += 1;
		}

		Bridges makeBridges = new Bridges(space, map);
		System.out.println(makeBridges.cheapBridges(bridges, col));

	}
}
