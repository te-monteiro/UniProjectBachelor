public class Pair {

	private int[] pair;
	public Pair(int i, int j) {
		//pair=new int[2];
		int[] onepair= {i,j};
		pair=onepair;
	}
	
	public int[] getPair() {
		return pair;
	}
	
}
