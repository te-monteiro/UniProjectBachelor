/**
 * @author Hugo Lopes 49873
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

		String[] s = in.readLine().split(" ");
		int nodes = Integer.parseInt(s[0]);
		int tasks = Integer.parseInt(s[1]);

		UnderControl uc = new UnderControl(nodes, tasks);

		for (int i = 0; i < tasks; i++) {
			String[] l = in.readLine().split(" ");
			int from = Integer.parseInt(l[0]);
			int to = Integer.parseInt(l[1]);
			int duration = Integer.parseInt(l[2]);
			uc.addTask(from, to, duration);
		}
		
		List<Pair> res = uc.calc();
		System.out.println(res.size());
		PairComparator c = new PairComparator();
		res.sort(c);
		for(Pair p : res)
			System.out.println(p.getPair()[0]+" "+p.getPair()[1]);
		in.close();
	}
}
