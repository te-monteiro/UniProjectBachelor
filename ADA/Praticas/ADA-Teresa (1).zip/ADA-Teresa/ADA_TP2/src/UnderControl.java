import java.util.LinkedList;
import java.util.List;
import java.util.Stack;

/**
 * @author Hugo Lopes 49873s
 */

public class UnderControl {

	private int nodes;
	private int[][] graph;
	private int[] preds;
	private List<Integer>[] sucs;
	private List<Integer>[] predecs;
	private int[] max;
	private List<Pair> res;

	@SuppressWarnings("unchecked")
	public UnderControl(int nodes, int tasks) {
		this.nodes = nodes;
		graph = new int[++nodes][++nodes];
		preds = new int[++nodes];

		predecs = new List[++nodes];
		for (int a = 0; a < predecs.length; a++)
			predecs[a] = new LinkedList<Integer>();

		sucs = new List[++nodes];
		for (int a = 0; a < sucs.length; a++)
			sucs[a] = new LinkedList<Integer>();

		max = new int[++nodes];
		res = new LinkedList<>();
	}

	public void addTask(int from, int to, int dur) {
		graph[from][to] = dur;
		sucs[from].add(to);
		preds[to]++;
		predecs[to].add(from);
	}

	public List<Pair> calc() {
		int[] g = topologicalSort();

		for (int i : g) {
			for (int j : predecs[i])
				if (graph[j][i]+max[j] >= max[i])
					max[i] = graph[j][i]+max[j];
		}
		for (int i : g) {
			for (int j : predecs[i])
				if (graph[j][i]+max[j] < max[i])
					res.add(new Pair(j, i));
		}
		return res;
	}

	int[] topologicalSort() {
		int[] permutation = new int[++nodes];
		int permSize = 0;
		Stack<Integer> ready = new Stack<>();

		for (int v = 1; v < nodes; v++) {
			if (preds[v] == 0)
				ready.push(v);
		}
		do {
			int node = ready.pop();
			permutation[permSize++] = node;
			for (int v : sucs[node]) {
				preds[v]--;
				if (preds[v] == 0)
					ready.push(v);
			}
		} while (!ready.isEmpty());
		return permutation;
	}

}
