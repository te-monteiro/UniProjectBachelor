/**
 * @author Hugo Lopes 49873
 */

import java.util.Comparator;

public class PairComparator implements Comparator<Pair>{
	
	public int compare(Pair p1, Pair p2) {
		int[] a = p1.getPair();
		int[] b = p2.getPair();
		if(a[0]<b[0])
			return -1;
		if(a[0]==b[0])
			if(a[1]<b[1])
				return -1;
			if(a[1]>b[1])
				return 1;
		return 1;
	}
}
