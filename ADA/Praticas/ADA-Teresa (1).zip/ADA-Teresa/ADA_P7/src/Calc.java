
public class Calc {
	
}
