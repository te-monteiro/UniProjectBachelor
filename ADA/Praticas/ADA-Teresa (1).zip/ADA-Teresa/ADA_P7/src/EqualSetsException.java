package dataStructures;

public class EqualSetsException extends RuntimeException {

    static final long serialVersionUID = 0L;


    public EqualSetsException( ) {
        super();
    }

    public EqualSetsException( String message ) {
        super(message);
    }

}

