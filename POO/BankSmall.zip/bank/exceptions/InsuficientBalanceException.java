package bank.exceptions;

@SuppressWarnings("serial")
public class InsuficientBalanceException extends Exception {
	public InsuficientBalanceException() {
		super();
	}
}
