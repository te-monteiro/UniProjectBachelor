package bank.exceptions;

@SuppressWarnings("serial")
public class InsuficientInitialAmountException extends Exception {
	public InsuficientInitialAmountException() {
		super();
	}
}
