package Base;
/**
 * 
 */

/**
 * @author franc
 *
 */
public class BaseCollectionClass implements  BaseCollection {
	private static final int DEFAULT_SIZE = 50;//default array size

	private Base[] bases;
	private int counter;

	public BaseCollectionClass() {
		bases = new Base[DEFAULT_SIZE];
		counter = 0;
		
	}

	@Override
	public void addBase(Base base) {
		if (counter == bases.length) {
			resize();
		}
		bases[counter++] = base;
	}

	@Override
	public void removeBase(String BaseId) {
		int i = searchIndex(BaseId);
		for(int j = i; j < counter-1; j++) {
			bases[j] = bases[j+1];
		}
		counter --;
	}

	@Override
	public int getNumberOfBases() {
		return counter;
	}

	@Override
	public boolean hasBase(String baseId) {
		return(searchIndex(baseId) != -1 );
	}
	@Override
	public Base getBase(String BaseId) {
		return bases[searchIndex(BaseId)];
	}
	
	public BaseIterator getIterator() {
		return new BaseIteratorClass(bases, counter);
	}

	//increases the size of the array
	private void resize() {
		Base aux[] = new Base[2 * bases.length];
		for (int i = 0; i < counter; i++)
			aux[i] = bases[i];
		bases = aux;
	}
	/**
	 * finds the position of the corresponding baseId
	 * @param baseId
	 * @return int of the position if found else -1 
	 * if there's not a base with the given id
	 */
	private int searchIndex(String baseId) {
		int i = -1;
		for (int j = 0; j < counter; j++) {
			if (bases[j].getBaseId().equals(baseId)) {
				i = j;
				break;
			}
		}
		return i;
	}


}
