package Base;
/**
 * 
 */

/**
 * @author franc/jo
 *
 */
public class BaseIteratorClass implements BaseIterator {
	private int current;
	private Base[] bases;
	private int counter;
	
	public BaseIteratorClass(Base[] bases, int counter) {
		this.bases = bases;
		this.counter = counter;
	}
	@Override
	public void initializeIterator() {
		current = 0;
	}
	@Override
	public boolean hasNext() {
		return current < counter;
	}

	@Override
	public Base next() {
		 return bases[current++];
	}
}
