package Base;
/**
 * 
 */

/**
 * @author franc/jo
 *
 */
public interface BaseCollection {
	/**
	 * adds a new base to the collection
	 * @param base
	 */
	void addBase(Base base);
	/**
	 * removes a base from the collection
	 * @param baseId
	 */
	void removeBase(String baseId);
	/**
	 * 
	 * @return total number of bases
	 */
	int getNumberOfBases();
	/**
	 * 
	 * @param baseId
	 * @return boolean that indicates if there is a base with the given baseId
	 */
	boolean hasBase(String baseId);
	/**
	 * 
	 * @param baseId
	 * @return Base corresponding to the given baseId
	 */
	Base getBase(String baseId);
	/**
	 * 
	 * @return Base iterator that contains all the bases
	 */
	BaseIterator getIterator();
}
