package Base;
/**
 * 
 */

/**
 * @author franc
 *
 */
public interface BaseIterator {
	/**
	 * resets the iterator counter
	 */
	void initializeIterator();
	/**
	 * @return true if there are still bases to be iterated, false if there aren't
	 */
	boolean hasNext();
	/**
	 * @pre hasNext()
	 * @return next base
	 */
	Base next();
}
