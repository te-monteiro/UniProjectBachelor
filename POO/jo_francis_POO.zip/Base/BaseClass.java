package Base;
import Location.*;
import Drone.*;
import Order.*;

// author /francqui/ jo anne


public class BaseClass implements Base {
	private Location location; //location of the base
	private String baseId;
	private DroneCollection baseCollection;//drones in the base hangar
	private DroneCollection serviceCollection;//drones in the service bay
	private OrderCollection orders;//pending orders of the base
	
	
		public BaseClass(String baseId, Location location) {
			this.baseId= baseId;
			this.location=location;
			baseCollection= new DroneCollectionClass();
			serviceCollection = new DroneCollectionClass();
			orders = new OrderCollectionClass();
		}
	@Override
	public DroneCollection getDroneCollection() {
		return baseCollection;
	}

	@Override
	public Location getLocation() {
		return location;
	}

	@Override
	public String getBaseId() {
		return baseId;
	}
	@Override
	public DroneIterator serviceDrones(int minRange) {
		DroneCollection collAux = new DroneCollectionClass();
		DroneIterator it = baseCollection.getIterator();
		while(it.hasNext()) {
			Drone droneAux = it.next();
			if(droneAux.getCurrentRange() < minRange && !(droneAux instanceof SwarmClass)) {
				baseCollection.removeDrone(droneAux.getId());
				serviceCollection.addDrone(droneAux);
				collAux.addDrone(droneAux);
				//new iterator without the removed drone is made
				it = baseCollection.getIterator();
			}
		}
	return collAux.getIterator();
	}
	@Override
	public OrderCollection getOrders() {
		return orders;
	}
	@Override
	public DroneCollection getServiceCollection() {
		return serviceCollection;
	}
}
