package Base;
import Drone.DroneCollection;
import Drone.DroneIterator;
import Location.Location;
/**
 * 
 */
import Order.OrderCollection;

/**
 * @author franc/joana
 *hub for  drones
 */

public interface Base {
	/**
	 * 
	 * @return DroneCollection that has the drones in service in the hangar
	 */
	/**
	 * @return
	 */
	DroneCollection getServiceCollection();
	/**
	 * 
	 * @return DroneCollection that the base stores
	 */
	DroneCollection getDroneCollection();
	/**
	 * @return base location
	 */
	Location getLocation();
	/**
	 * @return baseId
	 */
	String getBaseId();
	/**
	 * service the drones requiring service
	 * @param minCharge: range under which drones will be sent for charging
	 * @return DroneIterator that contains the drones that are put in service
	 */
	DroneIterator serviceDrones(int minCharge);
	/**
	 * 
	 * @return Order collection that contains the orders of the base
	 */
	OrderCollection getOrders();
	
}
