package Drone;
import Location.*;

/**
 * 
 */

/**
 * @author franc
 *
 */
public class SociableClass extends DroneClass {
	
	public SociableClass(String id,int capacity,int range,Location location) {
		super(id, capacity, range, location,"sociable");
	}
}
