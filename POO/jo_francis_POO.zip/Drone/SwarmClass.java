package Drone;
import Location.*;
/**
 * 
 */

/**
 * @author franc/ju
 *
 */
public class SwarmClass extends DroneClass implements Swarm {
	//collection of drones that make the swarm
	private DroneCollection drones;

	public SwarmClass(String id, DroneCollection drones, Location location) {
		super(id,-1,-1,location, "swarm");
		this.drones = drones;
		super.capacity = getSwarmCapacity();
		super.range = getMinRange();
	}

	@Override
	public void addDrone(Drone drone) {
		drones.addDrone(drone);
		super.capacity = getSwarmCapacity();
		super.range = getMinRange();
	}

	@Override
	public void removeDrone(String id) {
		drones.removeDrone(id);
		super.capacity = getSwarmCapacity();
		super.range = getMinRange();
	}

	@Override
	public DroneCollection getSwarmComponents() {
		return drones;
	}

	
	@Override
	public void travelComponents(int distance) {
		DroneIterator it = drones.getIterator();
		while(it.hasNext()) {
			it.next().travel(distance);
		}
	}
	
	/**
	 * calculates the total capacity
	 * based on each component capacity
	 * @return total capacity of the swarm
	 */
	private int getSwarmCapacity() {
		DroneIterator it = drones.getIterator();
		int capacity = 0;
		while (it.hasNext()) {
			capacity += it.next().getCapacity();
		}
		return capacity;
	}

	/**
	 * sets the swarm range based on the
	 * component with the lowest range
	 * @return range of the swarm
	 */
	private int getMinRange() {
		DroneIterator it = drones.getIterator();
		int min = it.next().getCurrentRange();
		while (it.hasNext()) {
			int aux = it.next().getCurrentRange();
			if (aux < min) {
				min = aux;
			}
		}
		return min;
	}
}
