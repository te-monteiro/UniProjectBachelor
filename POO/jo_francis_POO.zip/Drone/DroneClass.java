package Drone;
import Location.*;
import Action.*;
/**
 * 
 */

/**
 * @author franc and johanna
 *
 */
public abstract class DroneClass implements Drone {
	
	protected int capacity;//weight the drone can carry
	protected int range;//distance the drone can travel
	protected int maxRange;//maximum range 
	protected String id;//drone id
	protected Location location;//location where the drone is
	protected String type;//specifies the type of drone
	protected Action action;//stores the drone current movement
	
	protected DroneClass(String id,int capacity,int range,Location location, String type) {
		this.capacity = capacity;
		this.range = range;
		maxRange = range;
		this.id = id;
		this.location = location;
		this.type = type;
		action = null;
	}

	@Override
	public String getId() {
		return id;
	}

	@Override
	public int getCurrentRange() {
		return range;
	}

	@Override
	public int getCapacity() {
		return capacity;
	}
	@Override
	public String getType() {
		return type;
	}

	@Override
	public Location getLocation() {
		return location;
	}
	@Override
	public void charge() {
		range = maxRange;
	}
	
	 @Override
	public Action getAction() {
		return action;
	}
	@Override
	public void setAction(Action action) {
	this.action = action;
	}
	@Override
	public void travel(int distance) {
		range -= distance;
	}
}
