package Drone;
/**
 * 
 */

/**
 * @author franc/johanna
 *
 */
public interface Swarm extends Drone {
	/**
	 * adds the drone to the swarm
	 * @param drone that will be added to the swarm
	 */
	void addDrone(Drone drone);
	/**
	 * removes the drone from the swarm
	 * @param id from the drone that will be removed from the swarm
	 */
	void removeDrone(String id);
	/**
	 * @return Drone collection that contains all the drones in the swarm
	 */
	DroneCollection getSwarmComponents();
	/**
	 * decrements the range of each of the drones from the swarm
	 * @param distance that the swarm will travel
	 */
	
	void travelComponents(int distance);
}
