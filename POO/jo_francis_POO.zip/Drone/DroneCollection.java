package Drone;
/**
 * 
 */

/**
 * @author franc
 *
 */
public interface DroneCollection {
	/**
	 * adds a new drone to the collection
	 * @param drone
	 */
	void addDrone(Drone drone);
	/**
	 * removes the given drone from the collection
	 * @param droneId from the drone that will be removed
	 * @return removed drone
	 */
	Drone removeDrone(String droneId);
	/**
	 * @return total number of drones
	 */
	int getNumberOfDrones();
	/**
	 * boolean that indicates if there is a drone with the given droneId
	 * @param droneId
	 * @return
	 */
	boolean hasDrone(String droneId);
	/**
	 * @param droneId
	 * @return drone correspondent to the given droneId
	 */
	Drone getDrone(String droneId);
	public DroneIterator getIterator();
	
	
}
