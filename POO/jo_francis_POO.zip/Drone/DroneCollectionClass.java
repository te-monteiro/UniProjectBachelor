package Drone;

/**
 * @author franc joana
 *
 */
public class DroneCollectionClass implements DroneCollection {

	private static final int DEFAULT_SIZE = 50;

	private Drone[] drones;
	private int counter;

	public DroneCollectionClass() {
		drones = new Drone[DEFAULT_SIZE];
		counter = 0;

	}

	@Override
	public void addDrone(Drone drone) {
		if (counter == drones.length) {
			resize();
		}
		drones[counter++] = drone;
	}

	@Override
	public Drone removeDrone(String droneId) {
		int i = searchIndex(droneId);
		Drone droneAux = drones[i];
			for (int j = i; j < counter - 1; j++) {
				drones[j] = drones[j + 1];
			}
			this.counter--;
		return droneAux;
	}

	@Override
	public int getNumberOfDrones() {
		return counter;
	}

	@Override
	public boolean hasDrone(String droneId) {
		return (searchIndex(droneId) > -1);
	}

	@Override
	public Drone getDrone(String droneId) {
		return drones[searchIndex(droneId)];
	}

	public DroneIterator getIterator() {
		return new DroneIteratorClass(drones, counter);
	}
	// private methods

	private void resize() {
		Drone aux[] = new Drone[2 * drones.length];
		for (int i = 0; i < counter; i++)
			aux[i] = drones[i];
		drones = aux;
	}

	/**
	 * finds the position of the corresponding droneId
	 * @param droneId
	 * @return int of the position if found else -1 
	 * if there's not a drone with the given id
	 */
	private int searchIndex(String droneId) {
		int i = -1;
		for (int j = 0; j < counter && i == -1; j++) {
			if (drones[j].getId().equals(droneId)) {
				i = j;
			}
		}
		return i;
	}

}
