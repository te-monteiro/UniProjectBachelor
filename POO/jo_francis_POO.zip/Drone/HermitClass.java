package Drone;
import Location.*;

/**
 * 
 */

/**
 * @author franc
 *
 */
public class HermitClass extends DroneClass {
	
	
	public HermitClass(String id,int capacity,int range,Location location) {
		super(id, capacity, range, location,"hermit");
	}
}
