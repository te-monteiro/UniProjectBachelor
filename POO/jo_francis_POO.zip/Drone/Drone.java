package Drone;
import Location.*;
import Action.*;
/**
 * 
 */

/**
 * @author franc/juju
 *
 */
public interface Drone {
	/**
	 * @return drone Id
	 */
	String getId();
	/**
	 * 
	 * @return the current range of the drone
	 */
	int getCurrentRange();
	/**
	 * 
	 * @return the capacity of the drone
	 */
	int getCapacity();
	/**
	 * @return type of the drone
	 */
	String getType();
	/**
	 * @return location where the drone is
	 */
	Location getLocation();
	/**
	 * sets the range to its initial value
	 */
	void charge();
	/**
	 * @return action that the drone is completing
	 */
	Action getAction();
	/**
	 * sets the action the drone will be completing
	 * @param action
	 */
	void setAction(Action action);
	/**
	 * decrements the range of the drone
	 * @param distance the drone will travel
	 */
	void travel(int distance);
}
