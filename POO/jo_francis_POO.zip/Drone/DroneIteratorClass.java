package Drone;

public class DroneIteratorClass implements DroneIterator{

	private int current;
	private int counter;
	private Drone[]drones;
	
	
	public DroneIteratorClass(Drone[] drones, int counter){
		current=0;
		this.counter=counter;
		this.drones=drones;
	}
	
	@Override
	public void initializeIterator() {
		current=0;
	}

	@Override
	public boolean hasNext() {
		return (current >= 0) && (current < counter);
	}

	@Override
	public Drone next() {
		return drones[current++];
	}

}
