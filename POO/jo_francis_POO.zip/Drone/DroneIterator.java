package Drone;

public interface DroneIterator {
	/**
	 * resets the iterator counter
	 */
	void initializeIterator();
	/**
	 * @return true if there are still drones to be iterated, false if there aren't
	 */
	boolean hasNext();
	/**
	 * @pre hasNext()
	 * @return next drone
	 */
	Drone next();
}
