import java.util.Scanner;

import Action.Action;
import Base.Base;
import Base.BaseIterator;
import Central.Central;
import Central.CentralClass;
import Drone.Drone;
import Drone.DroneCollection;
import Drone.DroneCollectionClass;
import Drone.DroneIterator;
import Drone.SociableClass;
import Drone.SwarmClass;
import Location.Location;
import Location.LocationClass;
import Order.Order;
import Order.OrderIterator;

/**
 * @author franc/kala
 *
 */
public class Main {
	/**
	 * @param args
	 */

	private static final String EXIT = "EXIT";
	private static final String HELP = "HELP";
	private static final String BASE = "BASE";
	private static final String LISTBASES = "LISTBASES";
	private static final String DRONE = "DRONE";
	private static final String SERVICE = "SERVICE";
	private static final String SWARM = "SWARM";
	private static final String SWARMCOMPONENTS = "SWARMCOMPONENTS";
	private static final String DISBAND = "DISBAND";
	private static final String LISTDRONES = "LISTDRONES";
	private static final String FLYTOBASE = "FLYTOBASE";
	private static final String ADDORDER = "ADDORDER";
	private static final String ORDERS = "ORDERS";
	private static final String ALLORDERS = "ALLORDERS";
	private static final String DELIVER = "DELIVER";
	private static final String DELIVERED = "DELIVERED";
	private static final String INTRANSIT = "INTRANSIT";
	private static final String TICTAC = "TICTAC";

	private static final String HELPTEXT = ("base - registers a new distribution base\n"
			+ "listBases - lists existing distribution bases\n" + "drone - registers a new drone in a starting base\n"
			+ "service - service all grounded drones requiring service in a base\n"
			+ "swarm - creates a new swarm from free drones in a base\n"
			+ "swarmComponents - lists the drones within a swarm\n" + "disband - disbands the whole swarm\n"
			+ "listDrones - lists all existing drones (and swarms)\n" + "flyToBase - fly a drone (or swarm) to a base\n"
			+ "addOrder - add a new order to a base\n" + "orders - lists all pending orders from a base\n"
			+ "allOrders - lists all pending orders from all bases\n" + "deliver - deliver a package to a customer\n"
			+ "delivered - lists all delivered orders\n"
			+ "inTransit - lists all drones (and swarms) currently flying\n"
			+ "ticTac - advances the simulation clock n timestamps\n" + "help - shows the available commands\n"
			+ "exit - terminates the execution of the program\n");
	private static final String BASENAMEEXISTS = "Base already exists!";
	private static final String BASELOCATIONEXISTS = "There is already another base at ";
	private static final String NOBASES = "There are no bases!";
	private static final String NODRONES = "There are no drones!";
	private static final String EMPTYHANGAR = "The hangar is empty!";
	private static final String EMPTYSERVICE = "The service bay is empty!";
	private static final String INVALIDRANGE = "Invalid range for a new drone!";
	private static final String INVALIDCAPACITY = "Capacity has to be a positive integer!";
	private static final String INVALIDTYPE = "Invalid drone type!";
	private static final String NOSERVICE = "No drones were sent to the service station!";
	private static final String SWARMNUM = "Swarm must have at least two drones!";
	private static final String INVALIDDIMENSION = "Order dimension must be a positive integer!";
	private static final String ORDERQUEUD = "Order queued for delivery.";
	private static final String NOORDERS = "There are no pending orders!";
	private static final String NOTFLYING = "No drones are flying!";
	private static final String NODELIVERED = "No orders delivered so far!";

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		Central c = new CentralClass();
		System.out.print("> ");
		String comm = in.nextLine().toUpperCase();

		while (!comm.equals(EXIT)) {
			switch (comm) {
			case HELP:
				help();
				break;
			case BASE:
				newBase(in, c);
				break;
			case LISTBASES:
				listBases(c);
				break;
			case DRONE:
				newDrone(in, c);
				break;
			case SERVICE:
				service(in, c);
				break;
			case SWARM:
				createSwarm(in, c);
				break;
			case SWARMCOMPONENTS:
				listSwarmComponents(in, c);
				break;
			case DISBAND:
				disband(in, c);
				break;
			case LISTDRONES:
				listDrones(c);
				break;
			case FLYTOBASE:
				flyToBase(in, c);
				break;
			case ADDORDER:
				addOrder(in, c);
				break;
			case ORDERS:
				listBaseOrders(in, c);
				break;
			case ALLORDERS:
				listAllOrders(c);
				break;
			case DELIVER:
				deliver(in, c);
				break;
			case DELIVERED:
				listDelivered(c);
				break;
			case INTRANSIT:
				listInTransit(c);
				break;
			case TICTAC:
				ticTac(c, in);
				break;

			default:
				System.out.println("Unknown command. Type help to see available commands.");
			}
			System.out.print("> ");
			comm = in.nextLine().toUpperCase();
		}
		System.out.println("Bye!");
		in.close();
	}

	private static void ticTac(Central c, Scanner in) {
		int n = in.nextInt();
		in.nextLine();
		c.ticTac(n);

	}

	private static void listInTransit(Central c) {
		DroneIterator it = c.getInTransitIterator();
		if (!it.hasNext()) {
			System.out.println(NOTFLYING);
		} else {
			while (it.hasNext()) {
				Drone aux = it.next();
				Action actAux = aux.getAction();
				Base origin = actAux.getInicialBase();
				Base end = actAux.getEndBase();
				System.out.println(aux.getId() + " " + origin.getBaseId() + " " + end.getBaseId() + " "
						+ actAux.getTravelledDistance() + " " + actAux.getTotalDistance() + " " + actAux.getType()
						+ "!");
			}
		}
	}

	private static void listDelivered(Central c) {
		OrderIterator it = c.getDeliveredIterator();
		if (!it.hasNext()) {
			System.out.println(NODELIVERED);
		} else {
			while (it.hasNext()) {
				Order order = it.next();
				System.out.println(order.getTime() + " " + order.getOrderId() + " " + order.getBaseId() + ".");
			}
		}
	}

	private static void deliver(Scanner in, Central c) {
		String baseId = in.nextLine();
		String droneId = in.nextLine();
		String orderId = in.nextLine();

		if (!c.hasBase(baseId)) {
			System.out.println("Base " + baseId + " does not exist!");
		} else if (!c.hasDroneInBase(baseId, droneId)) {
			System.out.println(droneId + " is not at " + baseId + "!");
		} else if (!c.hasOrderInBase(baseId, orderId)) {
			System.out.println(orderId + " is not pending!");
		} else if (!c.canDeliver(orderId, droneId)) {
			System.out.println(orderId + " is too far for " + droneId + "!");
		} else if (c.isTooHeavy(orderId, droneId)) {
			System.out.println(orderId + " is too heavy for " + droneId + "!");
		} else {
			c.deliverOrder(baseId, droneId, orderId);
			System.out.println(droneId + " will deliver " + orderId + ".");
		}
	}

	private static void listAllOrders(Central c) {
		if (!c.getOrderIterator().hasNext()) {
			System.out.println(NOORDERS);
		} else {
			BaseIterator bit = c.getBaseIterator();
			while (bit.hasNext()) {
				String baseId = bit.next().getBaseId();
				OrderIterator it = c.getBaseOrderIterator(baseId);
				if (!it.hasNext()) {
					System.out.println("There are no pending orders in " + baseId + ".");
				} else {
					System.out.println("Orders in " + baseId + ":");
					while (it.hasNext()) {
						Order o = it.next();
						System.out.println(
								o.getOrderId() + "; " + o.getWeight() + "; " + o.getLocation().printCoordinates());
					}
				}
			}
		}
	}

	private static void listBaseOrders(Scanner in, Central c) {
		String baseId = in.nextLine();
		if (!c.hasBase(baseId)) {
			System.out.println("Base " + baseId + " does not exist!");
		} else {
			OrderIterator it = c.getBaseOrderIterator(baseId);
			if (!it.hasNext()) {
				System.out.println(NOORDERS);
			} else {
				while (it.hasNext()) {
					Order o = it.next();
					System.out
							.println(o.getOrderId() + "; " + o.getWeight() + "; " + o.getLocation().printCoordinates());
				}
			}
		}
	}

	private static void addOrder(Scanner in, Central c) {
		String baseId = in.nextLine();
		String orderId = in.nextLine();
		int dimension = in.nextInt();
		int latitude = in.nextInt();
		int longitude = in.nextInt();
		in.nextLine();
		if (!c.hasBase(baseId)) {
			System.out.println("Source base " + baseId + " does not exist!");
		} else if (c.hasOrder(orderId)) {
			System.out.println("Order " + orderId + " already registered!");
		} else if (dimension <= 0) {
			System.out.println(INVALIDDIMENSION);
		} else {
			c.addOrder(baseId, orderId, new LocationClass(latitude, longitude), dimension);
			System.out.println(ORDERQUEUD);
		}
	}

	private static void flyToBase(Scanner in, Central c) {
		String originId = in.nextLine();
		String droneId = in.nextLine();
		String destinationId = in.nextLine();
		if (!c.hasBase(originId)) {
			System.out.println("Source base " + originId + " does not exist!");
		} else if (!c.hasBase(destinationId)) {
			System.out.println("Target base " + destinationId + " does not exist!");
		} else if (!c.hasDroneInBase(originId, droneId)) {
			System.out.println(droneId + " is not at " + originId + "!");
		} else if (!c.canFly(droneId, originId, destinationId)) {
			System.out.println("Drone " + droneId + " cannot reach " + destinationId);
		} else {
			System.out.println(droneId + " flying from " + originId + " to " + destinationId + ".");
			c.flyToBase(originId, droneId, destinationId);
		}
	}

	private static void listDrones(Central c) {
		DroneIterator it = c.getDroneIterator();
		if (!it.hasNext()) {
			System.out.println(NODRONES);
		} else {
			while (it.hasNext()) {
				System.out.println(it.next().getId());
			}
		}

	}

	private static void disband(Scanner in, Central c) {
		String baseId = in.nextLine();
		String swarmId = in.nextLine();
		if (!c.hasBase(baseId)) {
			System.out.println("Base " + baseId + " does not exist!");
		} else {
			if (!c.hasDroneInBase(baseId, swarmId)) {
				System.out.println(swarmId + " is not at " + baseId);
			} else {
				if (!(c.getDrone(swarmId) instanceof SwarmClass)) {
					System.out.println(swarmId + " is not at " + baseId);
				}
			}
		}
		c.disbandSwarm(baseId, swarmId);
		System.out.println(swarmId + " disbanded.");

	}

	private static void listSwarmComponents(Scanner in, Central c) {
		String swarmId = in.nextLine();
		if (!(c.hasDrone(swarmId))) {
			System.out.println(swarmId + " is not a swarm!");
		} else {
			if (!(c.getDrone(swarmId) instanceof SwarmClass)) {
				System.out.println(swarmId + " is not a swarm!");
			} else {
				DroneIterator it = c.getSwarmComponents(swarmId).getIterator();
				while (it.hasNext()) {
					System.out.println(it.next().getId());
				}
				System.out.println(c.getDrone(swarmId).getCapacity() + " " + c.getDrone(swarmId).getCurrentRange());

			}
		}
	}

	private static void createSwarm(Scanner in, Central c) {
		String baseId = in.nextLine();
		String swarmId = in.nextLine();
		int droneNum = in.nextInt();
		in.nextLine();
		String[] droneIds = new String[droneNum];
		for (int i = 0; i < droneNum; i++) {
			droneIds[i] = in.nextLine();
		}
		if (!c.hasBase(baseId)) {
			System.out.println("Base " + baseId + " does not exist!");
		} else {
			if (droneNum < 2) {
				System.out.println(SWARMNUM);
			} else {
				DroneCollection collAux = new DroneCollectionClass();
				boolean aux = true;
				for (int i = 0; i < droneIds.length && aux == true; i++) {
					Drone droneAux = c.getDrone(droneIds[i]);
					if (!(droneAux instanceof SociableClass) && !(droneAux instanceof SwarmClass)) {
						System.out.println("Cannot add " + droneAux.getType() + " drone " + droneAux.getId() + "!");
						aux = false;
					} else {
						if (collAux.hasDrone(droneAux.getId())) {
							System.out.println("Cannot add drone " + droneAux.getId() + " twice!");
							aux = false;
						} else {
							if (!(c.hasDroneInBase(baseId, droneAux.getId()))) {
								System.out.println("Drone " + droneAux.getId() + " is not available in this base!");
								aux = false;
							}
							collAux.addDrone(droneAux);
						}
					}
				}
				if (c.hasDrone(swarmId)) {
					System.out.println("Swarm " + swarmId + " already exists!");
				} else {
					if (aux) {
						c.addSwarm(baseId, swarmId, collAux);
						System.out.println(swarmId + " created.");
					}
				}
			}
		}
	}

	private static void service(Scanner in, Central c) {
		String baseId = in.nextLine();
		int remainingRange = in.nextInt();
		in.nextLine();
		if (!c.hasBase(baseId)) {
			System.out.println("Base " + baseId + " does not exist!");
		} else {
			DroneIterator it = c.chargeDrones(baseId, remainingRange);
			if (!it.hasNext()) {
				System.out.println(NOSERVICE);
			} else {
				while (it.hasNext()) {
					Drone droneAux = it.next();
					System.out.println(droneAux.getId() + " moved to service bay.");
				}
			}
		}
	}

	private static void newDrone(Scanner in, Central c) {
		String droneId = in.nextLine();
		String baseId = in.nextLine();
		String type = in.next();
		int capacity = in.nextInt();
		int range = in.nextInt();
		in.nextLine();

		if (range < 10) {
			System.out.println(INVALIDRANGE);
		} else {
			if (capacity < 0) {
				System.out.println(INVALIDCAPACITY);
			} else {
				if (!c.hasBase(baseId)) {
					System.out.println("Base " + baseId + " does not exist!");
				} else {
					if (c.hasDrone(droneId)) {
						System.out.println("Drone " + droneId + " already exists!");
					} else {
						if (!c.isTypeValid(type)) {

							System.out.println(INVALIDTYPE);
						} else {
							c.addDrone(droneId, baseId, type.trim().toLowerCase(), capacity, range);
							System.out.println("Drone " + droneId + " created.");
						}
					}
				}
			}
		}
	}

	private static void listBases(Central c) {
		BaseIterator it = c.getBaseIterator();
		if (!it.hasNext()) {
			System.out.println(NOBASES);
		} else {
			while (it.hasNext()) {
				Base base = it.next();
				Location loc = base.getLocation();
				System.out.println(base.getBaseId() + " [" + loc.getLatitude() + "," + loc.getLongitude() + "]");
				DroneIterator hangar = base.getDroneCollection().getIterator();
				if (!hangar.hasNext()) {
					System.out.println(EMPTYHANGAR);
				} else {
					Drone aux1 = hangar.next();
					System.out.print(
							"Hangar: [" + aux1.getId() + " " + aux1.getCapacity() + " " + aux1.getCurrentRange());
					while (hangar.hasNext()) {
						aux1 = hangar.next();
						System.out.print(", " + aux1.getId() + " " + aux1.getCapacity() + " " + aux1.getCurrentRange());
					}
					System.out.print("]\n");
				}
				DroneIterator service = base.getServiceCollection().getIterator();
				if (!service.hasNext()) {
					System.out.println(EMPTYSERVICE);
				} else {
					Drone aux2 = service.next();
					System.out.print(
							"Service bay: [" + aux2.getId() + " " + aux2.getCapacity() + " " + aux2.getCurrentRange());
					while (service.hasNext()) {
						aux2 = service.next();
						System.out.print(", " + aux2.getId() + " " + aux2.getCapacity() + " " + aux2.getCurrentRange());
					}
					System.out.print("]\n");
				}
			}
		}
	}

	private static void newBase(Scanner in, Central c) {
		int latitude = in.nextInt();
		int longitude = in.nextInt();
		String baseId = in.nextLine().trim();
		if (c.hasBase(baseId)) {
			System.out.println(BASENAMEEXISTS);
		} else if (c.hasLocation(new LocationClass(latitude, longitude))) {
			System.out.println(BASELOCATIONEXISTS + "[" + latitude + "," + longitude + "]!");
		} else {
			c.addBase(latitude, longitude, baseId);
			System.out.println("Base " + baseId + " created at [" + latitude + "," + longitude + "].");
		}
	}

	private static void help() {
		System.out.print(HELPTEXT);
	}
}
