package Order;

/**
 * @author frankkie/anaoj
 *
 */
public class OrderCollectionClass implements OrderCollection {

	private static final int DEFAULT_SIZE = 50;

	private Order[] orders;
	private int counter;

	public OrderCollectionClass() {
		orders = new Order[DEFAULT_SIZE];
		counter = 0;
	}

	@Override
	public void addOrder(Order order) {
		if (counter == orders.length) {
			resize();
		}
		orders[counter++] = order;
	}

	@Override
	public Order removeOrder(String orderId) {
		int i = searchIndex(orderId);
		Order orderAux = orders[i];
		for (int j = i; j < counter - 1; j++) {
			orders[j] = orders[j + 1];
		}
		counter--;
		return orderAux;
	}

	@Override
	public int getNumberOfOrders() {
		return counter;
	}

	@Override
	public boolean hasOrder(String orderId) {
		return (searchIndex(orderId) != -1);
	}

	@Override
	public Order getOrder(String orderId) {
		return orders[searchIndex(orderId)];
	}

	public OrderIterator getOrderIterator() {
		return new OrderIteratorClass(orders, counter);
	}

	// increases the size of the array
	private void resize() {
		Order aux[] = new Order[2 * orders.length];
		for (int i = 0; i < counter; i++)
			aux[i] = orders[i];
		orders = aux;
	}

	/**
	 * finds the position of the corresponding orderId
	 * 
	 * @param orderId
	 * @return int of the position if found else -1 if there's no order with the
	 *         given id
	 */
	private int searchIndex(String orderId) {
		int i = -1;
		for (int j = 0; j < counter; j++) {
			if (orders[j].getOrderId().equals(orderId)) {
				i = j;
				break;
			}
		}
		return i;
	}

}
