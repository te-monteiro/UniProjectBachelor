package Order;
import Location.*;

/**
 * @author franc/jonny
 *
 */
public class OrderClass implements Order {
	private String orderId;
	private int weight;//weight of the order
	private Location location;//delivery location
	private String baseId;//base where the order is pending
	int timeStamp;//time of delivery
	
	
	public OrderClass(String baseId, String orderId,Location location,int dimension){
		this.orderId= orderId;
		this.baseId= baseId;
		this.weight=dimension;
		this.location=location;
		
	}
	
	@Override
	public String getOrderId() {
		return orderId;
	}

	@Override
	public int getWeight() {
		return weight;
	}

	@Override
	public Location getLocation() {
		return location;
	}

	@Override
	public String getBaseId() {
		return baseId;
	}

	@Override
	public void setTimeStamp(int n) {
		timeStamp = n;
	}

	@Override
	public int getTime() {
		return timeStamp;
	}

}
