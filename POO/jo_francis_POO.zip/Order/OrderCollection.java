package Order;
/**
 * 
 */

/**
 * @author franc/jojo
 */
public interface OrderCollection {
	/**
	 * adds the order to the order collection
	 * @param order
	 */
	void addOrder(Order order);
	/**
	 * removes the order from the collection of a given base
	 * @param baseId
	 * @return order removed
	 */
	Order removeOrder(String baseId);
	/**
	 * @return number of orders that are in the order collection 
	 */
	int getNumberOfOrders();
	/**
	 * @param orderId
	 * @return boolean that is true if there is an order 
	 * with the given orderId in the collection  and false otherwise
	 */
	boolean hasOrder(String orderId);
	/**
	 * @param orderId
	 * @return order that corresponds to the given orderId
	 */
	Order getOrder(String orderId);
	/**
	 * @return Order iterator that contains all the orders
	 */
	OrderIterator getOrderIterator();
}
