package Order;
/**
 * 
 */

/**
 * @author franc
 *
 */
public class OrderIteratorClass implements OrderIterator {
	
	private int current;
	private Order[] orders;
	private int counter;
	
	public OrderIteratorClass(Order[] orders, int counter) {
		this.orders = orders;
		this.counter = counter;
	}
	@Override
	public void initializeIterator() {
		current = 0;
	}
	@Override
	public boolean hasNext() {
		return current < counter;
	}

	@Override
	public Order next() {
		 return orders[current++];
	}
	
}
