package Order;
import Location.*;
/**
 * 
 */

/**
 * @author franc/jo
 *
 */
public interface Order {
	/**
	 * @return id of the base where the order is
	 */
	String getBaseId();
	/**
	 * @return id of the order
	 */
	String getOrderId();
	/**
	 * @return weight of the order
	 */
	int getWeight();
	/**
	 * @return location where the order is
	 */
	Location getLocation();
	/**
	 * sets the delivery time
	 * @param n : time of delivery 
	 */
	void setTimeStamp(int n);
	/**
	 * returns the passed since delivery
	 * @return
	 */
	int getTime();
}
