package Order;
/**
 * 
 */

/**
 * @author francosis/ jonneyboi
 *
 */
public interface OrderIterator {
	/**
	 * resets the iterator counter
	 */
	void initializeIterator();
	/**
	 * @return true if there are still orders to be iterated, false if there aren't
	 */
	boolean hasNext();
	/**
	 * @pre hasNext()
	 * @return next order
	 */
	Order next();
}
