package Central;
import Base.BaseIterator;
import Drone.Drone;
import Drone.DroneCollection;
import Drone.DroneIterator;
import Location.Location;
import Order.OrderIterator;

/**
 * 
 */

/**
 * @author franc/jo
 */
public interface Central {
	/**
	 * 
	 * @param baseId
	 * @return true if there is a base with the given baseId 
	 */
	boolean hasBase(String baseId);
	/**
	 * 
	 * @param droneId
	 * @return true if there is drone that has the same droneId,
	 * false otherwise
	 */
	boolean hasDrone(String droneId);
	/**
	 * @param location
	 * @return true if there is a base with same location,
	 * false otherwise
	 */
	boolean hasLocation(Location location);
	/**
	 * 
	 * @param baseId
	 * @param droneId
	 * @return true if there is a drone with the same droneId
	 * in the given base, false otherwise
	 */
	boolean hasDroneInBase(String baseId,String droneId);
	/**
	 * adds a new base to the collection that contains all of the bases
	 * @param latitude of the new base
	 * @param longitude of the new base
	 * @param id : baseId
	 */
	void addBase(int latitude, int longitude, String id);
	/**
	 * adds a new drone to a drone collection, depending 
	 * its type of drone
	 * @param droneId 
	 * @param baseId where the drone will be
	 * @param droneType (hermit or sociable)
	 * @param capacity 
	 * @param range
	 */
	void addDrone(String droneId, String baseId, String droneType, int capacity, int range);
	/**
	 * 
	 * @param baseId
	 * @param remainingCharge
	 * @return
	 */
	DroneIterator chargeDrones(String baseId, int remainingCharge);
	boolean isTypeValid(String type);
	
	
	
	/**
	 * @param baseId
	 * @param swarmId
	 * adds the asked drones or components of the asked swarm 
	 * to a new swarm, removing them from both the central and 
	 * base drone lists then adds the new swarm to these listss
	 */
	void addSwarm(String baseId, String swarmId, DroneCollection swarmColl);
	/**
	 * Disbands the whole swarm.
	 * Removes the swarm from the given base and adds each
	 * drone of the swarm to the drone collection of the base 
	 * and to the collection that stores all the drones
	 * @param baseId where the swarm is 
	 * @param swarmId that is going to be disbanded
	 */
	void disbandSwarm(String baseId, String swarmId);
	/**
	 * Flies a drone or a swarm.
	 * Adds the drone to the collection of drones that are in transit
	 * calculates the distance and time the drones will fly
	 * removes the drone from the origin base and adds it to
	 * the drone collection of the new base
	 * @param originBase where the drone initially is
	 * @param droneId from the drone that will fly
	 * @param newBase where the drone will go to
	 */
	void flyToBase(String originBase,String droneId,String newBase);
	/**
	 * adds the order to the collection that contains all of the orders
	 * puts the order in a pending orders collection of the base
	 * @param baseId 
	 * @param orderId
	 * @param location 
	 * @param dimension
	 */
	void addOrder(String baseId, String orderId,Location location,int dimension);
	
	/**
	 * puts the given order in delivery 
	 * adds the drone in transit and sets its action
	 * @param baseId where the drone is
	 * @param droneId that will carry the order
	 * @param orderId that will be delivered
	 */
	void deliverOrder(String baseId, String droneId, String orderId);
	/**
	 * increments the time and does the accoreding operations
	 * @param n: amount that time is incremented
	 */
	void ticTac(int n);
	/**
	 * @param droneId
	 * @return drone correspondent to the given droneId
	 */
	Drone getDrone(String droneId);
	
	
	/**
	 * @param swarmId
	 * @return DroneIterator that contains the 
	 * drones that are in the swarm
	 */
	DroneCollection getSwarmComponents(String swarmId);
	/**
	 * @return DroneIterator that contains all 
	 * the drones of the company
	 */
	DroneIterator getDroneIterator();
	/**
	 * @return DroneIterator that contains the 
	 * drones that are currently in transit
	 */
	DroneIterator getInTransitIterator();
	/**
	 * @param baseId
	 * @return Order iterator that contains the orders
	 * that are on the given base
	 */
	OrderIterator getBaseOrderIterator(String baseId);
	/**
	 * @return Order Iterator that contains 
	 * all the orders
	 */
	OrderIterator getOrderIterator();
	/**
	 * @return Base Iterator that contains 
	 * all the bases
	 */
	BaseIterator getBaseIterator();
	/**
	 * @return Order iterator that contains
	 *  the orders that were delivered
	 */
	OrderIterator getDeliveredIterator();
	/**
	 * @param droneId
	 * @return drone correspondent to the
	 * given droneId
	 */

    /**	
     * @param orderId
     * @return true if there already is an order 
     * with the given order id, false otherwise
     */
	boolean hasOrder(String orderId);
	/**
	 * @param droneId
	 * @param originBase
	 * @param newBase
	 * @return true if the drone's range is enough
	 * to fly the distance between two bases
	 */
	boolean canFly(String droneId, String originBase, String newBase);
	
	/**
	 * @param orderId
	 * @param droneId
	 * @return true if the drone's range is enough
	 * to deliver the order
	 */
	boolean canDeliver(String orderId, String droneId);
	/**
	 * @param orderId
	 * @param droneId
	 * @return true if the order is too heavy
	 * for the drone to carry, false otherwise
	 */
	boolean isTooHeavy(String orderId, String droneId);
	/**
	 * @param baseId
	 * @param orderId
	 * @return true if there is an order with the given
	 * orderId at the given base, false otherwise
	 */
	boolean hasOrderInBase(String baseId, String orderId);
	}
