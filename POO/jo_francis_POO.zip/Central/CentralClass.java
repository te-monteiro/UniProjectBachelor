package Central;

import Action.Action;
import Action.ActionClass;
import Base.Base;
import Base.BaseClass;
import Base.BaseCollection;
import Base.BaseCollectionClass;
import Base.BaseIterator;
import Drone.Drone;
import Drone.DroneCollection;
import Drone.DroneCollectionClass;
import Drone.DroneIterator;
import Drone.HermitClass;
import Drone.SociableClass;
import Drone.Swarm;
import Drone.SwarmClass;
import Location.Location;
import Location.LocationClass;
import Order.Order;
import Order.OrderClass;
import Order.OrderCollection;
import Order.OrderCollectionClass;
import Order.OrderIterator;

/**
 * @author franc/joana
 *
 */
public class CentralClass implements Central {
	private static final String HERMIT = "hermit";
	private static final String SOCIABLE = "sociable";
	private static final String DELIVERY = "delivery";
	private static final String SERVICE = "service";
	private static final String RELOCATION = "relocation";
	private static final int DSPEED = 10;// speed in units/tic

	private BaseCollection bases;// collection of all the bases
	private DroneCollection drones;// collection with all the drones
	private OrderCollection orders;// collection of all pending orders
	private DroneCollection inTransit;// collection of all drones flying
	private OrderCollection delivered;// colletion of delivered orders
	private int time;// current time

	public CentralClass() {
		bases = new BaseCollectionClass();
		drones = new DroneCollectionClass();
		orders = new OrderCollectionClass();
		inTransit = new DroneCollectionClass();
		delivered = new OrderCollectionClass();
		time = 0;

	}

	@Override
	public boolean hasBase(String baseId) {
		return bases.hasBase(baseId);
	}

	@Override
	public boolean hasDrone(String droneId) {
		return drones.hasDrone(droneId);
	}

	public boolean hasLocation(Location location) {
		BaseIterator it = bases.getIterator();
		boolean aux = false;
		while (it.hasNext()) {
			Location loc = it.next().getLocation();
			if (loc.getLatitude() == location.getLatitude() && loc.getLongitude() == location.getLongitude()) {
				aux = true;
			}
		}
		return aux;
	}

	@Override
	public boolean hasDroneInBase(String baseId, String droneId) {
		Base aux = bases.getBase(baseId);
		return aux.getDroneCollection().hasDrone(droneId);
	}

	@Override
	public boolean hasOrderInBase(String baseId, String orderId) {
		Base aux = bases.getBase(baseId);
		return aux.getOrders().hasOrder(orderId);
	}

	@Override
	public void addBase(int latitude, int longitude, String id) {
		bases.addBase(new BaseClass(id, new LocationClass(latitude, longitude)));
	}

	@Override
	public void addDrone(String droneId, String baseId, String droneType, int capacity, int range) {
		Base baseAux = bases.getBase(baseId);
		if (droneType.equals(HERMIT)) {
			Drone auxDrone = new HermitClass(droneId, capacity, range, baseAux.getLocation());
			addDroneAux(auxDrone, baseAux);
		}
		if (droneType.equals(SOCIABLE)) {
			Drone auxDrone = new SociableClass(droneId, capacity, range, baseAux.getLocation());
			addDroneAux(auxDrone, baseAux);
		}
	}

	@Override
	public DroneIterator chargeDrones(String baseId, int remainingCharge) {
		Base base = bases.getBase(baseId);
		DroneIterator it = base.serviceDrones(remainingCharge);
		while (it.hasNext()) {
			Drone aux = it.next();
			aux.setAction(new ActionClass(base, base, this.time + 3, SERVICE, 0));
		}
		it.initializeIterator();
		return it;
	}

	@Override
	public void addSwarm(String baseId, String swarmId, DroneCollection inputColl) {
		// creates new collection that will be the
		// components of the new swarm
		DroneCollection swarmColl = new DroneCollectionClass();
		Base baseAux = bases.getBase(baseId);
		DroneIterator it = inputColl.getIterator();

		while (it.hasNext()) {
			Drone droneAux = it.next();
			// if a drone that will be added is a swarm all of its
			// components are added to the new collection
			if (droneAux instanceof SwarmClass) {
				DroneIterator componentIterator = ((SwarmClass) droneAux).getSwarmComponents().getIterator();
				while (componentIterator.hasNext()) {
					swarmColl.addDrone(componentIterator.next());
				}
			}

			if (droneAux instanceof SociableClass) {
				swarmColl.addDrone(droneAux);
			}
			drones.removeDrone(droneAux.getId());
			baseAux.getDroneCollection().removeDrone(droneAux.getId());
		}
		Drone auxSwarm = new SwarmClass(swarmId, swarmColl, baseAux.getLocation());
		addDroneAux(auxSwarm, baseAux);
	}

	@Override
	public DroneCollection getSwarmComponents(String swarmId) {
		Drone swarmAux = drones.getDrone(swarmId);
		return ((Swarm) swarmAux).getSwarmComponents();
	}

	@Override
	public void disbandSwarm(String baseId, String swarmId) {
		Base baseAux = bases.getBase(baseId);
		baseAux.getDroneCollection().removeDrone(swarmId);
		// removes swarm from drones collection and stores its component drones in
		// "collAux"
		DroneCollection collAux = ((Swarm) drones.removeDrone(swarmId)).getSwarmComponents();
		DroneIterator it = collAux.getIterator();
		while (it.hasNext()) {
			Drone droneAux = it.next();
			drones.addDrone(droneAux);
			baseAux.getDroneCollection().addDrone(droneAux);
		}
	}

	@Override
	public void flyToBase(String originBaseId, String droneId, String newBaseId) {
		inTransit.addDrone(drones.getDrone(droneId));
		Drone droneAux = getDrone(droneId);
		Base originBase = bases.getBase(originBaseId);
		Base endBase = bases.getBase(newBaseId);
		Location originLoc = originBase.getLocation();
		Location endLoc = endBase.getLocation();

		int distance = originLoc.getDistance(endLoc);
		int travelTime = getTravelTime(distance);
		originBase.getDroneCollection().removeDrone(droneId);
		Action actionAux = new ActionClass(originBase, endBase, this.time + travelTime, RELOCATION, distance);
		droneAux.setAction(actionAux);
		droneAux.travel(distance);
		if (droneAux instanceof SwarmClass) {
			((SwarmClass) droneAux).travelComponents(distance);
		}
	}

	@Override
	public boolean canFly(String droneId, String originBase, String newBase) {
		int distance = bases.getBase(originBase).getLocation().getDistance(bases.getBase(newBase).getLocation());
		return distance < drones.getDrone(droneId).getCurrentRange();
	}

	@Override
	public void addOrder(String baseId, String orderId, Location location, int dimension) {
		Order orderAux = new OrderClass(baseId, orderId, location, dimension);
		orders.addOrder(orderAux);
		bases.getBase(baseId).getOrders().addOrder(orderAux);
	}

	@Override
	public void deliverOrder(String baseId, String droneId, String orderId) {
		Base baseAux = bases.getBase(baseId);
		Order orderAux = orders.removeOrder(orderId);
		DroneCollection colBaseAux = baseAux.getDroneCollection();
		Drone droneAux = colBaseAux.removeDrone(droneId);
		int distance = baseAux.getLocation().getDeliverDistance(orderAux.getLocation());
		int timeAux = getTravelTime(distance);
		Action action = new ActionClass(baseAux, baseAux, this.time + timeAux, DELIVERY, distance);

		baseAux.getOrders().removeOrder(orderId);
		inTransit.addDrone(droneAux);
		action.setOrder(orderAux);
		droneAux.setAction(action);
		droneAux.travel(distance);
		if (droneAux instanceof SwarmClass) {
			((SwarmClass) droneAux).travelComponents(distance);
		}
	}

	@Override
	public void ticTac(int n) {

		// does one loop per tick
		int finishTime = time + n;
		while (time < finishTime) {
			time++;
			DroneCollection removedrs = selectDoneInTransit();
			removeDoneInTransit(removedrs);
			selectDoneServiceDrones();

		}
	}

	@Override
	public DroneIterator getDroneIterator() {
		return drones.getIterator();
	}

	@Override
	public OrderIterator getBaseOrderIterator(String baseId) {
		return bases.getBase(baseId).getOrders().getOrderIterator();
	}

	@Override
	public OrderIterator getOrderIterator() {
		return orders.getOrderIterator();
	}

	@Override
	public DroneIterator getInTransitIterator() {
		return inTransit.getIterator();
	}

	@Override
	public BaseIterator getBaseIterator() {
		return bases.getIterator();
	}

	@Override
	public OrderIterator getDeliveredIterator() {
		return delivered.getOrderIterator();
	}

	@Override
	public boolean isTypeValid(String type) {
		return (type.equals(HERMIT) || type.equals(SOCIABLE));
	}

	private void addDroneAux(Drone auxDrone, Base baseAux) {
		baseAux.getDroneCollection().addDrone(auxDrone);
		drones.addDrone(auxDrone);
	}

	@Override
	public Drone getDrone(String droneId) {
		return drones.getDrone(droneId);
	}

	@Override
	public boolean hasOrder(String orderId) {
		return orders.hasOrder(orderId);
	}

	@Override
	public boolean canDeliver(String orderId, String droneId) {
		Drone aux = drones.getDrone(droneId);
		Location deliveryLocation = orders.getOrder(orderId).getLocation();
		Location baseLocation = aux.getLocation();
		return aux.getCurrentRange() >= (baseLocation.getDistance(deliveryLocation) * 2);
	}

	@Override
	public boolean isTooHeavy(String orderId, String droneId) {
		return orders.getOrder(orderId).getWeight() > drones.getDrone(droneId).getCapacity();
	}

	private int getTravelTime(int distance) {
		int travelTime = distance / 10;
		if (distance % 10 != 0) {
			travelTime += 1;
		}
		return travelTime;
	}

	// ticks the in transit drones and selects
	// the ones that are done
	private DroneCollection selectDoneInTransit() {

		DroneCollection removedrs = new DroneCollectionClass();
		DroneIterator it = inTransit.getIterator();
		it.initializeIterator();
		while (it.hasNext()) {
			Drone drone = it.next();
			Action action = drone.getAction();
			action.travel(DSPEED);
			if (action.getTotalDistance() <= action.getTravelledDistance()) {
				removedrs.addDrone(drone);
			}
		}
		return removedrs;
	}

	// removes the in transit drones that are done
	private void removeDoneInTransit(DroneCollection removedrs) {
		DroneIterator it = removedrs.getIterator();
		while (it.hasNext()) {
			Drone removeDrone = it.next();
			Action removeAction = removeDrone.getAction();
			inTransit.removeDrone(removeDrone.getId());
			removeAction.getEndBase().getDroneCollection().addDrone(removeDrone);
			if (removeAction.getType().equals(DELIVERY)) {
				Order removeOrder = removeAction.getOrder();
				removeOrder.setTimeStamp(time);
				delivered.addOrder(removeOrder);
			}
		}
	}

	// selects the service drones that are done
	private void selectDoneServiceDrones() {
		BaseIterator baseIt = bases.getIterator();
		while (baseIt.hasNext()) {
			Base base = baseIt.next();
			DroneIterator it = base.getServiceCollection().getIterator();
			while (it.hasNext()) {
				Drone drone = it.next();
				Action action = drone.getAction();
				if (action.getEndTime() <= time) {
					base.getServiceCollection().removeDrone(drone.getId());
					drone.charge();
					base.getDroneCollection().addDrone(drone);
					// iterator is reset after removing a drone
					it = base.getServiceCollection().getIterator();
				}
			}
		}
	}
}
