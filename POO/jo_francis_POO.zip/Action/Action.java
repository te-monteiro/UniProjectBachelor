package Action;

import Base.Base;
import Order.Order;

/**
 * 
 */

/**
 * @author Joana and xico Specifies the movements of the drone
 */
public interface Action {
	/**
	 * 
	 * @return time in which the action will be completed
	 */
	int getEndTime();

	/**
	 * 
	 * @return Base in which the action begins
	 */
	Base getInicialBase();

	/**
	 * 
	 * @return Base in which the action ends
	 */
	Base getEndBase();

	/**
	 * 
	 * @return total distance that the drone will travel for the action
	 */
	int getTotalDistance();

	/**
	 * 
	 * @return distance that the drone has travelled so far
	 */
	int getTravelledDistance();

	/**
	 * makes a drone travel the given distance
	 * 
	 * @param distance the drone will travel
	 */
	void travel(int distance);

	/**
	 * @return type of the action
	 */
	String getType();

	/**
	 * defines the order this action is completing
	 * 
	 * @param order
	 */
	void setOrder(Order order);

	/**
	 * 
	 * @return order that the action is completing
	 */
	Order getOrder();
}
