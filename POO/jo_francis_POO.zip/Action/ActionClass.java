package Action;

import Base.*;
import Order.*;

/**
 * 
 */

/**
 * @author Joana e chicanas

 */
public class ActionClass implements Action {

	private int endTime;
	Base inicialBase;
	Base endBase;
	String type;
	int totalDistance;
	int distanceTravelled;
	Order order;// order that the action is competing

	public ActionClass(Base inicialBase, Base endBase, int endTime, String type, int totalDistance) {
		this.endTime = endTime;
		this.inicialBase = inicialBase;
		this.endBase = endBase;
		this.type = type;
		this.totalDistance = totalDistance;
		distanceTravelled = 0;
	}

	@Override
	public int getEndTime() {
		return endTime;
	}

	@Override
	public Base getInicialBase() {
		return inicialBase;
	}

	@Override
	public Base getEndBase() {
		return endBase;
	}

	@Override
	public int getTotalDistance() {
		return totalDistance;
	}

	@Override
	public int getTravelledDistance() {
		return distanceTravelled;
	}

	@Override
	public void travel(int distance) {
		distanceTravelled += distance;
	}

	@Override
	public String getType() {
		return type;
	}

	@Override
	public void setOrder(Order order) {
		this.order = order;
	}

	@Override
	public Order getOrder() {
		return order;
	}
}
