package Location;
/**
 * @author francois/jeanne d'arc
 *
 */
public class LocationClass implements Location {
	private int latitude;
	private int longitude;
	
	public LocationClass(int latitude, int longitude) {
		this.latitude = latitude;
		this.longitude = longitude;
	}
	@Override
	public int getLatitude() {
		return latitude;
	}

	@Override
	public int getLongitude() {
		return longitude;
	}

	@Override
	public int getDistance(Location loc2) {
		int lat2= loc2.getLatitude();
		int long2=loc2.getLongitude();
		double sum = ((lat2-latitude)*(lat2-latitude)) + ((long2-longitude)*(long2-longitude));
		int distance = (int)Math.ceil( Math.sqrt(sum));
		return distance;
	}
	@Override
	public int getDeliverDistance(Location loc2) {
		int lat2= loc2.getLatitude();
		int long2=loc2.getLongitude();
		double sum = ((lat2-latitude)*(lat2-latitude)) + ((long2-longitude)*(long2-longitude));
		int distance = (int)Math.ceil( Math.sqrt(sum)*2);
		return distance;
	}
	
	@Override
	public String printCoordinates() {
		return "[" + latitude + "," + longitude +"]";
	}
}
