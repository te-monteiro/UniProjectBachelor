package Location;
/**
 * 
 */

/**
 * @author franc
 *
 */
public interface Location {
	/**
	 * @return latitude of the location
	 */
	int getLatitude();
	/**
	 * @return longitude of the location
	 */
	int getLongitude(); 
	/**
	 * calculates the distance between this location and the given one
	 * @param loc2 given location
	 * @return distance betweeen the two locations
	 */
	int getDistance(Location loc2);
	/**
	 * same as getDistance but including return trip
	 * @param loc2
	 * @return twice the distance from the two locations
	 */
	int getDeliverDistance(Location loc2);
	/**
	 * @return the coordinates of the location
	 */
	String printCoordinates();
}
