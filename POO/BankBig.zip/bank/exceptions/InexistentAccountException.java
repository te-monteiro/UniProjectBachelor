package bank.exceptions;

@SuppressWarnings("serial")
public class InexistentAccountException extends Exception {
	public InexistentAccountException() {
		super();
	}
}
