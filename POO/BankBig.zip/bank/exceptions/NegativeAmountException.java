package bank.exceptions;

@SuppressWarnings("serial")
public class NegativeAmountException extends Exception {
	public NegativeAmountException() {
		super();
	}
}
