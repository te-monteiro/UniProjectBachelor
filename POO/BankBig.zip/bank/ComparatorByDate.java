package bank;

import java.util.Comparator;

public class ComparatorByDate implements Comparator<Account> {

	@Override
	public int compare(Account a1,Account a2) {
		// se a1 < a2 deve devolver -1 
		// se a1 > a2 deve devolver 1
		return 0;
	}

}