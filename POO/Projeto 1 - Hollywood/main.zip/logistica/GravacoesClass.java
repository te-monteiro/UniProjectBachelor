package logistica;

public class GravacoesClass implements Gravacoes {

}
