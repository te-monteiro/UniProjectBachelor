package logistica;

public interface Cenario {

	int getCusto();
	String getNome();
}
