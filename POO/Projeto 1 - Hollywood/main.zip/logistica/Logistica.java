package logistica;

public interface Logistica {
	int searchIndexColab(String nome);
	
	void addColab(String tipo, String notoriedade, int custo, String nome);
	int searchIndexLocal(String nome);
	void addLocal(String local, int custo);
}
