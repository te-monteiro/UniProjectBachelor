package logistica;

public class CenarioClass implements Cenario {

	private String nome;
	private int custo;

	public CenarioClass(String nome, int custo) {

		this.nome = nome;
		this.custo = custo;
	}

	public String getNome() {
		return nome;
	}

	public int getCusto() {
		return custo;
	}
}
