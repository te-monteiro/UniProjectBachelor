package logistica;

import colaboradores.*;
import vedeta.*;

public class LogisticaClass implements Logistica {
	
	private Gravacoes gP;
	private Gravacoes gR;
	private Colaboradores staff;
	private Cenarios locais;
	
	public LogisticaClass() {
		gP = new GravacoesClass(); 
		gR = new GravacoesClass();
		staff = new ColaboradoresClass();
		locais = new CenariosClass();
	}

	public int searchIndexColab(String nome) {
		return staff.searchIndex(nome);
	}
	
	public int searchIndexLocal(String nome) {
		return locais.searchIndex(nome);
	}
	
	public void addColab(String tipo, String notoriedade, int custo, String nome) {
		switch(tipo) {
		case "senior":
			Colaborador senior = new ProdSen(nome, custo);
			staff.addColab(senior);
			break;
		case "junior":
			Colaborador junior = new ProdJun(nome, custo);
			staff.addColab(junior);
			break;
		case "tecnico":
			Colaborador tecnico = new Tecnicos(nome, custo);
			staff.addColab(tecnico);
			break;
		case "realizador":
			Colaborador realizador = new Realizadores(nome, custo, notoriedade);
			staff.addColab(realizador);
			break;
		case "actor":
			Colaborador actor = new Actores(nome, custo, notoriedade);
			staff.addColab(actor);
			break;
		}
	}
	
	public void addLocal(String local, int custo) {
		locais.addLocal(local, custo);
	}
}
