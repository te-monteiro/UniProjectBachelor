package logistica;

public class GravacaoClass implements Gravacao {

	private Cenario local;
	private int ano, mes, dia;
	private int horas, minutos;
	private int duracao;

}
