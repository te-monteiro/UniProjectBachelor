package logistica;

public interface Cenarios {

	int searchIndex(String name);
	void addLocal(String local, int custo);
}
