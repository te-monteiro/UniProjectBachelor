package logistica;

public class CenariosClass implements Cenarios {

	public static final int MAX = 50;

	private int counter;
	private Cenario[] locais;

	public CenariosClass() {
		locais = new CenarioClass[MAX];
		counter = 0;
	}

	public void addLocal(String local, int custo) {
		locais[counter++] = new CenarioClass(local, custo);
	}

	public int searchIndex(String name) {
		int found = -1;
		int i = 0;
		while (i < counter && found == -1) {
			if (locais[i].getNome().equals(name))
				found = i;
			i++;
		}
		return found;

	}

}
