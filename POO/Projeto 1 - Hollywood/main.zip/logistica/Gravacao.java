package logistica;

public interface Gravacao {

}
