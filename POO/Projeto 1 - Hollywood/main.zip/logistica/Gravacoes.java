package logistica;

public interface Gravacoes {

}
