import java.util.Scanner;

import logistica.*;

public class Main {

	// Comandos
	private static final String SAI = "SAI";
	private static final String AJUDA = "AJUDA";
	private static final String REGISTA = "REGISTA";
	private static final String STAFF = "STAFF";
	private static final String CENARIO = "CENARIO";
	private static final String CENARIOS = "CENARIOS";
	private static final String MARCA = "MARCA";
	private static final String AMUA = "AMUA";
	private static final String RECONCILIA = "RECONCILIA";
	private static final String REALIZADAS = "REALIZADAS";
	private static final String PREVISTAS = "PREVISTAS";
	private static final String LOCAL = "LOCAL";
	private static final String COLABORADOR = "COLABORADOR";
	private static final String GRAVA = "GRAVA";
	private static final String AMUANCOS = "AMUANCOS";

	// Mensagens de despedida
	private static final String ADEUS = "Ate a proxima.";

	// Mensagens de erro
	private static final String ERRO = "Opcao inexistente.";

	// Mensagens de ajuda
	private static final String AJUDA_REGISTA = "regista - regista um novo colaborador";
	private static final String AJUDA_STAFF = "staff - lista os colaboradores registados";
	private static final String AJUDA_CENARIO = "cenario - regista um novo local para gravacoes";
	private static final String AJUDA_CENARIOS = "cenarios - lista os locais para gravacoes registados";
	private static final String AJUDA_MARCA = "marca - marca uma nova gravacao";
	private static final String AJUDA_AMUA = "amua - vedeta deixa de trabalhar com colaborador";
	private static final String AJUDA_RECONCILIA = "reconcilia - vedeta faz as pazes com colaborador";
	private static final String AJUDA_REALIZADAS = "realizadas - lista as gravacoes realizadas";
	private static final String AJUDA_PREVISTAS = "previstas - lista as gravacoes previstas";
	private static final String AJUDA_LOCAL = "local - lista as gravacoes previstas para um local";
	private static final String AJUDA_COLABORADOR = "colaborador - lista as gravacoes previstas para um colaborador";
	private static final String AJUDA_GRAVA = "grava - executa a proxima gravacao agendada";
	private static final String AJUDA_AMUANCOS = "amuancos - lista os colaboradores com quem uma vedeta esta amuada";
	private static final String AJUDA_AJUDA = "ajuda - Mostra a ajuda";
	private static final String AJUDA_SAI = "sai - Termina a execucao do programa";

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);

		Logistica l = new LogisticaClass();

		String comm = getCommand(in);

		while (!comm.equals(SAI)) {
			switch (comm) {
			case AJUDA:// ENUMERADOS
				getAjuda();
				break;
			case REGISTA:
				regista(in, l);
				break;
			case STAFF:
				break;
			case CENARIO:
				addLocal(in, l);
				break;
			case CENARIOS:
				break;
			case MARCA:
				break;
			case AMUA:
				
				
				
				
				break;
			case RECONCILIA:
				break;
			case REALIZADAS:
				break;
			case PREVISTAS:
				break;
			case LOCAL:
				break;
			case COLABORADOR:
				break;
			case GRAVA:
				break;
			case AMUANCOS:
				break;
			default:
				System.out.println(ERRO);
			}

			comm = getCommand(in);
		}

		System.out.println(ADEUS);
		System.out.println();
		in.close();
	}

	private static void addLocal(Scanner in, Logistica l) {
		String local = in.nextLine();
		int custo = in.nextInt();
		if (l.searchIndexLocal(local) < 0)
			System.out.println("Localizacao ja tinha sido registada.");
		else if (custo < 0)
			System.out.println("Acha que eles nos pagam para gravar la?");
		else {
			l.addLocal(local, custo);
			System.out.println("Cenario registado.");
		}
	}

	private static void regista(Scanner in, Logistica l) {
		String tipo = in.next();
		String notoriedade;
		if (tipo.equals("realizador") || tipo.equals("actor")) {
			notoriedade = in.next();
		} else {
			notoriedade = "";
		}
		int custo = in.nextInt();
		String nome = in.nextLine();
		if (l.searchIndexColab(nome) < 0)
			System.out.println("Ja existe um colaborador com o mesmo nome.");
		else if (!tipo.equals("realizador") || !tipo.equals("actor") || !tipo.equals("senior") || !tipo.equals("junior")
				|| !tipo.equals("tecnico"))
			System.out.println("Tipo de colaborador desconhecido.");
		else if (!notoriedade.equals("normal") || !notoriedade.equals("vedeta"))
			System.out.println("Notoriedade invalida.");
		else if (custo < 0)
			System.out.println("Acha mesmo que este colaborador vai pagar para trabalhar?");
		else {
			l.addColab(tipo, notoriedade, custo, nome);
			System.out.println("Colaborador registado com sucesso!");
		}
	}

	private static void getAjuda() {
		System.out.println(AJUDA_REGISTA);
		System.out.println(AJUDA_STAFF);
		System.out.println(AJUDA_CENARIO);
		System.out.println(AJUDA_CENARIOS);
		System.out.println(AJUDA_MARCA);
		System.out.println(AJUDA_AMUA);
		System.out.println(AJUDA_RECONCILIA);
		System.out.println(AJUDA_REALIZADAS);
		System.out.println(AJUDA_PREVISTAS);
		System.out.println(AJUDA_LOCAL);
		System.out.println(AJUDA_COLABORADOR);
		System.out.println(AJUDA_GRAVA);
		System.out.println(AJUDA_AMUANCOS);
		System.out.println(AJUDA_AJUDA);
		System.out.println(AJUDA_SAI);
	}

	private static String getCommand(Scanner in) {
		System.out.print("> ");
		String input;
		input = in.nextLine().toUpperCase();
		return input;
	}
}
