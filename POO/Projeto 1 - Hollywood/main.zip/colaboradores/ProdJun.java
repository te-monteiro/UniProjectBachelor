package colaboradores;

public class ProdJun extends ColaboradorClass {

	public ProdJun(String nome, int custo) {
		super(nome, custo);
	}

}
