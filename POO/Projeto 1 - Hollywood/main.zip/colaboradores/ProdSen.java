package colaboradores;

public class ProdSen extends ColaboradorClass {

	public ProdSen(String nome, int custo) {
		super(nome, custo);
	}

}
