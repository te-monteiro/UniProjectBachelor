package colaboradores;

public class Tecnicos extends ColaboradorClass {

	public Tecnicos(String nome, int custo) {
		super(nome, custo);
	}

}
