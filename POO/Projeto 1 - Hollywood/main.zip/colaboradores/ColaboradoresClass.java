package colaboradores;

public class ColaboradoresClass implements Colaboradores {
	
	public static final int MAX = 50;
	
	private Colaborador[] staff;
	private int counter;

	public ColaboradoresClass() {
		staff = new ColaboradorClass[MAX];
		counter = 0;
	}
	
	public void addColab(Colaborador c) {
		staff[counter++] = c;
	}
	
	public int searchIndex(String name) {
		int found = -1;
		int i = 0;
		while (i < counter && found == -1) {
			if (staff[i].getNome().equals(name))
				found = i;
			i++;
		}
		return found;

	}
}
