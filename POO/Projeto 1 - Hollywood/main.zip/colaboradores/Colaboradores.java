package colaboradores;

public interface Colaboradores {
	int searchIndex(String nome);
	void addColab(Colaborador c);
}
