package colaboradores;

public interface Colaborador {
	int getCusto();
	String getNome();
}
