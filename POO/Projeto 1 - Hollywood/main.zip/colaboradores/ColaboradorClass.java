package colaboradores;

public abstract class ColaboradorClass implements Colaborador {

	private String nome;
	private int custo;
	// calendario

	public ColaboradorClass(String nome, int custo) {
		this.nome = nome;
		this.custo = custo;
	}

	public String getNome() {
		return nome;
	}

	public int getCusto() {
		return custo;
	}

}
