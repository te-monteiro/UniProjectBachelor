package vedeta;

public class Realizadores extends VedetaClass {

	public Realizadores(String nome, int custo, String notoriedade) {
		super(nome, custo, notoriedade);
	}

}
