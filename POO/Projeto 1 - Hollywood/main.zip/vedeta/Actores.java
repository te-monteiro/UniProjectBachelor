package vedeta;

public class Actores extends VedetaClass {

	public Actores(String nome, int custo, String notoriedade) {
		super(nome, custo, notoriedade);
	}

}
