package vedeta;

public interface Vedeta {

}
