package vedeta;

import colaboradores.*;

public class VedetaClass extends ColaboradorClass implements Vedeta {

	private boolean vedeta;

	public VedetaClass(String nome, int custo, String notoriedade) {
		super(nome, custo);
		if (notoriedade.equals("vedeta"))
			vedeta = true;
		else
			vedeta = false;
	}

}
