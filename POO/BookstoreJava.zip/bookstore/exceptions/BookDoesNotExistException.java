package bookstore.exceptions;

@SuppressWarnings("serial")
public class BookDoesNotExistException extends RuntimeException {
	public BookDoesNotExistException() {
		super();
	}
}
