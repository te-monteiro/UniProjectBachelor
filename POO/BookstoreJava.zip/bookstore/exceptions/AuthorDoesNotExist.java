package bookstore.exceptions;

@SuppressWarnings("serial")
public class AuthorDoesNotExist extends RuntimeException {
	public AuthorDoesNotExist() {
		super();
	}
}

