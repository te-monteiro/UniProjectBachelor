package bookstore.exceptions;

@SuppressWarnings("serial")
public class PublisherDoesNotExist extends RuntimeException {
	public PublisherDoesNotExist() {
		super();
	}
}

