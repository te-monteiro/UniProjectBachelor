package bookstore.exceptions;

@SuppressWarnings("serial")
public class NoTopSellerException extends RuntimeException {
	public NoTopSellerException() {
		super();
	}
}
