package bookstore.exceptions;

@SuppressWarnings("serial")
public class BookAlreadyExistsException extends RuntimeException {
	public BookAlreadyExistsException() {
		super();
	}
}
