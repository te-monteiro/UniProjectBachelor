
public enum Command {
	AC			("Add contact"),
	RC			("Remove contact"),
	GP			("Get phone"),
	GE			("Get email"),
	SP			("Set phone"),
	SE			("Set email"),
	LC			("List contacts"),
	Q			("Quit"),
	H			("Help"),
	UNKNOWN		("");

	private String description;

	private Command(String description) {
		this.description = description;
	}

	public String toString() {
		return description;
	}
}
