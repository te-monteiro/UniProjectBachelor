/**
 * 
 * @author Tiago Cotovio - 52349
 * @author Teresa Monteiro - 52597
 *
 */
package vedeta;

import colaboradores.Colaborador;

public interface Realizador extends Colaborador {
	static final String TIPO = "realizador";

}
