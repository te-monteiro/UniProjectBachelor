/**
 * 
 * @author Tiago Cotovio - 52349
 * @author Teresa Monteiro - 52597
 *
 */
package vedeta;

import colaboradores.*;

public class ActorClass extends ColaboradorClass implements Colaborador {

	private static final String TIPO = "actor";

	public ActorClass(String nome, int custo) {
		super(nome, custo, TIPO);
	}

}
