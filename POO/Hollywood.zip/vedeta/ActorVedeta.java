/**
 * 
 * @author Tiago Cotovio - 52349
 * @author Teresa Monteiro - 52597
 *
 */
package vedeta;

import colaboradores.Colaborador;
import vetores.VetorGenerico;
import vetores.VetorGenericoClass;

public class ActorVedeta extends ActorClass implements Vedeta {

	private VetorGenerico<Colaborador> listaNegra;

	public ActorVedeta(String nome, int custo) {
		super(nome, custo);
		listaNegra = new VetorGenericoClass<Colaborador>();
	}

	public void addInimigo(Colaborador c) {
		listaNegra.insertLast(c);
	}

	public boolean alreadyMad(Colaborador c) {
		return listaNegra.searchIndexOf(c) >= 0;
	}

	public void makePeace(Colaborador c) {
		int pos = listaNegra.searchIndexOf(c);
		listaNegra.removeAt(pos);
	}

	public VetorGenerico<Colaborador> getListaNegra() {
		return listaNegra;
	}

}
