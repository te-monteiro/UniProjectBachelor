/**
 * 
 * @author Tiago Cotovio - 52349
 * @author Teresa Monteiro - 52597
 *
 */
package vedeta;

import colaboradores.*;

public class RealizadorClass extends ColaboradorClass implements Realizador {

	public RealizadorClass(String nome, int custo) {
		super(nome, custo, TIPO);
	}

}
