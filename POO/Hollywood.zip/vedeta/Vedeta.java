/**
 * 
 * @author Tiago Cotovio - 52349
 * @author Teresa Monteiro - 52597
 *
 */
package vedeta;

import colaboradores.Colaborador;
import vetores.VetorGenerico;

public interface Vedeta extends Colaborador {

	/**
	 * Metodo que adiciona um inimigo
	 * 
	 * @param v
	 */
	void addInimigo(Colaborador c);

	/**
	 * Metodo que verifica se os vedetas estao chateados
	 * 
	 * @param v
	 * @return
	 */
	boolean alreadyMad(Colaborador c);

	/**
	 * Metodo que permite fazer as pazes
	 * 
	 * @param v
	 */
	void makePeace(Colaborador c);

	/**
	 * Metodo que devolve a lista negra de uma vedeta
	 * 
	 * @return o vetor que tem os colaboradores todos com que a vedeta esta chateada
	 */
	VetorGenerico<Colaborador> getListaNegra();

}
