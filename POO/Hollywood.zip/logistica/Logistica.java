/**
 * 
 * @author Tiago Cotovio - 52349
 * @author Teresa Monteiro - 52597
 *
 */
package logistica;

import java.time.LocalDateTime;

import colaboradores.*;
import vetores.Iterador;

public interface Logistica {

	/**
	 * Executa a proxima gravacao prevista
	 */
	void grava();

	/**
	 * 
	 * @param local
	 *            - nome do local a adicionar
	 * @param custo
	 *            - custo horario do local a adicionar
	 */

	void addLocal(String local, int custo);

	/**
	 * 
	 * @param tipo
	 *            - tipo de colaborador a adicionar
	 * @param notoriedade
	 *            - notoriedade do colaborador a adicionar (caso seja realizador ou
	 *            ator)
	 * @param custo
	 *            - custo horario do colaborador a adicionar
	 * @param nome
	 *            - nome do colaborador a adicionar
	 */

	void addColab(String tipo, String notoriedade, int custo, String nome);

	/**
	 * Devolve um iterador de locais
	 * 
	 * @return iterador
	 */

	Iterador<Cenario> iteradorLocais();

	/**
	 * Devolve um iterador de colaboradores
	 * 
	 * @return iterador
	 */

	Iterador<Colaborador> iteradorColab();

	/**
	 * Devolve um iterador das gravacoes previstas
	 * 
	 * @return iterador
	 */
	Iterador<Gravacao> iteradorPrevistas();

	/**
	 * Devolve um iterador das gravacoes realizadas
	 * 
	 * @return iterador
	 */

	Iterador<Gravacao> iteradorRealizadas();

	/**
	 * 
	 * @param nome
	 *            - nome do colaborador a pesquisar
	 * @return obter a posicao da pessoa com este nome no vetor dos colaboradores
	 *         registados
	 */
	int searchIndexColab(String nome);

	/**
	 * 
	 * @param nome
	 *            - nome do local a pesquisar
	 * @return obter a posicao do local com este nome no vetor dos locais registados
	 */
	int searchIndexLocal(String nome);

	/**
	 * 
	 * @param local
	 *            - nome do local onde vai ser executada a gravacao
	 * @param date
	 *            - data de inicio prevista para a gravacao
	 * @param duracao
	 *            - duracao da gravacao
	 * @param vip
	 *            - vetor que tem como elementos os nomes das 3 pessoas importantes
	 *            de uma gravacao (produtor, realizador, tecnico)
	 * @param nColaboradores
	 *            - numero de colaboradores extra a adicionar a gravacao
	 * @param nomes
	 *            - vetor que tem como elementos os nomes das pessoas extras a
	 *            adicionar a gravacao
	 * @param zangas
	 *            - numero de zangas presentes na marcacao da gravacao
	 */

	void marca(String local, LocalDateTime date, int duracao, String[] vip, int nColaboradores, String[] nomes,
			int zangas);

	/**
	 * 
	 * @return montante total orcamentado para todas as gravacoes previstas
	 */
	int getMontante();

	/**
	 * 
	 * @param nomeLocal
	 *            - nome do local onde vao decorrer gravacoes
	 * @return montante total orcamentado para todas as gravacoes previstas no local
	 *         de nome <code>nomeLocal</code>
	 */

	int getMontanteLocal(String nomeLocal);

	/**
	 * 
	 * @param nomeColab
	 *            - nome do colaborador cujas gravacoes queremos listar
	 * @return montante total orcamentado para todas as gravacoes previstas para o
	 *         colaborador de nome <code>nomeColab</code>
	 */
	int getMontanteColab(String nomeColab);

	/**
	 * 
	 * @return montante total gasto em todas as gravacoes realizadas
	 */
	int getGastos();

	/**
	 * 
	 * @param g
	 *            - objeto do tipo Gravacao
	 * @param nomeColab
	 *            - nome do colaborador
	 * @return true se o colaborador de nome <code>nomeColab</code> fizer parte do
	 *         staff da gravacao <code>g</code>
	 */
	boolean isRecording(Gravacao g, String nomeColab);

	/**
	 * 
	 * @param nome
	 *            - nome do Colaborador a verificar se e vedeta
	 * @return true se o colaborador for do tipo Vedeta
	 */
	boolean isVedeta(String nome);

	/**
	 * 
	 * @param nome
	 *            - nome da vedeta
	 * @param nomeInimigo
	 *            - nome do colaborador
	 * @return true se ja existir zanga da vedeta de nome <code>nome</code> com o
	 *         colaborador de nome <code>nomeInimigo</code>
	 */
	boolean alreadyMad(String nome, String nomeInimigo);

	/**
	 * 
	 * @param nome
	 *            - nome da vedeta
	 * @param nomeInimigo
	 *            - nome do colaborador
	 * @return numero de gravacoes suspensas devido a zanga entre a vedeta e o
	 *         colaborador
	 */
	int suspende(String nome, String nomeInimigo);

	/**
	 * 
	 * @param nome
	 *            - nome da vedeta
	 * @param nomeInimigo
	 *            - nome do colaborador
	 * @return numero de gravacoes salvas devido ao reconciliamento entre a vedeta e
	 *         o colaborador
	 */
	int reconcilia(String nome, String nomeInimigo);

	/**
	 * 
	 * @param date
	 *            - data a verificar se e valida
	 * @return true se a data for valida e se a data de inicio prevista nao faz
	 *         parte do passado
	 */
	boolean isDataValid(LocalDateTime date);

	/**
	 * 
	 * @param nomes-
	 *            vetor que tem como elementos os nomes das pessoas extras a
	 *            adicionar a gravacao
	 * @return true se todos os colaboradores forem validos, ou seja, se estiverem
	 *         registados
	 */
	boolean validColabs(String[] nomes);

	/**
	 * 
	 * @param nome
	 *            - nome do colaborador a verificar se e realizador
	 * @return true se o colaborador for do tipo realizador
	 */
	boolean isDirector(String nome);

	/**
	 * 
	 * @param nome
	 *            - nome do colaborador a verificar se e produtor
	 * @return true se o colaborador for do tipo produtor
	 */
	boolean isProducer(String nome);

	/**
	 * 
	 * @param nome
	 *            - nome do colaborador a verificar se e tecnico
	 * @return true se o colaborador for do tipo tecnico
	 */
	boolean isTecnico(String nome);

	/**
	 * 
	 * @param vip
	 *            - vetor que tem como elementos os nomes das 3 pessoas importantes
	 *            de uma gravacao (produtor, realizador, tecnico)
	 * @param nomes
	 *            - vetor que tem como elementos os nomes das pessoas extras a
	 *            adicionar a gravacao
	 * @return numero de zangas entre os colaboradores de uma gravacao a adicionar
	 */
	int isSomeoneMad(String[] vip, String[] nomes);

	/**
	 * 
	 * @param startDate
	 *            - data de inicio prevista da gravacao a marcar
	 * @param endDate
	 *            - data de fim prevista da gravacao a marcar
	 * @param nome
	 *            - nome do produtor da gravacao a marcar
	 * @param vip
	 *            - vetor que tem como elementos os nomes das 3 pessoas importantes
	 *            de uma gravacao (produtor, realizador, tecnico)
	 * @param outros
	 *            - vetor que tem como elementos os nomes das pessoas extras a
	 *            adicionar a gravacao
	 * @return true se nao houver conflito com locais ou colaboradores, sem
	 *         verificar prioridades
	 */
	boolean isBusyWithoutPriority(LocalDateTime startDate, LocalDateTime endDate, String nome, String[] vip,
			String[] outros);

	/**
	 * 
	 * @param startDate
	 *            - data de inicio prevista da gravacao a marcar
	 * @param endDate
	 *            - data de fim prevista da gravacao a marcar
	 * @param nome
	 *            - nome do produtor da gravacao a marcar
	 * @param vip
	 *            - vetor que tem como elementos os nomes das 3 pessoas importantes
	 *            de uma gravacao (produtor, realizador, tecnico)
	 * @param outros
	 *            - vetor que tem como elementos os nomes das pessoas extras a
	 *            adicionar a gravacao
	 * @return true se nao houver conflito com locais ou colaboradores, com
	 *         verificacao de prioridades
	 */
	boolean isBusyWithPriority(LocalDateTime startDate, LocalDateTime endDate, String nome, String[] vip,
			String[] outros);

	/**
	 * 
	 * @param nomeProdutor
	 *            - nome do produtor da gravacao a marcar
	 * @param g
	 *            - gravacao com que existe conflito de local ou de colaborador
	 * @return true se o produtor de nome <code>nomeProdutor</code> tiver prioridade
	 *         de marcacao sobre o produtor da gravacao <code>g</code>
	 */
	boolean minePriority(String nomeProdutor, Gravacao g);

	/**
	 * 
	 * @param nomeVedeta
	 *            - nome da vedeta
	 * @return o iterador que vai percorrer todos os colaboradores com quema vedeta
	 *         esta zangada
	 */
	Iterador<Colaborador> iteradorListaNegra(String nomeVedeta);
}
