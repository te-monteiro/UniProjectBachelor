/**
 * 
 * @author Tiago Cotovio - 52349
 * @author Teresa Monteiro - 52597
 *
 */
package logistica;

import java.time.LocalDateTime;

import colaboradores.*;

import vedeta.*;
import vetores.*;

public class LogisticaClass implements Logistica {

	private VetorGenerico<Colaborador> staff;
	private VetorGenerico<Cenario> locais;
	private VetorGenerico<Gravacao> gP;
	private VetorGenerico<Gravacao> gR;

	public LogisticaClass() {
		staff = new VetorGenericoClass<Colaborador>();
		locais = new VetorGenericoClass<Cenario>();
		gP = new VetorGenericoClass<Gravacao>();
		gR = new VetorGenericoClass<Gravacao>();
	}

	public void grava() {
		Gravacao g = gP.get(0);
		int pos = this.findIndex(g, gR);
		gR.insertAt(g, pos);
		gP.removeAt(0);
	}

	public boolean isDataValid(LocalDateTime date) {
		if (gR.size() == 0) {
			return true;
		}
		return gR.get(0).getStartDate().isBefore(date);
	}

	public boolean isProducer(String nome) {
		return (this.searchIndexColab(nome) >= 0 && (staff.get(this.searchIndexColab(nome)) instanceof ProdSen
				|| staff.get(this.searchIndexColab(nome)) instanceof ProdJun));
	}

	public boolean isDirector(String nome) {
		return (this.searchIndexColab(nome) >= 0 && (staff.get(this.searchIndexColab(nome)) instanceof Realizador));
	}

	public boolean isTecnico(String nome) {
		return (this.searchIndexColab(nome) >= 0 && (staff.get(this.searchIndexColab(nome)) instanceof Tecnico));
	}

	public boolean validColabs(String[] nomes) {
		for (int i = 0; i < nomes.length; i++) {
			if (this.searchIndexColab(nomes[i]) < 0) {
				return false;
			}
		}
		return true;
	}

	public int isSomeoneMad(String[] vip, String[] nomes) {
		int result = 0;
		for (int i = 0; i < vip.length; i++) {
			for (int j = 0; j < nomes.length; j++) {
				if ((staff.get(this.searchIndexColab(vip[1])) instanceof Vedeta && (this.alreadyMad(vip[1], nomes[j])))
						|| (staff.get(this.searchIndexColab(nomes[j])) instanceof Vedeta
								&& this.alreadyMad(nomes[j], vip[i]))) {
					result++;
				}
			}
			if (staff.get(this.searchIndexColab(vip[1])) instanceof Vedeta && this.alreadyMad(vip[1], vip[i]))
				result++;
		}
		for (int i = 0; i < nomes.length; i++) {
			for (int j = 0; j < nomes.length; j++) {
				if (staff.get(this.searchIndexColab(nomes[j])) instanceof Vedeta
						&& this.alreadyMad(nomes[j], nomes[i])) {
					result++;
				}
			}
		}
		return result;
	}

	public void marca(String local, LocalDateTime date, int duracao, String[] vip, int nColaboradores, String[] nomes,
			int zangas) {
		Gravacao g = new GravacaoClass(locais.get(this.searchIndexLocal(local)), date, duracao);
		for (int i = 0; i < nColaboradores; i++) {
			this.joinStaff(nomes[i], g);
		}
		for (int i = 0; i < zangas; i++) {
			g.amua();
		}
		gP.insertAt(g, this.findIndex(g, gP));
		Colaborador p = staff.get(this.searchIndexColab(vip[0]));
		Colaborador r = staff.get(this.searchIndexColab(vip[1]));
		Colaborador t = staff.get(this.searchIndexColab(vip[2]));
		g.addVip(p, r, t);
	}

	private int findIndex(Gravacao g, VetorGenerico<Gravacao> elems) {
		int result;
		if (elems.size() > 0) {
			result = elems.size();
			LocalDateTime date = g.getStartDate();
			for (int i = 0; i < elems.size(); i++) {
				if (date.isBefore(elems.get(i).getStartDate())) {
					result = i;
					return result;
				}
			}
		} else {
			result = 0;
		}
		return result;
	}

	public void joinStaff(String nome, Gravacao g) {
		Colaborador c = staff.get(this.searchIndexColab(nome));
		g.addColaborador(c);
	}

	public void addColab(String tipo, String notoriedade, int custo, String nome) {
		switch (tipo) {
		case "senior":
			ProdSen senior = new ProdSenClass(nome, custo);
			staff.insertLast(senior);
			break;
		case "junior":
			ProdJun junior = new ProdJunClass(nome, custo);
			staff.insertLast(junior);
			break;
		case "tecnico":
			Tecnico tecnico = new TecnicoClass(nome, custo);
			staff.insertLast(tecnico);
			break;
		case "realizador":
			if (notoriedade.equals("normal")) {
				Realizador realizador = new RealizadorClass(nome, custo);
				staff.insertLast(realizador);
			} else {
				Vedeta realizador = new RealizadorVedeta(nome, custo);
				staff.insertLast(realizador);
			}
			break;
		case "actor":
			if (notoriedade.equals("normal")) {
				Colaborador actor = new ActorClass(nome, custo);
				staff.insertLast(actor);
			} else {
				Vedeta actor = new ActorVedeta(nome, custo);
				staff.insertLast(actor);
			}
			break;
		}
	}

	public void addLocal(String local, int custo) {
		locais.insertLast(new CenarioClass(local, custo));
	}

	public Iterador<Cenario> iteradorLocais() {
		return locais.iterator();
	}

	public Iterador<Colaborador> iteradorColab() {
		return staff.iterator();
	}

	public Iterador<Gravacao> iteradorPrevistas() {
		return gP.iterator();
	}

	public Iterador<Gravacao> iteradorRealizadas() {
		return gR.iterator();
	}

	public Iterador<Colaborador> iteradorListaNegra(String nomeVedeta) {
		Vedeta v = (Vedeta) staff.get(this.searchIndexColab(nomeVedeta));
		return v.getListaNegra().iterator();
	}

	public int searchIndexColab(String nome) {
		Iterador<Colaborador> it = this.iteradorColab();
		int result = -1;
		int i = 0;
		if (!it.isEmpty()) {
			// tentar com do while
			if (it.next().equals(nome)) {
				result = 0;
			} else
				i++;
			while (it.hasNext()) {
				if (it.next().equals(nome)) {
					result = i;
				}
				i++;
			}
		} else {
			result = -1;
		}
		return result;
	}

	public int searchIndexLocal(String nome) {
		Iterador<Cenario> it = this.iteradorLocais();
		int result = -1;
		int i = 0;
		if (!it.isEmpty()) {
			// tentar com do while
			if (it.next().equals(nome)) {
				result = 0;
			} else
				i++;
			while (it.hasNext()) {
				if (it.next().equals(nome)) {
					result = i;
				}
				i++;

			}
		} else {
			result = -1;
		}
		return result;
	}

	public int getMontante() {
		int result = 0;
		for (int i = 0; i < gP.size(); i++) {
			result += gP.get(i).getMontante();
		}
		return result;
	}

	public int getGastos() {
		int result = 0;
		for (int i = 0; i < gR.size(); i++) {
			if (gR.get(i).isOn())
				result += gR.get(i).getMontante();
		}
		return result;
	}

	public int getMontanteLocal(String nomeLocal) {
		int result = 0;
		for (int i = 0; i < gP.size(); i++) {
			if (gP.get(i).getLocal().getNome().equals(nomeLocal))
				result += gP.get(i).getMontante();
		}
		return result;
	}

	public int getMontanteColab(String nomeColab) {
		int result = 0;
		int pos = this.searchIndexColab(nomeColab);
		for (int i = 0; i < gP.size(); i++) {
			if (gP.get(i).getStaff().searchIndexOf(staff.get(pos)) >= 0)
				result += gP.get(i).getMontante();
		}
		return result;
	}

	public boolean isRecording(Gravacao g, String nomeColab) {
		int pos = this.searchIndexColab(nomeColab);
		return g.getStaff().searchIndexOf(staff.get(pos)) >= 0;
	}

	public boolean isVedeta(String nome) {
		if (this.searchIndexColab(nome) >= 0) {
			return (staff.get(this.searchIndexColab(nome)) instanceof Vedeta);
		}
		return false;
	}

	private void addInimigo(String nome, String nomeInimigo) {
		Vedeta v = (Vedeta) staff.get(this.searchIndexColab(nome));
		Colaborador inimigo = staff.get(this.searchIndexColab(nomeInimigo));
		v.addInimigo(inimigo);
	}

	private void friendsAgain(String nome, String nomeInimigo) {
		Vedeta v = (Vedeta) staff.get(this.searchIndexColab(nome));
		Colaborador inimigo = staff.get(this.searchIndexColab(nomeInimigo));
		v.makePeace(inimigo);
	}

	public boolean alreadyMad(String nome, String nomeInimigo) {
		Vedeta v = (Vedeta) staff.get(this.searchIndexColab(nome));
		Colaborador inimigo = staff.get(this.searchIndexColab(nomeInimigo));
		return v.alreadyMad(inimigo);
	}

	public int suspende(String nome, String nomeInimigo) {
		Colaborador v = staff.get(this.searchIndexColab(nome));
		Colaborador inimigo = staff.get(this.searchIndexColab(nomeInimigo));
		this.addInimigo(nome, nomeInimigo);
		int result = 0;
		for (int i = 0; i < gP.size(); i++) {
			if (gP.get(i).getStaff().searchIndexOf(v) >= 0 && gP.get(i).getStaff().searchIndexOf(inimigo) >= 0) {
				boolean wasOn = gP.get(i).isOn();
				gP.get(i).amua();
				if (wasOn && !gP.get(i).isOn())
					result++;

			}
		}
		return result;
	}

	public int reconcilia(String nome, String nomeInimigo) {
		Colaborador v = staff.get(this.searchIndexColab(nome));
		Colaborador inimigo = staff.get(this.searchIndexColab(nomeInimigo));
		int result = 0;
		for (int i = 0; i < gP.size(); i++) {
			if (gP.get(i).getStaff().searchIndexOf(v) >= 0 && gP.get(i).getStaff().searchIndexOf(inimigo) >= 0) {
				gP.get(i).makePeace();
				if (gP.get(i).isOn())
					result++;
			}
		}
		this.friendsAgain(nome, nomeInimigo);
		return result;
	}

	public boolean isBusyWithoutPriority(LocalDateTime startDate, LocalDateTime endDate, String nome, String[] vip,
			String[] outros) {
		String nomeProdutor = vip[0];
		for (int i = 0; i < gP.size(); i++) {
			Gravacao g = gP.get(i);
			if (busyLocal(startDate, endDate, nome, vip, g))
				if (!this.minePriority(nomeProdutor, g))
					return true;

			for (int j = 0; j < vip.length; j++) {
				Colaborador e = staff.get(this.searchIndexColab(vip[j]));
				if (busyColab(startDate, endDate, vip, g, e))
					if (!this.minePriority(nomeProdutor, g))
						return true;
			}

			for (int j = 0; j < outros.length; j++) {
				Colaborador e = staff.get(this.searchIndexColab(outros[j]));
				if (busyColab(startDate, endDate, vip, g, e))
					if (!this.minePriority(nomeProdutor, g))
						return true;
			}

		}
		return false;
	}

	public boolean isBusyWithPriority(LocalDateTime startDate, LocalDateTime endDate, String nome, String[] vip,
			String[] outros) {
		boolean busy = false;
		busy = conflitoLocalPrioridade(startDate, endDate, nome, vip, busy);

		busy = conflitoColabPrioridade(startDate, endDate, vip, busy);

		busy = conflitoColabPrioridade(startDate, endDate, outros, busy);
		return busy;

	}

	private boolean conflitoLocalPrioridade(LocalDateTime startDate, LocalDateTime endDate, String nome, String[] nomes,
			boolean busy) {
		VetorGenerico<Gravacao> reagendar = new VetorGenericoClass<Gravacao>();
		for (int i = 0; i < gP.size(); i++) {
			Gravacao g = gP.get(i);
			if (this.busyLocal(startDate, endDate, nome, nomes, g)) {
				if (this.minePriority(nomes[0], g)) {
					reagendar.insertLast(g);
					busy = true;
				}
			}
		}
		if (reagendar.size() > 0)
			this.remarca(reagendar);
		return busy;
	}

	private boolean conflitoColabPrioridade(LocalDateTime startDate, LocalDateTime endDate, String[] nomes,
			boolean busy) {
		VetorGenerico<Gravacao> reagendar = new VetorGenericoClass<Gravacao>();
		reagendar = new VetorGenericoClass<Gravacao>();
		for (int i = 0; i < gP.size(); i++) {
			for (int j = 0; j < nomes.length; j++) {
				Gravacao g = gP.get(i);
				Colaborador e = staff.get(this.searchIndexColab(nomes[j]));
				if (this.busyColab(startDate, endDate, nomes, g, e)) {
					if (this.minePriority(nomes[0], g)) {
						reagendar.insertLast(g);
						busy = true;
					}
				}
			}
		}
		if (reagendar.size() > 0)
			this.remarca(reagendar);
		return busy;
	}

	private boolean busyColab(LocalDateTime startDate, LocalDateTime endDate, String[] nomes, Gravacao g,
			Colaborador e) {
		if (sameTime(startDate, endDate, g)) {
			if (g.getStaff().searchIndexOf(e) >= 0) {
				return true;
			}
		}
		return false;
	}

	private boolean busyLocal(LocalDateTime startDate, LocalDateTime endDate, String nome, String[] nomes, Gravacao g) {
		if (g.getLocal().getNome().equals(nome)) {
			if (sameTime(startDate, endDate, g)) {
				return true;
			}
		}
		return false;
	}

	public void remarca(VetorGenerico<Gravacao> g) {
		int dias = 1;
		boolean remarcada = false;
		for (int i = 0; i < g.size(); i++) {
			int pos = gP.searchIndexOf(g.get(i));
			Gravacao grav = g.get(i);
			gP.removeAt(pos);
			while (!remarcada) {
				boolean can = true;
				for (int j = pos; j < gP.size(); j++) {
					if (this.sameTime(grav.getStartDate().plusDays(dias), grav.getEndDate().plusDays(dias),
							gP.get(j))) {
						can = false;
					}
				}
				if (can) {
					remarcada = true;
				} else {
					dias++;
				}
			}
			grav.setNewDate(grav.getStartDate().plusDays(dias), grav.getEndDate().plusDays(dias));
			gP.insertAt(grav, this.findIndex(grav, gP));
		}
	}

	private boolean sameTime(LocalDateTime startDate, LocalDateTime endDate, Gravacao g) {
		return ((g.getEndDate().isAfter(startDate) || g.getEndDate().isEqual(startDate))
				&& (g.getEndDate().isBefore(endDate) || g.getEndDate().isEqual(endDate)))
				|| ((g.getStartDate().isAfter(startDate) || g.getStartDate().isEqual(startDate))
						&& (g.getStartDate().isBefore(endDate) || g.getStartDate().isEqual(endDate)));
	}

	public boolean minePriority(String nomeProdutor, Gravacao g) {
		Colaborador produtor = staff.get(this.searchIndexColab(nomeProdutor));
		if ((produtor instanceof ProdJun) || (produtor instanceof ProdSen && g.getStaff().get(0) instanceof ProdSen))
			return false;
		return true;
	}

}
