/**
 * 
 * @author Tiago Cotovio - 52349
 * @author Teresa Monteiro - 52597
 *
 */
package logistica;

public class CenarioClass implements Cenario {

	private String nome;
	private int custo;

	/**
	 * Construtor da classe Cenario que permite criar os locais atraves do nome,
	 * custo
	 * 
	 * @param nome
	 *            - colaborador nome
	 * @param custo
	 *            - custo horario
	 */
	public CenarioClass(String nome, int custo) {
		this.nome = nome;
		this.custo = custo;
	}

	public String getNome() {
		return nome;
	}

	public int getCusto() {
		return custo;
	}

	public boolean equals(String nome) {
		return this.nome.equals(nome);
	}
}
