/**
 * 
 * @author Tiago Cotovio - 52349
 * @author Teresa Monteiro - 52597
 *
 */
package logistica;

public interface Cenario {

	/**
	 * Metodo que retorna o custo horario do local
	 * 
	 * @return custo
	 */

	int getCusto();

	/**
	 * Metodo que retorna o nome do local
	 * 
	 * @return nome
	 */

	String getNome();

	/**
	 * Metodo que verifica se existe um local de nome igual
	 * 
	 * @param nome
	 * @return se o <code>nome</code> for igual ao nome de outro local ja registado
	 */

	boolean equals(String nome);
}
