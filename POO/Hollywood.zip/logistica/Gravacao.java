/**
 * 
 * @author Tiago Cotovio - 52349
 * @author Teresa Monteiro - 52597
 *
 */
package logistica;

import java.time.LocalDateTime;

import colaboradores.Colaborador;
import vetores.VetorGenerico;

public interface Gravacao {
	static final int POSICAO_PRODUTOR = 0;
	static final int POSICAO_REALIZADOR = 1;
	static final int POSICAO_TECNICO = 2;

	/**
	 * Metodo que permite obter o local onde se realiza a gravacao do tipo cenario
	 * 
	 * @return local
	 */
	Cenario getLocal();

	/**
	 * 
	 * @return a data de inicio da gravacao
	 */
	LocalDateTime getStartDate();

	/**
	 * 
	 * @return a data final da gravacao
	 */
	LocalDateTime getEndDate();

	/**
	 * 
	 * @returno vetor de colaboradores envolvidos na gravacao
	 */
	VetorGenerico<Colaborador> getStaff();

	/**
	 * Metodo que adiciona colaboradores
	 * 
	 * @param c
	 */
	void addColaborador(Colaborador c);

	/**
	 * Metodo que adiciona os tres elementos mais importantes da gravacao nas tres
	 * primeiras posicoes do vetor do staff dessa gravacao
	 * 
	 * @param p
	 *            - produtor da gravacao
	 * @param r
	 *            - realizador da gravacao
	 * @param t
	 *            - tecnico da gravacao
	 */

	void addVip(Colaborador p, Colaborador r, Colaborador t);

	/**
	 * Metodo que obtem o custo da duracao da gravacao num determinado local
	 * 
	 * @return custo da gravacao num determinado local
	 */
	int getMontante();

	/**
	 * Metodo que acrescenta uma zanga a gravacao e que a torna suspensa, caso nao
	 * houvesse ainda zangas
	 */
	void amua();

	/**
	 * Metodo que permite reconciliar
	 */
	void makePeace();

	/**
	 * 
	 * @return true se a gravacao nao estiver suspensa
	 */
	boolean isOn();

	/**
	 * Metodo que remarca uma gravacao
	 * 
	 * @param start
	 *            - nova data de inicio da gravacao
	 * @param end
	 *            - nova data de fim da gravacao
	 */
	void setNewDate(LocalDateTime start, LocalDateTime end);

	/**
	 * Metodo que retorna a duracao da gravacao
	 * 
	 * @return duracao
	 */
	int getDuracao();
}
