/**
 * 
 * @author Tiago Cotovio - 52349
 * @author Teresa Monteiro - 52597
 *
 */
package logistica;

import java.time.LocalDateTime;

import colaboradores.Colaborador;
import vetores.VetorGenerico;
import vetores.VetorGenericoClass;

public class GravacaoClass implements Gravacao {
	private Cenario local;
	private LocalDateTime start;
	private LocalDateTime end;
	private int duracao;
	private VetorGenerico<Colaborador> staff;
	private boolean isOn;
	private int zangas;

	/**
	 * Construtor da classe gravacao que e definida atraves do local, dia, mes, ano,
	 * horas, minutos, duracao
	 * 
	 * @param local
	 *            onde se realiza a gravacao
	 * @param dia
	 *            onde se realiza a gravacao
	 * @param mes
	 *            onde se realiza a gravacao
	 * @param ano
	 *            onde se realiza a gravacao
	 * @param horas
	 *            onde se realiza a gravacao
	 * @param minutos
	 *            onde se realiza a gravacao
	 * @param duracao
	 *            onde se realiza a gravacao
	 */
	public GravacaoClass(Cenario local, LocalDateTime date, int duracao) {
		this.local = local;
		start = date;
		end = start.plusMinutes(duracao);
		staff = new VetorGenericoClass<Colaborador>();
		this.duracao = duracao;
		isOn = true;
		zangas = 0;
	}

	public void addVip(Colaborador p, Colaborador r, Colaborador t) {
		staff.insertAt(p, POSICAO_PRODUTOR);
		staff.insertAt(r, POSICAO_REALIZADOR);
		staff.insertAt(t, POSICAO_TECNICO);
	}

	public Cenario getLocal() {
		return local;
	}

	public LocalDateTime getStartDate() {
		return start;
	}

	public LocalDateTime getEndDate() {
		return end;
	}

	public VetorGenerico<Colaborador> getStaff() {
		return staff;
	}

	public void addColaborador(Colaborador c) {
		staff.insertLast(c);
	}

	public int getMontante() {
		int result = 0;
		int horas;
		if (duracao % 60 == 0)
			horas = duracao / 60;
		else
			horas = (int) (duracao / 60) + 1;
		for (int i = 0; i < staff.size(); i++) {
			result += staff.get(i).getCusto() * horas;
		}
		result += this.getLocal().getCusto() * horas;
		return result;
	}

	public void amua() {
		isOn = false;
		zangas++;
	}

	public void makePeace() {
		zangas--;
		if (zangas == 0)
			isOn = true;
	}

	public boolean isOn() {
		return isOn;
	}

	public void setNewDate(LocalDateTime start, LocalDateTime end) {
		this.start = start;
		this.end = end;
	}

	public int getDuracao() {
		return duracao;
	}
}
