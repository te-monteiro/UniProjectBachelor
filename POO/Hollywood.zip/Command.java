/**
 * 
 * @author Tiago Cotovio - 52349
 * @author Teresa Monteiro - 52597
 *
 */
public enum Command {

	AJUDA_REGISTA("regista - regista um novo colaborador"), AJUDA_STAFF(
			"staff - lista os colaboradores registados"), AJUDA_CENARIO(
					"cenario - regista um novo local para gravacoes"), AJUDA_CENARIOS(
							"cenarios - lista os locais para gravacoes registados"), AJUDA_MARCA(
									"marca - marca uma nova gravacao"), AJUDA_AMUA(
											"amua - vedeta deixa de trabalhar com colaborador"), AJUDA_RECONCILIA(
													"reconcilia - vedeta faz as pazes com colaborador"), AJUDA_REALIZADAS(
															"realizadas - lista as gravacoes realizadas"), AJUDA_PREVISTAS(
																	"previstas - lista as gravacoes previstas"), AJUDA_LOCAL(
																			"local - lista as gravacoes previstas para um local"), AJUDA_COLABORADOR(
																					"colaborador - lista as gravacoes previstas para um colaborador"), AJUDA_GRAVA(
																							"grava - executa a proxima gravacao agendada"), AJUDA_AMUANCOS(
																									"amuancos - lista os colaboradores com quem uma vedeta esta amuada"), AJUDA_AJUDA(
																											"ajuda - Mostra a ajuda"), AJUDA_SAI(
																													"sai - Termina a execucao do programa");

	private String description;

	private Command(String description) {
		this.description = description;
	}

	public String toString() {
		return description;
	}
}
