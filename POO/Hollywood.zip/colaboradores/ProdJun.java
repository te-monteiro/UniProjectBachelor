/**
 * 
 * @author Tiago Cotovio - 52349
 * @author Teresa Monteiro - 52597
 *
 */
package colaboradores;

public interface ProdJun extends Colaborador {
	static final String TIPO = "produtor junior";
}
