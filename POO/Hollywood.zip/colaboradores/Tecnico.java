/**
 * 
 * @author Tiago Cotovio - 52349
 * @author Teresa Monteiro - 52597
 *
 */
package colaboradores;

public interface Tecnico extends Colaborador {
	static final String TIPO = "tecnico";

}
