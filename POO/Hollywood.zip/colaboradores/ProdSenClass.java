/**
 * 
 * @author Tiago Cotovio - 52349
 * @author Teresa Monteiro - 52597
 *
 */
package colaboradores;

public class ProdSenClass extends ColaboradorClass implements ProdSen {

	public ProdSenClass(String nome, int custo) {
		super(nome, custo, TIPO);
	}

}
