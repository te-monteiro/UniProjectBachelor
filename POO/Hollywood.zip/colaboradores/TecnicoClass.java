/**
 * 
 * @author Tiago Cotovio - 52349
 * @author Teresa Monteiro - 52597
 *
 */
package colaboradores;

public class TecnicoClass extends ColaboradorClass implements Tecnico {

	public TecnicoClass(String nome, int custo) {
		super(nome, custo, TIPO);
	}

}
