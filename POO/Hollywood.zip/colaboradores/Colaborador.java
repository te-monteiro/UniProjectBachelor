/**
 * 
 * @author Tiago Cotovio - 52349
 * @author Teresa Monteiro - 52597
 *
 */
package colaboradores;

public interface Colaborador {
	/**
	 * Metodo que retorna o custo horario do colaborador
	 * 
	 * @return custo
	 */

	int getCusto();

	/**
	 * Metodo que retorna o nome do colaborador
	 * 
	 * @return nome
	 */
	String getNome();

	/**
	 * Metodo que retorna o tipo de colaborador
	 * 
	 * @return tipo
	 */
	String getTipo();

	/**
	 * Metodo que verifica se existe um nome de colaborador igual
	 * 
	 * @param nome
	 * @return true se o <code>nome</nome> for igual ao nome de outro colaborador ja
	 *         registado
	 */
	boolean equals(String nome);

	/**
	 * Metodo que retorna a notoriedade ou do realizador ou do actor
	 * 
	 * @return notoriedade
	 */
	String getNotoriedade();
}
