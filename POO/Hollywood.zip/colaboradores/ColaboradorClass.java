/**
 * 
 * @author Tiago Cotovio - 52349
 * @author Teresa Monteiro - 52597
 *
 */
package colaboradores;

import vedeta.Vedeta;

public abstract class ColaboradorClass implements Colaborador {

	private String tipo;
	private String nome;
	private int custo;

	/**
	 * Construtor da classe Colaborador que permite criar colaboradores atraves do
	 * nome, custo e tipo
	 * 
	 * @param nome
	 *            - colaborador nome
	 * @param custo
	 *            - custo horario
	 * @param tipo
	 *            - tipo de colaborador
	 */
	public ColaboradorClass(String nome, int custo, String tipo) {
		this.nome = nome;
		this.custo = custo;
		this.tipo = tipo;

	}

	public String getNome() {
		return nome;
	}

	public int getCusto() {
		return custo;
	}

	public boolean equals(String nome) {
		return this.nome.equals(nome);
	}

	public String getTipo() {
		return tipo;
	}

	public String getNotoriedade() {
		if (this instanceof Vedeta) {
			return "vedeta";
		} else {
			return "normal";
		}
	}

}
