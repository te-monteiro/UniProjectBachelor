/**
 * 
 * @author Tiago Cotovio - 52349
 * @author Teresa Monteiro - 52597
 *
 */
package colaboradores;

public class ProdJunClass extends ColaboradorClass implements ProdJun {

	public ProdJunClass(String nome, int custo) {
		super(nome, custo, TIPO);
	}

}
