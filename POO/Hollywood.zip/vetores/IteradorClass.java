/**
 * 
 * @author Tiago Cotovio - 52349
 * @author Teresa Monteiro - 52597
 *
 */
package vetores;

public class IteradorClass<E> implements Iterador<E> {

	private E[] elems;
	private int counter, current;

	public IteradorClass(E[] elems, int counter) {
		this.elems = elems;
		this.counter = counter;
		init();
	}

	@Override
	public void init() {
		current = 0;
	}

	@Override
	public boolean hasNext() {
		return current < counter;
	}

	@Override
	public E next() {
		return elems[current++];
	}

	public boolean isEmpty() {
		return counter == 0;
	}

}
