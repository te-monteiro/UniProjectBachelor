
/**
 * 
 * @author Tiago Cotovio - 52349
 * @author Teresa Monteiro - 52597
 *
 */
import java.time.LocalDateTime;
import java.util.Scanner;

import colaboradores.Colaborador;
import logistica.Cenario;
import logistica.Gravacao;
import logistica.Logistica;
import logistica.LogisticaClass;
import vetores.Iterador;

public class Main {

	private static final String FORMAT_COLAB_INFO = "%s %s %d\n";
	private static final String PROMPT = "> ";
	private static final String SUSPENSA = " Suspensa!\n";
	private static final String GRAVACAO_PRIORITARIA_AGENDADA = "Gravacao prioritaria agendada provocou mudancas noutra(s) gravacao(oes).";
	private static final String CONFLITO_DE_DATAS = "Gravacao nao agendada por conflito de datas.";
	private static final String GRAVACAO_PENDENTE_DE_UMA_BIRRA = "Gravacao pendente de uma birra.";
	private static final String TECNICO_DESCONHECIDO = "Tecnico desconhecido.";
	private static final String REALIZADOR_DESCONHECIDO = "Realizador desconhecido.";
	private static final String PRODUTOR_DESCONHECIDO = "Produtor desconhecido.";
	private static final String DURACAO_INVALIDA = "Duracao invalida.";
	private static final String DATA_DE_GRAVACAO_INVALIDA = "Data de gravacao invalida.";
	private static final String CANCELADA = " Cancelada!\n";
	private static final String LOCAL_DESCONHECIDO = "Local desconhecido.";
	private static final String NENHUMA_GRAVACAO_PREVISTA_EM = "Nenhuma gravacao prevista em %s.\n";
	private static final String COLABORADOR_DESCONHECIDO = "Colaborador desconhecido.";
	private static final String NENHUMA_GRAVACAO_PREVISTA_COM = "Nenhuma gravacao prevista com %s.\n";
	private static final String FORMAT_STAFF_REDUCED = "%s; %s.\n";
	private static final String ADICIONADO_LISTA_NEGRA = "%s colocou %s na sua lista negra, suspendendo %d gravacoes.\n";
	private static final String FALTA_DE_PACIENCIA = "Que falta de paciencia para divas...";
	private static final String NAO_E_COLABORADOR = "%s nao e um colaborador.\n";
	private static final String NAO_EXISTE_ZANGA = "Nao existe zanga com %s.\n";
	private static final String NAO_E_VEDETA = "%s nao e uma vedeta.\n";
	private static final String GRAVACAO_AGENDADA_COM_SUCESSO = "Gravacao agendada com sucesso!";
	private static final String EUROS_ORCAMENTADOS = " euros orcamentados.";
	private static final String NENHUMA_GRAVACAO_PREVISTA = "Nenhuma gravacao prevista.";
	private static final String FORMAT_LOCAL = "%s %d.\n";
	private static final String NAO_EXISTEM_LOCALIZACOES_REGISTADAS = "Nao existem localizacoes registadas.";
	private static final String FORMAT_NOTORIED_STAFF = "%s %s %s %d\n";
	private static final String NAO_EXISTEM_COLABORADORES_REGISTADOS = "Nao existem colaboradores registados.";
	private static final String LOCALIZACAO_JA_REGISTADA = "Localizacao ja tinha sido registada.";
	private static final String CUSTO_LOCAL_INSUF = "Acha que eles nos pagam para gravar la?";
	private static final String CENARIO_REGISTADO = "Cenario registado.";
	private static final String NOMES_IGUAIS = "Ja existe um colaborador com o mesmo nome.";
	private static final String TIPO_DESCONHECIDO = "Tipo de colaborador desconhecido.";
	private static final String TECNICO = "tecnico";
	private static final String JUNIOR = "junior";
	private static final String SENIOR = "senior";
	private static final String REALIZADOR = "realizador";
	private static final String ACTOR = "actor";
	private static final String NORMAL = "normal";
	private static final String VEDETA = "vedeta";
	private static final String NOTORIEDADE_INVALIDA = "Notoriedade invalida.";
	private static final String CUSTO_INSUF = "Acha mesmo que este colaborador vai pagar para trabalhar?";
	private static final String REGISTO_SUCESSO = "Colaborador registado com sucesso!";
	private static final String NENHUMA_GRAVACAO_AGENDADA = "Nenhuma gravacao agendada.";
	private static final String NENHUMA_GRAVACAO_REALIZADA = "Nenhuma gravacao realizada.";
	private static final String EUROS_GASTOS = " euros gastos.";
	private static final String GRAVADA = " Gravada!\n";
	private static final String FORMAT_STAFF = "%s; %s; %s.";
	private static final String FORMAT_DATE = "%d %d %d; ";

	private static final String SAI = "SAI";
	private static final String AJUDA = "AJUDA";
	private static final String REGISTA = "REGISTA";
	private static final String STAFF = "STAFF";
	private static final String CENARIO = "CENARIO";
	private static final String CENARIOS = "CENARIOS";
	private static final String MARCA = "MARCA";
	private static final String AMUA = "AMUA";
	private static final String RECONCILIA = "RECONCILIA";
	private static final String REALIZADAS = "REALIZADAS";
	private static final String PREVISTAS = "PREVISTAS";
	private static final String LOCAL = "LOCAL";
	private static final String COLABORADOR = "COLABORADOR";
	private static final String GRAVA = "GRAVA";
	private static final String AMUANCOS = "AMUANCOS";
	/**
	 * Mensagens de despedida
	 */
	private static final String ADEUS = "Ate a proxima";

	/**
	 * Mensagens de erro
	 */
	private static final String ERRO = "Opcao inexistente.";

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);

		Logistica l = new LogisticaClass();

		String comm = getCommand(in);

		while (!comm.equals(SAI)) {
			switch (comm) {
			case AJUDA:
				getAjuda();
				break;
			case REGISTA:
				regista(in, l);
				break;
			case STAFF:
				listStaff(l);
				break;
			case CENARIO:
				addLocal(in, l);
				break;
			case CENARIOS:
				listCenas(l);
				break;
			case MARCA:
				marca(in, l);
				break;
			case AMUA:
				amua(in, l);
				break;
			case RECONCILIA:
				reconcilia(in, l);
				break;
			case REALIZADAS:
				listRealizadas(l);
				break;
			case PREVISTAS:
				listPrevistas(l);
				break;
			case LOCAL:
				listLocal(in, l);
				break;
			case COLABORADOR:
				listColab(in, l);
				break;
			case GRAVA:
				grava(l);
				break;
			case AMUANCOS:
				listAmuancos(in, l);
				break;
			default:
				System.out.println(ERRO);
			}

			comm = getCommand(in);
		}
		System.out.println(ADEUS);
		in.close();
	}

	private static void listAmuancos(Scanner in, Logistica l) {
		String nomeVedeta = in.nextLine();
		if (!l.isVedeta(nomeVedeta)) {
			System.out.printf("Mas quem e %s?\n", nomeVedeta);
		} else {
			Iterador<Colaborador> it = l.iteradorListaNegra(nomeVedeta);
			while (it.hasNext()) {
				Colaborador c = it.next();
				System.out.println(c.getNome());
			}
		}
	}

	/**
	 * Metodo que permite que a vedeta reconcilie com o colaborador, podendo voltar
	 * a trabalhar com o mesmo
	 * 
	 * @param in
	 *            - Scanner
	 * @param l
	 *            - Objecto da classe Logistica
	 */
	private static void reconcilia(Scanner in, Logistica l) {
		String nomeVedeta = in.nextLine();
		String nomeColab = in.nextLine();
		if (!l.isVedeta(nomeVedeta))
			System.out.printf(NAO_E_VEDETA, nomeVedeta);
		else if (l.searchIndexColab(nomeColab) < 0 || !l.alreadyMad(nomeVedeta, nomeColab))
			System.out.printf(NAO_EXISTE_ZANGA, nomeColab);
		else {
			int vezes = l.reconcilia(nomeVedeta, nomeColab);
			System.out.printf("%s <3 %s. %d gravacoes salvas!\n", nomeVedeta, nomeColab, vezes);
		}
	}

	/**
	 * Metodo que permite que a vedeta deixe de trabalhar com um colaborador
	 * 
	 * @param in
	 *            - Scanner
	 * @param l
	 *            - Objecto da classe logistica
	 */
	private static void amua(Scanner in, Logistica l) {
		String nomeVedeta = in.nextLine();
		String nomeColab = in.nextLine();
		if (!l.isVedeta(nomeVedeta))
			System.out.printf(NAO_E_VEDETA, nomeVedeta);
		else if (l.searchIndexColab(nomeColab) < 0)
			System.out.printf(NAO_E_COLABORADOR, nomeColab);
		else if (l.alreadyMad(nomeVedeta, nomeColab))
			System.out.println(FALTA_DE_PACIENCIA);
		else {
			int vezes = l.suspende(nomeVedeta, nomeColab);
			System.out.printf(ADICIONADO_LISTA_NEGRA, nomeVedeta, nomeColab, vezes);
		}
	}

	/**
	 * Metodo que lista todos os colaboradores
	 * 
	 * @param in
	 *            -Scanner
	 * @param l
	 *            - Objecto da classe Logistica
	 */
	private static void listColab(Scanner in, Logistica l) {
		String nomeColab = in.nextLine();
		Iterador<Gravacao> it = l.iteradorPrevistas();
		if (l.searchIndexColab(nomeColab) >= 0) {
			if (l.getMontanteColab(nomeColab) > 0 && !it.isEmpty()) {
				while (it.hasNext()) {
					Gravacao g = it.next();
					if (l.isRecording(g, nomeColab)) {
						System.out.printf(FORMAT_DATE + FORMAT_STAFF_REDUCED, g.getStartDate().getYear(),
								g.getStartDate().getMonthValue(), g.getStartDate().getDayOfMonth(),
								g.getStaff().get(0).getNome(), g.getStaff().get(1).getNome());
					}
				}
				System.out.println(l.getMontanteColab(nomeColab) + EUROS_ORCAMENTADOS);
			} else {
				System.out.printf(NENHUMA_GRAVACAO_PREVISTA_COM, nomeColab);
			}
		} else {
			System.out.println(COLABORADOR_DESCONHECIDO);
		}
	}

	/**
	 * Metodo que lista todos os cenarios
	 * 
	 * @param in
	 *            - Scanner
	 * @param l
	 *            - Objecto da classe Logistica
	 */
	private static void listLocal(Scanner in, Logistica l) {
		String nomeLocal = in.nextLine();
		Iterador<Gravacao> it = l.iteradorPrevistas();
		if (l.searchIndexLocal(nomeLocal) >= 0) {
			if (l.getMontanteLocal(nomeLocal) > 0 && !it.isEmpty()) {
				while (it.hasNext()) {
					Gravacao g = it.next();
					if (g.getLocal().getNome().equals(nomeLocal)) {
						System.out.printf(FORMAT_DATE + FORMAT_STAFF_REDUCED, g.getStartDate().getYear(),
								g.getStartDate().getMonthValue(), g.getStartDate().getDayOfMonth(),
								g.getStaff().get(0).getNome(), g.getStaff().get(1).getNome());
					}
				}
				System.out.println(l.getMontanteLocal(nomeLocal) + EUROS_ORCAMENTADOS);
			} else {
				System.out.printf(NENHUMA_GRAVACAO_PREVISTA_EM, nomeLocal);
			}
		} else {
			System.out.println(LOCAL_DESCONHECIDO);
		}
	}

	/**
	 * Metodo que lista as gravacoes realizadas
	 * 
	 * @param l
	 *            -Objecto da classe Logistica
	 */
	private static void listRealizadas(Logistica l) {
		Iterador<Gravacao> it = l.iteradorRealizadas();
		if (!it.isEmpty()) {
			while (it.hasNext()) {
				Gravacao g = it.next();
				if (g.isOn()) {
					System.out.printf(FORMAT_DATE + FORMAT_STAFF + "\n", g.getStartDate().getYear(),
							g.getStartDate().getMonthValue(), g.getStartDate().getDayOfMonth(), g.getLocal().getNome(),
							g.getStaff().get(0).getNome(), g.getStaff().get(1).getNome());
				} else {
					System.out.printf(FORMAT_DATE + FORMAT_STAFF + CANCELADA, g.getStartDate().getYear(),
							g.getStartDate().getMonthValue(), g.getStartDate().getDayOfMonth(), g.getLocal().getNome(),
							g.getStaff().get(0).getNome(), g.getStaff().get(1).getNome());
				}
			}
			System.out.println(l.getGastos() + EUROS_GASTOS);
		} else {
			System.out.println(NENHUMA_GRAVACAO_REALIZADA);
		}
	}

	/**
	 * Metodo que executa a proxima gravacao agendada
	 * 
	 * @param l
	 *            - objecto da classe Logistica
	 */
	private static void grava(Logistica l) {
		Iterador<Gravacao> it = l.iteradorPrevistas();
		if (!it.isEmpty()) {
			Gravacao g = it.next();
			l.grava();
			if (g.isOn()) {
				System.out.printf(FORMAT_DATE + FORMAT_STAFF + GRAVADA, g.getStartDate().getYear(),
						g.getStartDate().getMonthValue(), g.getStartDate().getDayOfMonth(), g.getLocal().getNome(),
						g.getStaff().get(0).getNome(), g.getStaff().get(1).getNome());
			} else {
				System.out.printf(FORMAT_DATE + FORMAT_STAFF + CANCELADA, g.getStartDate().getYear(),
						g.getStartDate().getMonthValue(), g.getStartDate().getDayOfMonth(), g.getLocal().getNome(),
						g.getStaff().get(0).getNome(), g.getStaff().get(1).getNome());
			}
		} else {
			System.out.println(NENHUMA_GRAVACAO_AGENDADA);
		}
	}

	/**
	 * Metodo que marca uma nova gravacao
	 * 
	 * @param in
	 *            - Scanner
	 * @param l
	 *            - Objecto da classe Logistica
	 */
	private static void marca(Scanner in, Logistica l) {
		String local = in.nextLine();
		int ano = in.nextInt();
		int mes = in.nextInt();
		int dia = in.nextInt();
		int horas = in.nextInt();
		int minutos = in.nextInt();
		int duracao = in.nextInt();
		in.nextLine();
		LocalDateTime startDate = LocalDateTime.of(ano, mes, dia, horas, minutos);
		LocalDateTime endDate = startDate.plusMinutes(duracao);
		String[] vip = new String[3];
		for (int i = 0; i < 3; i++) {
			vip[i] = in.nextLine();
		}
		int nColaboradores = in.nextInt();
		in.nextLine();
		String[] nomes = new String[nColaboradores];
		for (int i = 0; i < nColaboradores; i++) {
			nomes[i] = in.nextLine().trim();
		}
		if (l.searchIndexLocal(local) < 0)
			System.out.println(LOCAL_DESCONHECIDO);
		else if (!l.isDataValid(startDate))
			System.out.println(DATA_DE_GRAVACAO_INVALIDA);
		else if (duracao <= 0)
			System.out.println(DURACAO_INVALIDA);
		else if (!l.isProducer(vip[0]))
			System.out.println(PRODUTOR_DESCONHECIDO);
		else if (!l.isDirector(vip[1]))
			System.out.println(REALIZADOR_DESCONHECIDO);
		else if (!l.isTecnico(vip[2]))
			System.out.println(TECNICO_DESCONHECIDO);
		else if (!l.validColabs(nomes))
			System.out.println(COLABORADOR_DESCONHECIDO);
		else if (l.isSomeoneMad(vip, nomes) > 0) {
			System.out.println(GRAVACAO_PENDENTE_DE_UMA_BIRRA);
			l.marca(local, startDate, duracao, vip, nColaboradores, nomes, l.isSomeoneMad(vip, nomes));
		} else if (l.isBusyWithoutPriority(startDate, endDate, local, vip, nomes)) {
			System.out.println(CONFLITO_DE_DATAS);
		} else if (l.isBusyWithPriority(startDate, endDate, local, vip, nomes)) {
			l.marca(local, startDate, duracao, vip, nColaboradores, nomes, 0);
			System.out.println(GRAVACAO_PRIORITARIA_AGENDADA);
		} else {
			l.marca(local, startDate, duracao, vip, nColaboradores, nomes, 0);
			System.out.println(GRAVACAO_AGENDADA_COM_SUCESSO);
		}
	}

	/**
	 * Metodo que lista as gravacoes previstas
	 * 
	 * @param l
	 *            - objecto da classe Logistica
	 */
	private static void listPrevistas(Logistica l) {
		Iterador<Gravacao> it = l.iteradorPrevistas();
		if (!it.isEmpty()) {
			while (it.hasNext()) {
				Gravacao g = it.next();
				if (g.isOn()) {
					System.out.printf(FORMAT_DATE + FORMAT_STAFF + "\n", g.getStartDate().getYear(),
							g.getStartDate().getMonthValue(), g.getStartDate().getDayOfMonth(), g.getLocal().getNome(),
							g.getStaff().get(0).getNome(), g.getStaff().get(1).getNome());
				} else {
					System.out.printf(FORMAT_DATE + FORMAT_STAFF + SUSPENSA, g.getStartDate().getYear(),
							g.getStartDate().getMonthValue(), g.getStartDate().getDayOfMonth(), g.getLocal().getNome(),
							g.getStaff().get(0).getNome(), g.getStaff().get(1).getNome());
				}
			}
			System.out.println(l.getMontante() + EUROS_ORCAMENTADOS);
		} else {
			System.out.println(NENHUMA_GRAVACAO_PREVISTA);
		}
	}

	/**
	 * Metodo que regista um novo cenario para gravacoes
	 * 
	 * @param l
	 *            - objecto da classe Logistica
	 */
	private static void listCenas(Logistica l) {
		Iterador<Cenario> it = l.iteradorLocais();
		if (!it.isEmpty()) {
			while (it.hasNext()) {
				Cenario cenas = it.next();
				System.out.printf(FORMAT_LOCAL, cenas.getNome(), cenas.getCusto());
			}
		} else {
			System.out.println(NAO_EXISTEM_LOCALIZACOES_REGISTADAS);
		}
	}

	/**
	 * Metodos que lista os elementos do staff registados
	 * 
	 * @param l
	 *            - objecto da classe Logistica
	 */
	private static void listStaff(Logistica l) {
		Iterador<Colaborador> it = l.iteradorColab();
		if (!it.isEmpty()) {
			while (it.hasNext()) {
				Colaborador c = it.next();
				if (c.getTipo().equals(ACTOR) || c.getTipo().equals(REALIZADOR))
					System.out.printf(FORMAT_NOTORIED_STAFF, c.getTipo(), c.getNotoriedade(), c.getNome(),
							c.getCusto());
				else
					System.out.printf(FORMAT_COLAB_INFO, c.getTipo(), c.getNome(), c.getCusto());
			}
		} else {
			System.out.println(NAO_EXISTEM_COLABORADORES_REGISTADOS);
		}
	}

	/**
	 * Metodo que permite adicionar local
	 * 
	 * @param in
	 *            - Scanner
	 * @param l
	 *            - objecto da classe Logistica
	 */
	private static void addLocal(Scanner in, Logistica l) {
		String local = in.nextLine().trim();
		int custo = in.nextInt();
		in.nextLine();
		if (l.searchIndexLocal(local) >= 0)
			System.out.println(LOCALIZACAO_JA_REGISTADA);
		else if (custo < 0)
			System.out.println(CUSTO_LOCAL_INSUF);
		else {
			l.addLocal(local, custo);
			System.out.println(CENARIO_REGISTADO);
		}
	}

	/**
	 * Metodo que regista um novo colaborador
	 * 
	 * @param in
	 *            - Scanner
	 * @param l
	 *            - objecto da classe Logistica
	 */
	private static void regista(Scanner in, Logistica l) {
		String tipo = in.next().toLowerCase();
		String notoriedade;
		if (tipo.equals(REALIZADOR) || tipo.equals(ACTOR)) {
			notoriedade = in.next().toLowerCase();
		} else {
			notoriedade = "";
		}
		int custo = in.nextInt();
		String nome = in.nextLine().trim();
		if (l.searchIndexColab(nome) >= 0)
			System.out.println(NOMES_IGUAIS);
		else if (!tipo.equals(REALIZADOR) && !tipo.equals(ACTOR) && !tipo.equals(SENIOR) && !tipo.equals(JUNIOR)
				&& !tipo.equals(TECNICO))
			System.out.println(TIPO_DESCONHECIDO);
		else if ((tipo.equals(ACTOR) || tipo.equals(REALIZADOR))
				&& (!notoriedade.equals(NORMAL) && !notoriedade.equals(VEDETA)))
			System.out.println(NOTORIEDADE_INVALIDA);
		else if (custo < 0)
			System.out.println(CUSTO_INSUF);
		else {
			l.addColab(tipo, notoriedade, custo, nome);
			System.out.println(REGISTO_SUCESSO);
		}
	}

	/**
	 * Metodo que representa as funcionalidades de cada comando
	 */
	private static void getAjuda() {
		for (Command c : Command.values())
			System.out.println(c);
	}

	/**
	 * Metodo para obter o comando do scanner
	 * 
	 * @param in
	 *            - Scanner
	 * @return input
	 */
	private static String getCommand(Scanner in) {
		System.out.print(PROMPT);
		return in.nextLine().toUpperCase();
	}
}
