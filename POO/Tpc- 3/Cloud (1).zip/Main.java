
/**
 * 
 */
import java.util.Scanner;

import Cloud.*;

/**
 * @author Goncalo Mateus / Teresa Monteiro
 *
 */

public class Main {

	// Constantes que definem os comandos
	public static final String ADD = "ADD";
	public static final String UPLOAD = "UPLOAD";
	public static final String SHARE = "SHARE";
	public static final String MINSPACE = "MINSPACE";
	public static final String LISTFILES = "LISTFILES";
	public static final String LISTALL = "LISTALL";
	public static final String SAIR = "SAIR";

	// Constantes que definem as mensagens
	public static final String ERROR_MESSAGE = "ERRO";
	public static final String EXIT_MESSAGE = "Exiting...";
	public static final String ADDED_ACCOUNT = "Account was added.";
	public static final String ACCOUNT_ALREADY_EXISTS = "Account already exists.";
	public static final String ACCOUNT_DOES_NOT_EXISTS = "Account does not exist.";
	public static final String FILE_ALREADY_EXISTS = "File already exists in the account.";
	public static final String FILE_EXCEEDS_CAPACITY = "File size exceeds account capacity.";
	public static final String FILE_UPLOADED = "File uploaded into account.";
	public static final String ACCOUNT_FILES = "Account ﬁles:";

	
	
	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		Dropbox d = new Dropbox();
		String comm = getCommand(in);

		while (!comm.equals(SAIR)) {
			switch (comm) {
			case ADD:
				addAccount(in, d);
				break;
			case UPLOAD:
				addFile(in, d);
				break;
			case SHARE:
				share(in, d);
				break;
			case MINSPACE:
				minspace(d);
				break;
			case LISTFILES:
				listFiles(in, d);
				break;
			case LISTALL:
				listAllAccounts(d);
				break;
			default:
				System.out.println(ERROR_MESSAGE);
			}
			comm = getCommand(in);

		}
		System.out.println(EXIT_MESSAGE);
		in.close();

	}

	private static String getCommand(Scanner in) {
		String input;

		input = in.nextLine().toUpperCase();

		return input;
	}

	private static void addAccount(Scanner in, Dropbox d) {
		String name = in.nextLine();
		String type = in.nextLine();

		if (!d.hasAccount(name)) {
			d.addAccount(name, type);
			System.out.println(ADDED_ACCOUNT);
		} else
			System.out.println(ACCOUNT_ALREADY_EXISTS);

	}

	private static void addFile(Scanner in, Dropbox d) {
		String name = in.nextLine();
		String fileName = in.nextLine().toUpperCase();
		int mg = in.nextInt();
		in.nextLine();
		
		if (!d.hasAccount(name)) {
			System.out.println(ACCOUNT_DOES_NOT_EXISTS);
			
		} else if (d.hasFile(name, fileName)) {
			System.out.println(FILE_ALREADY_EXISTS);
			
		} else if (!d.hasSpace(name, mg)) {
			System.out.println(FILE_EXCEEDS_CAPACITY);
			
		} else {
			d.createFile(name, fileName, mg);
			System.out.println(FILE_UPLOADED);
		}
	}
	
	private static void share(Scanner in, Dropbox d) {
		String accountName = in.nextLine();
		String accountSharing=in.nextLine();
		String fileName= in.nextLine();
		
		if (!d.hasAccount(accountName) || !d.hasAccount(accountSharing)) {
			System.out.println(ACCOUNT_DOES_NOT_EXISTS);
		} else if (!d.hasFile(accountName, fileName)) {
			System.out.println("File does not exist.");
		} else if (d.isAccountBasic(accountName)) {
			System.out.println("Account does not allow ﬁle sharing");
		} else if (d.fileShare(accountSharing, fileName)) {
			System.out.println("File already shared.");
		} else if (!d.spaceFile(accountName, accountSharing, fileName)) {
			System.out.println("File size exceeds account capacity.");
		} else {
			d.shareFile(accountName, accountSharing, fileName);
			System.out.println("File was shared.");
		}
		
		
	}

	private static void minspace(Dropbox d) {
		if (!d.hasAccounts()) {
			System.out.println("No accounts.");
		} else {
			System.out.println("Account with least free space: " + d.leastFreeSpace());
		}
	}
	
	private static void listFiles(Scanner in, Dropbox d) {
		String name = in.nextLine();
		
		if(!d.hasAccount(name)) {
			System.out.println(ACCOUNT_DOES_NOT_EXISTS);
		}else {
			System.out.println(ACCOUNT_FILES);
			
		}
	}
	
	private static void listAllAccounts(Dropbox d) {
		System.out.println("All accounts:");
		d.inicializeIterator();
		while(d.hasNext()) {
			Users u = d.next();
			System.out.println(u.getName() + " (" + u.getAccountType() + ")");
		}
	}
	
	
	
	
	
	
	
	
	
	
}
