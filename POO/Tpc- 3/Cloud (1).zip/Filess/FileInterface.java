package Filess;

/**
 * 
 * @author Goncalo Mateus / Teresa Monteiro
 *
 */

public interface FileInterface {

	/**
	 * Devolve o nome de um ficheiro.
	 * @return o nome do ficheiro
	 */
	String getFileName();
	
	/**
	 * Devolve o tamanho de um ficheiro.
	 * @return o tamanho do ficheiro
	 */
	int getFileSize();

	/**
	 * E inicializada caso o ficheiro seja um ficheiro partilhado.
	 */
	void shareFile();
	
	/**
	 * Verifica se o ficheiro e partilhado <code>description</code>
	 * @param description - descricao da accao.
	 * @return devolve <code>true</code> se o ficheiro e partilhado <code>description</code>
	 */
	boolean isFileShared();
	
	void changeFileSize();

	

}
