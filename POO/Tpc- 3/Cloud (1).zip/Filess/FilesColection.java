/**
 * 
 */
package Filess;

/**
 * 
 * @author Goncalo Mateus / Teresa Monteiro
 *
 */

public class FilesColection implements FilesColectionInterface {

	private File[] files;
	private int counter;
	private int currentFile;
	private static final int DEFAULT = 100;
	

	public FilesColection() {
		files = new File[DEFAULT];
		counter = 0;
		currentFile = 0;
	}

	@Override
	public void addFile(String fileName, int mg) {
		files[counter++] = new File(fileName, mg);
	}

	@Override
	public boolean searchFile(String fileName) {
		boolean found = false;
		if (searchIndex(fileName) >= 0) {
			found = true;
		}
		return found;
	}

	@Override
	public int sumSpace() {
		int result = 0;
		for (int i = 0; i < counter; i++) {
			result += files[i].getFileSize();
		}
		return result;

	}

	private int searchIndex(String fileName) {
		int found = -1;
		int i = 0;
		while (i < counter && found == -1) {
			if (files[i].getFileName().equals(fileName))
				found = i;
			i++;
		}
		return found;
	}

	@Override
	public void shareFile(String fileName) {
		files[searchIndex(fileName)].shareFile();

	}

	@Override
	public boolean isFileshared(String fileName) {
		return files[searchIndex(fileName)].isFileShared();

	}

	@Override
	public int fileSize(String fileName) {
		return files[searchIndex(fileName)].getFileSize();
	}

	@Override
	public void changeFilesize(String fileName) {
		files[searchIndex(fileName)].changeFileSize();
	}

	
	@Override
	public void inicializeIterator() {
		currentFile = 0;
	}

	@Override
	public boolean hasNext() {
		return (currentFile >= 0 ) && (currentFile < counter);
	}

	@Override
	public File next() {
		return files[currentFile++];
	}

	
}
