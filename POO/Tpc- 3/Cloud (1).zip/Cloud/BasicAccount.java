package Cloud;

public class BasicAccount extends Users {

	private static final int SIZE = 2048;
	private static final String TYPE = "BASIC";

	public BasicAccount(String name) {
		super(name);
	}

	@Override
	public int getAccountSize() {
		return SIZE;
	}
	
	@Override
	public String getAccountType() {
		return TYPE;
	}

}
