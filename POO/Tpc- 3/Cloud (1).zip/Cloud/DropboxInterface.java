package Cloud;

public interface DropboxInterface {

	void addAccount(String name, String type);
	boolean hasAccount(String name);
	boolean hasFile(String name, String nameFile);
	boolean hasSpace(String name, int mg);
	void createFile(String name, String fileName, int mg);
	boolean isAccountBasic(String name);
	boolean isAccountPremium(String name);
	boolean fileShare(String name, String fileName);
	boolean spaceFile(String name1, String name2, String fileName);
	void shareFile(String accountName, String accountSharing, String fileName);
	boolean hasAccounts();
	String leastFreeSpace();
	void inicializeIterator();
	boolean hasNext();
	Users next();
	


}
