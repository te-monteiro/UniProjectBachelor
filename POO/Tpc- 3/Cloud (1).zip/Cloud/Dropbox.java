package Cloud;

public class Dropbox implements DropboxInterface {

	// Constantes que definem os comandos
	public static final String BASIC = "BASIC";
	private static final int DEFAULT = 100;

	private Users[] user;
	private int counter;
	private int currentUser;
	

	public Dropbox() {
		user = new Users[DEFAULT];
		counter = 0;
		currentUser = 0;
	}

	@Override
	public void addAccount(String name, String type) {
		if (type.equals(BASIC)) {
			Users a = new BasicAccount(name);
			user[counter++] = a;
		} else {
			Users a = new PremiumAccount(name);
			user[counter++] = a;
		}
	}

	@Override
	public boolean hasAccount(String name) {
		return searchIndex(name) >= 0;
	}

	private int searchIndex(String name) {
		int found = -1;
		int i = 0;
		while (i < counter && found == -1) {
			if (user[i].getName().equals(name))
				found = i;
			i++;
		}
		return found;

	}

	@Override
	public boolean hasFile(String name, String fileName) {
		return user[searchIndex(name)].hasFile(fileName);	
	}

	@Override
	public boolean hasSpace(String name, int mg) {
		return user[searchIndex(name)].hasSpace(mg);
	}

	@Override
	public void createFile(String name, String fileName, int mg) {
		user[searchIndex(name)].addFile(fileName, mg);

	}

	@Override
	public boolean isAccountBasic(String name) {
		return (user[searchIndex(name)].getAccountType().equals("BASIC"));
	}

	@Override
	public boolean isAccountPremium(String name) {
		return (user[searchIndex(name)].getAccountType().equals("PREMIUM"));
	}

	@Override
	public boolean fileShare(String name, String fileName) {
		return user[searchIndex(name)].hasShared(fileName);
	}

	@Override
	public boolean spaceFile(String name1, String name2, String fileName) {
		boolean result = false;
		int space = 0;
		if(isAccountPremium(name2)) {
			result = true;
		} else {
			space = user[searchIndex(name1)].fileSize(fileName);
			result = hasSpace(name2, space/2);
		}
		return result;
			
	}

	@Override
	public void shareFile(String accountName, String accountSharing, String fileName) {
		int result = 0;
		user[searchIndex(accountName)].changeFileSize(fileName);
		result = user[searchIndex(accountName)].fileSize(fileName);
		user[searchIndex(accountSharing)].addFile(fileName, result);

	}

	
	@Override
	public boolean hasAccounts() {
		return (counter >= 0);
	}

	@Override
/*	public String leastFreeSpace() {
		String result = "";
		for(int i = 0; i<counter; i++) {
			if (user[i+1].freeSpace() >= user[i].freeSpace()) {
				result = user[i].getName();
			}
		}
		return result;
	}
	*/
	public String leastFreeSpace() {
		String result = "";
		for(int i = 0; i<=counter-1; i++)
			for(int j=i+1; j<=counter-1; j++) {
				if (user[i].freeSpace() <= user[j].freeSpace()) {
					result = user[i].getName();
					i=counter;
				}
			}
			
		return result;
	}

	@Override
	public void inicializeIterator() {
		currentUser = 0;
	}

	@Override
	public boolean hasNext() {
		return (currentUser >= 0 ) && (currentUser < counter);
	}

	@Override
	public Users next() {
		return user[currentUser++];
	}

	

	

}

