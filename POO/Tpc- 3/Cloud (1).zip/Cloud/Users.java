package Cloud;

import Filess.*;

public abstract class Users {

	public abstract int getAccountSize();
	
	public abstract String getAccountType();

	private String name;
	private FilesColection f;

	public Users(String name) {
		this.name = name;
		f = new FilesColection();
	}

	public String getName() {
		return name;
	}

	public void addFile(String fileName, int mg) {
		f.addFile(fileName, mg);
	}

	public boolean hasFile(String fileName) {
		return f.searchFile(fileName);
	}

	public boolean hasSpace(int mg) {
		boolean result = false;
		int sum = 0;

		sum = (f.sumSpace() + (mg));

		if (sum <= getAccountSize()) {
			result = true;
		}
		return result;
	}
	
	public boolean hasShared (String fileName) {
		return f.isFileshared(fileName);
	}
	
	public int fileSize(String fileName) {
		return f.fileSize(fileName);
	}

	public void changeFileSize(String fileName) {
		f.changeFilesize(fileName);
	}

	public int freeSpace() {
		return (getAccountSize() - (f.sumSpace()));
	}



}
