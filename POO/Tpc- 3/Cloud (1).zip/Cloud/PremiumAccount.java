package Cloud;

public class PremiumAccount extends Users {

	private static final int SIZE = 5120;
	private static final String TYPE = "PREMIUM";

	
	public PremiumAccount(String name) {
		super(name);
	}

	@Override
	public int getAccountSize() {
		return SIZE;
	}

	@Override
	public String getAccountType() {
		return TYPE;
	}
	

}
