package Cloud;

import Filess.*;
/**
 * @author Goncalo Mateus, numero-53052 / Teresa Monteiro, numero-52597 
 *
 */
public class Dropbox implements DropboxInterface {

	// Constantes que definem os comandos
	public static final String BASIC = "basic";
	private static final int DEFAULT = 100;

	private Users[] user;
	private int counter;
	private int currentUser;

	public Dropbox() {
		user = new Users[DEFAULT];
		counter = 0;
		currentUser = 0;
	}

	@Override
	public void addAccount(String name, String type) {
		if (type.equals(BASIC)) {
			Users a = new BasicAccount(name);
			user[counter++] = a;
		} else {
			Users a = new PremiumAccount(name);
			user[counter++] = a;
		}
	}

	@Override
	public boolean hasAccount(String name) {
		return searchIndex(name) >= 0;
	}

	private int searchIndex(String name) {
		int found = -1;
		int i = 0;
		while (i < counter && found == -1) {
			if (user[i].getName().equals(name))
				found = i;
			i++;
		}
		return found;

	}

	@Override
	public void createFile(String name, String fileName, int mg, int ocupysize, boolean sharing, String ifisshared) {
		user[searchIndex(name)].addFile(fileName, mg, ocupysize, sharing, ifisshared);

	}

	@Override
	public boolean hasFile(String name, String nameFile) {
		return user[searchIndex(name)].hasFile(nameFile);
	}

	@Override
	public boolean hasSpace(String name, int mg) {
		return user[searchIndex(name)].fileSpace(mg);
	}

	@Override
	public void inicializeIterator() {
		currentUser = 0;
	}

	@Override
	public boolean hasNext() {
		return (currentUser >= 0) && (currentUser < counter);
	}

	@Override
	public Users next() {
		return user[currentUser++];
	}

	@Override
	public boolean isAccountBasic(String name) {
		return (user[searchIndex(name)].getAccountType().equals("Basic"));
	}

	@Override
	public boolean fileShare(String nameaccounttoshare, String fileName, String nameOrigin) {
		return (user[searchIndex(nameaccounttoshare)].isthisfileshared(fileName, nameOrigin));

	}

	@Override
	public boolean canSharethisFile(String nameaccountfile, String nameaccounttoshare, String fileName) {
		boolean result = false;
		int i = 0;
		i = user[searchIndex(nameaccountfile)].getSizeFile(fileName);

		if (isAccountBasic(nameaccounttoshare)) {
			result = hasSpace(nameaccounttoshare, i / 2);
		} else {
			result = true;
		}
		return result;
	}

	@Override
	public void shareFile(String nameaccountfile, String nameaccounttoshare, String fileName) {
		int i = 0;
		user[searchIndex(nameaccountfile)].changeFileSpaceOcupy(fileName);
		i = user[searchIndex(nameaccountfile)].getOriginalFileSize(fileName);
		if (isAccountBasic(nameaccounttoshare)) {
			createFile(nameaccounttoshare, fileName, i, i / 2, true, nameaccountfile);
		} else {
			createFile(nameaccounttoshare, fileName, i, 0, true, nameaccountfile);
		}
	}

	@Override
	public void inicializeFileIterator(String name) {
		user[searchIndex(name)].inicializeiterator();
	}

	@Override
	public boolean fileHasNext(String name) {
		return user[searchIndex(name)].hasNext();
	}

	@Override
	public String listFileInformation(String name) {
		String result = "";
		File f = user[searchIndex(name)].next();
		if (f.isFileShare()) {
			result = " (shared)";
		}
		return f.getFileName() + " (" + f.getFileSize() + " MB)" + result;

	}

	@Override
	public boolean hasRegistedAccounts() {
		return (counter > 0);
	}

	@Override
	public String minSpaceAccount() {
		int minSpace = user[0].freeSpace();
		
		String accountName = user[0].getName();
		
		for(int i = 1; i<counter;i++)
			if(user[i].freeSpace() < minSpace) {
				minSpace = user[i].freeSpace();
				accountName = user[i].getName();
			}
		
		return accountName;
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
