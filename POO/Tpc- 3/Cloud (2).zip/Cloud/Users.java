package Cloud;

import Filess.*;
/**
 * @author Goncalo Mateus, numero-53052 / Teresa Monteiro, numero-52597 
 *
 */
public abstract class Users {

	public abstract int getAccountSize();

	public abstract String getAccountType();

	private String name;
	private File[] files;
	private static final int DEFAULT = 100;
	private int counter;
	private int currentFile;

	public Users(String name) {
		this.name = name;
		files = new File[DEFAULT];
		counter = 0;
		currentFile = 0;
	}

	public String getName() {
		return name;
	}

	public void addFile(String fileName, int mg, int ocupysize,boolean sharing, String nameOrigin) {
		files[counter++] = new File(fileName, mg, ocupysize, sharing, nameOrigin);
	}
	
	public int searchFile(String fileName) {
		int found = -1;
		int i = 0;
		while (i < counter && found == -1) {
			if (files[i].getFileName().equals(fileName))
				found = i;
			i++;
		}
		return found;
	}
	
	public int getSizeFile(String fileName) {
		return files[searchFile(fileName)].getSpaceOcupy();
	}
	public int getOriginalFileSize(String fileName) {
		return files[searchFile(fileName)].getFileSize();
	}
	
	public boolean hasFile(String name) {
		return searchFile(name) >= 0;
	}
	
	public int freeSpace() {
		int result = 0;
		for (int i = 0; i < counter; i++) {
			result = result + files[i].getSpaceOcupy();
		}
		
		return (getAccountSize() - result);
	}
	
	public boolean fileSpace(int mg) {
		boolean result = false;
		if ((freeSpace() - mg) >= 0)
			result= true;
		return result;
	}
	
	public boolean isFileShared(String fileName) {
		return (files[searchFile(fileName)].isFileShare());
	}

	public boolean isthisfileshared(String fileName, String nameOrigin) {
		boolean result = false;
		if (hasFile(fileName)) {
			if (isFileShared(fileName)) {
				if(files[searchFile(fileName)].nameOrigin().equals(nameOrigin)) {
					result = true;
				}
			}
		}
		return result;
	}
	
	public void changeFileSpaceOcupy (String fileName) {
		files[searchFile(fileName)].changeSpaceOcupy();
	}
	
	
	public void inicializeiterator() {
		currentFile = 0;
	}
	public boolean hasNext() {
		return (currentFile >= 0) && (currentFile < counter);
	}
		
	public File next() {
		return files[currentFile++];
	}


}
