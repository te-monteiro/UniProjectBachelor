package Filess;

/**
 * @author Goncalo Mateus, numero-53052 / Teresa Monteiro, numero-52597 
 *
 */

public interface FileInterface {

	String getFileName();
	int getFileSize();
	int getSpaceOcupy();
	void changeSpaceOcupy();
	boolean isFileShare();
	String nameOrigin();


}
