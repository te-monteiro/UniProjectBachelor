/**
 * 
 */
package Filess;

/**
 * @author Goncalo Mateus, numero-53052 / Teresa Monteiro, numero-52597 
 *
 */

public class File implements FileInterface {

	private String fileName;
	private int mg;
	private int ocupysize;
	private boolean share;
	private String nameOrigin;

	public File(String fileName, int mg, int ocupysize, boolean share, String nameOrigin) {
		this.fileName = fileName;
		this.mg = mg;
		this.ocupysize = ocupysize;
		this.share = share;
		this.nameOrigin=nameOrigin;
	}

	@Override
	public String getFileName() {
		return fileName;
	}

	@Override
	public int getFileSize() {
		return mg;
	}

	@Override
	public int getSpaceOcupy() {
		return ocupysize;
	}

	@Override
	public void changeSpaceOcupy() {
		ocupysize = (ocupysize/2);
	}


	@Override
	public boolean isFileShare() {
		return share;
	}

	@Override
	public String nameOrigin() {
		return nameOrigin;
	}
	
	

}
