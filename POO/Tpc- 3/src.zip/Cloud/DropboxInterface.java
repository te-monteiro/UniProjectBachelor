package Cloud;
/**
 * @author Goncalo Mateus, numero-53052 / Teresa Monteiro, numero-52597 
 *
 */
public interface DropboxInterface {

	void addAccount(String name, String type);
	boolean hasAccount(String name);
	boolean hasRegistedAccounts();
	void createFile(String name, String fileName, int mg, int ocupysize, boolean sharing, String inisshared);
	boolean hasFile(String name, String nameFile);
	boolean hasSpace(String name, int mg);
	void inicializeIterator();
	boolean hasNext();
	Users next();
	boolean isAccountBasic(String name);
	boolean fileShare(String nameaccounttoshare, String fileName, String nameOrigin);
	boolean canSharethisFile(String nameaccountfile, String nameaccounttoshare, String fileName);
	void shareFile(String nameaccountfile, String nameaccounttoshare, String fileName);
	void inicializeFileIterator(String name);
	boolean fileHasNext(String name);
	String listFileInformation(String name);
	String minSpaceAccount();
	

}
