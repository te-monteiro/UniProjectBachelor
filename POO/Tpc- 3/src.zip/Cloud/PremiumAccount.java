package Cloud;
/**
 * @author Goncalo Mateus, numero-53052 / Teresa Monteiro, numero-52597 
 *
 */
public class PremiumAccount extends Users {

	private static final int SIZE = 5120;
	private static final String TYPE = "Premium";

	
	public PremiumAccount(String name) {
		super(name);
	}

	@Override
	public int getAccountSize() {
		return SIZE;
	}

	@Override
	public String getAccountType() {
		return TYPE;
	}
	

}
