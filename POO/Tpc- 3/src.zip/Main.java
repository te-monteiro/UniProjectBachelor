
/**
 * 
 */
import java.util.Scanner;

import Cloud.*;

/**
 * @author Goncalo Mateus, numero-53052 / Teresa Monteiro, numero-52597 
 *
 */

public class Main {

	// Constantes que definem os comandos
	public static final String ADD = "ADD";
	public static final String UPLOAD = "UPLOAD";
	public static final String SHARE = "SHARE";
	public static final String MINSPACE = "MINSPACE";
	public static final String LISTFILES = "LISTFILES";
	public static final String LISTALL = "LISTALL";
	public static final String SAIR = "EXIT";

	// Constantes que definem as mensagens
	public static final String ERROR_MESSAGE = "ERRO";
	public static final String EXIT_MESSAGE = "Exiting...\n";
	public static final String ADDED_ACCOUNT = "Account was added.\n";
	public static final String ACCOUNT_ALREADY_EXISTS = "Account already exists.\n";
	public static final String ACCOUNT_DOES_NOT_EXISTS = "Account does not exist.\n";
	public static final String ACCOUNT_FILES = "Account files:";
	public static final String ALL_ACCOUNT = "All accounts:";
	public static final String NO_ACCOUNT = "No accounts.\n";
	public static final String ACCOUNT_LEAST_FREE_SPACE = "Account with least free space: ";
	public static final String FILE_ALREADY_EXISTS = "File already exists in the account.\n";
	public static final String FILE_NOT_EXISTS = "File does not exist.\n";
	public static final String FILE_EXCEEDS_CAPACITY = "File size exceeds account capacity.\n";
	public static final String FILE_UPLOADED = "File uploaded into account.\n";
	public static final String FILE_ALREADY_SHARED = "File already shared.\n";
	public static final String ACCOUNT_NOT_ALLOW_SHARING = "Account does not allow file sharing.\n";
	public static final String FILE_SHARED = "File was shared.\n";



	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		Dropbox d = new Dropbox();
		String comm = getCommand(in);

		while (!comm.equals(SAIR)) {
			switch (comm) {
			case ADD:
				addAccount(in, d);
				break;
			case UPLOAD:
				addFile(in, d);
				break;
			case SHARE:
				share(in, d);
				break;
			case MINSPACE:
				minSpace(d);
				break;
			case LISTFILES:
				listfiles(in, d);
				break;
			case LISTALL:
				listAllAccounts(d);
				break;
			default:
				System.out.println(ERROR_MESSAGE);
			}
			comm = getCommand(in);

		}
		System.out.println(EXIT_MESSAGE);
		in.close();

	}

	private static String getCommand(Scanner in) {
		String input;
		input = in.next().toUpperCase();

		return input;
	}

	private static void addAccount(Scanner in, Dropbox d) {
		String name = in.next();
		String type = in.nextLine().trim().toLowerCase();

		if (!d.hasAccount(name)) {
			d.addAccount(name, type);
			System.out.println(ADDED_ACCOUNT);
		} else
			System.out.println(ACCOUNT_ALREADY_EXISTS);

	}

	private static void addFile(Scanner in, Dropbox d) {
		String name = in.next();
		String fileName = in.next();
		int mg = in.nextInt();
		in.nextLine();

		if (!d.hasAccount(name)) {
			System.out.println(ACCOUNT_DOES_NOT_EXISTS);

		} else if (d.hasFile(name, fileName)) {
			System.out.println(FILE_ALREADY_EXISTS);

		} else if (!d.hasSpace(name, mg)) {
			System.out.println(FILE_EXCEEDS_CAPACITY);

		} else {
			d.createFile(name, fileName, mg, mg, false, "");
			System.out.println(FILE_UPLOADED);
		}
	}
	
	private static void minSpace(Dropbox d) {
		if(d.hasRegistedAccounts()) {
			System.out.println(ACCOUNT_LEAST_FREE_SPACE + d.minSpaceAccount() + "\n");
		}else {
			System.out.println(NO_ACCOUNT);
		}
	}

	private static void share(Scanner in, Dropbox d) {
		String nameaccountfile = in.next();
		String nameaccounttoshare = in.next().trim();
		String fileName = in.next().trim();

		if (!d.hasAccount(nameaccountfile) || !d.hasAccount(nameaccounttoshare)) {
			System.out.println(ACCOUNT_DOES_NOT_EXISTS);
		} else if (!d.hasFile(nameaccountfile, fileName)) {
			System.out.println(FILE_NOT_EXISTS);
		} else if (d.isAccountBasic(nameaccountfile)) {
			System.out.println(ACCOUNT_NOT_ALLOW_SHARING);
		} else if (d.fileShare(nameaccounttoshare, fileName, nameaccountfile)) {
			System.out.println(FILE_ALREADY_SHARED);

		} else if (!d.canSharethisFile(nameaccountfile, nameaccounttoshare, fileName)) {
			System.out.println(FILE_EXCEEDS_CAPACITY);
		} else {
			d.shareFile(nameaccountfile, nameaccounttoshare, fileName);
			System.out.println(FILE_SHARED);
		}

	}

	private static void listfiles(Scanner in, Dropbox d) {
		String name = in.next();
		
		if(d.hasAccount(name)) {
			System.out.println(ACCOUNT_FILES);
			d.inicializeFileIterator(name);
			while (d.fileHasNext(name)) {
				System.out.println(d.listFileInformation(name));
			}
			System.out.println();
		} else {
			System.out.println(ACCOUNT_DOES_NOT_EXISTS);
		}
		
		
	}

	private static void listAllAccounts(Dropbox d) {
		System.out.println(ALL_ACCOUNT);
		d.inicializeIterator();
		while (d.hasNext()) {
			Users u = d.next();
			System.out.println(u.getName() + " (" + u.getAccountType() + ")");
		}
		System.out.println();
	}

}
