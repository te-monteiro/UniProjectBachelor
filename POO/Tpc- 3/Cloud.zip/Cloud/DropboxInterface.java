package Cloud;

public interface DropboxInterface {

	void addAccount(String name, String type);
	boolean hasAccount(String name);
	boolean hasFile(String name, String nameFile);
	boolean hasSpace(String name, int mg);
	void createFile(String name, String fileName, int mg);

}
