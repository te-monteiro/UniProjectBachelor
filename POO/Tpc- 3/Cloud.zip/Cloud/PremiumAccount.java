package Cloud;

public class PremiumAccount extends Users {

	private static final int SIZE = 5120;
	
	public PremiumAccount(String name) {
		super(name);
	}

	@Override
	public int getAccountSize() {
		return SIZE;
	}
	

}
