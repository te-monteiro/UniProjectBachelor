package Cloud;

import Filess.*;

public abstract class Users {

	public abstract int getAccountSize();

	private String name;
	private FilesColection f;

	public Users(String name) {
		this.name = name;
		f = new FilesColection();
	}

	public String getName() {
		return name;
	}

	public void addFile(String fileName, int mg) {
		f.addFile(fileName, mg);
	}

	public boolean hasFile(String fileName) {
		return f.searchFile(fileName);
	}

	public boolean hasSpace(int mg) {
		boolean result = false;
		int sum = 0;

		sum = (f.sumSpace() + (mg));

		if (sum <= getAccountSize()) {
			result = true;
		}
		return result;
	}
}
