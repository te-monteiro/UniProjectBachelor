package Cloud;

public class BasicAccount extends Users {

	private static final int SIZE = 2048;

	public BasicAccount(String name) {
		super(name);
	}

	@Override
	public int getAccountSize() {
		return SIZE;
	}

}
