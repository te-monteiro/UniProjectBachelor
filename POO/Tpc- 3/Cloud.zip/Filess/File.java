/**
 * 
 */
package Filess;

/**
 * 
 * @author Goncalo Mateus / Teresa Monteiro
 *
 */

public class File implements FileInterface {

	private String fileName;
	private int mg;
	private boolean result;

	public File(String fileName, int mg) {
		this.fileName = fileName;
		this.mg = mg;
		result = false;
	}

	@Override
	public String getFileName() {
		return fileName;

	}

	@Override
	public int getFileSize() {
		return mg;
	}

	@Override
	public boolean isFileShared() {
		return result;
	}

	@Override
	public void shareFile() {
		result=true;		
	}

}
