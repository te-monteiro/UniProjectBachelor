package Filess;

/**
 * 
 * @author Goncalo Mateus / Teresa Monteiro
 *
 */

public interface FilesColectionInterface {

	/**
	 * Acrescenta um ficheiro <code>fileName</code> a colecao de ficheiros
	 * 
	 * @pre !searchFile(fileName)
	 * @param fileName
	 *            - nome do ficheiro.
	 */
	void addFile(String fileName, int size);

	/**
	 * Verifica se a colecao ficheiros tem o ficheiro <code>fileName</code>
	 * 
	 * @param fileName
	 *            - nome do ficheiro.
	 * @return devolve <code>true</code> se a colecao de ficheiros tem o ficheiro
	 *         <code>fileName</code>
	 */
	boolean searchFile(String fileName);

	/**
	 * Devolve o espaco total ocupado pelos ficheiros numa conta.
	 * 
	 * @return devolve um inteiro que representa um espaco total ocupado pelos
	 *         ficheiros de uma conta.
	 */
	int sumSpace();

	/**
	 * Informa que o ficheiro <code>fileName</code> passa a ser partilhado
	 * 
	 * @pre !searchFile(fileName)
	 * @param fileName
	 *            - nome do ficheiro.
	 */
	void shareFile(String fileName);

	/**
	 * Verifica se a colecao ficheiros tem o ficheiro <code>fileName</code> 
	 * @pre !searchFile(fileName)
	 * @param fileName - nome do ficheiro.
	 * @return devolve <code>true</code> o ficheiro <code>fileName</code> e um ficheiro partilhado
	 */
	boolean isFileshared(String fileName);
}
