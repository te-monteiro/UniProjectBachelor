
/**
 * 
 */
import java.util.Scanner;

import Cloud.*;

/**
 * @author Goncalo Mateus / Teresa Monteiro
 *
 */

public class Main {

	// Constantes que definem os comandos
	public static final String ADD = "ADD";
	public static final String UPLOAD = "UPLOAD";
	public static final String SHARE = "SHARE";
	public static final String MINSPACE = "MINSPACE";
	public static final String LISTFILES = "LISTFILES";
	public static final String LISTALL = "LISTALL";
	public static final String SAIR = "SAIR";

	// Constantes que definem as mensagens
	public static final String ERROR_MESSAGE = "ERRO";
	public static final String EXIT_MESSAGE = "Exiting...";
	public static final String ADDED_ACCOUNT = "Account was added.";
	public static final String ACCOUNT_ALREADY_EXISTS = "Account already exists.";
	public static final String ACCOUNT_DOES_NOT_EXISTS = "Account does not exist.";
	public static final String FILE_ALREADY_EXISTS = "File already exists in the account.";
	public static final String FILE_EXCEEDS_CAPACITY = "File size exceeds account capacity.";
	public static final String FILE_UPLOADED = "File uploaded into account.";
	
	
	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		Dropbox d = new Dropbox();
		String comm = getCommand(in);

		while (!comm.equals(SAIR)) {
			switch (comm) {
			case ADD:
				addAccount(in, d);
				break;
			case UPLOAD:
				addFile(in, d);
				break;
			case SHARE:

				break;
			case MINSPACE:

				break;
			case LISTFILES:

				break;
			case LISTALL:

				break;
			default:
				System.out.println(ERROR_MESSAGE);
			}
			comm = getCommand(in);

		}
		System.out.println(EXIT_MESSAGE);
		in.close();

	}

	private static String getCommand(Scanner in) {
		String input;

		input = in.nextLine().toUpperCase();

		return input;
	}

	private static void addAccount(Scanner in, Dropbox d) {
		String name = in.nextLine();
		String type = in.nextLine();

		if (!d.hasAccount(name)) {
			d.addAccount(name, type);
			System.out.println(ADDED_ACCOUNT);
		} else
			System.out.println(ACCOUNT_ALREADY_EXISTS);

	}

	private static void addFile(Scanner in, Dropbox d) {
		String name = in.nextLine();
		String fileName = in.nextLine().toUpperCase();
		int mg = in.nextInt();
		in.nextLine();
		
		if (!d.hasAccount(name)) {
			System.out.println(ACCOUNT_DOES_NOT_EXISTS);
			
		} else if (d.hasFile(name, fileName)) {
			System.out.println(FILE_ALREADY_EXISTS);
			
		} else if (!d.hasSpace(name, mg)) {
			System.out.println(FILE_EXCEEDS_CAPACITY);
			
		} else {
			d.createFile(name, fileName, mg);
			System.out.println(FILE_UPLOADED);
		}
	}

}
