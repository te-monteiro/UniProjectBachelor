package CloudSharing;

public interface File {

	String getName();

	int getSize();

	String getOwner();

}
