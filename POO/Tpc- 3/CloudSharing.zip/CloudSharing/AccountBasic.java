package CloudSharing;

public class AccountBasic extends User {
	public static final String BASIC = "Basic";
	protected File[] files;
	protected int numberOfFiles;

	public AccountBasic(String email) {
		super(email);
		setSpace(2 * 1024);

	}
	
	

}


