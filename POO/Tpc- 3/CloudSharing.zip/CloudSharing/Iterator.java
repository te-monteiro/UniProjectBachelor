package CloudSharing;

public interface Iterator<E> {
	void init();

	boolean hasNext();

	E next();

}

