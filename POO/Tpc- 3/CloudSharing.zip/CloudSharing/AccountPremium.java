package CloudSharing;

public class AccountPremium extends User {
	public static final String PREMIUM = "Premium";
	protected File[] files;
	protected int numberOfFiles;

	public AccountPremium(String email) {
		super(email);
		setSpace(5 * 1024);

	}

}
