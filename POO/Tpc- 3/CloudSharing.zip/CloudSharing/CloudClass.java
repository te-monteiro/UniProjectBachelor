package CloudSharing;

public class CloudClass implements Cloud {
	private User[] users;
	private int numberOfUsers;

	private static final int DEFAULT_SIZE = 10;

	public CloudClass() {
		users = new User[DEFAULT_SIZE];
		numberOfUsers = 0;

	}

	private void resize() {
		User[] tmp = new User[users.length * 2];
		for (int i = 0; i < numberOfUsers; i++) {
			tmp[i] = users[i];
		}
		users = tmp;

	}

	public int getNumberOfUsers() {
		return numberOfUsers;
	}

	@Override
	public void addAccount(String email, String typeAccount) {
		if (users.length == numberOfUsers) {
			resize();
		}
		if (typeAccount.equalsIgnoreCase("Basic")) {
			users[numberOfUsers++] = new AccountBasic(email);

		} else {
			users[numberOfUsers++] = new AccountPremium(email);
		}
	}

	private int searchIndex(String email) {
		int result = -1;
		for (int i = 0; i < numberOfUsers; i++) {
			if (users[i].getEmail().equalsIgnoreCase(email)) {
				result = i;
			}
		}
		return result;
	}

	public void addFileShared(String emailFrom, int size, String filename, String emailTo) {
		User a = users[searchIndex(emailTo)];

		if (a instanceof AccountBasic && a.compareOwner(emailFrom, filename) != null) 
			size = size/2;
		
		a.addFileShared(emailFrom, size, filename, emailTo);

	}

	public int getSize(String email, String filename) {
		return users[searchIndex(email)].getSize(filename);
	}

	@Override
	public boolean hasAccount(String email) {
		return searchIndex(email) != -1;
	}

	@Override
	public void addFile(String email, String filename, int size) {
		users[searchIndex(email)].addFile(filename, size);
	}

	@Override
	public boolean hasFile(String email, String filename) {
		return users[searchIndex(email)].hasFileOwner(filename);
	}

	@Override
	public boolean hasFreeSpace(String email, int size) {
		return users[searchIndex(email)].hasSpace(size);
	}

	@Override
	public String getNameAccount(String email) {
		return users[searchIndex(email)].getClass().getName();
	}

	@Override
	public boolean hasShared(String emailFrom, String filename, String emailTo) {
		return users[searchIndex(emailFrom)].hasFileShared(filename, emailTo);
	}

	@Override
	public User minSpace() {
		User min = users[0];
		for (int i = 0; i < numberOfUsers; i++) {
			if (min.getSpace() > users[i].getSpace()) {
				min = users[i];
			}
		}
		return min;
	}

	public Iterator<User> IteratorUsers() {
		return new IteratorClass<User>(users, numberOfUsers);
	}

	public Iterator<File> IteratorFiles(String email) {
		return users[searchIndex(email)].IteratorFiles();
	}

}
