
import java.util.Scanner;

import CloudSharing.Cloud;
import CloudSharing.CloudClass;
import CloudSharing.User;
import CloudSharing.File;
import CloudSharing.Iterator;

public class Main {

	public static void main(String[] args) {
		Main.commands();

	}

	private static void commands() {
		Cloud cloud = new CloudClass();
		Scanner in = new Scanner(System.in);
		String command = in.next().toUpperCase();
		while (!command.equals("EXIT")) {
			switch (command) {
			case "ADD":
				addAccount(cloud, in);
				break;
			case "UPLOAD":
				addFiles(cloud, in);
				break;
			case "SHARE":
				share(cloud, in);
				break;
			case "MINSPACE":
				minspace(cloud, in);
				break;
			case "LISTFILES":
				listfiles(cloud, in);
				break;
			case "LISTALL":
				listall(cloud, in);
				break;
			case "EXIT":
				break;
			default:
				System.out.println("Invalid command.");
				break;
			}
			command = in.next().toUpperCase();
			System.out.println();
		}
		System.out.println("Exiting...");

	}

	private static void listall(Cloud cloud, Scanner in) {
		// TODO Auto-generated method stub
		System.out.println("All accounts:");
		Iterator<User> u = cloud.IteratorUsers();
		while (u.hasNext()) {
			User a = u.next();
			System.out.println(a.getEmail() + " (" + a.getNameAccount() + ")" + " " + a.getSpace());
		}

	}

	private static void listfiles(Cloud cloud, Scanner in) {
		String email = in.next();
		if (!cloud.hasAccount(email)) {
			System.out.println("Account does not exist.");
		} else {
			System.out.println("Account files:");
			Iterator<File> m = cloud.IteratorFiles(email);
			while (m.hasNext()) {
				File file = m.next();
				if (!file.getOwner().equals(email)) {
					System.out.println(file.getName() + " (" + file.getSize() + " MB) (shared)");

				} else {
					System.out.println(file.getName() + " (" + file.getSize() + " MB)");

				}

			}

		}

	}

	private static void minspace(Cloud cloud, Scanner in) {
		if (cloud.getNumberOfUsers() == 0) {
			System.out.println("No accounts.");
		} else {
			System.out.println("Account with least free space: " + cloud.minSpace().getEmail());
		}
	}

	private static void share(Cloud cloud, Scanner in) {
		String emailFrom = in.next();
		String emailTo = in.next();
		String filename = in.next();
		if (!cloud.hasAccount(emailFrom) || !cloud.hasAccount(emailTo)) {
			System.out.println("Account does not exist.");
		} else if (!cloud.hasFile(emailFrom, filename)) {
			System.out.println("File does not exist.");
		} else if (cloud.getNameAccount(emailFrom).equalsIgnoreCase("Basic")) {
			System.out.println("Account does not allow file sharing.");
		} else if (cloud.hasShared(emailFrom, filename, emailTo)) {
			System.out.println("File already shared.");
		} else if (!cloud.hasFreeSpace(emailTo, cloud.getSize(emailFrom, filename))) {
			System.out.println("File size exceeds account capacity.");

		} else {
			cloud.addFileShared(emailFrom, cloud.getSize(emailFrom, filename),filename, emailTo);
			System.out.println("File was shared.");
		}

	}

	private static void addFiles(Cloud cloud, Scanner in) {
		String email = in.next();
		String filename = in.next();
		int size = in.nextInt();
		if (!cloud.hasAccount(email)) {
			System.out.println("Account does not exist.");
		} else if (cloud.hasFile(email, filename)) {
			System.out.println("File already exists in the account.");
		} else if (!cloud.hasFreeSpace(email, size) && !cloud.getNameAccount(email).equalsIgnoreCase("Premium")) {
			System.out.println("File size exceeds account capacity.");

		} else {
			cloud.addFile(email, filename, size);
			System.out.println("File uploaded into account.");
		}

	}

	private static void addAccount(Cloud cloud, Scanner in) {
		String email = in.next();
		String type = in.next();

		if (cloud.hasAccount(email)) {
			System.out.println("Account already exists.");
		} else {
			cloud.addAccount(email, type);
			System.out.println("Account was added.");
		}
	}

}

