/**
 *
 */
package comparators;

import java.util.Comparator;
import java.util.List;

/**
 * @author Afonso Figuinha
 *
 */
public class MRComparator implements Comparator<List<String>> {

	@Override
	public int compare(List<String> entry1, List<String> entry2) {
		// nLovers
		if (Integer.parseInt(entry1.get(1)) > Integer.parseInt(entry2.get(1)))
			return -1;
		else if (Integer.parseInt(entry1.get(1)) < Integer.parseInt(entry2.get(1)))
			return 1;
		// nShows
		else if (Integer.parseInt(entry1.get(2)) > Integer.parseInt(entry2.get(2)))
			return 1;
		else if (Integer.parseInt(entry1.get(2)) < Integer.parseInt(entry2.get(2)))
			return -1;
		// nShowsWLovers
		else if (Integer.parseInt(entry1.get(3)) > Integer.parseInt(entry2.get(3)))
			return -1;
		else if (Integer.parseInt(entry1.get(3)) < Integer.parseInt(entry2.get(3)))
			return 1;
		else
			// Alphabet
			return entry1.get(0).compareTo(entry2.get(0));

	}
}
