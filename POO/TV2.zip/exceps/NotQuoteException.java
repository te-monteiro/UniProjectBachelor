package exceps;

/**
 * @author Afonso Figuinha
 *
 */
public class NotQuoteException extends Exception {
	private static final long serialVersionUID = -1118217250745178256L;

	public NotQuoteException() {
		super();
	}
}
