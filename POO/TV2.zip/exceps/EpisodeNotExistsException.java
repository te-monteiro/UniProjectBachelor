package exceps;

/**
 * @author Afonso Figuinha
 *
 */
public class EpisodeNotExistsException extends Exception {
	private static final long serialVersionUID = -3099781691023153257L;

	public EpisodeNotExistsException() {
		super();
	}

}
