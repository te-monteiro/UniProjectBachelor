package exceps;

/**
 * @author Afonso Figuinha
 *
 */
public class CharacterNotExistsException extends Exception {
	private static final long serialVersionUID = -8731622107062814861L;
	// private String characterName;

	public CharacterNotExistsException(String name) {
		// this.characterName = name;
		super(name);
	}

	/*
	 * public String character() { return characterName; }
	 */

}
