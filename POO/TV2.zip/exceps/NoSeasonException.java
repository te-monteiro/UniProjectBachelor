package exceps;

/**
 * @author Afonso Figuinha
 *
 */
public class NoSeasonException extends Exception {
	private static final long serialVersionUID = 2764262232666360147L;

	public NoSeasonException() {
		super();

	}
}
