/**
 *
 */
package exceps;

/**
 * @author Afonso Figuinha
 *
 */
public class ActorNotExistsException extends Exception {
	private static final long serialVersionUID = -7071314108181120098L;

	public ActorNotExistsException(String actorName) {
		super(actorName);
	}

}
