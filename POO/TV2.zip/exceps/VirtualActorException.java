package exceps;

/**
 * @author Afonso Figuinha
 *
 */
public class VirtualActorException extends Exception {

	private static final long serialVersionUID = -5809441835163282157L;

	public VirtualActorException() {
		super();
	}
}
