package exceps;

/**
 * @author Afonso Figuinha
 *
 */
public class ShowAlreadyExistsException extends Exception {
	private static final long serialVersionUID = 729821737052327073L;

	public ShowAlreadyExistsException() {
		super();
	}
}
