/**
 * 
 */
package exceps;

/**
 * @author Afonso Figuinha
 *
 */
public class NegativeFeeException extends Exception {
	private static final long serialVersionUID = 8680293151169399790L;

	public NegativeFeeException() {
		super();
	}
}
