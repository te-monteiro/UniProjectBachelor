package exceps;

/**
 * @author Afonso Figuinha
 *
 */
public class SamePersonException extends Exception {
	private static final long serialVersionUID = -1550001927449305372L;

	public SamePersonException() {
		super();
	}
}
