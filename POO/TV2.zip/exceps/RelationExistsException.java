package exceps;

/**
 * @author Afonso Figuinha
 *
 */
public class RelationExistsException extends Exception {
	private static final long serialVersionUID = -6130512927543443963L;

	public RelationExistsException() {
		super();
	}
}
