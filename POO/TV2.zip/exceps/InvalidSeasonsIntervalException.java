package exceps;

/**
 * @author Afonso Figuinha
 *
 */
public class InvalidSeasonsIntervalException extends Exception {
	private static final long serialVersionUID = 7030777752366821235L;

	public InvalidSeasonsIntervalException() {
		super();
	}
}
