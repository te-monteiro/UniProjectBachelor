package exceps;

/**
 * @author Afonso Figuinha
 *
 */
public class NoVirtualCharactersException extends Exception {
	private static final long serialVersionUID = 1197957837691616531L;

	public NoVirtualCharactersException() {
		super();
	}

}
