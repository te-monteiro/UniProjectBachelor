package exceps;

/**
 * @author Afonso Figuinha
 *
 */
public class NotAsRomanticException extends Exception {
	private static final long serialVersionUID = -6117969083464717417L;

	public NotAsRomanticException() {
		super();
	}

}
