/**
 * 
 */
package exceps;

/**
 * @author Afonso Figuinha
 *
 */
public class DuplicatedCharacterNameException extends Exception {
	private static final long serialVersionUID = 2332566701778944020L;

	public DuplicatedCharacterNameException() {
		super();
	}
}
