package exceps;

/**
 * @author Afonso Figuinha
 *
 */
public class ShowNotExistsException extends Exception {
	private static final long serialVersionUID = -6813122123827036944L;

	public ShowNotExistsException() {
		super();
	}
}
