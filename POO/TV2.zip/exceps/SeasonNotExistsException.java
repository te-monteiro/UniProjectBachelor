package exceps;

/**
 * @author Afonso Figuinha
 *
 */
public class SeasonNotExistsException extends Exception {
	private static final long serialVersionUID = -2557881917787101823L;

	public SeasonNotExistsException() {
		super();
	}

}
