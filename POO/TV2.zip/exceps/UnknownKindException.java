/**
 * 
 */
package exceps;

/**
 * @author Afonso Figuinha
 *
 */
public class UnknownKindException extends Exception {
	private static final long serialVersionUID = 3499369803035301998L;

	public UnknownKindException() {
		super();
	}
}
