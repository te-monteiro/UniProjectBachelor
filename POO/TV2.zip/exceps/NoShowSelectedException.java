package exceps;

/**
 * @author Afonso Figuinha
 *
 */
public class NoShowSelectedException extends Exception {

	private static final long serialVersionUID = 5373952734674587032L;

	public NoShowSelectedException() {
		super();
	}

}
