package exceps;

/**
 * @author Afonso Figuinha
 *
 */
public class NotRelatedException extends Exception {
	private static final long serialVersionUID = 5725562140233796866L;

	public NotRelatedException() {
		super();
	}
}
