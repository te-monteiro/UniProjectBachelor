import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

import classes.ShowPediaClass;
import exceps.ActorNotExistsException;
import exceps.CharacterNotExistsException;
import exceps.DuplicatedCharacterNameException;
import exceps.EpisodeNotExistsException;
import exceps.InvalidSeasonsIntervalException;
import exceps.NegativeFeeException;
import exceps.NoShowSelectedException;
import exceps.NoVirtualCharactersException;
import exceps.NotAsRomanticException;
import exceps.NotQuoteException;
import exceps.NotRelatedException;
import exceps.RelationExistsException;
import exceps.SamePersonException;
import exceps.SeasonNotExistsException;
import exceps.ShowAlreadyExistsException;
import exceps.ShowNotExistsException;
import exceps.UnknownKindException;
import exceps.VirtualActorException;
import inters.Character;
import inters.Episode;
import inters.Event;
import inters.Season;
import inters.Show;
import inters.ShowPedia;

/**
 * @author Afonso Figuinha
 *
 */
public class Main {
	// Commands
	private static final String CURRENT = "currentshow";
	private static final String ADDSHOW = "addshow";
	private static final String SWITCH = "switchtoshow";
	private static final String ADDSEASON = "addseason";
	private static final String ADDEPISODE = "addepisode";
	private static final String ADDCHARACTER = "addcharacter";
	private static final String ADDRELATION = "addrelationship";
	private static final String ADDROMANCE = "addromance";
	private static final String ADDEVENT = "addevent";
	private static final String ADDQUOTE = "addquote";
	private static final String SEASONSOUTLINE = "seasonsoutline";
	private static final String CHARACTERRESUME = "characterresume";
	private static final String HATTRELATED = "howarethesetworelated";
	private static final String FAMOUSQUOTES = "famousquotes";
	private static final String ALSOON = "alsoappearson";
	private static final String MOSTROMANTIC = "mostromantic";
	private static final String KINGCGI = "kingofcgi";
	private static final String HELP = "help";
	private static final String EXIT = "exit";

	// Messages
	private static final String ERROR = "Unknown command. Type help to see available commands.";
	private static final String BYE = "Bye!";
	private static final String PROMPT = "> ";
	private static final String CURRENTSHOW = "%s. Seasons: %d Episodes: %d%n";
	private static final String SHOWCREATED = "%s created.%n";
	private static final String NEWEPISODE = "%s S%d, Ep%d: %s.%n";
	private static final String ADDCHARBOTH = "%s is now part of %s. This is ";
	private static final String ADDCHARREAL = "%s role %d.%n";
	private static final String ADDCHARVIRTUAL = "a virtual actor.";
	private static final String RELATIONSHIPSTATUS = "%s has now %d kids. %s has now %d parent(s).%n";
	private static final String SAMEPERSON = "%s cannot be parent and child at the same time!%n";
	private static final String WHO_IS = "Who is %s?%n";
	private static final String NOW_COUPLE = "%s and %s are now a couple.%n";
	private static final String SINGLE_RELATION = "%s cannot be in a single person romantic relationship!%n";
	private static final String EVENT_ADDED = "Event added.";
	private static final String NO_SEASON = "%s does not have season %d!%n";
	private static final String NO_EPISODE = "%s S%d does not have episode %d!%n";
	private static final String EPISODE_TITLE = "S%d EP%d: %s%n";
	private static final String COMMA = ", %s";
	private static final String DOT_COMMA = "; %s";
	private static final String VIRTUAL_ACTOR = "%s is played by a virtual actor!%n";
	private static final String SPACEN = "%s %s%n";
	private static final String SHOW_EXISTS = "Show already exists!";
	private static final String UNKNOWN_SHOW = "Unknown show!";
	private static final String NO_SHOW_SELECTED = "No show is selected!";
	private static final String UNKNOWN_SEASON = "Unknown season!";
	private static final String SLAVERY = "Slavery is long gone and this is outrageous!";
	private static final String DUPLICATED_NAMES = "Duplicate character names are not allowed!";
	private static final String UNKNOWN_CATEGORY = "Unknown actor category!";
	private static final String REAL = "real";
	private static final String QUOTE_ADDED = "Quote added.";
	private static final String INVALID_S_INTERVAL = "Invalid seasons interval!";
	private static final String PARENTS2 = "Parents: ";
	private static final String KIDS2 = "Kids: ";
	private static final String NONE = "None.";
	private static final String SIBLINGS = "Siblings: ";
	private static final String ROM_RELATIONS = "Romantic relationships: ";
	private static final String RELATED_SAME = "Like... you know, they are THE SAME character! duuuuh...";
	private static final String NOT_RELATED = "These characters are not related!";
	private static final String NOT_QUOTE = "First time I hear that!";
	private static final String RELATION_EXISTS = "What else is new? We already know about those two...";
	private static final String NO_LOVE = "Love is not in the air. :-(";
	private static final String REAL_THING = "This is the real thing, this is art!";

	// Help
	private static final String HELP1 = "currentShow - show the current show";
	private static final String HELP2 = "addShow - add a new show";
	private static final String HELP3 = "switchToShow - change the context to a particular show";
	private static final String HELP4 = "addSeason - add a new season to the current show";
	private static final String HELP5 = "addEpisode - add a new episode to a particular season of the current show";
	private static final String HELP6 = "addCharacter - add a new character to a show";
	private static final String HELP7 = "addRelationship - add a family relationship between characters";
	private static final String HELP8 = "addRomance - add a romantic relationship between characters";
	private static final String HELP9 = "addEvent - add a significant event involving at least one character";
	private static final String HELP10 = "addQuote - add a new quote to a character";
	private static final String HELP11 = "seasonsOutline - outline the contents of the selected seasons for the selected show";
	private static final String HELP12 = "characterResume - outline the main information on a specific character";
	private static final String HELP13 = "howAreTheseTwoRelated - find out if and how two characters may be related";
	private static final String HELP14 = "famousQuotes - find out which character(s) said a particular quote";
	private static final String HELP15 = "alsoAppearsOn - which other shows and roles is the same actor on?";
	private static final String HELP16 = "mostRomantic - find out who is at least as romantic as X";
	private static final String HELP17 = "kingOfCGI - find out which company has earned more revenue with their CGI virtual actors";
	private static final String HELP18 = "help - shows the available commands";
	private static final String HELP19 = "exit - terminates the execution of the program";

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		ShowPedia showpedia = new ShowPediaClass();
		String comm = getCommand(in);
		while (!comm.equals(EXIT)) {
			switch (comm) {
			case CURRENT:
				currentShow(showpedia);
				break;
			case ADDSHOW:
				addShow(in, showpedia);
				break;
			case SWITCH:
				switchToShow(in, showpedia);
				break;
			case ADDSEASON:
				addSeason(showpedia);
				break;
			case ADDEPISODE:
				addEpisode(in, showpedia);
				break;
			case ADDCHARACTER:
				addCharacter(in, showpedia);
				break;
			case ADDRELATION:
				addRelationship(in, showpedia);
				break;
			case ADDROMANCE:
				addRomance(in, showpedia);
				break;
			case ADDEVENT:
				addEvent(in, showpedia);
				break;
			case ADDQUOTE:
				addQuote(in, showpedia);
				break;
			case SEASONSOUTLINE:
				seasonsOutline(in, showpedia);
				break;
			case CHARACTERRESUME:
				characterResume(in, showpedia);
				break;
			case HATTRELATED:
				howAreTheseTwoRelated(in, showpedia);
				break;
			case FAMOUSQUOTES:
				famousQuotes(in, showpedia);
				break;
			case ALSOON:
				alsoAppearsOn(in, showpedia);
				break;
			case MOSTROMANTIC:
				mostRomantic(in, showpedia);
				break;
			case KINGCGI:
				kingOfCGI(showpedia);
				break;
			case HELP:
				help();
				break;
			default:
				System.out.println(ERROR);
			}
			comm = getCommand(in);
		}
		System.out.println(BYE);
		in.close();

	}

	private static void currentShow(ShowPedia showpedia) {
		try {
			Show actShow = showpedia.currentShow();
			System.out.printf(CURRENTSHOW, actShow.name(), actShow.nSeasons(), actShow.nEpisodes());
		} catch (NoShowSelectedException e) {
			System.out.println(NO_SHOW_SELECTED);
		}
	}

	private static void addShow(Scanner in, ShowPedia showpedia) {
		String showName = in.nextLine();
		try {
			showpedia.addShow(showName);
			System.out.printf(SHOWCREATED, showName);
		} catch (ShowAlreadyExistsException e) {
			System.out.println(SHOW_EXISTS);
		}
	}

	private static void switchToShow(Scanner in, ShowPedia showpedia) {
		String showName = in.nextLine();
		try {
			showpedia.switchToShow(showName);
			currentShow(showpedia);
		} catch (ShowNotExistsException e) {
			System.out.println(UNKNOWN_SHOW);
		}
	}

	private static void addSeason(ShowPedia showpedia) {
		try {
			showpedia.addSeason();
			currentShow(showpedia);
		} catch (NoShowSelectedException e) {
			System.out.println(NO_SHOW_SELECTED);
		}
	}

	private static void addEpisode(Scanner in, ShowPedia showpedia) {
		int seasonNumber = in.nextInt();
		String episodeTitle = in.nextLine().trim();

		try {
			int epNumber = showpedia.addEpisode(seasonNumber, episodeTitle);
			String showName = showpedia.currentShowName();
			System.out.printf(NEWEPISODE, showName, seasonNumber, epNumber, episodeTitle);
		} catch (NoShowSelectedException e) {
			System.out.println(NO_SHOW_SELECTED);
		} catch (SeasonNotExistsException e) {
			System.out.println(UNKNOWN_SEASON);
		}

	}

	private static void addCharacter(Scanner in, ShowPedia showpedia) {
		String kind = in.nextLine();
		String characterName = in.nextLine();
		String actorNameOrCompanyName = in.nextLine();
		int feeEpisodeOrCostSeason = in.nextInt();
		in.nextLine();

		try {
			int roleNumber = showpedia.addCharacter(kind, characterName, actorNameOrCompanyName,
					feeEpisodeOrCostSeason);
			// Same for the both
			System.out.printf(ADDCHARBOTH, characterName, showpedia.currentShowName());
			if (kind.equals(REAL))
				System.out.printf(ADDCHARREAL, actorNameOrCompanyName, roleNumber);
			else
				// virtual
				System.out.println(ADDCHARVIRTUAL);

		} catch (NoShowSelectedException e) {
			System.out.println(NO_SHOW_SELECTED);
		} catch (UnknownKindException e) {
			System.out.println(UNKNOWN_CATEGORY);
		} catch (DuplicatedCharacterNameException e) {
			System.out.println(DUPLICATED_NAMES);
		} catch (NegativeFeeException e) {
			System.out.println(SLAVERY);
		}

	}

	private static void addRelationship(Scanner in, ShowPedia showpedia) {
		String parent = in.nextLine();
		String kid = in.nextLine();

		try {
			showpedia.addRelationship(parent, kid);
			int nKids = showpedia.numberOfKids(parent);
			int nParents = showpedia.numberOfParents(kid);
			System.out.printf(RELATIONSHIPSTATUS, parent, nKids, kid, nParents);
		} catch (NoShowSelectedException e) {
			System.out.println(NO_SHOW_SELECTED);
		} catch (SamePersonException e) {
			System.out.printf(SAMEPERSON, parent);
		} catch (CharacterNotExistsException e) {
			System.out.printf(WHO_IS, e.getMessage());
		} catch (RelationExistsException e) {
			System.out.println(RELATION_EXISTS);
		}
	}

	private static void addRomance(Scanner in, ShowPedia showpedia) {
		String lover1 = in.nextLine();
		String lover2 = in.nextLine();
		try {
			showpedia.addRomance(lover1, lover2);
			System.out.printf(NOW_COUPLE, lover1, lover2);
		} catch (NoShowSelectedException e) {
			System.out.println(NO_SHOW_SELECTED);
		} catch (SamePersonException e) {
			System.out.printf(SINGLE_RELATION, lover1);
		} catch (CharacterNotExistsException e) {
			System.out.printf(WHO_IS, e.getMessage());
		} catch (RelationExistsException e) {
			System.out.println(RELATION_EXISTS);
		}

	}

	private static void addEvent(Scanner in, ShowPedia showpedia) {
		String event = in.nextLine();
		int seasonN = in.nextInt();
		int epiN = in.nextInt();
		int charN = in.nextInt();
		in.nextLine();
		List<String> charList = new LinkedList<String>();
		for (int i = 0; i < charN; i++)
			charList.add(in.nextLine());

		try {
			showpedia.addEvent(event, seasonN, epiN, charN, charList);
			System.out.println(EVENT_ADDED);
		} catch (NoShowSelectedException e) {
			System.out.println(NO_SHOW_SELECTED);
		} catch (SeasonNotExistsException e) {
			System.out.printf(NO_SEASON, showpedia.currentShowName(), seasonN);
		} catch (EpisodeNotExistsException e) {
			System.out.printf(NO_EPISODE, showpedia.currentShowName(), seasonN, epiN);
		} catch (CharacterNotExistsException e) {
			System.out.printf(WHO_IS, e.getMessage());
		} catch (SamePersonException e) {
			System.out.println(DUPLICATED_NAMES);
		}

	}

	private static void addQuote(Scanner in, ShowPedia showpedia) {
		int seasonN = in.nextInt();
		int epiN = in.nextInt();
		in.nextLine();
		String charName = in.nextLine();
		String quote = in.nextLine();

		try {
			showpedia.addQuote(seasonN, epiN, charName, quote);
			System.out.println(QUOTE_ADDED);
		} catch (NoShowSelectedException e) {
			System.out.println(NO_SHOW_SELECTED);
		} catch (SeasonNotExistsException e) {
			System.out.printf(NO_SEASON, showpedia.currentShowName(), seasonN);
		} catch (EpisodeNotExistsException e) {
			System.out.printf(NO_EPISODE, showpedia.currentShowName(), seasonN, epiN);
		} catch (CharacterNotExistsException e) {
			System.out.printf(WHO_IS, e.getMessage());
		}
	}

	private static void seasonsOutline(Scanner in, ShowPedia showpedia) {
		int season1 = in.nextInt();
		int season2 = in.nextInt();
		in.nextLine();
		try {
			Iterator<Season> it = showpedia.seasonsOutline(season1, season2);
			System.out.println(showpedia.currentShowName());

			// Each Season
			while (it.hasNext()) {
				Season actSeason = it.next();
				Iterator<Episode> ite = actSeason.episodes();
				// Each episode
				while (ite.hasNext()) {
					Episode actEpisode = ite.next();
					System.out.printf(EPISODE_TITLE, actSeason.number(), actEpisode.number(), actEpisode.name());
					// Each event
					Iterator<Event> itv = actEpisode.events();
					while (itv.hasNext())
						System.out.println(itv.next().text());
				}
			}
		} catch (NoShowSelectedException e) {
			System.out.println(NO_SHOW_SELECTED);
		} catch (InvalidSeasonsIntervalException e) {
			System.out.println(INVALID_S_INTERVAL);
		}

	}

	private static void charResumeHelper(Iterator<String> it) {
		if (!it.hasNext())
			System.out.println(NONE);
		else {
			System.out.print(it.next());
			while (it.hasNext())
				System.out.printf(COMMA, it.next());
			System.out.println();
		}
	}

	private static void characterResume(Scanner in, ShowPedia showpedia) {
		String charName = in.nextLine();

		try {
			Character actChar = showpedia.getCharacter(charName);

			// Parents
			Iterator<String> itp = actChar.parents();
			System.out.print(PARENTS2);
			charResumeHelper(itp);

			// Kids
			Iterator<String> itk = actChar.kids();
			System.out.print(KIDS2);
			charResumeHelper(itk);

			// Siblings
			Iterator<String> its = actChar.siblings();
			System.out.print(SIBLINGS);
			charResumeHelper(its);

			// Romantic relationships
			Iterator<String> itr = actChar.romRelationships();
			System.out.print(ROM_RELATIONS);
			charResumeHelper(itr);

			// Events where this character appears
			Iterator<Season> it = showpedia.seasonsWithChar(charName);
			// Each Season
			while (it.hasNext()) {
				Season actSeason = it.next();
				Iterator<Episode> ite = actSeason.episodesWithCar(charName);

				// Each episode
				while (ite.hasNext()) {
					Episode actEpisode = ite.next();
					System.out.printf(EPISODE_TITLE, actSeason.number(), actEpisode.number(), actEpisode.name());
					// Each event
					Iterator<Event> itv = actEpisode.eventsWithCar(charName);
					while (itv.hasNext())
						System.out.println(itv.next().text());
				}
			}

		} catch (NoShowSelectedException e) {
			System.out.println(NO_SHOW_SELECTED);
		} catch (CharacterNotExistsException e) {
			System.out.printf(WHO_IS, e.getMessage());
		}
	}

	private static void howAreTheseTwoRelated(Scanner in, ShowPedia showpedia) {
		String char1 = in.nextLine();
		String char2 = in.nextLine();

		try {
			Iterator<String> it = showpedia.related(char1, char2);
			System.out.print(it.next());
			while (it.hasNext())
				System.out.printf(DOT_COMMA, it.next());
			System.out.println();

		} catch (NoShowSelectedException e) {
			System.out.println(NO_SHOW_SELECTED);
		} catch (CharacterNotExistsException e) {
			System.out.printf(WHO_IS, e.getMessage());
		} catch (SamePersonException e) {
			System.out.println(RELATED_SAME);
		} catch (NotRelatedException e) {
			System.out.println(NOT_RELATED);
		}
	}

	private static void famousQuotes(Scanner in, ShowPedia showpedia) {
		String quote = in.nextLine();
		try {
			Iterator<String> it = showpedia.quoteOwners(quote);
			System.out.print(it.next());
			while (it.hasNext())
				System.out.printf(COMMA, it.next());
			System.out.println();

		} catch (NoShowSelectedException e) {
			System.out.println(NO_SHOW_SELECTED);
		} catch (NotQuoteException e) {
			System.out.println(NOT_QUOTE);
		}

	}

	private static void alsoAppearsOn(Scanner in, ShowPedia showpedia) {
		String charName = in.nextLine();

		try {
			Iterator<String> it = showpedia.alsoAppearsOn(charName);
			while (it.hasNext())
				System.out.println(it.next());

		} catch (NoShowSelectedException e) {
			System.out.println(NO_SHOW_SELECTED);
		} catch (CharacterNotExistsException e) {
			System.out.printf(WHO_IS, charName);
		} catch (VirtualActorException e) {
			System.out.printf(VIRTUAL_ACTOR, charName);
		}
	}

	private static void mostRomantic(Scanner in, ShowPedia showpedia) {
		String actorName = in.nextLine();
		Boolean found = false;

		try {
			Iterator<List<String>> it = showpedia.mostRomantic(actorName);
			while (it.hasNext() && !found) {
				List<String> actActor = it.next();
				System.out.printf(SPACEN, actActor.get(0), actActor.get(1));
				if (actActor.get(0).equals(actorName))
					found = true;
			}
		} catch (ActorNotExistsException e) {
			System.out.printf(WHO_IS, e.getMessage());
		} catch (NotAsRomanticException e) {
			System.out.println(NO_LOVE);
		}

	}

	private static void kingOfCGI(ShowPedia showpedia) {
		try {
			List<String> kingCompany = showpedia.kingOfCGI();
			System.out.printf(SPACEN, kingCompany.get(0), kingCompany.get(1));
		} catch (NoVirtualCharactersException e) {
			System.out.println(REAL_THING);
		}

	}

	private static void help() {
		System.out.println(HELP1);
		System.out.println(HELP2);
		System.out.println(HELP3);
		System.out.println(HELP4);
		System.out.println(HELP5);
		System.out.println(HELP6);
		System.out.println(HELP7);
		System.out.println(HELP8);
		System.out.println(HELP9);
		System.out.println(HELP10);
		System.out.println(HELP11);
		System.out.println(HELP12);
		System.out.println(HELP13);
		System.out.println(HELP14);
		System.out.println(HELP15);
		System.out.println(HELP16);
		System.out.println(HELP17);
		System.out.println(HELP18);
		System.out.println(HELP19);
	}

	private static String getCommand(Scanner in) {
		System.out.print(PROMPT);
		return in.nextLine().toLowerCase().trim();
	}

}
