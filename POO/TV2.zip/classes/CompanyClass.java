/**
 *
 */
package classes;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import inters.Company;

/**
 * @author Afonso Figuinha
 *
 */
public class CompanyClass implements Company {
	String name;
	Map<String, String> charactersWShows;

	public CompanyClass(String companyName) {
		this.name = companyName;
		this.charactersWShows = new HashMap<>();
	}

	@Override
	public String name() {
		return name;
	}

	@Override
	public void addCharacter(String characterName, String currentShow) {
		charactersWShows.put(characterName, currentShow);
	}

	@Override
	public boolean hasCharacter(String charName) {
		return charactersWShows.containsKey(charName);
	}

	@Override
	public int nCharacters() {
		return charactersWShows.size();
	}

	@Override
	public Iterator<Entry<String, String>> characterWShows() {
		return charactersWShows.entrySet().iterator();
	}

}
