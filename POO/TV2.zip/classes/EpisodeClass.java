/**
 *
 */
package classes;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import inters.Episode;
import inters.Event;

/**
 * @author Afonso Figuinha
 *
 */
public class EpisodeClass implements Episode {

	String title;
	int number;
	List<Event> events;
	List<String> characters;

	public EpisodeClass(String episodeTitle, int episodeNumber) {
		this.title = episodeTitle;
		this.number = episodeNumber;
		this.events = new LinkedList<Event>();
		this.characters = new LinkedList<String>();
	}

	@Override
	public int number() {
		return number;
	}

	@Override
	public String name() {
		return title;
	}

	@Override
	public Iterator<Event> events() {
		return events.iterator();
	}

	@Override
	public Iterator<Event> eventsWithCar(String charName) {
		List<Event> auxList = new LinkedList<Event>();
		Iterator<Event> it = events.iterator();
		Event actEvent;
		while (it.hasNext()) {
			actEvent = it.next();
			if (actEvent.hasCharacter(charName))
				auxList.add(actEvent);
		}

		return auxList.iterator();
	}

	@Override
	public void addEvent(String event, List<String> charList) {
		events.add(new EventClass(event, charList));
		assert events.get(events.size() - 1).text() == event;
	}

	@Override
	public void addCharacters(List<String> charList) {
		String actChar;
		Iterator<String> it = charList.iterator();
		while (it.hasNext()) {
			actChar = it.next();
			if (!characters.contains(actChar))
				characters.add(actChar);
		}
	}

	@Override
	public boolean hasCharacter(String charName) {
		return characters.contains(charName);
	}
}
