/**
 *
 */
package classes;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * @author Afonso Figuinha
 *
 */
public class CharacterClass implements inters.Character {
	String name;
	String actorName;
	int fee;
	List<String> kids;
	List<String> parents;
	List<String> lovers;
	List<String> siblings;

	public CharacterClass(String characterName, String actorNameOrCompanyName, int feeEpisodeOrCostSeason) {
		this.name = characterName;
		this.actorName = actorNameOrCompanyName;
		this.fee = feeEpisodeOrCostSeason;

		this.kids = new LinkedList<String>();
		this.parents = new LinkedList<String>();
		this.lovers = new LinkedList<String>();
		this.siblings = new LinkedList<String>();
	}

	@Override
	public Iterator<String> parents() {
		return parents.iterator();
	}

	@Override
	public Iterator<String> kids() {
		return kids.iterator();
	}

	@Override
	public Iterator<String> siblings() {
		return siblings.iterator();
	}

	@Override
	public Iterator<String> romRelationships() {
		return lovers.iterator();
	}

	@Override
	public String name() {
		return name;
	}

	@Override
	public boolean hasKid(String kidName) {
		return kids.contains(kidName);
	}

	@Override
	public void addKid(String kidName) {
		kids.add(kidName);
	}

	@Override
	public void addParent(String parentName) {
		parents.add(parentName);
	}

	@Override
	public int nKids() {
		return kids.size();
	}

	@Override
	public int nParents() {
		return parents.size();
	}

	@Override
	public boolean hasLover(String loverName) {
		return lovers.contains(loverName);
	}

	@Override
	public void addLover(String loverName) {
		lovers.add(loverName);
	}

	@Override
	public boolean hasSibling(String siblingName) {
		return siblings.contains(siblingName);
	}

	@Override
	public void addSibling(String siblingName) {
		siblings.add(siblingName);
	}

	@Override
	public String actor() {
		return actorName;
	}

	@Override
	public int nLovers() {
		return lovers.size();
	}

	@Override
	public int fee() {
		return fee;
	}

	@Override
	public boolean hasParent(String parentName) {
		return parents.contains(parentName);
	}

}
