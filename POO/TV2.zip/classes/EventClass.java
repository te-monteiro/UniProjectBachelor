/**
 *
 */
package classes;

import java.util.List;

import inters.Event;

/**
 * @author Afonso Figuinha
 *
 */
public class EventClass implements Event {
	String text;
	List<String> characters;

	public EventClass(String event, List<String> charList) {
		this.text = event;
		this.characters = charList;
	}

	@Override
	public String text() {
		return text;
	}

	@Override
	public boolean hasCharacter(String charName) {
		return characters.contains(charName);
	}

}
