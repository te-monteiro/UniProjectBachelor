package classes;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import comparators.CGIComparator;
import comparators.MRComparator;
import exceps.ActorNotExistsException;
import exceps.CharacterNotExistsException;
import exceps.DuplicatedCharacterNameException;
import exceps.EpisodeNotExistsException;
import exceps.InvalidSeasonsIntervalException;
import exceps.NegativeFeeException;
import exceps.NoShowSelectedException;
import exceps.NoVirtualCharactersException;
import exceps.NotAsRomanticException;
import exceps.NotQuoteException;
import exceps.NotRelatedException;
import exceps.RelationExistsException;
import exceps.SamePersonException;
import exceps.SeasonNotExistsException;
import exceps.ShowAlreadyExistsException;
import exceps.ShowNotExistsException;
import exceps.UnknownKindException;
import exceps.VirtualActorException;
import inters.Actor;
import inters.Character;
import inters.Company;
import inters.Season;
import inters.Show;
import inters.ShowPedia;

/**
 * @author Afonso Figuinha
 *
 */
public class ShowPediaClass implements ShowPedia {

	// Types of characters
	private static final String REAL = "real";
	private static final String VIRTUAL = "virtual";

	String currentShow;
	List<Show> shows;
	List<Actor> actors;
	List<Company> companies;

	public ShowPediaClass() {
		this.currentShow = null;
		this.shows = new LinkedList<Show>();
		this.actors = new LinkedList<Actor>();
		this.companies = new LinkedList<Company>();
	}

	@Override
	public String currentShowName() {
		return currentShow;
	}

	@Override
	public Show currentShow() throws NoShowSelectedException {
		if (currentShow == null)
			throw new NoShowSelectedException();

		return getCurrentShow();
	}

	/**
	 * @return current show
	 */
	private Show getCurrentShow() {
		return showByName(currentShow);
	}

	/**
	 * @param showName
	 * @return show by name
	 */
	private Show showByName(String showName) {
		Show actShow;
		Iterator<Show> it = shows.iterator();
		while (it.hasNext()) {
			actShow = it.next();
			if (actShow.name().equals(showName))
				return actShow;
		}
		return null;
	}

	@Override
	public void addShow(String showName) throws ShowAlreadyExistsException {
		if (showByName(showName) != null)
			throw new ShowAlreadyExistsException();

		shows.add(new ShowClass(showName));
		currentShow = showName;
	}

	@Override
	public void switchToShow(String showName) throws ShowNotExistsException {
		if (showByName(showName) == null)
			throw new ShowNotExistsException();

		currentShow = showName;
	}

	@Override
	public void addSeason() throws NoShowSelectedException {
		if (currentShow == null)
			throw new NoShowSelectedException();

		getCurrentShow().addSeason();
	}

	@Override
	public int addEpisode(int seasonNumber, String episodeTitle)
			throws NoShowSelectedException, SeasonNotExistsException {
		if (currentShow == null)
			throw new NoShowSelectedException();
		if (!getCurrentShow().hasSeason(seasonNumber))
			throw new SeasonNotExistsException();

		return getCurrentShow().addEpisode(seasonNumber, episodeTitle);
	}

	@Override
	public int addCharacter(String kind, String characterName, String actorNameOrCompanyName,
			int feeEpisodeOrCostSeason) throws NoShowSelectedException, UnknownKindException,
			DuplicatedCharacterNameException, NegativeFeeException {

		if (currentShow == null)
			throw new NoShowSelectedException();
		if (!(kind.equals(REAL) || kind.equals(VIRTUAL)))
			throw new UnknownKindException();
		if (getCurrentShow().getCharacter(characterName) != null)
			throw new DuplicatedCharacterNameException();
		if (feeEpisodeOrCostSeason < 0)
			throw new NegativeFeeException();

		int nRole = 0;
		if (kind.equals(REAL)) {
			if (getActor(actorNameOrCompanyName) == null)
				actors.add(new ActorClass(actorNameOrCompanyName));
			Actor actActor = getActor(actorNameOrCompanyName);
			if (!actActor.hasShow(currentShow))
				actActor.addShow(currentShow);
			actActor.addRole();
			nRole = actActor.nShows();
		} else {
			if (getCompany(actorNameOrCompanyName) == null)
				companies.add(new CompanyClass(actorNameOrCompanyName));
			Company actCompany = getCompany(actorNameOrCompanyName);
			actCompany.addCharacter(characterName, currentShow);
		}

		getCurrentShow().addCharacter(characterName, actorNameOrCompanyName, feeEpisodeOrCostSeason);
		return nRole;
	}

	/**
	 * @param actorName
	 * @return actor by name
	 */
	private Actor getActor(String actorName) {
		Actor actActor;
		Iterator<Actor> it = actors.iterator();
		while (it.hasNext()) {
			actActor = it.next();
			if (actActor.name().equals(actorName))
				return actActor;
		}
		return null;
	}

	/**
	 * @param companyName
	 * @return company by name
	 */
	private Company getCompany(String companyName) {
		Company actCompany;
		Iterator<Company> it = companies.iterator();
		while (it.hasNext()) {
			actCompany = it.next();
			if (actCompany.name().equals(companyName))
				return actCompany;
		}
		return null;
	}

	@Override
	public void addRelationship(String parent, String kid)
			throws NoShowSelectedException, SamePersonException, CharacterNotExistsException, RelationExistsException {

		if (currentShow == null)
			throw new NoShowSelectedException();
		if (parent.equals(kid))
			throw new SamePersonException();
		if (getCurrentShow().getCharacter(parent) == null)
			throw new CharacterNotExistsException(parent);
		if (getCurrentShow().getCharacter(kid) == null)
			throw new CharacterNotExistsException(kid);
		if (getCurrentShow().getCharacter(parent).hasKid(kid))
			throw new RelationExistsException();

		getCurrentShow().addRelationship(parent, kid);

	}

	@Override
	public int numberOfKids(String parentName) {
		return getCurrentShow().getCharacter(parentName).nKids();
	}

	@Override
	public int numberOfParents(String childName) {
		return getCurrentShow().getCharacter(childName).nParents();
	}

	@Override
	public void addRomance(String lover1, String lover2)
			throws NoShowSelectedException, SamePersonException, CharacterNotExistsException, RelationExistsException {
		if (currentShow == null)
			throw new NoShowSelectedException();
		if (lover1.equals(lover2))
			throw new SamePersonException();
		if (getCurrentShow().getCharacter(lover1) == null)
			throw new CharacterNotExistsException(lover1);
		if (getCurrentShow().getCharacter(lover2) == null)
			throw new CharacterNotExistsException(lover2);
		if (getCurrentShow().getCharacter(lover1).hasLover(lover2))
			throw new RelationExistsException();

		getCurrentShow().addRomRelationship(lover1, lover2);

	}

	@Override
	public void addEvent(String event, int seasonN, int epiN, int charN, List<String> charList)
			throws NoShowSelectedException, SeasonNotExistsException, EpisodeNotExistsException,
			CharacterNotExistsException, SamePersonException {

		String actName;
		if (currentShow == null)
			throw new NoShowSelectedException();
		if (!getCurrentShow().hasSeason(seasonN))
			throw new SeasonNotExistsException();
		if (!getCurrentShow().hasEpisode(seasonN, epiN))
			throw new EpisodeNotExistsException();
		if ((actName = hasCurrShowCharacters(charList)) != null)
			throw new CharacterNotExistsException(actName);
		if (duplicatedChars(charList))
			throw new SamePersonException();

		getCurrentShow().addEvent(event, seasonN, epiN, charList);

	}

	/**
	 * @param charList
	 * @return true if current shows has all character in a list
	 */
	private String hasCurrShowCharacters(List<String> charList) {
		Iterator<String> it = charList.iterator();
		while (it.hasNext()) {
			String actName = it.next();
			if (getCurrentShow().getCharacter(actName) == null)
				return actName;
		}
		return null;
	}

	/**
	 * @param charList
	 * @return true if there are duplicated names in a list
	 */
	private Boolean duplicatedChars(List<String> charList) {
		List<String> auxList = new LinkedList<String>();
		Iterator<String> it = charList.iterator();
		while (it.hasNext()) {
			String actName = it.next();
			if (auxList.contains(actName))
				return true;
			auxList.add(actName);
		}
		return false;
	}

	@Override
	public void addQuote(int seasonN, int epiN, String charName, String quote) throws NoShowSelectedException,
			SeasonNotExistsException, EpisodeNotExistsException, CharacterNotExistsException {

		if (currentShow == null)
			throw new NoShowSelectedException();
		if (!getCurrentShow().hasSeason(seasonN))
			throw new SeasonNotExistsException();
		if (!getCurrentShow().hasEpisode(seasonN, epiN))
			throw new EpisodeNotExistsException();
		if (getCurrentShow().getCharacter(charName) == null)
			throw new CharacterNotExistsException(charName);

		getCurrentShow().addQuote(seasonN, epiN, charName, quote);

	}

	@Override
	public Iterator<Season> seasonsOutline(int season1, int season2)
			throws NoShowSelectedException, InvalidSeasonsIntervalException {

		if (currentShow == null)
			throw new NoShowSelectedException();
		if (!(getCurrentShow().hasSeason(season1) && getCurrentShow().hasSeason(season2)))
			throw new InvalidSeasonsIntervalException();

		return getCurrentShow().seasonsInterval(season1, season2);
	}

	@Override
	public Character getCharacter(String charName) throws NoShowSelectedException, CharacterNotExistsException {
		if (currentShow == null)
			throw new NoShowSelectedException();
		if (getCurrentShow().getCharacter(charName) == null)
			throw new CharacterNotExistsException(charName);

		return getCurrentShow().getCharacter(charName);
	}

	@Override
	public Iterator<Season> seasonsWithChar(String charName) {
		return getCurrentShow().seasonsWithChar(charName);
	}

	@Override
	public Iterator<String> related(String char1, String char2)
			throws NoShowSelectedException, CharacterNotExistsException, SamePersonException, NotRelatedException {

		if (currentShow == null)
			throw new NoShowSelectedException();
		if (getCurrentShow().getCharacter(char1) == null)
			throw new CharacterNotExistsException(char1);
		if (getCurrentShow().getCharacter(char2) == null)
			throw new CharacterNotExistsException(char2);
		if (char1.equals(char2))
			throw new SamePersonException();

		List<String> related = getCurrentShow().related(char1, char2);

		if (related.size() == 0)
			throw new NotRelatedException();
		return related.iterator();
	}

	@Override
	public Iterator<String> quoteOwners(String quote) throws NoShowSelectedException, NotQuoteException {
		if (currentShow == null)
			throw new NoShowSelectedException();
		if (!getCurrentShow().hasQuote(quote))
			throw new NotQuoteException();

		return getCurrentShow().quoteOwners(quote);

	}

	@Override
	public Iterator<String> alsoAppearsOn(String charName)
			throws NoShowSelectedException, CharacterNotExistsException, VirtualActorException {

		if (currentShow == null)
			throw new NoShowSelectedException();
		if (getCurrentShow().getCharacter(charName) == null)
			throw new CharacterNotExistsException(charName);
		if (isVirtualActor(charName))
			throw new VirtualActorException();
		return actorShows(charName);
	}

	/**
	 * @param charName
	 * @return an iterator of all shows played by the actor
	 */
	private Iterator<String> actorShows(String charName) {
		String actorName = getCurrentShow().getCharacter(charName).actor();
		Iterator<Actor> it = actors.iterator();
		Actor actActor;
		while (it.hasNext()) {
			actActor = it.next();
			if (actorName.equals(actActor.name()))
				return actActor.shows();
		}
		return null;
	}

	/**
	 * @param charName
	 * @return true if character is played by a virtual actor
	 */
	private boolean isVirtualActor(String charName) {
		Iterator<Company> it = companies.iterator();
		Company actCompany;
		while (it.hasNext()) {
			actCompany = it.next();
			if (actCompany.hasCharacter(charName))
				return true;
		}
		return false;
	}

	@Override
	public Iterator<List<String>> mostRomantic(String actorName)
			throws ActorNotExistsException, NotAsRomanticException {

		if (getActor(actorName) == null)
			throw new ActorNotExistsException(actorName);
		List<List<String>> auxMap = mostRomanticHelper(actorName);
		if (auxMap.size() == 0)
			throw new NotAsRomanticException();
		return auxMap.iterator();
	}

	/**
	 * @param actorName
	 * @return List of lists of actors with more or equal romantic relationships to
	 *         input actor
	 */
	private List<List<String>> mostRomanticHelper(String actorName) {

		List<String> actorLevels = actorRomanticLevels(actorName);

		List<List<String>> auxList = new LinkedList<List<String>>();

		Actor actActor;
		Iterator<Actor> it = actors.iterator();
		// All actors
		while (it.hasNext()) {
			actActor = it.next();
			List<String> actActorLevels = actorRomanticLevels(actActor.name());

			if (Integer.parseInt(actActorLevels.get(0)) > 0
					&& Integer.parseInt(actActorLevels.get(0)) >= Integer.parseInt(actorLevels.get(0))) {
				List<String> actActorList = new ArrayList<String>();
				actActorList.add(actActor.name());
				actActorList.addAll(actActorLevels);
				auxList.add(actActorList);
			}
		}

		auxList.sort(new MRComparator());

		List<List<String>> res = new LinkedList<List<String>>();
		for (List<String> actRes : auxList)
			res.add(new ArrayList<String>(Arrays.asList(actRes.get(0), actRes.get(1))));

		return res;

	}

	/**
	 * @param actorName
	 * @return all romantic levels from an actor (number of lovers, number of shows,
	 *         number of shows with lovers)
	 */
	private List<String> actorRomanticLevels(String actorName) {
		List<String> actorNumbers;
		int nLovers = 0;
		int showsWLovers = 0;
		int actNLovers = 0;
		Actor actActor = getActor(actorName);
		Character actCharacter;
		String actShow;

		Iterator<String> its;
		its = actActor.shows();
		// shows of actor
		while (its.hasNext()) {
			actShow = its.next();
			actCharacter = showByName(actShow).characterByActor(actorName);
			// Get values
			actNLovers = actCharacter.nLovers();
			if (actNLovers > 0) {
				nLovers += actNLovers;
				showsWLovers++;
			}
		}
		// Add actor to list
		actorNumbers = new ArrayList<String>(Arrays.asList(Integer.toString(nLovers),
				Integer.toString(actActor.nShows()), Integer.toString(showsWLovers)));
		return actorNumbers;
	}

	@Override
	public List<String> kingOfCGI() throws NoVirtualCharactersException {

		if (companies.size() == 0)
			throw new NoVirtualCharactersException();

		List<List<String>> resList = new ArrayList<List<String>>();
		Company actCompany;
		Iterator<Company> it = companies.iterator();
		while (it.hasNext()) {
			actCompany = it.next();
			resList.add(Arrays.asList(actCompany.name(), Integer.toString(companyRevenue(actCompany)),
					Integer.toString(actCompany.nCharacters())));
		}

		resList.sort(new CGIComparator());

		return resList.get(0);
	}

	private int companyRevenue(Company actCompany) {
		String charName;
		String showName;
		Show actShow;
		int res = 0;
		int nSeasons = 0;
		Map.Entry<String, String> entry;
		Iterator<Map.Entry<String, String>> it = actCompany.characterWShows();
		while (it.hasNext()) {
			entry = it.next();
			charName = entry.getKey();
			showName = entry.getValue();
			actShow = showByName(showName);
			nSeasons = actShow.nSeasonsWithChar(charName);
			res += nSeasons * actShow.getCharacter(charName).fee();
		}
		return res;
	}

//
//	Iterator<Map.Entry<String, String>> it = actCompany.characterWShows();
//	String charName;
//	String showName;
//	Show actShow;
//	int res = 0;
//	Map.Entry<String, String> entry;
//	while (it.hasNext()) {
//		entry = it.next();
//		charName = entry.getKey();
//		showName = entry.getValue();
//		actShow = showByName(showName);
//		res += actShow.nSeasons() * actShow.getCharacter(charName).fee();
//	}
//	return res;

}
