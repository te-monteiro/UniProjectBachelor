/**
 *
 */
package classes;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import inters.Episode;
import inters.Season;

/**
 * @author Afonso Figuinha
 *
 */
public class SeasonClass implements Season {

	List<Episode> episodes;
	List<String> characters;
	int number;
	List<String> quoters;

	public SeasonClass(int seasonNumber) {
		this.episodes = new ArrayList<Episode>();
		this.characters = new LinkedList<String>();
		this.number = seasonNumber;
		this.quoters = new LinkedList<String>();
	}

	@Override
	public int number() {
		return number;
	}

	@Override
	public int addEpisode(String episodeTitle) {
		episodes.add(new EpisodeClass(episodeTitle, episodes.size() + 1));
		return episodes.size();
	}

	@Override
	public int nEpisodes() {
		return episodes.size();
	}

	@Override
	public Iterator<Episode> episodes() {
		return episodes.iterator();
	}

	@Override
	public Iterator<Episode> episodesWithCar(String charName) {
		List<Episode> auxList = new LinkedList<Episode>();
		Iterator<Episode> it = episodes.iterator();
		Episode actEpisode;
		while (it.hasNext()) {
			actEpisode = it.next();
			if (actEpisode.hasCharacter(charName))
				auxList.add(actEpisode);
		}

		return auxList.iterator();
	}

	@Override
	public Episode getEpisode(int episodeNumber) {
		return episodes.get(episodeNumber - 1);
	}

	@Override
	public void addCharacters(List<String> charList) {
		String actChar;
		Iterator<String> it = charList.iterator();
		while (it.hasNext()) {
			actChar = it.next();
			if (!characters.contains(actChar))
				characters.add(actChar);
		}

	}

	@Override
	public boolean hasCharacter(String charName) {
		return characters.contains(charName);
	}

	@Override
	public void addQuoteBy(String charName) {
		quoters.add(charName);
	}

	@Override
	public boolean hasQuoteBy(String charName) {
		return quoters.contains(charName);
	}

}
