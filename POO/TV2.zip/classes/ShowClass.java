/**
 *
 */
package classes;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import inters.Character;
import inters.Season;
import inters.Show;

/**
 * @author Afonso Figuinha
 *
 */
public class ShowClass implements Show {
	String name;
	int nEpisodes;
	List<Season> seasons;
	List<Character> characters;
	Map<String, List<String>> quotes;

	public ShowClass(String showName) {
		this.name = showName;
		this.nEpisodes = 0;
		this.seasons = new ArrayList<Season>();
		addSeason();
		this.characters = new LinkedList<Character>();
		this.quotes = new HashMap<>();
	}

	@Override
	public int nEpisodes() {
		return nEpisodes;
	}

	@Override
	public int nSeasons() {
		return seasons.size();
	}

	@Override
	public String name() {
		return name;
	}

	@Override
	public void addSeason() {
		seasons.add(new SeasonClass(nSeasons() + 1));
	}

	@Override
	public boolean hasSeason(int seasonNumber) {
		return seasonNumber > 0 && seasonNumber <= seasons.size();
	}

	@Override
	public int addEpisode(int seasonNumber, String episodeTitle) {
		nEpisodes++;
		return seasons.get(seasonNumber - 1).addEpisode(episodeTitle);
	}

	@Override
	public Character getCharacter(String characterName) {
		Character actChar;
		Iterator<Character> it = characters.iterator();
		while (it.hasNext()) {
			actChar = it.next();
			if (actChar.name().equals(characterName))
				return actChar;
		}
		return null;
	}

	@Override
	public void addCharacter(String characterName, String actorNameOrCompanyName, int feeEpisodeOrCostSeason) {
		characters.add(new CharacterClass(characterName, actorNameOrCompanyName, feeEpisodeOrCostSeason));
	}

	@Override
	public void addRelationship(String parentName, String kidName) {
		addSiblings(parentName, kidName);
		getCharacter(parentName).addKid(kidName);
		getCharacter(kidName).addParent(parentName);
	}

	/**
	 * Add siblings to kid and kid to siblings
	 *
	 * @param parentName
	 * @param kidName
	 */
	private void addSiblings(String parentName, String kidName) {
		String actSon;
		Iterator<String> it = getCharacter(parentName).kids();
		while (it.hasNext()) {
			actSon = it.next();
			if (!getCharacter(kidName).hasSibling(actSon)) {
				getCharacter(kidName).addSibling(actSon);
				getCharacter(actSon).addSibling(kidName);
			}
		}
	}

	@Override
	public void addRomRelationship(String lover1, String lover2) {
		getCharacter(lover1).addLover(lover2);
		getCharacter(lover2).addLover(lover1);
	}

	@Override
	public boolean hasEpisode(int seasonN, int epiN) {
		return seasonN > 0 && epiN <= seasons.get(seasonN - 1).nEpisodes();
	}

	@Override
	public void addEvent(String event, int seasonN, int epiN, List<String> charList) {
		seasons.get(seasonN - 1).getEpisode(epiN).addEvent(event, charList);
		seasons.get(seasonN - 1).addCharacters(charList);
		seasons.get(seasonN - 1).getEpisode(epiN).addCharacters(charList);

	}

	@Override
	public Iterator<Season> seasons() {
		return seasons.iterator();
	}

	@Override
	public Iterator<Season> seasonsInterval(int season1, int season2) {
		int auxS;
		if (season1 > season2) {
			auxS = season1;
			season1 = season2;
			season2 = auxS;
		}

		List<Season> auxList = new LinkedList<Season>();
		auxS = season1 - 1;
		while (auxS < season2) {
			auxList.add(seasons.get(auxS));
			auxS++;
		}
		return auxList.iterator();
	}

	@Override
	public void addQuote(int seasonN, int epiN, String charName, String quote) {
		List<String> auxList;
		if (quotes.containsKey(quote))
			auxList = quotes.get(quote);
		else
			auxList = new LinkedList<String>();

		if (!auxList.contains(charName)) {
			auxList.add(charName);
			quotes.put(quote, auxList);
		}

		Season actSeason = seasons.get(seasonN - 1);
		if (!actSeason.hasQuoteBy(charName))
			actSeason.addQuoteBy(charName);
	}

	@Override
	public boolean hasQuote(String quote) {
		return quotes.containsKey(quote);
	}

	@Override
	public Iterator<String> quoteOwners(String quote) {
		List<String> auxList = quotes.get(quote);
		Collections.sort(auxList);
		return auxList.iterator();
	}

	@Override
	public Iterator<Season> seasonsWithChar(String charName) {
		List<Season> auxList = new LinkedList<Season>();
		Iterator<Season> it = seasons.iterator();
		Season actSeason;
		while (it.hasNext()) {
			actSeason = it.next();
			if (actSeason.hasCharacter(charName))
				auxList.add(actSeason);
		}

		return auxList.iterator();
	}

	@Override
	public List<String> related(String char1, String char2) {

		List<String> resList = new LinkedList<String>();
		// Check if char2 is in parents of parents of char1
		relatedParent(char1, char2, resList);
		if (resList.size() == 0)
			// Check if char1 is in parents of parents of char2
			relatedParent(char2, char1, resList);
		return resList;
	}

	/**
	 * @param char1
	 * @param char2
	 * @param resList
	 * @return Check if char2 is in parents of parents of char1
	 */
	private void relatedParent(String char1, String char2, List<String> resList) {
		if (getCharacter(char1).hasParent(char2)) {
			resList.add(char2);
			resList.add(char1);
		} else if (getCharacter(char1).nParents() != 0) {
			Iterator<String> it = getCharacter(char1).parents();
			String actParent;
			while (it.hasNext()) {
				actParent = it.next();
				List<String> actList = new LinkedList<String>();
				relatedParent(actParent, char2, actList);
				if (actList.size() > 0) {
					actList.add(char1);
					resList.addAll(actList);
				}

			}
		}
	}

	@Override
	public Character characterByActor(String actorName) {
		Iterator<Character> it = characters.iterator();
		Character actChar;
		while (it.hasNext()) {
			actChar = it.next();
			if (actChar.actor().contentEquals(actorName))
				return actChar;
		}
		return null;
	}

	@Override
	public int nSeasonsWithChar(String charName) {
		Iterator<Season> it = seasons.iterator();
		Season actSeason;
		int res = 0;
		while (it.hasNext()) {
			actSeason = it.next();
			if (actSeason.hasCharacter(charName))
				res++;
			else if (actSeason.hasQuoteBy(charName))
				res++;
		}
		return res;
	}

}
