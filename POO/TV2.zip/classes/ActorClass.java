/**
 *
 */
package classes;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import inters.Actor;

/**
 * @author Afonso Figuinha
 *
 */
public class ActorClass implements Actor {

	String name;
	List<String> shows;
	int nRoles;

	public ActorClass(String actorName) {
		this.name = actorName;
		this.shows = new LinkedList<String>();
		this.nRoles = 0;
	}

	@Override
	public String name() {
		return name;
	}

	@Override
	public void addRole() {
		nRoles++;
	}

	@Override
	public void addShow(String show) {
		shows.add(show);
	}

	@Override
	public boolean hasShow(String currentShow) {
		return shows.contains(currentShow);
	}

	@Override
	public int nShows() {
		return nRoles;
	}

	@Override
	public Iterator<String> shows() {
		List<String> auxList = shows;
		Collections.sort(auxList);
		return auxList.iterator();

	}

}
