/**
 *
 */
package inters;

/**
 * @author Afonso Figuinha
 *
 */
public interface Event {

	/**
	 * @return text of event
	 */
	String text();

	/**
	 * @param charName
	 * @return true if event has character
	 */
	boolean hasCharacter(String charName);

}
