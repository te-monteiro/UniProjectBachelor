/**
 *
 */
package inters;

import java.util.Iterator;

/**
 * @author Afonso Figuinha
 *
 */
public interface Actor {

	/**
	 * @return actor name
	 */
	String name();

	/**
	 * Add show to actor list of shows
	 *
	 * @param currentShow
	 */
	void addShow(String show);

	/**
	 * @return number of shows participated
	 */
	int nShows();

	/**
	 * @return all shows this actor appeared
	 */
	Iterator<String> shows();

	/**
	 * @param currentShow
	 * @return true if actor has show in list
	 */
	boolean hasShow(String currentShow);

	/**
	 * Increment number of roles
	 */
	void addRole();

}
