package inters;

import java.util.Iterator;
import java.util.List;

public interface Show {

	/**
	 * @return name of show
	 */
	String name();

	/**
	 * @return number of episodes
	 */
	int nEpisodes();

	/**
	 * @return number of seasons
	 */
	int nSeasons();

	/**
	 * add one more season and increment nSeasons
	 */
	void addSeason();

	/**
	 * @param seasonNumber
	 * @return true if show has that season number
	 */
	boolean hasSeason(int seasonNumber);

	/**
	 * @param seasonNumber
	 * @param episodeTitle
	 * @return number of added episode
	 */
	int addEpisode(int seasonNumber, String episodeTitle);

	/**
	 * @param characterName
	 * @return character with that name or null
	 */
	Character getCharacter(String characterName);

	/**
	 * Add character to the show
	 *
	 * @param kind
	 * @param characterName
	 * @param actorNameOrCompanyName
	 * @param feeEpisodeOrCostSeason
	 * @return how many shows the actor has participated in
	 */
	void addCharacter(String characterName, String actorNameOrCompanyName, int feeEpisodeOrCostSeason);

	/**
	 * Add parent child relationship to both
	 *
	 * @param parent
	 * @param kid
	 */
	void addRelationship(String parentName, String kidName);

	/**
	 * Add lovers relationship for both
	 *
	 * @param lover1
	 * @param lover2
	 */
	void addRomRelationship(String lover1, String lover2);

	/**
	 * @param epiN
	 * @return true if shows has episode in a certain season
	 */
	boolean hasEpisode(int seasonN, int epiN);

	/**
	 * Add event to list of events of a certain episode
	 *
	 * @param event
	 * @param seasonN
	 * @param epiN
	 * @param charN
	 * @param charList
	 */
	void addEvent(String event, int seasonN, int epiN, List<String> charList);

	/**
	 * @return iterator of all seasons in the show
	 */
	Iterator<Season> seasons();

	/**
	 *
	 * @param season1
	 * @param season2
	 * @return iterator of seasons between this interval
	 */
	Iterator<Season> seasonsInterval(int season1, int season2);

	/**
	 * Add quote to character
	 *
	 * @param seasonN
	 * @param epiN
	 * @param charName
	 * @param quote
	 */
	void addQuote(int seasonN, int epiN, String charName, String quote);

	/**
	 * @param quote
	 * @return true if show has quote
	 */
	boolean hasQuote(String quote);

	/**
	 * @param quote
	 * @return iterator with all quote owners
	 */
	Iterator<String> quoteOwners(String quote);

	/**
	 * @param charName
	 * @return seasons with character
	 */
	Iterator<Season> seasonsWithChar(String charName);

	/**
	 * @param char1
	 * @param char2
	 * @return List of related people untill the other char ordered by the oldest
	 */
	List<String> related(String char1, String char2);

	/**
	 * @param actorName
	 * @return character by its actor name
	 */
	Character characterByActor(String actorName);

	/**
	 * @param charName
	 * @return number of seasons with character in this show
	 */
	int nSeasonsWithChar(String charName);

}
