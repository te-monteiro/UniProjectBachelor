package inters;
/**
 *
 */

import java.util.Iterator;
import java.util.List;

import exceps.ActorNotExistsException;
import exceps.CharacterNotExistsException;
import exceps.DuplicatedCharacterNameException;
import exceps.EpisodeNotExistsException;
import exceps.InvalidSeasonsIntervalException;
import exceps.NegativeFeeException;
import exceps.NoSeasonException;
import exceps.NoShowSelectedException;
import exceps.NoVirtualCharactersException;
import exceps.NotAsRomanticException;
import exceps.NotQuoteException;
import exceps.NotRelatedException;
import exceps.RelationExistsException;
import exceps.SamePersonException;
import exceps.SeasonNotExistsException;
import exceps.ShowAlreadyExistsException;
import exceps.ShowNotExistsException;
import exceps.UnknownKindException;
import exceps.VirtualActorException;

/**
 * @author Afonso Figuinha
 *
 */
public interface ShowPedia {

	/**
	 * @return current selected show
	 * @throws NoCurrentShowException
	 */
	Show currentShow() throws NoShowSelectedException;

	/**
	 * Create new show, start a first season with no episodes and chars
	 *
	 * @param showName
	 * @throws ShowAlreadyExistsException
	 */
	void addShow(String showName) throws ShowAlreadyExistsException;

	/**
	 * Change current show to showName
	 *
	 * @param showName
	 * @throws ShowNotExistsException
	 */
	void switchToShow(String showName) throws ShowNotExistsException;

	/**
	 * Add season to the current show
	 *
	 * @throws NoShowSelectedException
	 */
	void addSeason() throws NoShowSelectedException;

	/**
	 * Add episode to current show
	 *
	 * @param seasonNumber
	 * @param episodeTitle
	 * @return number of added episode
	 * @throws NoShowSelectedException
	 * @throws NoSeasonException
	 */
	int addEpisode(int seasonNumber, String episodeTitle) throws NoShowSelectedException, SeasonNotExistsException;

	/**
	 * @return current show name (Current show exists)
	 */
	String currentShowName();

	/**
	 * Add real or virtual character to show and maybe list of characters
	 *
	 * @param kind
	 * @param characterName
	 * @param actorNameOrCompanyName
	 * @param feeEpisodeOrCostSeason
	 * @return how many shows the actor has participated in
	 * @throws NoShowSelectedException
	 * @throws UnknownKindException
	 * @throws DuplicatedCharacterNameException
	 * @throws NegativeFeeException
	 */
	int addCharacter(String kind, String characterName, String actorNameOrCompanyName, int feeEpisodeOrCostSeason)
			throws NoShowSelectedException, UnknownKindException, DuplicatedCharacterNameException,
			NegativeFeeException;

	/**
	 * Add a parent child relationship
	 *
	 * @param parent
	 * @param child
	 * @throws NoShowSelectedException
	 * @throws RelationshipNotPossibleException
	 * @throws CharacterNotExistsException
	 */
	void addRelationship(String parent, String child)
			throws NoShowSelectedException, SamePersonException, CharacterNotExistsException, RelationExistsException;

	/**
	 * @param parent
	 * @return number of kids (Character must exist)
	 */
	int numberOfKids(String parent);

	/**
	 * @param child
	 * @return number of parents (Character exists)
	 */
	int numberOfParents(String child);

	/**
	 * Add romance between two characters
	 *
	 * @param lover1
	 * @param lover2
	 * @throws NoShowSelectedException
	 * @throws SamePersonException
	 * @throws CharacterNotExistsException
	 */
	void addRomance(String lover1, String lover2)
			throws NoShowSelectedException, SamePersonException, CharacterNotExistsException, RelationExistsException;

	/**
	 * Add event to a episode in a certain season with a list of characters
	 *
	 * @param event
	 * @param seasonN
	 * @param epiN
	 * @param charN
	 * @param charList
	 * @throws NoShowSelectedException
	 * @throws SeasonNotExistsException
	 * @throws EpisodeNotExistsException
	 * @throws CharacterNotExistsException
	 */
	void addEvent(String event, int seasonN, int epiN, int charN, List<String> charList) throws NoShowSelectedException,
			SeasonNotExistsException, EpisodeNotExistsException, CharacterNotExistsException, SamePersonException;

	/**
	 * Adds quote to a character that appears in a certain season and episode
	 *
	 * @param seasonN
	 * @param epiN
	 * @param charName
	 * @param quote
	 * @throws NoShowSelectedException
	 * @throws SeasonNotExistsException
	 * @throws EpisodeNotExistsException
	 * @throws CharacterNotExistsException
	 */
	void addQuote(int seasonN, int epiN, String charName, String quote) throws NoShowSelectedException,
			SeasonNotExistsException, EpisodeNotExistsException, CharacterNotExistsException;

	/**
	 * @param season1
	 * @param season2
	 * @return All events in all seasons between a interval
	 * @throws NoShowSelectedException
	 * @throws InvalidSeasonsIntervalException
	 */
	Iterator<Season> seasonsOutline(int season1, int season2)
			throws NoShowSelectedException, InvalidSeasonsIntervalException;

	/**
	 * @param charName
	 * @return Character by name
	 * @throws NoShowSelectedException
	 * @throws CharacterNotExistsException
	 */
	Character getCharacter(String charName) throws NoShowSelectedException, CharacterNotExistsException;

	/**
	 * @param charName
	 * @return seasons that a character appear (Character exists)
	 */
	Iterator<Season> seasonsWithChar(String charName);

	/**
	 * @param char1
	 * @param char2
	 * @return iterator in order of relation by the parent to the child
	 * @throws NoShowSelectedException
	 * @throws CharacterNotExistsException
	 * @throws SamePersonException
	 * @throws NotRelatedException
	 */
	Iterator<String> related(String char1, String char2)
			throws NoShowSelectedException, CharacterNotExistsException, SamePersonException, NotRelatedException;

	/**
	 * @param quote
	 * @return iterator of owners of a quote
	 * @throws NoShowSelectedException
	 * @throws NotQuoteException
	 */
	Iterator<String> quoteOwners(String quote) throws NoShowSelectedException, NotQuoteException;

	/**
	 * @param charName
	 * @return iterator of shows that a actor that plays this character appears by
	 *         alphabetical order
	 * @throws NoShowSelectedException
	 * @throws CharacterNotExistsException
	 * @throws VirtualActorException
	 */
	Iterator<String> alsoAppearsOn(String charName)
			throws NoShowSelectedException, CharacterNotExistsException, VirtualActorException;

	/**
	 * @param actorName
	 * @return Map with all actors which are at least as romantic as that actor by
	 *         descending order of relations count, number of shows (less is more
	 *         romantic), number of shows with romantic relations(more is more
	 *         romantic), alphabetical;
	 * @throws ActorNotExistsException
	 * @throws NotAsRomanticException
	 */
	Iterator<List<String>> mostRomantic(String actorName) throws ActorNotExistsException, NotAsRomanticException;

	/**
	 * @return Company with most revenue sorted by total fees which is fee from a
	 *         character per season times number of seasons, number of characters
	 *         (less is better), alphabetical
	 * @throws NoVirtualCharactersException
	 */
	List<String> kingOfCGI() throws NoVirtualCharactersException;

}
