/**
 *
 */
package inters;

import java.util.Iterator;
import java.util.Map.Entry;

/**
 * @author Afonso Figuinha
 *
 */
public interface Company {

	/**
	 * @return company name
	 */
	String name();

	/**
	 * Add character key with map with value currentShow
	 *
	 * @param characterName
	 * @param currentShow
	 */
	void addCharacter(String characterName, String currentShow);

	/**
	 * @param charName
	 * @return true if company has character
	 */
	boolean hasCharacter(String charName);

	int nCharacters();

	/**
	 * @return iterator of all character with its show
	 */
	Iterator<Entry<String, String>> characterWShows();

}
