/**
 *
 */
package inters;

import java.util.Iterator;
import java.util.List;

/**
 * @author Afonso Figuinha
 *
 */
public interface Episode {

	/**
	 * @return episode number
	 */
	int number();

	/**
	 * @return episode name
	 */
	String name();

	/**
	 * @return iterator of events
	 */
	Iterator<Event> events();

	/**
	 * @param charName
	 * @return events that character appears
	 */
	Iterator<Event> eventsWithCar(String charName);

	/**
	 * Adds event to episode events list
	 *
	 * @param event
	 * @param charList
	 */
	void addEvent(String event, List<String> charList);

	/**
	 * Add characters to list of characters that appear in this episode
	 *
	 * @param charList
	 */
	void addCharacters(List<String> charList);

	/**
	 * @param charName
	 * @return true if episode contains character
	 */
	boolean hasCharacter(String charName);

}
