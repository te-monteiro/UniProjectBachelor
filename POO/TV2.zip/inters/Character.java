/**
 *
 */
package inters;

import java.util.Iterator;

/**
 * @author Afonso Figuinha
 *
 */
public interface Character {

	String name();

	Iterator<String> parents();

	Iterator<String> kids();

	Iterator<String> siblings();

	Iterator<String> romRelationships();

	/**
	 * @param kidName
	 * @return true if character has kid with that name
	 */
	boolean hasKid(String kidName);

	/**
	 * Add kidName to the list of kids
	 *
	 * @param kidName
	 */
	void addKid(String kidName);

	/**
	 * Add parent Name to the list of parents
	 *
	 * @param parentName
	 */
	void addParent(String parentName);

	/**
	 * @return number of kids
	 */
	int nKids();

	/**
	 * @return number of parents
	 */
	int nParents();

	/**
	 * @param loverName
	 * @return true if character has lover with that name
	 */
	boolean hasLover(String loverName);

	/**
	 * Add lover name to the list
	 *
	 * @param loverName
	 */
	void addLover(String loverName);

	/**
	 * @param actSon
	 * @return true if sibling name is in the list
	 */
	boolean hasSibling(String siblingName);

	/**
	 * Add sibling name to list
	 *
	 * @param siblingName
	 */
	void addSibling(String siblingName);

	/**
	 * @return actor name
	 */
	String actor();

	/**
	 * @return number of romantic relationships
	 */
	int nLovers();

	/**
	 * @return character fee
	 */
	int fee();

	/**
	 * @param parentName
	 * @return true if character has parent
	 */
	boolean hasParent(String parentName);

}
