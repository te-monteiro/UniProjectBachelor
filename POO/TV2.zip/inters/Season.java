/**
 *
 */
package inters;

import java.util.Iterator;
import java.util.List;

/**
 * @author Afonso Figuinha
 *
 */
public interface Season {

	/**
	 * @return iterator of episodes
	 */
	Iterator<Episode> episodes();

	/**
	 * @return season number
	 */
	int number();

	/**
	 * @param charName
	 * @return episodes that character appears
	 */
	Iterator<Episode> episodesWithCar(String charName);

	/**
	 * @param episodeTitle
	 * @return number of the added episode
	 */
	int addEpisode(String episodeTitle);

	/**
	 * @return number of episodes
	 */
	int nEpisodes();

	/**
	 * @param episodeNumber
	 * @return episode with that number
	 */
	Episode getEpisode(int episodeNumber);

	/**
	 * Add characters to list of characters that appear in this season
	 *
	 * @param charList
	 */
	void addCharacters(List<String> charList);

	/**
	 * @param charName
	 * @return true if seasons contains character
	 */
	boolean hasCharacter(String charName);

	/**
	 * @param charName
	 * @return true if season contains quote by character
	 */
	boolean hasQuoteBy(String charName);

	/**
	 * Add character to characters with quotes
	 * 
	 * @param charName
	 */
	void addQuoteBy(String charName);

}
