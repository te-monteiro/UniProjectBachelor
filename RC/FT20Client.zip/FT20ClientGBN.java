
import java.io.File;
import java.io.RandomAccessFile;
import java.util.LinkedList;
import java.util.Queue;

import cnss.simulator.Node;
import ft20.FT20AbstractApplication;
import ft20.FT20_AckPacket;
import ft20.FT20_DataPacket;
import ft20.FT20_FinPacket;
import ft20.FT20_PacketHandler;
import ft20.FT20_UploadPacket;

public class FT20ClientGBN extends FT20AbstractApplication implements FT20_PacketHandler {

	static int SERVER = 1;

	enum State {
		BEGINNING, UPLOADING, FINISHING
	};

	static int DEFAULT_TIMEOUT = 1000;

	private File file;
	private RandomAccessFile raf;
	private int blockSize;
	private int nextPacketSeqN, lastPacketSeqN, windowSize, counterRepeat, timeoutDisplay, lastElement, lastAck;
	private Queue<Integer[]> window;
	private boolean onRepeat, isLastPacket;

	private State state;

	public FT20ClientGBN() {
		super(true, "FT20-ClientGBN");
	}

	public int initialise(int now, int node_id, Node nodeObj, String[] args) {
		super.initialise(now, node_id, nodeObj, args, this);

		raf = null;
		file = new File(args[0]);
		blockSize = Integer.parseInt(args[1]);

		windowSize = Integer.parseInt(args[2]);

		window = new LinkedList<Integer[]>();

		lastElement = 0;
		counterRepeat = 0;
		lastAck = 0;

		onRepeat = false;
		isLastPacket = false;
		timeoutDisplay = DEFAULT_TIMEOUT;
		//we have the tally timeout in this protocol because we want to compare the number of samples

		state = State.BEGINNING;
		lastPacketSeqN = (int) Math.ceil(file.length() / (double) blockSize);

		sendNextPacket(now);
		return 1;
	}

	public void on_clock_tick(int now) {
		switch (state) {
		case BEGINNING:
			if (now == timeoutDisplay) {
				sendNextPacket(now);
			}
			break;
			
		case UPLOADING:
			if (nextPacketSeqN <= lastPacketSeqN) {
				if (now >= timeoutDisplay && counterRepeat <= window.size() && !window.isEmpty()) {
					// First packet of repeat
					if (counterRepeat == 0) {
						timeoutDisplay = now + DEFAULT_TIMEOUT;
						super.tallyTimeout(DEFAULT_TIMEOUT);

						onRepeat = true;
						nextPacketSeqN = window.peek()[0];
					}

					// Case that is not the first packet in the window
					if (counterRepeat < window.size()) {
						counterRepeat++;
						sendRepeatPacket(now);

					} else {
						// !retransmission
						counterRepeat = 0;
						onRepeat = false;
						nextPacketSeqN = window.peek()[0];
						removeFromWindow();
					}

				} else if (window.size() < windowSize && nextPacketSeqN < lastPacketSeqN) {
					// condition that treat when the window have space to send new packet
					sendNextPacket(now);

				}
			}
			break;

		case FINISHING:
			if (lastPacketSeqN == lastAck && isLastPacket) {
				nextPacketSeqN = lastPacketSeqN + 1;
				counterRepeat++;
				sendNextPacket(now);
				isLastPacket = false;

			} else if (lastAck <= lastPacketSeqN && now == timeoutDisplay) {
				sendNextPacket(now);
			}

			break;
		}

	}

	/**
	 * Send packet one by one during retransmission
	 * 
	 * @param now
	 */
	private void sendRepeatPacket(int now) {
		super.sendPacket(now, SERVER, readDataPacket(file, nextPacketSeqN, now));
		window.remove();
		Integer[] packInfo = new Integer[2];
		packInfo[0] = nextPacketSeqN;
		packInfo[1] = now;
		window.add(packInfo);
		nextPacketSeqN++;
	}

	/**
	 * Send the new packet
	 * 
	 * @param now
	 */
	private void sendNextPacket(int now) {
		switch (state) {
		case BEGINNING:
			timeoutDisplay = now + DEFAULT_TIMEOUT;
			super.tallyTimeout(DEFAULT_TIMEOUT);
			super.sendPacket(now, SERVER, new FT20_UploadPacket(file.getName(), now));
			break;

		case UPLOADING:
			nextPacketSeqN++;

			// Add the first packet of the window
			if (window.isEmpty()) {
				timeoutDisplay = now + DEFAULT_TIMEOUT;
				super.tallyTimeout(DEFAULT_TIMEOUT);
			}

			super.sendPacket(now, SERVER, readDataPacket(file, nextPacketSeqN, now));
			Integer[] doc = new Integer[2];
			doc[0] = nextPacketSeqN;
			doc[1] = now;
			window.add(doc);
			lastElement = nextPacketSeqN;

			break;
		case FINISHING:
			timeoutDisplay = now + DEFAULT_TIMEOUT;
			super.tallyTimeout(DEFAULT_TIMEOUT);

			super.sendPacket(now, SERVER, new FT20_FinPacket(nextPacketSeqN, now));
			break;
		}
	}

	@Override
	public void on_receive_ack(int now, int client, FT20_AckPacket ack) {
		// last ack received
		lastAck = ack.cSeqN;
		super.tallyRTT(now - ack.timestamp);

		switch (state) {
		case BEGINNING:
			state = State.UPLOADING;
			break;
		case UPLOADING:
			if (!window.isEmpty()) {
				if (window.peek()[0] <= ack.cSeqN && !onRepeat) {
					removeFromWindow();
					nextPacketSeqN = lastElement;
				}
			}
			if (lastAck == lastPacketSeqN) {
				state = State.FINISHING;
				isLastPacket = true;
			}
			break;
		case FINISHING:

			super.log(now, "All Done. Transfer complete...");
			super.printReport(now);

			System.out.println("\nsimulation ended - last processing step with clock = " + now + "\n");
			System.exit(0);
			return;
		}
	}

	/**
	 * Removes acked packets
	 * 
	 * @param cSeqN
	 */
	private void removeFromWindow() {
		while (window.peek()[0] <= lastAck) {
			window.poll();
			if (window.isEmpty())
				break;
		}

		if (!window.isEmpty()) {
			timeoutDisplay = window.peek()[1] + DEFAULT_TIMEOUT;
			super.tallyTimeout(DEFAULT_TIMEOUT);
		}
	}

	private FT20_DataPacket readDataPacket(File file, int seqN, int timestamp) {
		try {
			if (raf == null)
				raf = new RandomAccessFile(file, "r");

			raf.seek(blockSize * (seqN - 1));
			byte[] data = new byte[blockSize];
			int nbytes = raf.read(data);
			return new FT20_DataPacket(seqN, timestamp, data, nbytes);
		} catch (Exception x) {
			throw new Error("Fatal Error: " + x.getMessage());
		}
	}
}