
import java.io.File;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;

import cnss.simulator.Node;
import ft20.FT20AbstractApplication;
import ft20.FT20_AckPacket;
import ft20.FT20_DataPacket;
import ft20.FT20_FinPacket;
import ft20.FT20_PacketHandler;
import ft20.FT20_UploadPacket;

public class FT20ClientSR_DT extends FT20AbstractApplication implements FT20_PacketHandler {

	static int SERVER = 1;

	enum State {
		BEGINNING, UPLOADING, FINISHING
	};

	static double ALFA = 0.875;
	static double BETA = 0.75;

	private File file;
	private RandomAccessFile raf;
	private int blockSize;
	private int nextPacketSeqN, lastPacketSeqN, windowSize, timeoutDisplay, lastAck, counterRepeat;
	private Queue<Integer[]> window;
	private Map<Integer, Integer> ackMap;
	private boolean isLastPacket, onRepeat;

	private double avgRTT, sRTTVar;
	private List<Integer> rttList;
	int defaultTimeout;

	private State state;

	public FT20ClientSR_DT() {
		super(true, "FT20-ClientSR_DT");
	}

	public int initialise(int now, int node_id, Node nodeObj, String[] args) {
		super.initialise(now, node_id, nodeObj, args, this);
		
		defaultTimeout = 1000;

		raf = null;
		file = new File(args[0]);
		blockSize = Integer.parseInt(args[1]);

		windowSize = Integer.parseInt(args[2]);

		window = new LinkedList<Integer[]>();

		ackMap = new HashMap<Integer, Integer>();

		// var aux to make a circular movement and guarantee that at the end the window
		// has same packets
		counterRepeat = 0;

		lastAck = 0;

		onRepeat = false;

		isLastPacket = false;

		timeoutDisplay = defaultTimeout;
		super.tallyTimeout(defaultTimeout);

		state = State.BEGINNING;
		lastPacketSeqN = (int) Math.ceil(file.length() / (double) blockSize);

		rttList = new ArrayList<Integer>();

		avgRTT = 3.0;
		sRTTVar = 0;

		sendNextPacket(now);

		return 1;

	}

	public void on_clock_tick(int now) {
		switch (state) {
		case BEGINNING:
			if (now == timeoutDisplay)
				sendNextPacket(now);

			break;

		case UPLOADING:
			if (lastAck != lastPacketSeqN) {

				if (now == timeoutDisplay) {
					onRepeat = true;
				}

				if (onRepeat && counterRepeat <= window.size()) {
					int minTimeout = 0;
					int auxPacketN = nextPacketSeqN;

					if (!ackMap.containsKey(window.peek()[0]) && (window.peek()[1] + defaultTimeout) <= now) {
						counterRepeat++;
						nextPacketSeqN = window.peek()[0] - 1;
						window.poll();

						sendNextPacket(now);
					}
					while (counterRepeat < window.size()
							&& (ackMap.containsKey(window.peek()[0]) || (window.peek()[1] + defaultTimeout) > now)) {

						counterRepeat++;

						if (!ackMap.containsKey(window.peek()[0])) {

							// to keep the lowest timeout
							if (minTimeout == 0)
								minTimeout = window.peek()[1] + defaultTimeout;
							else if (minTimeout > window.peek()[1] + defaultTimeout) {
								minTimeout = window.peek()[1] + defaultTimeout;
							}
						}

						Integer[] auxPacket = window.poll();
						window.add(auxPacket);
					}

					if (counterRepeat >= window.size()) {

						counterRepeat = 0;

						onRepeat = false;
						if (minTimeout == 0 || minTimeout > window.peek()[1] + defaultTimeout) {

							timeoutDisplay = window.peek()[1] + defaultTimeout;
							super.tallyTimeout(defaultTimeout);

						} else {
							timeoutDisplay = minTimeout;
							super.tallyTimeout(defaultTimeout);
						}
					}

					nextPacketSeqN = auxPacketN;

				} else if (window.size() < windowSize && nextPacketSeqN < lastPacketSeqN) {
					// condition that treat when the window have space to send new packet
					sendNextPacket(now);
				}
			}

			break;

		case FINISHING:

			if (lastPacketSeqN == lastAck && isLastPacket) {

				nextPacketSeqN = lastPacketSeqN + 1;

				timeoutDisplay = now + defaultTimeout;
				super.tallyTimeout(defaultTimeout);

				sendNextPacket(now);
				isLastPacket = false;

			} else if (lastAck <= lastPacketSeqN && now == timeoutDisplay) {
				sendNextPacket(now);
			}

			break;
		}
	}

	/**
	 * Send the new packet
	 * 
	 * @param now
	 */
	private void sendNextPacket(int now) {
		switch (state) {
		case BEGINNING:
			timeoutDisplay = now + defaultTimeout;
			super.tallyTimeout(defaultTimeout);

			super.sendPacket(now, SERVER, new FT20_UploadPacket(file.getName(), now));
			break;

		case UPLOADING:
			nextPacketSeqN++;

			// Add the first packet of the window
			if (window.isEmpty()) {
				timeoutDisplay = now + defaultTimeout;
				super.tallyTimeout(defaultTimeout);

			}
			

			super.sendPacket(now, SERVER, readDataPacket(file, nextPacketSeqN, now));
			Integer[] doc = new Integer[2];
			doc[0] = nextPacketSeqN;
			doc[1] = now;
			window.add(doc);

			break;

		case FINISHING:

			super.sendPacket(now, SERVER, new FT20_FinPacket(nextPacketSeqN, now));
			break;
		}
	}

	private void calcTimeout(int lastRTT, int now) {
		int sum = 0;

		for (int i = 0; i < rttList.size(); i++) {
			sum += rttList.get(i);
		}
		if (!rttList.isEmpty())
			avgRTT = sum / rttList.size(); // oldest RTT

		avgRTT = (ALFA * avgRTT + (1 - ALFA) * lastRTT);

		sRTTVar = BETA * sRTTVar + (1 - BETA) * Math.abs(avgRTT - lastRTT);
		
		defaultTimeout = (int) avgRTT + 4 * (int) sRTTVar;
		
		rttList.add(lastRTT);

	}

	@Override
	public void on_receive_ack(int now, int client, FT20_AckPacket ack) {

		int rtt = now - ack.timestamp;
		rttList.add(rtt);

		super.tallyRTT(rtt);

		switch (state) {
		case BEGINNING:
			state = State.UPLOADING;
			lastAck = ack.cSeqN;

			sRTTVar = rtt / 2;

			calcTimeout(rtt, now);

			break;

		case UPLOADING:

			calcTimeout(rtt, now);

			if (!window.isEmpty()) {
				if (ack.sSeqN == ack.cSeqN && ack.sSeqN == window.peek()[0]) {
					window.poll();

					if (!window.isEmpty()) {
						timeoutDisplay = window.peek()[1] + defaultTimeout;
						super.tallyTimeout(defaultTimeout);
					}

				} else if (lastAck != ack.cSeqN) {
					lastAck = ack.cSeqN;
					removeFromWindow();

				} else if (ack.sSeqN != -1) {
					ackMap.put(ack.sSeqN, ack.sSeqN);

				}
			}
			lastAck = ack.cSeqN;

			if (lastAck == lastPacketSeqN) {

				state = State.FINISHING;
				isLastPacket = true;
			}

			break;

		case FINISHING:

			super.log(now, "All Done. Transfer complete...");
			super.printReport(now);

			System.out.println("\nsimulation ended - last processing step with clock = " + now + "\n");
			System.exit(0);
			return;
		}
	}

	/**
	 * Removes acked packets
	 */
	private void removeFromWindow() {

		if (!window.isEmpty()) {
			int windowP = window.peek()[0];

			while (lastAck >= windowP) {
				if (ackMap.containsKey(windowP)) {
					ackMap.remove(windowP);
				}
				window.poll();

				if (window.isEmpty())
					break;

				windowP = window.peek()[0];
			}

			if (!window.isEmpty() && (window.peek()[1] + defaultTimeout) > timeoutDisplay) {
				timeoutDisplay = window.peek()[1] + defaultTimeout;
				super.tallyTimeout(defaultTimeout);
			}
		}
	}

	private FT20_DataPacket readDataPacket(File file, int seqN, int timestamp) {
		try {
			if (raf == null)
				raf = new RandomAccessFile(file, "r");

			raf.seek(blockSize * (seqN - 1));
			byte[] data = new byte[blockSize];
			int nbytes = raf.read(data);
			return new FT20_DataPacket(seqN, timestamp, data, nbytes);
		} catch (Exception x) {
			throw new Error("Fatal Error: " + x.getMessage());
		}
	}
}
