import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.Socket;
import java.net.URL;

/** A really simple HTTP Client
 * 
 * @author The RC - FCT/UNL class instructors
 *
 */

public class GetFile {
	private static final int BUF_SIZE = 1024;
	private static final int REQUEST_SIZE = 8192;
	private static long requestStartBytes = 0;
	private static Stats stats;
	
	/*
	 * metodo auxiliar para determinar a partir de que byte comeca o request pedido
	 */
	private synchronized static long requestBytes(long requestLenght) {
		long startBytes;
     	startBytes = requestStartBytes;
		requestStartBytes += requestLenght;
		return startBytes;
	}
	
	static class Requester implements Runnable {
		String fName;
		String host;
		String path;
		int port;
		
		public Requester(URL u) {
			processUrl(u);
		}
		
		@Override
		public void run() {
			try {
				requestFile();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		/*
		 * metodo principal da thread que fica a receber bytes e a escreve los no ficheiro enquanto houver bytes para receber
		 */
		private void requestFile() throws Exception{
			RandomAccessFile outFile = new RandomAccessFile(fName,"rw");
			Socket sock = null;
			InputStream in = null;
			long startBytes=0;
			long endBytes=0;
			int code = -1;
			int n;
			int localStart=0;
			boolean done = false;
			boolean failed = false;
			byte[] buffer = new byte[BUF_SIZE];
			while (!done) {
				sock = new Socket(host, port);
				if(in != null)
					in.close();
				in = sock.getInputStream();
				if(!failed) {
					startBytes = requestBytes(REQUEST_SIZE);
					endBytes = startBytes + REQUEST_SIZE -1 ;
				}
				localStart=0;
				sendRequest(startBytes, endBytes, path, host, sock);
				code = readAnswer(sock, in);
				while ((n = in.read(buffer)) > 0) {
					outFile.seek(startBytes);
					outFile.write(buffer, 0, n);
					startBytes += n;
					localStart+=n;
				}
				stats.newRequest(localStart);
				if((code == 416 && n <= 0))
					done = true;
				if(startBytes != endBytes+1) {
					failed= true;
					}
				else failed = false;
			}
			outFile.close();
			sock.close();
		}
		
		/*
		 * metodo auxiliar que divide o URL em port, path, fileName e host
		 */
		private void processUrl(URL u) {
			this.port = u.getPort() == -1 ? 80 : u.getPort();
			this.path = u.getPath() == "" ? "/" : u.getPath();
			String f = (u.getPath() == "" ? "/nameless" : u.getPath().substring(0, u.getPath().length()));
			this.fName = f.substring(f.lastIndexOf('/') + 1) + ".copy";
			this.host = u.getHost();
		}
	}
	
	public static void main(String[] args) throws Exception {
		if ( args.length < 1 ) {
			System.out.println("Usage: java HttpClientDemo url_to_access");
			System.exit(0);
		}
		stats = new Stats();
		Thread[] reqs = new Thread[args.length];
		for(int i = 0; i < args.length; i++) {
			URL u = new URL(args[i]);
			reqs[i] = new Thread(new Requester(u));
			reqs[i].start();
		}
		for(int i = 0; i< reqs.length; i++) {
			reqs[i].join();
		}
		stats.printReport();
	}

	/*
	 * metodo auxiliar que constroi e envia um http request dado 
	 */
	private static void sendRequest(long xRange, long yRange, String path, String host, Socket sock) throws Exception {
		OutputStream out = sock.getOutputStream();
		String request = String.format(
				"GET %s HTTP/1.0\r\n"+
				"Host: %s\r\n"+
				"Range: bytes=%d-%s\r\n"+
				"User-Agent: X-Client-Demo-RC2019\r\n\r\n", path, host, xRange, yRange);
		out.write(request.getBytes());
		
	}
	
	
	
	/*
	 * metodo auxiliar que le o cabecalho da resposta recebida do servidor e devolve o codigo associado
	 */
	private static int readAnswer(Socket sock, InputStream in) throws Exception {
		String answerLine = Http.readLine(in);  // first line is always present
		int code = Integer.parseInt(Http.parseHttpReply(answerLine)[1]);
		answerLine = Http.readLine(in);
		while ( !answerLine.equals("") ) {
			answerLine = Http.readLine(in);
		}
		return code;
	}

}