import java.util.*;

/*
 * My Distance-Vector Routing Implementation
 */
public class DV implements RoutingAlgorithm
{
	static final int LOCAL = -1;		// local destination/interface
	static final int UNKNOWN = -2;		// unknown destination
	static final int BROADCAST = 255;	// broadcast address
	static final int INFINITY = 60;		// "infinity" metric
	
	Router thisRouter = null;  // the router were this algorithm is running

	SortedMap<Integer, DVRoutingTableEntry> routingTable;
	int updateInterval;
	boolean pReverse = false;
	boolean pExpire = false;

	public DV()
	{
		this.routingTable = new TreeMap<Integer, DVRoutingTableEntry>();
	}

	public void setRouterObject(Router obj)
	{
		thisRouter = obj;
	}

	public void setUpdateInterval(int u)
	{
		updateInterval = u;
	}

	public void setAllowPReverse(boolean flag)
	{
		pReverse = flag;
	}

	public void setAllowExpire(boolean flag)
	{
		pExpire = flag;
	}

	public void initalise()
	{
		routingTable.put(thisRouter.getId(), new DVRoutingTableEntry(thisRouter.getId(), LOCAL, 0, thisRouter.getCurrentTime()));
	}

	public int getNextHop(int destination)
	{
		DVRoutingTableEntry entry = routingTable.get(destination);
		if(entry == null || entry.getMetric() == INFINITY){
			return UNKNOWN;
		} else
			return entry.getInterface();

	}

	public void tidyTable()
	{
		Set<Integer> removeSet = new HashSet<Integer>();
		for(DVRoutingTableEntry entry: routingTable.values()){
			if((thisRouter.getCurrentTime() - entry.getTime()) > 3*updateInterval && entry.getMetric() == INFINITY && pExpire)
				removeSet.add(entry.getDestination());
			
			if(!thisRouter.getInterfaceState(entry.getInterface()) && entry.getMetric() != INFINITY){
			int dest = entry.getDestination();
			routingTable.put(dest, new DVRoutingTableEntry(dest, entry.getInterface(), INFINITY, thisRouter.getCurrentTime()));
			}
		}
		routingTable.keySet().removeAll(removeSet);
	}

	public Packet generateRoutingPacket(int iface)
	{
		Packet p = new RoutingPacket(thisRouter.getId(), BROADCAST);

		Payload payload = new Payload();
		for(DVRoutingTableEntry entry: routingTable.values()){
		DVRoutingTableEntry sendEntry = new DVRoutingTableEntry(entry.getDestination(), entry.getInterface(), entry.getMetric(), entry.getTime());
		if(entry.getInterface() == iface && pReverse){
			sendEntry.setMetric(INFINITY);
		}
		payload.addEntry(sendEntry);
		}

		p.setPayload(payload);

		return p;
	}

	public void processRoutingPacket(Packet p, int iface)
	{
		Payload pl = p.getPayload();
		int cost = thisRouter.getInterfaceWeight(iface);

		for(Object entryO : pl.getData()){
			DVRoutingTableEntry entry = (DVRoutingTableEntry) entryO;
			int dest = entry.getDestination();
			DVRoutingTableEntry myEntry = this.routingTable.get(dest);
			if(myEntry == null){
				if (cost + entry.getMetric() < INFINITY){
					myEntry = new DVRoutingTableEntry(dest, iface, entry.getMetric() + cost, thisRouter.getCurrentTime());
					routingTable.put(dest, myEntry);
				}
			}else{
				if(iface == myEntry.getInterface()){
					int time = 0;
					int newCost = cost + entry.getMetric();
					
					int myMetric = myEntry.getMetric();
					int rcvMetric = entry.getMetric();
					if (myMetric == newCost || (rcvMetric == 60 && myMetric == 60))
						time = myEntry.getTime();
					else
						time = thisRouter.getCurrentTime();
								

					if(newCost > 60)
						newCost = 60;
					
					routingTable.put(dest, new DVRoutingTableEntry(dest, iface, newCost, time));
				}
				else if(entry.getMetric() + cost < myEntry.getMetric()){
				routingTable.put(dest, new DVRoutingTableEntry(dest, iface, cost + entry.getMetric(), thisRouter.getCurrentTime()));
				}
			}
		}
	}

	public void showRoutes()
	{
		System.out.println("Router " + thisRouter.getId() );
		for (DVRoutingTableEntry entry : routingTable.values()) {
			System.out.println("d " + entry.getDestination() + " i " + entry.getInterface() + " m " + entry.getMetric());
		}
	}
}



/*
 * My Routing Table Entry
 */
class DVRoutingTableEntry implements RoutingTableEntry
{
	private int d, i, m, t;

	public DVRoutingTableEntry(int d, int i, int m, int t)
	{
		this.d = d;
		this.i = i;
		this.m = m;
		this.t = t;
	}

	public boolean equals(Object o){
		if(this == o) return true;
		if(o == null || getClass() != o.getClass()) return false;
		DVRoutingTableEntry entry = (DVRoutingTableEntry) o;
		return d == entry.d;
	}

	public int hashCode() {
        return Objects.hash(d);
    }

	public int getDestination() { return d; }

	public void setDestination(int d) { this.d = d; }

	public int getInterface() { return i; }

	public void setInterface(int i) { this.i = i; }

	public int getMetric() { return m; }

	public void setMetric(int m) { this.m = m; } 

	public int getTime() { return t; }

	public void setTime(int t) { this.t = t; }

	public String toString() 
	{
		return "Destination: " + d + "\nInterface: " + i + "\nMetric: " + m + "\nTime: " + t;
	}
}

