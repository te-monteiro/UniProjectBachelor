import java.util.*;
import cnss.lib.AbstractControlAlgorithm;
import cnss.simulator.GlobalParameters;
import cnss.simulator.Link;
import cnss.simulator.Node;
import cnss.simulator.Packet;

/**
 * 
 * @author Andreia Mendes - 51749
 * @author Teresa Monteiro - 52597
 *
 */

public class Flood extends AbstractControlAlgorithm {

	private Node nodeObj;
	private Link[] links;
	private boolean filter;
	private boolean drop_duplicates;
	//<sender_Id, iFace>
	private Map<Integer, Integer> map;
	//<sender_Id, seqNum>
	private Map<Integer, Integer> knownPackets;



	public Flood() {
		super("flood students version");
	}

	public int initialise(int now, int node_id, Node mynode, GlobalParameters parameters, Link[] links, int nint) {
		super.initialise(now, node_id, mynode, parameters, links, nint);
		super.set_trace(parameters.containsKey("trace"));
		map = new HashMap<Integer, Integer>();
		knownPackets = new HashMap<Integer, Integer>();


		filter = parameters.containsKey("filter");
		drop_duplicates = parameters.containsKey("drop_duplicates");

		trace(now, "starting - drop dup: " + drop_duplicates+ " filter: " + filter);
		nodeObj = mynode;
		this.links = links;
		return 0;
	}


	private void flood_packet (int now, Packet p, int iface) {
		int copiesSent = 0;
		// do the flood
		if(copiesSent == 0) {
			for (int i = 0; i < links.length; i++) {

				if (i != iface && links[i].isUp()) {
					// always send a copy of p, not the object itself
					nodeObj.send(p.getCopy(), i);
					copiesSent++;
				}
			}
		}
		if (copiesSent == 0) { // allows the local node to count dropped packets
			nodeObj.send(p, UNKNOWN);
		}
		trace(now, "forwarded " + copiesSent + " packet copy(ies)");
	}


	public void forward_packet(int now, Packet p, int iface) {
		int wkSource = p.getSource();
		int wkDest = p.getDestination();

		if ( drop_duplicates ) {
			//duplicated Packet
			if(knownPackets.containsKey(wkSource) && knownPackets.get(wkSource) == p.getSequenceNumber()) {

				trace(now, "dropped duplicate");
				nodeObj.send(p, UNKNOWN);
				return;

			} else { 
				//new Packet
				knownPackets.put(wkSource, p.getSequenceNumber());
			}	
		} 

		if ( p.getDestination() == nodeObj.getId()) {
			Packet localPacket = p.getCopy();
			nodeObj.send(localPacket, LOCAL);
			trace(now, "forwarded a packet locally sent to this node");
			return; // all done
		}

		if ( p.getDestination() == Packet.BROADCAST ) {
			Packet localPacket = p.getCopy();
			localPacket.setDestination(nodeObj.getId());
			nodeObj.send(localPacket, LOCAL);
			trace(now, "forwarded a copy of a broadcasted packet to this node");
		}

		if ( filter ) {
			//if the entry(key) already exists the iface is replaced. Other wise it creates a new entry. 
			map.put(wkSource, iface);

			//send to the known link
			if(map.containsKey(wkDest)) {	
				int wkIface = map.get(wkDest);

				//to guarantee that the packet is flood, if the link known is down at the moment
				if(links[wkIface].isUp()) {		
					nodeObj.send(p.getCopy(), wkIface);
					return;
				} 
				//If this link is out it will not be removed from the map because it may avoid a 
				// flood in case that the link turn up again and the map it was not updated yet.
			}
		}
		flood_packet (now, p, iface);
	}
}
