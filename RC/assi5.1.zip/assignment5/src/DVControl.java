// the skeleton control algorithm (routing) of a node that will
// use the distance-vector (DV) routing algorithm

import cnss.simulator.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map.Entry;
import java.util.SortedMap;
import java.util.TreeMap;


import cnss.lib.*;

/**
 * 
 * @author Andreia Mendes 51749
 * @author Teresa Monteiro 52597
 *
 */
public class DVControl extends AbstractControlAlgorithm {

	// Do not modify
	static int INFINITY = 1000000; 
	static int REFERENCE_BAND = 100000000; // reference bandwidth = 100 Mbps
	static int UPDATE_INTERVAL = 1000;

	// variables that will contain the parameters transmitted by the CNSS node code and
	// assigned by the initialise upcall()
	private Node nodeObj;					// the CNSS node code that supports this node algorithm 
	private int nodeId;						// my Id or address
	private GlobalParameters parameters;	// configuration file parameters
	private Link[] links;					// this node links, numbered from 0 .. nInterfaces - 1
	private int nInterfaces;				// this node number of interfaces, each with a link 
	// link attached

	// variables containing the flags that drive traces - calls to the trace() method are
	// shown or not and stages executed by the algorithm besides the base line solution
	// these flags are set by the initialise() upcall and their values are driven by the
	// configuration file content
	private boolean tracingOn;
	private boolean triggered; // if true we should use triggered updates
	private boolean preverse; // if true split horizon with poison reverse should be implemented
	private boolean expire;  // if true it should expire useless routing table entries
	// that is, those with metric or cost infinity for more 3 times the update interval

	// YOUR VARIABLES HERE, NAMELY THE ROUTING TABLE
	private SortedMap<Integer, DVRoutingTableEntry> routingTable;

	public DVControl() {
		super("dv control");
	}



	/**
	 * Initializes the control algorithm and returns the required
	 * control_clock_tick_period. If control_clock_tick_period == 0, no clock_ticks
	 * will be submitted; Interfaces are numbered 0 to nint-1. Each has a link
	 * attached: links[i] Interface; -1 is virtual and denotes, when needed, the
	 * local loop interface.
	 * 
	 * DV code: initialises the routing table 
	 * DV Code: if ( triggered ) sends first announcements
	 * 
	 * @param now        the current virtual clock value
	 * @param id         this node id
	 * @param nodeObj    a reference to the node object executing this algorithm
	 * @param parameters the collection of global parameters
	 * @param links      the nodes links array
	 * @param nint       the number of interfaces (or links) of this node, not including the LOCAL one
	 * @return the requested clock_tick_period
	 */
	public int initialise(int now, int node_id, Node mynode, GlobalParameters parameters, Link[] links, int nint) {
		super.initialise(now, node_id, mynode, parameters, links, nint);
		this.parameters=parameters;
		nodeId = node_id;
		nodeObj = mynode;
		this.links=links;
		nInterfaces=nint;

		tracingOn = parameters.containsKey("trace");
		preverse = parameters.containsKey("preverse");
		expire = parameters.containsKey("expire");
		triggered = parameters.containsKey("triggered");

		super.set_trace(tracingOn);
		trace(now, "starting w/ period / trig. upds / shpr / expire: "+UPDATE_INTERVAL+","+triggered+","+preverse+","+expire);

		// DV CODE HERE:
		//<dest, tableEntry>
		routingTable = new TreeMap<Integer, DVRoutingTableEntry>();
		//first entry to get to this node with cost 0.
		routingTable.put(nodeId, new DVRoutingTableEntry(nodeId, LOCAL, 0, now));

		if(triggered) {
			sendAnnouncements();
		}

		return UPDATE_INTERVAL; // do not touch this line
	}



	/**
	 * A periodic clock interrupt. 
	 * 
	 * DV code: sends announcements to neighbors
	 * DV code: if ( expire ) expires stalled entries in the routing table
	 * 
	 * @param now the current virtual clock value
	 */
	public void on_clock_tick(int now) { 	
		//trace(now, "on clock tick ");
		if(expire) {
			//List to avoid the routingTable concurrency ( entrySet vs remove) 
			//List<DestToRemove>
			List<Integer> delete = new ArrayList<Integer>();

			for(Entry<Integer, DVRoutingTableEntry> e: routingTable.entrySet()){

				DVRoutingTableEntry wkE = e.getValue();
				int wkDest = wkE.getDestination();
				// remove entries after 3 update intervals as stale entries
				boolean toExpire = wkE.getTime() < now - 3*UPDATE_INTERVAL;
				if(nodeId != wkDest && wkE.getMetric() == INFINITY && toExpire){
					delete.add(wkDest);
				}
			}

			for(int i = 0; i < delete.size(); i++) {

				routingTable.remove(delete.get(i));

			}
		}

		sendAnnouncements();
	}

	/**
	 * Given a packet from another node, forward it to the appropriate interfaces
	 * using nodeObj.send(Packet p, int iface); Packet ttl has already been
	 * decreased and controlled. If the algorithm has no solution to route this packet,
	 * send it to the UNKNOWN interface using nodeObj.send(p,UNKNOWN)
	 * 
	 * DV code: use the routing table contents to forward packets
	 * 
	 * @param now   the current virtual clock value
	 * @param p     the packet to process
	 * @param iface the interface it was received by the node
	 */
	public void forward_packet(int now, Packet p, int iface) {
		// DV CODE HERE:
		//UNKNOWN is the default value of wkIfaceDest
		int wkIfaceDest = UNKNOWN;
		DVRoutingTableEntry wkEntry = routingTable.get(p.getDestination());
		//INFINITY would imply that it has no solution to route this packet
		if (wkEntry != null && wkEntry.getMetric() != INFINITY){
			wkIfaceDest = wkEntry.getInterface();
		}

		nodeObj.send(p, wkIfaceDest);
	}


	/**
	 * Signals a link up event; links[iface].isUp() becomes true
	 * 
	 * DV code: if ( triggered ) sends announcements to neighbors
	 * 
	 * @param now   the current virtual clock value
	 * @param iface interface id where this link is connected
	 */
	public void on_link_up(int now, int iface) {
		trace(now, "interface "+iface + " link up");
		// DV CODE HERE:
		if(triggered) {
			sendAnnouncements();
		}
	}

	/**
	 * Signals a link down event; links[iface].isUp() becomes false
	 * 
	 * DV code: update routing table entries
	 * DV code: if ( triggered ) sends announcements to neighbors
	 * 
	 * @param now   the current virtual clock value
	 * @param iface interface id where this link is connected
	 */
	public void on_link_down(int now, int iface) {
		trace(now, "interface "+iface + " link down");
		// DV CODE HERE:
		for (Entry<Integer, DVRoutingTableEntry> e: routingTable.entrySet()) {

			DVRoutingTableEntry wkE = e.getValue();

			if(wkE.getInterface() == iface) {

				e.getValue().setInterface(iface);
				e.getValue().setMetric(INFINITY);

			}
		}

		if(triggered) {
			sendAnnouncements();
		}	
	}


	/**
	 * Given a control packet from another node, process it
	 * 
	 * DV code: process the DV announcement contained in packet p
	 * DV code: if ( triggered && routing table updated ) sends announcements to neighbors
	 * 
	 * @param now   the current virtual clock value
	 * @param p     the packet to process
	 * @param iface the interface it came in from
	 */
	public void on_receive(int now, Packet p, int iface) {
		// DV CODE HERE:
		boolean changed = false;
		DVControlPayload wkPayload = new DVControlPayload(p.getPayload());
		int total = wkPayload.getTotal();
		int[] wkAnnouc = wkPayload.getAnnouncements(total);

		int wkLinkMetric = getInterfaceMetric(iface);

		for ( int i = 0; i < total; i++) {
			int wkDest = wkAnnouc[i*2];
			//Math.min to guarantee that the metric is always <= INFINITY
			int wkMetric = Math.min(INFINITY, wkAnnouc[i*2 + 1] + wkLinkMetric);

			DVRoutingTableEntry	wkOldEntry = routingTable.get(wkDest);

			if(wkOldEntry == null || wkMetric < wkOldEntry.getMetric() || 
					(iface == wkOldEntry.getInterface() && wkMetric > wkOldEntry.getMetric())) {

				changed = true;
				routingTable.put(wkDest, new DVRoutingTableEntry(wkDest, iface, wkMetric, now));

			} else if (iface == wkOldEntry.getInterface() && wkOldEntry.getMetric()!= INFINITY && nodeId != wkDest) {
				wkOldEntry.setTime(now);
			}
		}

		if(triggered && changed) {
			sendAnnouncements();
		}

	}

	public void showControlState(int now) {
		trace(now, "has no extra state to show");
	}


	/**
	 * Prints the routing table to the screen.
	 * The format is :
	 * <blank line>
	 * Node <id> routing table at time stamp
	 * d <destination> i <interface> m <metric> lu <last_update>
	 * d <destination> i <interface> m <metric> lu <last_update>
	 * d <destination> i <interface> m <metric> lu <last_update>
	 */
	public void showRoutingTable(int now) {
		System.out.println("\nRouter "+nodeId+" time "+now);

		// DV CODE HERE:
		for (Entry<Integer, DVRoutingTableEntry> e: routingTable.entrySet()) {
			DVRoutingTableEntry wkE = e.getValue();
			System.out.println(wkE.toString());
		}

	}

	/**
	 * Auxiliary method
	 */
	/**
	 * Sees all neighbor's interface and send an announcement to the ones with link up  
	 */
	private void sendAnnouncements() {

		for ( int i = 0; i < nInterfaces; i++) {
			Packet p = createVec(i);
			if (links[i].isUp()) {
				nodeObj.send(p.getCopy(), i);
			}
		}
	}

	/**
	 * Iterate the routingTable information and put it at a packet, to return
	 * 
	 * @param iface the interface to send
	 */
	private Packet createVec(int iface) {

		Collection<DVRoutingTableEntry> wkmap = routingTable.values();
		int[] announcements = new int[wkmap.size()*2];
		int i = 0;

		for (Entry<Integer, DVRoutingTableEntry> e: routingTable.entrySet()) {

			DVRoutingTableEntry wkEntry = e.getValue();
			announcements[i++] = wkEntry.getDestination();
			//split horizon with poison-reverse
			if(wkEntry.getInterface() == iface && preverse) {
				announcements[i++] = INFINITY;
			} else {
				announcements[i++] = wkEntry.getMetric();
			}	
		}		

		DVControlPayload dvCPayload = new DVControlPayload((routingTable.size()), announcements);
		Packet p = nodeObj.createControlPacket(nodeId, Packet.ONEHOP, dvCPayload.toByteArray() );
		return p;
	}

	/**
	 * Given the link connected to an interface, returns its weight or cost
	 * When the protocol metric is the cost all links is equal to 1 this method is useless
	 * 
	 * @param iface
	 * @return metric
	 */
	private int getInterfaceMetric(int iface) {
		// loopback interfaces are virtual with cost = 0
		// the array of interfaces has no entry for the loopback interface
		if (iface == LOCAL) return 0;
		return (int) ( REFERENCE_BAND / links[iface].getBandWidth()); 
	}

}


