import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class SmartHttpClient {
	private static final int BUF_SIZE = 512;
	private static final int MAX_RETRY = 3;

	private static final int RANGE = 100000;/// 321 deve ser multiplo BUF_SIZE
	private static final String CONTENT_LENGTH = "Content-Length:";

	private static Stats stat;

	public static void main(String[] args) throws Exception {
		if (args.length != 1) {
			System.out.println("Usage: java SmartHttpClient url_to_access");
			System.exit(0);
		}
		String url = args[0];
		URL u = new URL(url);
		// Assuming URL of the form http://server-name:port/path ....
		int port = u.getPort() == -1 ? 80 : u.getPort();
		String path = u.getPath() == "" ? "/" : u.getPath();
		// FileInputStream wkFile;
		// outFile = new RandomAccessFile(wkFile, "rw");

		downloadFile(u.getHost(), port, path);
	}

	private static void downloadFile(String host, int port, String path) throws UnknownHostException, IOException {

		stat = new Stats();
		int totalBytes = 0;
		int minRange = 0;
		int maxRange = RANGE;
		boolean fin = false;
		int fileSize = -1;
		OutputStream wkFile = new FileOutputStream("tmp.out");
		String filename = path.substring(path.lastIndexOf('/') + 1);
		if (filename.equals("")) {
			filename = "index.html";
		}

		while (!fin) {
			
			int numBytes = 0;
			Socket sock = new Socket(host, port);
			OutputStream out = sock.getOutputStream();
			InputStream in = sock.getInputStream();

			String request = String.format("GET " + path + " HTTP/1.0\r\n" + "Host: " + host + "\r\n" + "Range: bytes="
					+ String.valueOf(minRange) + "-" + String.valueOf(maxRange) + "\r\n"
					+ "User-Agent: X-RC2020 SmartHttpClient\r\n\r\n");

			out.write(request.getBytes());

			System.out.println("\nSent Request:\n-------------\n" + request);
			System.out.println("Got Reply:");
			System.out.println("\nReply Header:\n--------------");

			String answerLine = Http.readLine(in); // first line is always present
			System.out.println("first: " + answerLine);
			String[] reply = Http.parseHttpReply(answerLine);
			long[] range = null;

			answerLine = Http.readLine(in);
			while (!answerLine.equals("")) {
			
				String[] head = Http.parseHttpHeader(answerLine);

				answerLine = Http.readLine(in);
				/// System.out.println("get LINEEEE: " + answerLine.indexOf(":", )
				if (answerLine.contains(CONTENT_LENGTH)) {
					fileSize = Integer.parseInt(answerLine.substring(answerLine.lastIndexOf(":") + 2));
					System.out.println("get LINEEEE: " + fileSize);
				}
			}

			if (reply[1].equals("206") || reply[1].equals("200")) {
				int wkCount = 0;
				System.out.println("\nReply Body:\n--------------");
				long time0 = System.currentTimeMillis();
				int n;
				byte[] buffer = new byte[BUF_SIZE];

				while ((n = in.read(buffer)) >= 0) {
					wkCount++;
					wkFile.write(buffer, 0, n);
					//	System.out.println("Range " + RANGE + "  FileSize  " + fileSize + " Max Range " + maxRange + " Min "
					//			+ minRange);

					numBytes += n;
					//	System.out.println("NUM BYTES" + numBytes);

					if (fileSize < RANGE) {
						fin = true;
					}
					//System.out.println("nNNNN " + n + "    numBytes " + numBytes); 
					///se o numBytes == ao range, se nao sig q rebentou a meioo e temos de calcular o min rang com base nessa falha
				//	System.out.println("couter     " + wkCount);
				}

			} else {
				System.out.println("Ooops, received status:" + reply[1]);
				break;
			}
			
			totalBytes += numBytes;
			minRange = totalBytes; //// testar byte de apoio depois
			maxRange = minRange + RANGE;

		
			stat.newRequest(numBytes);
			System.out.println("entrei no while");
			stat.printReport();
		
			sock.close();
			//break;
		}

		stat.printReport();
	}

	///////forcar o tricky a rebentar a meio, para vermos que resposta nos da, para lidarmos com isso. 
	//se pedirmos 100 e ele manda so 50, o prox pedido pedimos 50-150
}

// long time = System.currentTimeMillis()-time0;
// System.err.println("Time= "+time+"ms "+(f.length()-start)+"bytes Kbits/s= "+ (8*(f.length()-start)/(double)time));