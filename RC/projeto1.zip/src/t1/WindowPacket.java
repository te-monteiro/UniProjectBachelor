package t1;

public class WindowPacket {
	
	private FTP19Packet packet;
	private boolean acknowledged, inTransit, resended;
	private long lastSend;
	private long csn;
	
	public WindowPacket(FTP19Packet packet, long csn) {
		this.packet = packet;
		acknowledged = false;
		lastSend  = 0;
		inTransit = false;
		this.csn = csn;
		resended = false;
		
	}
	
	public void turnACK() {
		acknowledged = true;
	}
	
	public void setLastSend(long time) {
		lastSend = time;
	}
	
	public void setInTransit() {
		inTransit = true;
	}
	
	public void setNotInTransit() {
		inTransit = false;
	}
	
	public boolean isInTransit() {
		return inTransit;
	}
	
	public boolean isACK() {
		return acknowledged;
	}
	
	public long getLastSend() {
		return lastSend;
	}
	
	public FTP19Packet getPacket() {
		return packet;
	}
	
	public long getCumulative() {
		return csn;
	}
	
	public void turnResended() {
		resended = true;
	}
	
	public boolean isResended() {
		return resended;
	}

}
