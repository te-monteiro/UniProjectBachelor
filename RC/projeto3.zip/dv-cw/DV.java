import java.util.ArrayList;
import java.util.Map.Entry;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.Vector;

/*
 * My Distance-Vector Routing Implementation
 */
public class DV implements RoutingAlgorithm {
	static final int LOCAL = -1; // local destination/interface
	static final int UNKNOWN = -2; // unknown destination
	static final int BROADCAST = 255; // broadcast address
	static final int INFINITY = 60; // "infinity" metric

	Router thisRouter = null; // the router were this algorithm is running

	// declare your routing table here using DVRoutingTableEntry (see end of this
	// file)
	SortedMap<Integer, DVRoutingTableEntry> routingTable;
	int updateInterval;
	boolean preverse, expire;

	public DV() {
		routingTable = new TreeMap<>();
		updateInterval = -1;
		preverse = false;
		expire = false;
	}

	public void setRouterObject(Router obj) {
		thisRouter = obj;
	}

	public void setUpdateInterval(int u) {
		updateInterval = u;
	}

	public void setAllowPReverse(boolean flag) {
		preverse = flag;
	}

	public void setAllowExpire(boolean flag) {
		expire = flag;
	}

	public void initalise() {
		DVRoutingTableEntry e = new DVRoutingTableEntry(thisRouter.getId(), LOCAL, 0, thisRouter.getCurrentTime());
		routingTable.put(e.getDestination(), e);
	}

	public int getNextHop(int destination) {
		if (destination == thisRouter.getId())
			return LOCAL;
		for (Entry<Integer, DVRoutingTableEntry> e : routingTable.entrySet()) {
			if (e.getValue().getDestination() == destination && e.getValue().getMetric() < INFINITY)
				return e.getValue().getInterface();
		}
		return UNKNOWN;
	}

	/**
	 * Now with SH/PR enabled, run test3.cfg and test4.cfg: Examine the behavior of
	 * your DV implementation. For each of the two tests, does SH/PR prevent each
	 * pathology you previously observed? Explain why or why not. Com o SH/PR ativo,
	 * um n� R1 anuncia ao n� R2 todos os destinos para os quais R1 usa R2 como
	 * melhor caminho � dist�ncia infinito; ou seja, R1 anuncia a R2 com dist�ncia
	 * infinito tudo aquilo que R1 acha que est� por detr�s de R2. Assim sendo, com
	 * o SP/HR, sempre que um n� conclu� que h� altera��es pode desencadear
	 * imediatamente um an�ncio para que o algoritmo convirja mais rapidamente.
	 * Contudo, e como podemos observar, o poison reverse n�o � suficiente para
	 * garantir que n�o aparecem epis�dios de contagem para o infinito, sobretudo no
	 * caso de redes com muitos destinos.
	 */

	public void tidyTable() {
		ArrayList<DVRoutingTableEntry> toRemove = new ArrayList<>();
		for (Entry<Integer, DVRoutingTableEntry> e : routingTable.entrySet()) {
			DVRoutingTableEntry entry = e.getValue();
			if (!thisRouter.getInterfaceState(entry.getInterface()) && entry.getMetric() != INFINITY) {
				entry.setMetric(INFINITY);
				entry.setTime(thisRouter.getCurrentTime());
			}
			if (expire && entry.getMetric() == INFINITY
					&& thisRouter.getCurrentTime() - entry.getTime() > 3 * updateInterval)
				toRemove.add(entry);
		}
		toRemove.forEach((e) -> routingTable.remove(e.getDestination()));
	}

	public Packet generateRoutingPacket(int iface) {
		Packet p;
		p = new RoutingPacket(thisRouter.getId(), BROADCAST);
		Payload payload = new Payload();

		for (Entry<Integer, DVRoutingTableEntry> e : routingTable.entrySet()) {
			DVRoutingTableEntry entry = e.getValue();
			if (preverse && entry.getInterface() == iface)
				payload.addEntry(new DVRoutingTableEntry(entry.getDestination(), entry.getInterface(), INFINITY,
						entry.getTime()));
			else
				payload.addEntry(new DVRoutingTableEntry(entry.getDestination(), entry.getInterface(),
						entry.getMetric(), entry.getTime()));
		}
		p.setPayload(payload);
		return p;
	}

	public void processRoutingPacket(Packet p, int iface) {
		Vector<Object> table = p.getPayload().getData();
		for (int i = 0; i < table.size(); i++) {
			DVRoutingTableEntry inEntry = (DVRoutingTableEntry) table.get(i);
			boolean finished = false;

			for (Entry<Integer, DVRoutingTableEntry> e : routingTable.entrySet()) {
				DVRoutingTableEntry entry = e.getValue();
				if (inEntry.getDestination() == entry.getDestination()) {
					finished = true;
					if (iface == entry.getInterface()
							|| inEntry.getMetric() + thisRouter.getInterfaceWeight(iface) < entry.getMetric()) {
						int newMetric = Math.min(INFINITY, inEntry.getMetric() + thisRouter.getInterfaceWeight(iface));
						if (entry.getMetric() != newMetric) {
							entry.setMetric(newMetric);
							entry.setTime(thisRouter.getCurrentTime());
							entry.setInterface(iface);
						}
					}
				}
			}

			if (!finished && inEntry.getMetric() < INFINITY) {
				routingTable.put(inEntry.getDestination(), new DVRoutingTableEntry(inEntry.getDestination(), iface,
						inEntry.getMetric() + thisRouter.getInterfaceWeight(iface), thisRouter.getCurrentTime()));
			}
		}
	}

	/**
	 * 
	 * Without SH/PR enabled, run test3.cfg and test4.cfg: Consider the link
	 * failures that occur during these simulations. When links fail, what routing
	 * pathologies, if any, do you observe in each of these two test configurations
	 * when not using SH/PR? * Para o teste 3: Quando o link <<10 3.1 4.0>> vai
	 * abaixo, conseguimos ver o efeito ping pong entre os routers 1 e 2 e um ciclo
	 * no encaminhamento (routing loop). Assim, o ciclo s� para quando o custo
	 * chegar a �infinito�. Downlink <<35 0.0 3.0>> n�o cria problemas de "contagem
	 * para o infinito". Downlink <<45 2.2 5.0>> vai criar uma divis�o na rede,
	 * ficando assim composta pelas sub-redes formadas pelos routers 0,1,2 e
	 * 3,4,5,6. Por exemplo no envio do pacote com src 0 e dst 5 (time 50), o pacote
	 * vai andar entre (2.1->1.1) e (1.1->2.1), ou seja, um routing loop.
	 * 
	 * Para o teste 4: Quando o link << 15 2.2 5.0>> vai abaixo, n�o cria problemas
	 * de "contagem para o infinito". Downlink <<45 2.2 5.0>> vai "dividir" a rede
	 * em duas sub-redes, s�o elas compostas pelos routers 0,1,2 e 3,4,5,6,7. Por
	 * exemplo no envio do pacote com src 7 e dst 2 (time 41), o pacote vai andar
	 * entre(6.2->5.2) e (5.2->6.2), um routing loop.
	 */

	public void showRoutes() {
		System.out.println("Router " + thisRouter.getId());
		for (Entry<Integer, DVRoutingTableEntry> e : routingTable.entrySet()) {
			System.out.printf(e.getValue().toString());
		}
	}
}

/*
 * My Routing Table Entry
 */
class DVRoutingTableEntry implements RoutingTableEntry {

	int d, i, m, t;

	public DVRoutingTableEntry(int d, int i, int m, int t) {
		this.d = d;
		this.i = i;
		this.m = m;
		this.t = t;
	}

	public int getDestination() {
		return d;
	}

	public void setDestination(int d) {
		this.d = d;
	}

	public int getInterface() {
		return i;
	}

	public void setInterface(int i) {
		this.i = i;
	}

	public int getMetric() {
		return m;
	}

	public void setMetric(int m) {
		this.m = m;
	}

	public int getTime() {
		return t;
	}

	public void setTime(int t) {
		this.t = t;
	}

	public String toString() {
		return String.format("d %d i %d m %d\n", d, i, m);
	}
}
