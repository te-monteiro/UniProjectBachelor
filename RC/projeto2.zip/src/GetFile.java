import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.Socket;
import java.net.URL;

/**
 * A really simple HTTP Client
 * 
 * @author The RC - FCT/UNL class instructors
 *
 */

public class GetFile {
	private static final int BUF_SIZE = 1024;
	private static final long RANGE = 7860;

	static File f;
	static RandomAccessFile outFile;
	static long byteToTransfer;
	static Thread[] threads;
	static Stats stats;

	
	static class Requester implements Runnable {

		URL u;
		int port;
		String path;
		long minRange, maxRange, fileSize;
		boolean end;

		Requester(URL u) {
			this.u = u;
			port = u.getPort() == -1 ? 80 : u.getPort();
			path = u.getPath() == "" ? "/" : u.getPath();
			minRange = newRequest() - RANGE;
			maxRange = minRange + RANGE - 1;
			fileSize = -1;
			end = false;
		}

		public void run() {
			try {
				while (!end) {
					byte[] buffer = new byte[BUF_SIZE];
					Socket sock = new Socket(u.getHost(), port);
					OutputStream out = sock.getOutputStream();
					InputStream in = sock.getInputStream();

					String request = String.format(
							"GET %s HTTP/1.0\r\n" + "Host: %s\r\n" + "Range: bytes=%d-%d\n"
									+ "User-Agent: X-Client-Demo-RC2019\r\n\r\n",
							path, u.getHost(), minRange, maxRange);
					out.write(request.getBytes());
					// System.out.println("\nSent:\n\n"+request);

					long[] rangeValues = getRangeValues(in);
					
					if (rangeValues != null && fileSize < 0)
						fileSize = rangeValues[2];

					int n, counter = 0;
					while ((n = in.read(buffer)) > 0) {
						writeFileAux(buffer, in, minRange + (counter * BUF_SIZE), n);
						counter++;
					}
					
					sock.close();
					out.close();
					in.close();

					stats.newRequest((int) (rangeValues[1] - minRange + 1));

					if (rangeValues[1] < maxRange) {
						minRange = rangeValues[1] + 1;
					} else {
						minRange = newRequest() - RANGE;
						maxRange = minRange + RANGE - 1;
					}
					if (minRange >= fileSize && fileSize >= 0) {
						end = true;
					}
				}
				System.out.printf("Thread %d done.\n", port);
			} catch (Exception e) {
				System.out.printf("Thread %d failed.\n", port);
			}
		}

		private long[] getRangeValues(InputStream in) throws IOException {
			// System.out.println("Got:\n");
			long[] rangeValues = new long[3];
			String answerLine = Http.readLine(in); // first line is always present
			// System.out.println(answerLine);
			answerLine = Http.readLine(in);
			while (!answerLine.equals("")) {
				// System.out.println(answerLine);
				String[] header = Http.parseHttpHeader(answerLine);
				if (header[0].equals("Content-Range")) {
					rangeValues = Http.parseRangeValuesSentByServer(header[1]);
				}
				answerLine = Http.readLine(in);
			}
			return rangeValues;
		}

	}

	public static void main(String[] args) throws Exception {
		if (args.length < 1) {
			System.out.println("Usage: java HttpClientDemo url(s)_to_access");
			System.exit(0);
		}

		threads = new Thread[args.length];
		byteToTransfer = 0;
		f = new File(args[0].substring(22) + "2");
		outFile = new RandomAccessFile(f, "rw");
		stats = new Stats();

		for (int i = 0; i < args.length; i++) {
			String url1 = args[i];
			URL u = new URL(url1);
			threads[i] = new Thread(new Requester(u));
			threads[i].start();
		}

		for (int i = 0; i < threads.length; i++) {
			threads[i].join();
		}

		outFile.close();
		stats.printReport();
		System.out.println("Transfer done.");
	}
	
	private synchronized static void writeFileAux(byte[] buffer, InputStream in, long minRange, int n)
			throws IOException {
		outFile.seek(minRange);
		outFile.write(buffer, 0, n);
	}

	private synchronized static long newRequest() {
		byteToTransfer += RANGE;
		return byteToTransfer;
	}

}
