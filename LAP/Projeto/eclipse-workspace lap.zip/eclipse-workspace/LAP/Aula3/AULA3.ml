type 'a tree = Nil | Node of 'a * 'a tree * 'a tree

let rec howMany v t=
	match t with
	 Nil -> 0
	| Node(x, l, r) -> if x = v then 1 + howMany v l + howMany v r else howMany v l + howMany v r;;

let t1 = Node(1, Node(2, Nil, Nil), Node(3, Nil, Nil));;

howMany 1 t1;;


let rec eqPairs t=
	 match t with
		Nil -> 0
	| Node((x,y), l, r) -> if x = y then 1 + eqPairs l + eqPairs r else eqPairs l + eqPairs r;;

let t2 = Node((1, 1) , Node((2, 3), Nil, Nil), Node((2,2), Nil, Nil));;

eqPairs t2;;


let rec treeToList t=
	match t with
	 Nil -> []
	|Node(x, l, r) -> (x:: treeToList l) @ treeToList r;;

(* (treeToList l) @ [x] // criar uma lista de inteiros @ treeToList r*)
(* (treeToList l) @ (treeToList r) @ [x] *)

treeToList t2;;



(* balanced: 'a tree -> bool*)


    (* height: 'a tree -> int *)

    let rec height t =
        match t with
           Nil -> 0
         | Node(x,l,r) ->
               1 + max (height l) (height r)
    ;;


let rec balanced t=
	match t with
	 Nil -> true
	|Node(_, l, r) ->  ( height l - height r ) > 1 || ( height l - height r ) < -1 ;;

balanced Nil;;
balanced (Node(3,Node(5,Nil,Nil),Node(6,Nil,Nil)));;
balanced (Node(1,Nil,Node(2,Nil,Node(3,Nil,Nil))));;

	(*subtrees: 'a tree -> 'a tree list*)

let rec union l1 l2=
	match l1 with
	| [] -> l2
	| x:: xs -> if belongs x l2 
	
	(*passar em casa o union*)
	
let rec subtrees t=
	match t with
	 Nil-> [Nil]
	|Node(_, l, r) -> t:: subtrees l @ subtrees r;;

subtrees (Node(5,Nil,Node(6,Nil,Nil))) ;;
subtrees Nil;;

(*spring: 'a -> 'a tree -> 'a tree*)
let rec spring x t=
	match t with
	 Nil -> Node(x, Nil, Nil)
	| Node(y, l, r) -> Node(y, spring x l, spring x r);;

(*fall: 'a tree -> 'a tree*)

let rec fall t=
	match t with
	 Nil -> Nil
	| Node(_, Nil, Nil) ->  Nil
	| Node(x, l, r) -> Node(x, fall l, fall r);;
















