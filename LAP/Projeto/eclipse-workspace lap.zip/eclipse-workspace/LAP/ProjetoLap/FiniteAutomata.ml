(* FiniteAutomata module body *)

(* 
Aluno 1: Ana Filipa Silva 52787 
Aluno 2: Teresa Monteiro 52597 

Comment:
*)

(*ver os casos dos automatos quando tem so um e aceita a palavra vazia
01234567890123456789012345678901234567890123456789012345678901234567890123456789
   80 columns
*)

type symbol = char;;       (* our symbols are represented by chars *)
type word = symbol list;;  (* our words are represented by lists of symbols *)

type state = string;;      (* our states are represented by strings *)
type states = state list;;

type transition =
    state   (* state *)
  * symbol  (* consumed input symbol *)
  * state   (* next state *)
;;
type transitions = transition list;;

type fAutomaton = {
    initialState: state;       (* Initial state *)
    transitions: transitions;  (* Transition relation *)
    acceptStates: states       (* Accept states *)
};;


(* PRIVATE DEFINITIONS *)

let abc = {
    initialState = "START" ;
    transitions = [
            ("START",'a',"A"); ("START",'b',"START"); ("START",'c',"START");
                                                      ("START",'d',"START");
            ("A",'a',"A"); ("A",'b',"AB"); ("A",'c',"START"); ("A",'d',"START"); 
            ("AB",'a',"A"); ("AB",'b',"START"); ("AB",'c',"SUCCESS");
                                                    ("AB",'d',"START");
            ("SUCCESS",'a',"SUCCESS"); ("SUCCESS",'b',"SUCCESS");
                         ("SUCCESS",'c',"SUCCESS"); ("SUCCESS",'d',"SUCCESS")
        ];
    acceptStates = ["SUCCESS"]
};;

let abcND = {
    initialState = abc.initialState ;
    transitions = abc.transitions @ [
            ("SUCCESS",'a',"UNPRODUCTIVE");
            ("UNREACHABLE",'a',"SUCCESS");
            ("SUCCESS",'e',"UNPRODUCTIVE"); ("UNPRODUCTIVE",'a',"UNPRODUCTIVE");
        ];
    acceptStates = abc.acceptStates
};;

let canonical l =
    List.sort_uniq compare l
;;

let addAll symb =
    List.map (fun l -> symb::l)
;;

let flatMap f l =
    List.flatten (List.map f l)
;;


(* PUBLIC FUNCTIONS *)

let getAlphabet fa = 
	    canonical (List.map(fun (a,b,c) -> b ) fa.transitions)
;;

let getStates fa =
     canonical (List.map ( fun(a,b,c) -> a) fa.transitions 
															  	@ List.map(fun (a,b,c) -> c ) fa.transitions)
;;

let gcut s ts =
	List.partition (fun(a,b,c) -> a = s) ts ;;

(* l - lista de transicoes*)
(* e feita a desconcatenacao da lista de transicoes*)
(* em que e visto se existe mais que algum triplo*)
(* com a e b igual, se sim entao nao e determinista *)
let rec auxDeterminism l =
	match l with
	[] -> true
	|(a,b,c)::xs ->  if List.exists(fun(x,y,z) -> a = x && b= y && c <> z) xs 
																						  then false else auxDeterminism xs
;;

let determinism fa = 
	auxDeterminism fa.transitions
;;

(* a - estado inicial; t - estados de transicao*)
(* ao utilizador o gcut conseguimos obter duas*)
(* listas em que a primeira obtem todas as transicoes*)
(* com a igual 'a' e a segunda as restantes*)
(* ao fazer isto recursivamente conseguimos obter *)
(* um caminho partindo do 'a' terminando quando nao*)
(* for possivel obter mais transicoes*)
let rec auxReachable a t =

	let(s, vs) = gcut a t in 
		a:: lStates s vs
and 
  lStates l tl =
			match l with
			[] -> []
			|(_,_,c):: xs -> auxReachable c tl @ lStates xs tl;;

let reachable fa =
	canonical (auxReachable fa.initialState fa.transitions)
;;

(*G cut'invertido' de forma a obter todas as transicoes*)
(* com o 'c' igual*)
let invGcut s ts =
	List.partition (fun(a,b,c) -> c = s) ts 
;;

(* a - estado t - estados de transicao*)
(*funcao auxiliar que permite obter todos os estados *)
(* produtivos de um determinado estado final*)
(* onde e que como encontrado o caminho contrarioa a*)
(* partir do estado final *)
let rec auxProductive a t =
	let(s, vs) = invGcut a t in 
		a::lStates s vs
and 
  lStates l tl =
			match l with
			[] -> []
			|(x,_,_):: xs -> auxProductive x tl @ lStates xs tl;;

(* a - lista dos estados finais; t - estados de transicao*)
(* funcao auxiliar que permite concatenar todos os estados*)
(* produtivos de todos os estados finais*)
let rec auxTotal a t =
	match a with
	[] -> []
	|x::xs-> (auxProductive x t)  @ (auxTotal xs t)
;;

let productive fa =
	 canonical (auxTotal fa.acceptStates fa.transitions)
;;

(* x - estado; s - estado ; t - lista de transicoes *)
(* encontra o estado 'c' ao qual a transicao chega*)
let rec findAestado x s t =
	match t with 
	[] -> x
	|(a,b,c)::xs-> if (a = x && b = s ) then c else findAestado x s xs
	;;

(* s - estado; w-  lista de palavras; fa - lista de transicoes*)
(* funcao auxiliar que permite guardar todos os estados*)
(* que vao ser alcancados consoante a palavra*)
let rec acceptA s w fa =
	s::	let t = s in auxAcceptA t w fa 
and
	auxAcceptA s w fa =
		match w with 
		[] -> []
		|x::xs -> acceptA(findAestado s x fa) xs fa  ;;
 
(* l - list dos estados finais; l2 - lista de todos os estados de *)
(* transicao consoante a palavra recebida*)
(* funcao auxiliar que permite verificar se a lista de palavras*)
(* permite chegar a um estado final atraves da verificacao*)
(* do ultimo estado atingido, isto e se este e o estado final *)
let rec hasFinalState l l2 =
	match l with 
	[] -> false
	|x::xs -> if List.hd (List.rev l2) = x then true else hasFinalState  xs l2 
;;

let accept w fa =
	let l2 = acceptA fa.initialState w fa.transitions in
    hasFinalState fa.acceptStates l2
;;
  
let generate n fa =
    canonical []
;;

let accept2 w fa =
    accept w fa
;;

