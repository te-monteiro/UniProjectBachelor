type tree = Nil | Node of int * trree * tree;;
