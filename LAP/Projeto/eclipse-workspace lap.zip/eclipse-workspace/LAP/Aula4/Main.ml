open BinTree;;

let cut s = (*pre: s <> "" *)
	(String.get s 0, String.sub s 1 ((String.length s ) -1))
;;
(*cut "antonieta" *)