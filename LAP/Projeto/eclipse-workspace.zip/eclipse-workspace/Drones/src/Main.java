import java.util.Scanner;

import Drones.Drones;
import Drones.DronesClass;

public class Main {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);

		Drones d = new DronesClass();

		String comm = getCommand(in);

		while (!comm.equals("exit")) {
			switch (comm) {
			case "help":
				help(in);
				break;
			case "base":
				registerNewBase(in, d);
				break;

			default:
				System.out.println("TENS UM ERRO!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
			}
			comm = getCommand(in);
		}
		System.out.println("Bye!");
		in.close();
	}

	private static void registerNewBase(Scanner in, Drones d) {
		int latitude = in.nextInt();
		int longitude = in.nextInt();
		String nameBase = in.nextLine().trim();
		
		if(d.searchIndexBase(nameBase) >= 0)
			System.out.println("Base already exists!");
		else if(d.searchIndexCoord(latitude, longitude) >= 0)
			System.out.printf("There is already another base at at [%d,-%d]!\n",latitude, longitude);
		
		d.registerNewBase(latitude, longitude, nameBase);
		System.out.printf("Base %s created at [%d,-%d]. \n", nameBase, latitude, longitude);
		
		
		
		
		
		
		
		
		
	}

	private static void help(Scanner in) {
		System.out.println("base - registers a new distribution base");
		System.out.println("listBases - lists existing distribution bases");
		System.out.println("drone - registers a new drone in a starting base");
		System.out.println("service - service all grounded drones requiring service in a base");
		System.out.println("swarm - creates a new swarm from free drones in a base");
		System.out.println("swarmComponents - lists the drones within a swarm");
		System.out.println("disband - disbands the whole swarm");
		System.out.println("listDrones - lists all existing drones (and swarms)");
		System.out.println("flyToBase - fly a drone (or swarm) to a base");
		System.out.println("addOrder - add a new order to a base");
		System.out.println("orders - lists all pending orders from a base");
		System.out.println("allOrders - lists all pending orders from all bases");
		System.out.println("deliver - deliver a package to a customer");
		System.out.println("delivered - lists all delivered orders");
		System.out.println("inTransit - lists all drones (and swarms) currently flying");	
		System.out.println("ticTac - advances the simulation clock n timestamps");
		System.out.println("help - shows the available commands");
		System.out.println("exit - terminates the execution of the program");
		
	}

	private static String getCommand(Scanner in) {
		String input;
		System.out.println();
		input = in.next().toLowerCase();

		return input;
	}
}

