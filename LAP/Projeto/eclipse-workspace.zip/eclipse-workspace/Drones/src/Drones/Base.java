package Drones;

public interface Base {
	/**
	 * Method that returns the name of the base
	 * @return - nameBase
	 */
	String getNameBase();
	
	/**
	 * Method that returns the coordinates longitude
	 * @return - longitude
	 */
	int getLongitude();
	
	/**
	 * Method that returns the coordinates latitude
	 * @return - latitude
	 */
	int getLatitude();

}
