package Drones;

public class BaseClass implements Base {
	
	int latitude, longitude;
	String nameBase;
	
	
	public BaseClass(int latitude, int longitude, String nameBase) {
		this.latitude = latitude;
		this.longitude = longitude;
		this.nameBase = nameBase;
	}


	@Override
	public String getNameBase() {
		return nameBase;
	}


	@Override
	public int getLongitude() {
		return longitude;
	}


	@Override
	public int getLatitude() {
		return latitude;
	}

	
}
