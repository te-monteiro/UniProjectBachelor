package Drones;

public interface Drones {

	/**
	 * Method that search if the name of the base already exist
	 * @param nameBase
	 * @return if exist or not through -1 or 0
	 */
	int searchIndexBase(String nameBase);

	/**
	 * Method that search if this coordinates of the base already exist
	 * @param latitude
	 * @param longitude
	 * @return if exist or not through -1 or 0
	 */
	int searchIndexCoord(int coordinate);

}
