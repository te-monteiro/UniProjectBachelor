package Drones;

import Iterator.Iterator;
import Iterator.VetorGenerico;
import Iterator.VetorGenericoClass;

public class DronesClass implements Drones {

	//private VetorGenerico<Base> base;
	private Base[] base
	int counter;

	public DronesClass() {
	//	this.base = new VetorGenericoClass<Base>();
		this.counter = 0;
	}

	@Override
	public int searchIndexBase(String nameBase) {
		Iterator<Base> it = this.iteratorBase(nameBase);
		int result = -1;
		
		if (!it.isEmpty()) {
			if (it.next().equals(nameBase))
				result = 0;
			else
				counter++;
			while (it.hasNext()) {
				if (it.next().equals(nameBase))
					result = counter;
			}
			counter++;
		} else
			result = -1;
		return result;
	}

	private Iterator<Base> iteratorBase(String nameBase) {
		return base.iterator();
	}

	@Override
	public int searchIndexCoord(int coordinate) {
		int result = -1;
		int i = 0;
			while (i< counter && result == -1) {
				if(base[i].get)
			}
		return result;
	}
	
	
	
	
	

}
