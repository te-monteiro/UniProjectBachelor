package Iterator;

public class VetorGenericoClass<E> implements VetorGenerico<E> {
	private static final int SIZE = 50;
	private E[] elems;
	private int counter;

	@SuppressWarnings("unchecked")
	public VetorGenericoClass() {
		elems = (E[]) new Object[SIZE];
		counter = 0;
	}

	@Override
	public void insertLast(E e) {
		if (counter == elems.length)
			resize();
		elems[counter++] = e;
	}

	@Override
	public E removeLast() {
		return elems[--counter];
	}

	@Override
	public void insertAt(E e, int pos) {
		if (counter == elems.length)
			resize();
		for (int i = counter - 1; i >= pos; i--)
			elems[i + 1] = elems[i];
		elems[pos] = e;
		counter++;
	}

	@Override
	public E removeAt(int pos) {
		E elem = elems[pos];
		for (int i = pos; i < counter - 1; i++)
			elems[i] = elems[i + 1];
		counter--;
		return elem;
	}

	public boolean search(E e) {
		return searchIndexOf(e) != -1;
	}

	public int searchIndexOf(E elem) {
		boolean found = false;
		int i = 0;
		while (i < counter && !found)
			if (elems[i].equals(elem))
				found = true;
			else
				i++;
		if (found)
			return i;
		else
			return -1;
	}

	public E get(int pos) {
		return elems[pos];
	}

	public int size() {
		return counter;
	}

	@SuppressWarnings("unchecked")
	private void resize() {
		E[] tmp = (E[]) new Object[2 * elems.length];
		for (int i = 0; i < counter; i++)
			tmp[i] = elems[i];
		elems = tmp;
	}

	@Override
	public Iterator<E> iterator() {
		return new IteratorClass<E>(elems, counter);

	}
}
