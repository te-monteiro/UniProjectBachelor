package Iterator;

public interface Iterator<E> {

	boolean hasNext();

	boolean isEmpty();

	void init();

	E next();

}
