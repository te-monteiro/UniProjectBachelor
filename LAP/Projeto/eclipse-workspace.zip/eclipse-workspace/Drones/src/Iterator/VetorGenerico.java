package Iterator;

public interface VetorGenerico<E> {
	/**
	 * Insere o elemento <code>e</code> na ultima posicao do vector @param e
	 * elemento a inserir no vector
	 */
	void insertLast(E e);

	/**
	 * Insere o elemento <code>e</code> na posicao <code>pos</code> do vector
	 * 
	 * @param e
	 *            elemento a inserir no vector
	 * @param pos
	 *            posicao do vector a inserir o elemento * @pre pos < size()
	 */
	void insertAt(E e, int pos);

	/**
	 * Remove o ultimo elemento do vector
	 * 
	 * @pre size() > 0
	 */
	E removeLast();

	/**
	 * @param pos
	 *            posicao do elemento a remover do vector
	 * @pre pos < size()
	 */
	E removeAt(int pos);

	/**
	 * @param e
	 *            elemento a procurar do vector
	 * @return a posicao do elemento no vector, <code>-1</code> caso o elemento nao
	 *         exista
	 */
	int searchIndexOf(E e);

	/**
	 * Procura a posicao do elemento <code>e</code> no vector
	 * 
	 * @param pos
	 *            posicao do vector do elemento a devolver
	 * @return o elemento na posicao <code>pos</code>,
	 * @pre pos < size()
	 */
	E get(int pos);

	/**
	 * Devolve o numero de elementos no vector
	 * 
	 * @return o numero de elementos no vector
	 */
	int size();

	/**
	 * Devolve um iterador para os contactos
	 * 
	 * @return iterador para os contactos
	 */
	Iterator<E> iterator();

}
