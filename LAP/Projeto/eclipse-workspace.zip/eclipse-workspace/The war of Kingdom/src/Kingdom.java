/**
 * 
 * @author Pedro Oliveira
 * @author Teresa Monteiro
 *
 */
public class Kingdom {

	private String name;
	private Castles castles;
	private Army soldiers;
	private int totalWealth;

	/**
	 * Constructor of the class Kingdom that allows to form a kingdom, by having a
	 * name and a castle initially
	 * 
	 * @param name
	 *            - kingdom's name
	 * @param numTotalCastles
	 *            - size of the array of castles that the kingdom has
	 * @param kingdomCastle
	 *            - castle that each kingdom starts with
	 */
	public Kingdom(String name, int numTotalCastles, Castle kingdomCastle) {
		this.name = name;
		castles = new Castles(numTotalCastles);
		castles.addCastle(kingdomCastle);
		castles.setOwner(kingdomCastle.getName(), name);
		soldiers = new Army();

	}

	/**
	 * Method that returns the castle by using its position
	 * 
	 * @param x
	 *            - x position of the castle
	 * @param y
	 *            - y position of the castle
	 * @return castle
	 */
	public boolean hasCastle(int x, int y) {
		return castles.hasCastlePos(x, y);
	}

	/**
	 * Method that returns the class Castles
	 * 
	 * @return class Castles
	 */
	public Castles getCastles() {
		return castles;

	}

	/**
	 * Method that allows to conquer a castle, and set its new owner
	 * 
	 * @param castle
	 *            - castle that the user will conquer
	 */
	public void conquerCastle(Castle castle) {
		castles.addCastle(castle);
		castle.setOwner(name);
	}

	/**
	 * Method that allows to get a soldier by using its index
	 * 
	 * @param i
	 *            - index of the soldier .
	 * @return - soldier
	 */
	public Soldiers getSoldier(int i) {
		return soldiers.getSoldier(i);
	}

	/**
	 * Method that allows to get a soldier by using its positions
	 * 
	 * @param x
	 *            - x position of the castle
	 * @param y
	 *            - y position of the castle
	 * @return - soldier
	 */
	public Soldiers getSoldier(int x, int y) {
		return soldiers.getSoldier(searchSoldier(x, y));
	}

	/**
	 * Method that initializes the castle iterator
	 */
	public void initializeIterator() {
		castles.initializeIterator();
	}

	/**
	 * Method that returns the next castle
	 * 
	 * @return castle
	 */
	public Castle next() {
		return castles.next();
	}

	/**
	 * Method that verifies if there is a next castle
	 * 
	 * @return true if there is
	 */
	public boolean hasNext() {
		return castles.hasNext();
	}

	/**
	 * Method that initializes the soldiers's iterator
	 */
	public void initializeIteratorSoldiers() {
		soldiers.initializeIterator();
	}

	/**
	 * Method that returns the next soldier
	 * 
	 * @return soldier
	 */
	public Soldiers nextSoldier() {
		return soldiers.next();
	}

	/**
	 * Method that verifies if there is a next soldier
	 * 
	 * @return true if there is
	 */
	public boolean hasNextSoldier() {
		return soldiers.hasNext();
	}

	/**
	 * Method that allows to remove a soldier by using its position
	 * 
	 * @param x
	 *            - x position of the soldier
	 * @param y
	 *            - y position of the soldier
	 */
	public void killSoldier(int x, int y) {
		soldiers.killSoldier(x, y);
	}

	/**
	 * Method that returns the kingdom name
	 * 
	 * @return name
	 */
	public String getKingdomName() {
		return name;
	}

	/**
	 * Method that compares the kingdom name
	 * 
	 * @param otherContact
	 * @return
	 */
	public boolean equals(Kingdom otherKingdom) {
		return name.equals(otherKingdom.getKingdomName());
	}

	/**
	 * Method that gets the number of castles that the kingdom playing has
	 * 
	 * @return counter
	 */
	public int getNumCastles() {
		return castles.getNumCastles();
		// return castles.getNumCastles();
	}

	/**
	 * Method that adds a castle to the kingdom's array
	 * 
	 * @param castle
	 *            - castle that is added
	 */
	public void addNumCastles(Castle castle) {
		castles.addCastle(castle);
	}

	/**
	 * Method that decreases the number of castles
	 * 
	 * @param x
	 *            - x position of the castle
	 * @param y
	 *            - y position of the castle
	 */
	public void removeCastles(int x, int y) {
		castles.removeCastles(x, y);
	}

	/**
	 * Method that returns the number of total soldiers that the kingdom playing has
	 * 
	 * @return numTotalSoldiers
	 */
	public int getKingdomSoldiers() {
		return soldiers.getTotalSoldiers();
	}

	/**
	 * Method that returns the total of wealth that one kingdom has
	 * 
	 * @return totalWealth
	 */
	public int getTotalWealth() {
		return totalWealth;
	}

	/**
	 * Method that verifies the number of letters that this kingdom has and compares
	 * it
	 * 
	 * @param other
	 *            - object of the class Kingdom
	 * @return true if it is greater
	 */
	public boolean greaterThan(Kingdom other) {
		return this.getKingdomName().compareTo(other.getKingdomName()) > 0;
	}

	/**
	 * Method that allows to buy a soldier by using its type
	 * 
	 * @param type
	 *            - type of soldier
	 * @return cost of the soldier
	 */
	public int getSoldierCost(String type) {
		return soldiers.soldierCost(type);
	}

	/**
	 * Method that allows to create a soldier inside the kingdom who is playing
	 * 
	 * @param x
	 *            - x position of the new soldier
	 * @param y
	 *            - y position of the new soldier
	 * @param type
	 *            - type of the new soldier
	 */
	public void createSoldier(int x, int y, String type) {
		soldiers.recruitSoldier(new Soldiers(x, y, type));
	}

	/**
	 * Method that verifies if the type of the soldier that the user chose is
	 * invalid or not
	 * 
	 * @param type
	 *            - type of the soldier
	 * @return true if it is invalid
	 */
	public boolean invalidSoldier(String type) {
		return soldiers.invalidSoldier(type);
	}

	/**
	 * Method that verifies if a soldier exists or not, by using a position
	 * 
	 * @param x
	 *            - x position of the soldier
	 * @param y
	 *            - y position of the soldier
	 * @return true if the soldier exists
	 */
	public boolean statusSoldier(int x, int y) {
		return soldiers.statusSoldier(x, y);
	}

	/**
	 * Method that verifies if there is another soldier of the same kingdom on the
	 * position to where the user wants to move to
	 * 
	 * @param x
	 *            - x position of the soldier
	 * @param y
	 *            - y position of the soldier
	 * @return true if there is
	 */
	public int samePos(int x, int y) {
		return soldiers.samePosition(x, y);
	}

	/**
	 * Method that allows to find a soldier by using its position
	 * 
	 * @param x
	 *            - x position of the soldier
	 * @param y
	 *            - y position of the soldier
	 * @return index of the soldier
	 */
	public int searchSoldier(int x, int y) {
		return soldiers.searchSoldier(x, y);
	}

	/**
	 * Method that returns the x position of the soldier by using its position
	 * 
	 * @param x
	 *            - x position of the soldier
	 * @param y
	 *            - y position of the soldier
	 * @return x
	 */
	public int getSpecifiedSoldierX(int x, int y) {
		return soldiers.getSoldier(searchSoldier(x, y)).getX();
	}

	/**
	 * Method that returns the y position of the soldier by using its position
	 * 
	 * @param x
	 *            - x position of the soldier
	 * @param y
	 *            - y position of the soldier
	 * @return y
	 */
	public int getSpecifiedSoldierY(int x, int y) {
		return soldiers.getSoldier(searchSoldier(x, y)).getY();
	}

	public String getSpecifiedType(int x, int y) {
		return soldiers.getSoldier(searchSoldier(x, y)).getType();
	}

	public boolean friendlySoldier(int x, int y) {
		boolean found = true;
		for (int i = 0; i < getKingdomSoldiers(); i++)
			if (getSoldier(i).getX() == x && getSoldier(i).getY() == y
					&& !getSoldier(i).getSoldierOwner().equals(getKingdomName()))
				found = false;
			else
				i++;
		return found;
	}

	/**
	 * 
	 * @return do numero total de soldados existentes num reino
	 */
	public int getTotalSoldiers() {
		return soldiers.getTotalSoldiers();
	}

	public boolean isKnight(int i) {
		return soldiers.isKnight(i);
	}

	public boolean isSwordsman(int i) {
		return soldiers.isSwordsman(i);
	}

	public boolean isLancer(int i) {
		return soldiers.isLancer(i);
	}

	public String getType(int i) {
		return soldiers.getType(i);
	}

	public int getXSoldier(int i) {
		return soldiers.getXSoldier(i);
	}

	public int getYSoldier(int i) {
		return soldiers.getYSoldier(i);
	}
}
