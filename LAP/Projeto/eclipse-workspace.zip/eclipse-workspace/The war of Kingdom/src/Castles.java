/**
 * 
 * @author Pedro Oliveira
 * @author Teresa Monteiro
 *
 */
public class Castles {

	private Castle[] castles;
	private int counter, currentCastles;

	/**
	 * Constructor of the class Castles that defines a collection of castles, its
	 * initial number and the current castle
	 * 
	 * @param numTotalCastles
	 *            - size of the array
	 */
	public Castles(int numTotalCastles) {
		castles = new Castle[numTotalCastles];
		counter = 0;
		currentCastles = -1;
	}

	/**
	 * Method that allows to get a castle by using its index
	 * 
	 * @param i
	 *            - index of the castle
	 * @return - castle
	 */
	public Castle getCastle(int i) {
		return castles[i];
	}

	/**
	 * Method that allows to add a castle to the array
	 * 
	 * @param castle
	 *            - object from the class Castle that is added
	 */
	public void addCastle(Castle castle) {
		castles[counter++] = castle;
	}

	/**
	 * Method that allows to remove a castle from the array by using its position
	 * 
	 * @param x
	 *            - x position of the castle
	 * @param y
	 *            - y position of the castle
	 */
	public void removeCastles(int x, int y) {
		if (getCastlePos(x, y) >= 0) {
			removeAt(getCastlePos(x, y));
		}
	}

	/**
	 * Method that allows to remove a castle from the array by using its index
	 * 
	 * @param pos
	 *            - index of the castle
	 */
	private void removeAt(int pos) {
		for (int i = pos; i < this.counter; i++) {
			castles[i] = castles[i + 1];
		}
		counter--;
	}

	/**
	 * Method that allows to set the castle's owner by using a string with the
	 * castle name to find it and a string with the kingdom's name to set it
	 * 
	 * @param castleName
	 *            - name of the castle
	 * @param owner
	 *            - name of the kingdom that got it
	 */
	public void setOwner(String castleName, String owner) {
		castles[searchIndex(castleName)].setOwner(owner);
	}

	/**
	 * Method that allows to get the owner of a castle by using the castle's name
	 * 
	 * @param castleName
	 *            - name of the castle
	 * @return name
	 */
	public String getSpecifiedOwner(String castleName) {
		String name = "";
		if (searchIndex(castleName) >= 0)
			name = castles[searchIndex(castleName)].getOwner();
		return name;
	}

	/**
	 * Method that allows to get the owner of a castle by using the castle position
	 * 
	 * @param x
	 *            - x position of the castle
	 * @param y
	 *            - y position of the castle
	 * @return owner
	 */
	public String getSpecifiedOwnerPos(int x, int y) {
		return castles[getCastlePos(x, y)].getOwner();
	}

	/**
	 * Method that returns the number of castles on the array
	 * 
	 * @return - counter
	 */
	public int getNumCastles() {
		return counter;
	}

	/**
	 * Method that allows to find the index of a castle by using its name
	 * 
	 * @param name
	 *            - name of the castle
	 * @return - index
	 */
	public int searchIndex(String name) {
		int i = 0;
		int result = -1;
		boolean found = false;
		while (i < counter && !found) {

			if (castles[i].getName().equals(name))
				found = true;
			else
				i++;
			if (found)
				result = i;
		}
		return result;
	}

	/**
	 * Method that allows to verify if there is a castle on a position that the user
	 * defines
	 * 
	 * @param x
	 *            - x position of the castle
	 * @param y
	 *            - y position of the castle
	 * @return true if there is a castle on that position
	 */
	public boolean searchCastle(int x, int y) {
		int i = 0;
		boolean found = false;
		while (i < counter && !found) {
			if (castles[i].getXCastle() == x && castles[i].getYCastle() == y)
				found = true;
			else
				i++;
		}
		return found;
	}

	/**
	 * Method that allows to get a castle index by using its position
	 * 
	 * @param x
	 *            - x position of the castle
	 * @param y
	 *            - y position of the castle
	 * @return - result
	 */
	public int getCastlePos(int x, int y) {
		int i = 0;
		int result = -1;
		boolean found = false;
		while (i < counter && !found) {
			if (castles[i].getXCastle() == x && castles[i].getYCastle() == y) {
				result = i;
				found = true;
			}
			i++;
		}
		return result;
	}

	/**
	 * Method that initializes an iterator
	 */
	public void initializeIterator() {
		currentCastles = 0;
	}

	/**
	 * Method that returns the next castle
	 * 
	 * @return castle
	 */
	public Castle next() {
		return castles[currentCastles++];
	}

	/**
	 * Method that verifies if there is a next castle
	 * 
	 * @return true if there is a next castle
	 */
	public boolean hasNext() {
		return ((currentCastles >= 0) && (currentCastles < counter));
	}

	/**
	 * Method that verifies if there is a castle by using its name
	 * 
	 * @param name
	 *            - castle name
	 * @return true if there is a castle
	 */
	public boolean hasCastle(String name) {
		return (searchIndex(name) >= 0);
	}

	/**
	 * Method that verifies if there is a castle by using its position
	 * 
	 * @param x
	 *            - x position of the castle
	 * @param y
	 *            - y position of the castle
	 * @return true if there is
	 */
	public boolean hasCastlePos(int x, int y) {
		return (getCastlePos(x, y) >= 0);
	}

	/**
	 * Method that returns the number of soldiers on it by using its index
	 * 
	 * @param i
	 *            - castle's index
	 * @return - number of soldiers
	 */
	public int getNumSoldiers(int i) {
		return getCastle(i).getCastleSoldiers();
	}

	/**
	 * Method that gets the owner of the castle by using its index
	 * 
	 * @param i
	 *            - castle's index
	 * @return owner
	 */
	public String getOwner(int i) {
		return getCastle(i).getOwner();
	}

	/**
	 * Method that returns the x position of a castle by using its index
	 * 
	 * @param i
	 *            - castle's index
	 * @return - x
	 */
	public int getXCastle(int i) {
		return getCastle(i).getXCastle();
	}

	/**
	 * Method that returns the y position of a castle by using its index
	 * 
	 * @param i
	 *            - castle's index
	 * @return - y
	 */
	public int getYCastle(int i) {
		return getCastle(i).getYCastle();
	}

}