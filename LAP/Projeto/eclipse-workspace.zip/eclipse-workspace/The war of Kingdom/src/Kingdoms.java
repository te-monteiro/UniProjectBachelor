
public class Kingdoms {

	private Castles c;
	private Kingdom k;
	private Kingdom[] kingdoms;
	private int counter, currentKingdom, currentOrd;
	private Kingdom[] iteraOrd;

	public Kingdoms(int numKingdoms) {
		kingdoms = new Kingdom[numKingdoms];
		counter = 0;
		currentKingdom = -1;
		currentOrd = -1;
	}

	public boolean hasCastle(int i, int x, int y) {
		return kingdoms[i].hasCastle(x, y);
	}

	/** Metodo que adiciona reinos */
	public void addKingdom(String name, int numTotalCastles, Castle castle) {
		kingdoms[counter++] = new Kingdom(name, numTotalCastles, castle);
	}

	public boolean hasKingdom(int i, String lastOwner) {
		return (searchKingdomName(lastOwner) >= 0);
	}

	public void removeKingdom(String name) {
		if (searchKingdomName(name) >= 0) {
			removeAt(searchKingdomName(name));
			searchKingdomName(name);
		}
	}

	public void removeAt(int pos) {
		for (int i = pos; i < counter - 1; i++) {
			kingdoms[i] = kingdoms[i + 1];
		}
		counter--;
	}

	public int numKingdoms() {
		return counter;
	}

	// public int getNumKingdoms() {
	// return this.numKingdoms;
	// }

	public Kingdom getKingdom(int i) {
		return kingdoms[i];
	}

	public String getKingdomName(int i) {
		return kingdoms[i].getKingdomName();
	}

	public int searchKingdomName(String name) {
		int result = -1;
		boolean found = false;
		for (int i = 0; i < counter && !found; i++)
			if (getKingdomName(i).equals(name)) {
				result = i;
				found = true;
			}
		return result;
	}

	public boolean hasKingdom(String name) {
		return (searchKingdomName(name) >= 0);
	}

	public void initializeIterator() {
		currentKingdom = 0;
	}
	

	public boolean hasNext() {
		return ((currentKingdom >= 0) && (currentKingdom < counter));
	}

	public Kingdom next() {
		return kingdoms[currentKingdom++];
	}


	public int searchOwner(String name, Castle castle) {
		int i = 0;
		int result = -1;
		boolean found = false;
		while (i < counter && !found) {
			if (c.getCastle(i).getOwner() == k.getKingdomName()) {
				found = true;
				k.addNumCastles(castle);
			} else
				i++;
			if (found)
				result = i;
		}
		return result;
	}

	public void bubbleSort(Kingdom[] kingdoms) {
		for (int i = 1; i < counter; i++)
			for (int j = counter - 1; j >= i; j--)
				if (kingdoms[j - 1].greaterThan(kingdoms[j])) {
					Kingdom temp = kingdoms[j - 1];
					kingdoms[j - 1] = kingdoms[j];
					kingdoms[j] = temp;
				}
	}

	public void initializeOrdIterator() {
		// copia de vector
		iteraOrd = new Kingdom[counter];
		for (int i = 0; i < counter; i++)
			iteraOrd[i] = kingdoms[i];
		// ordenar contactos por nome
		bubbleSort(iteraOrd);
		currentOrd = 0;
	}

	public boolean hasNextOrd() {
		return ((currentOrd >= 0) && (currentOrd < counter));
	}

	public Kingdom nextOrd() {
		return iteraOrd[currentOrd++];
	}

	/**
	 * 
	 * @param i
	 *            Corresponde ao indice do reino
	 * @return do numero total de soldados que existem num reino
	 */
	public int getNumTotalSoldiers(int i) {
		return getKingdom(i).getTotalSoldiers();
	}

	/**
	 * 
	 * @param i
	 *            Corresponde ao indice do reino.
	 * @param x
	 *            Corresponde a abcissa do soldado que pretendemos procurar.
	 * @param y
	 *            Corresponde a ordenada do soldado que pretendemos procurar.
	 * @return do indice do soldado cujas coordenas correspondem as que
	 *         introduzimos.
	 */
	public int searchSoldier(int i, int x, int y) {
		return getKingdom(i).searchSoldier(x, y);
	}

	/**
	 * Metodo que permite obter um soldado de acordo com as suas coordenadas e, de
	 * seguida, remove-lo.
	 * 
	 * @param x
	 *            Corresponde a abcissa do soldado que pretendemos procurar.
	 * @param y
	 *            Corresponde a ordenada do soldado que pretendemos procurar.
	 */
	public void killSoldier(int i, int x, int y) {
		getKingdom(i).killSoldier(x, y);
	}

	public boolean isKnight(int i, int j) {
		return getKingdom(i).isKnight(j);
	}

	public boolean isSwordsman(int i, int j) {
		return getKingdom(i).isSwordsman(j);
	}

	public boolean isLancer(int i, int j) {
		return getKingdom(i).isLancer(j);
	}

	public String getType(int i, int j) {
		return getKingdom(i).getType(j);
	}

	public int getXSoldier(int i, int j) {
		return getKingdom(i).getXSoldier(j);
	}

	public int getYSoldier(int i, int j) {
		return getKingdom(i).getYSoldier(j);
	}

	public boolean friendlySoldier(int i, int x, int y) {
		return getKingdom(i).friendlySoldier(x, y);
	}

	public int getNumCastles(int i) {
		return getKingdom(i).getNumCastles();
	}

	public void removeCastles(int i, int x, int y) {
		getKingdom(i).removeCastles(x, y);
	}

}
