import java.util.Scanner;

public class Main {

	/**
	 * Constants that represents inputs that the user is allowed to do, to access
	 * the menu
	 */
	private static final String NEW_GAME = "novo";
	private static final String SOLDIER = "soldado";
	private static final String RECRUIT = "recruta";
	private static final String MAP = "mapa";
	private static final String CASTLES = "castelos";
	private static final String ARMY = "exercito";
	private static final String KINGDOMS = "reinos";
	private static final String HELP = "ajuda";
	private static final String QUIT = "sai";

	/**
	 * Constants that represent Help Command messages
	 */
	private static final String NEW_GAME_HELP = "novo - Novo jogo";
	private static final String SOLDIER_HELP = "soldado - Move o soldado";
	private static final String RECRUIT_HELP = "recruta - Recruta um soldado num castelo";
	private static final String MAP_HELP = "mapa - Lista todos os castelos do mapa, incluindo os abandonados, pela ordem de criacao no jogo e todos os reinos ainda em jogo, pela ordem de jogada";
	private static final String CASTLES_HELP = "castelos - Lista os castelos do jogador activo, pela ordem pela qual foram conquistados";
	private static final String ARMY_HELP = "exercito - Lista os soldados vivos do jogador activo, pela ordem de recrutamento";
	private static final String KINGDOMS_HELP = "reinos - Lista os varios reinos ainda em jogo, ordenados por nome do reino";
	private static final String HELP_HELP = "ajuda - Mostra a ajuda";
	private static final String QUIT_HELP = "sai - Termina a execucao do programa";

	/** Constantes que representam mensagens de erro */
	private static final String INACTIVE_COMMAND = "Comando inactivo.";
	private static final String INEXISTENT_OPTION = "Opcao inexistente.";
	private static final String FATAL_ERROR = "Erro fatal, jogo nao inicializado.";
	private static final String SMALL_MAP_ERROR = "Mapa pequeno demais para o jogo.";
	private static final String INVALID_NUMBER_KINGDOMS = "Numero de reinos invalido.";
	private static final String INVALID_NUMBER_CASTLES = "Numero de castelos invalido.";
	private static final String INVALID_CASTLE_POSITION = "Castelo em posicao invalida.";
	private static final String INVALID_WEALTH = "Castelo com riqueza invalida.";
	private static final String INSUFFICIENT_CASTLES = "Numero insuficiente de castelos criados.";
	private static final String INSUFFICIENT_KINGDOMS = "Numero insuficiente de reinos criados.";
	private static final String CASTLE_MISSING = "Castelo nao existe.";
	private static final String CASTLES_NAMES = "Os castelos nao podem ter nomes duplicados.";
	private static final String KINGDOMS_NAMES = "Os reinos nao podem ter nomes duplicados.";
	private static final String OCCUPIED_CASTLE = "Castelo ja ocupado.";
	private static final String INVALID_SOLDIER = "Tipo de soldado inexistente.";
	private static final String ILLEGAL_INVASION = "Castelo invadido ilegalmente.";
	private static final String INSUFFICIENT_WEALTH = "Riqueza insuficiente para recrutamento.";
	private static final String NOT_FREE = "Castelo nao livre.";
	private static final String NO_SOLDIER = "Nao existe nenhum soldado ilustre da casa de %s na posicao (%s,%s).%n";
	private static final String IS_COWARD = "O %s da ilustre casa de %s e um cobardolas.%n";
	private static final String OTHER_PLACE = "O %s da ilusre casa de %s devia tentar ir para outro sitio.%n";
	private static final String NO_CASTLES = "Sem castelos.";
	private static final String DEAD_SOLDIER = "%s %s morto%n";

	/**
	 * Constants that represent game' messages
	 */
	private static final String GAME_INITIATED = "Jogo iniciado, comeca o reino %s.%n";
	private static final String BYE = "Obrigado por jogar. Ate a proxima.";
	private static final String NO_ARMY = "Sem exercito.";
	private static final String KINGDOM = " reinos:";
	private static final String CASTLE = " castelos:";
	private static final String SOLDIERS = " soldados:";
	private static final String WITH_RICHES = "%s com riqueza %s na posicao (%s,%s)%n";
	private static final String OF_RICHES = "%s, %s castelos, %s soldados, %s de riqueza%n";
	private static final String ON_POSITION = "%s na posicao (%s,%s)%n";
	private static final String NEW_CASTLE = "O %s da ilustre casa de %s adquiriu um novo castelo %s para o seu reino.%n";
	private static final String KNIGHT = "cavaleiro";
	private static final String LANCER = "lanceiro";
	private static final String SWORDSMAN = "espadachim";
	private static final String COORDINATES = "%s %s (%s,%s)%n";
	private static final String GLORIOUS_BATTLE = "Sou um heroi %s! Vitoria gloriosa!%n";
	private static final String WIN_BATTLE = "Muhahah, sou um %s! Sou invencivel! Nenhum %s me faz frente!%n";
	private static final String LOSE_BATTLE = "Argh! A dor! Maldito sejas, %s %s.%n";
	private static final String RECRUIT_SUCCESS = "%s recrutado no %s do reino %s por %s moedas.%n";
	private static final String MAP_COORDINATES = "%s %s%n";
	private static final String CASTLE_BIO = "%s (%s)%n";
	private static final String KINGDOM_INFORMATION = "%s; ";

	/**
	 * Constants that represent map limits and kingdom capacity limits
	 */
	private static final int MAP_LIMIT = 10;
	private static final int MAP_MIN_LIMIT = 1;
	private static final int MIN_KINGDOMS = 2;
	private static final int MAX_KINGDOMS = 8;

	/**
	 * Method to get the Scanner command
	 * 
	 * @param in
	 *            - Scanner
	 * @param gamePlay
	 *            - Game class object
	 * @return input
	 */
	private static String getCommand(Scanner in, Game gamePlay) {
		if (!gamePlay.gameStatus())
			System.out.print("> ");
		else {
			System.out.print(gamePlay.getKingdomName() + " > ");
		}
		String input = in.next().toLowerCase();
		return input;

	}

	/**
	 * Method that allows to start a new game
	 * 
	 * @param in
	 *            - Scanner
	 * @param gamePlay
	 *            - Game class object
	 */
	private static void processNewGame(Scanner in, Game gamePlay) {
		gamePlay.resetTeamPlayingInt();

		int width = in.nextInt();
		int height = in.nextInt();
		int numTotalKingdoms = in.nextInt();
		int numTotalCastles = in.nextInt();
		in.nextLine();
		if (width < MAP_LIMIT || height < MAP_LIMIT) {
			System.out.println(SMALL_MAP_ERROR);
			System.out.println(FATAL_ERROR);
			gamePlay.gameOff();
		} else if (numTotalKingdoms < MIN_KINGDOMS || numTotalKingdoms > MAX_KINGDOMS) {
			System.out.println(INVALID_NUMBER_KINGDOMS);
			System.out.println(FATAL_ERROR);
			gamePlay.gameOff();
		} else if (numTotalCastles > width * height || numTotalCastles < numTotalKingdoms) {
			System.out.println(INVALID_NUMBER_CASTLES);
			System.out.println(FATAL_ERROR);
			gamePlay.gameOff();
		} else {
			gamePlay.createGame(width, height, numTotalKingdoms, numTotalCastles);
			gamePlay.gameOn();
			System.out.println(numTotalCastles + CASTLE);
			createCastles(in, numTotalCastles, gamePlay, width, height);

			if (numTotalCastles < numTotalKingdoms) {
				System.out.println(INSUFFICIENT_CASTLES);
				System.out.println(FATAL_ERROR);
				gamePlay.gameOff();
			}
			if (gamePlay.getKingdomCastles() < numTotalKingdoms) {
				System.out.println(INSUFFICIENT_CASTLES);
				System.out.println(FATAL_ERROR);
				gamePlay.gameOff();
			} else {
				System.out.println(numTotalKingdoms + KINGDOM);
				createKingdoms(in, numTotalKingdoms, gamePlay);
				if (gamePlay.getNumKingdoms() < MIN_KINGDOMS) {
					System.out.println(INSUFFICIENT_KINGDOMS);
					System.out.println(FATAL_ERROR);
					gamePlay.gameOff();
				} else
					System.out.printf(GAME_INITIATED, gamePlay.getKingdomName());
			}
		}
	}

	/**
	 * Method that allows to create a castle
	 * 
	 * @param in
	 *            - Scanner
	 * @param numTotalCastles
	 *            - total number of castles
	 * @param gamePlay
	 *            - Game class object
	 * @param width
	 *            - horizontal map boundary
	 * @param height
	 *            - vertical map boundary
	 */

	private static void createCastles(Scanner in, int numTotalCastles, Game gamePlay, int width, int height) {
		for (int i = 0; i < numTotalCastles; i++) {
			int x = in.nextInt();
			int y = in.nextInt();
			int wealth = in.nextInt();
			String name = in.nextLine().trim();
			if (x < MAP_MIN_LIMIT || x > width || y < MAP_MIN_LIMIT || y > height || !gamePlay.statusCastles(x, y)) {
				System.out.println(INVALID_CASTLE_POSITION);
			} else if (wealth < 0) {
				System.out.println(INVALID_WEALTH);
			} else if (gamePlay.nameExistsCastles(name))
				System.out.println(CASTLES_NAMES);
			else {
				gamePlay.createCastle(x, y, wealth, name);

			}

		}

	}

	/**
	 * Method that allows to create kingdoms
	 * 
	 * @param in
	 *            - Scanner
	 * @param numTotalKingdoms
	 *            - total number of kingdoms
	 * @param gamePlay
	 *            - Game class object
	 */
	private static void createKingdoms(Scanner in, int numTotalKingdoms, Game gamePlay) {
		for (int i = 0; i < numTotalKingdoms; i++) {
			String kingdomName = in.next().trim();
			String castleName = in.nextLine().trim();
			if (gamePlay.nameExistsKingdoms(kingdomName)) {
				System.out.println(KINGDOMS_NAMES);
			} else if (!gamePlay.nameExistsCastles(castleName)) {
				System.out.println(CASTLE_MISSING);
			} else if (gamePlay.getOwner(castleName) != "")
				System.out.println(OCCUPIED_CASTLE);
			else
				gamePlay.createKingdom(kingdomName, gamePlay.getCastle(castleName));
		}

	}

	/**
	 * Method that represents the menu, when there is no game started
	 */
	private static void listMenu() {
		System.out.println(NEW_GAME_HELP);
		System.out.println(HELP_HELP);
		System.out.println(QUIT_HELP);
	}

	/**
	 * Method that represents the functionalities of each commands
	 * 
	 * @param gamePlay
	 *            - Game class object
	 */
	private static void processHelp(Game gamePlay) {
		if (gamePlay.gameStatus() == false)
			listMenu();
		else {
			System.out.println(NEW_GAME_HELP);
			System.out.println(SOLDIER_HELP);
			System.out.println(RECRUIT_HELP);
			System.out.println(MAP_HELP);
			System.out.println(CASTLES_HELP);
			System.out.println(ARMY_HELP);
			System.out.println(KINGDOMS_HELP);
			System.out.println(HELP_HELP);
			System.out.println(QUIT_HELP);
		}

	}

	/**

	 * Method that allows to move the soldier and if there is any unforeseen in
	 * relation to the movement, to give error
	 * 
	 * @param in
	 *            - Scanner
	 * @param gamePlay
	 *            - Game class object
	 */
	private static void processSoldier(Scanner in, Game gamePlay) {
		int n = 0;
		Kingdom k = gamePlay.getTeamPlaying();
		int x = in.nextInt();
		int y = in.nextInt();
		if (!k.statusSoldier(x, y)) {
			System.out.printf(NO_SOLDIER, k.getKingdomName(), x, y);
			in.nextLine();
			gamePlay.turnChange();
			auxiliaryGainWealth(gamePlay);
		} else {
			Soldiers s = k.getSoldier(k.searchSoldier(x, y));
			if (s.isKnight()) {
				while (n < 3) {
					Soldiers soldier = k.getSoldier(k.searchSoldier(x, y));
					String move = in.next();
					soldier.movement(move);
					x = soldier.getX();
					y = soldier.getY();
					if (gamePlay.gameStatus()) {
						if (gamePlay.outsidemap(soldier.getX(),
								soldier.getY())) { /** Se o soldado for para fora do mapa */
							soldier.moveBack(move);
							System.out.printf(IS_COWARD, soldier.getType(), k.getKingdomName());
						} else if (k.samePos(x, y) > 1) {
							System.out.printf(OTHER_PLACE, soldier.getType(), k.getKingdomName());
							soldier.moveBack(move);
						} else if (!gamePlay.friendlySoldier(x,
								y)) {/** Se houver um soldado inimigo no lugar para qual queremos ir */
							auxKnightFights(gamePlay, k, x, y);
							conquerCastles(gamePlay, k, soldier, x, y, k.getKingdomName());
							kingdomLose(gamePlay, k.getKingdomName(), soldier);
							if (!k.statusSoldier(x, y)) {
								n = 3;
								in.nextLine();
							}
						} else {
							conquerCastles(gamePlay, k, s, x, y, k.getKingdomName());
							kingdomLose(gamePlay, k.getKingdomName(), soldier);

						}
						x = soldier.getX();
						y = soldier.getY();
						if (k.samePos(x, y) == 1 && gamePlay.gameStatus()) {
							System.out.printf(COORDINATES, k.getKingdomName(), soldier.getType(), soldier.getX(),
									soldier.getY());
						}
					}
					n++;

				}
				gamePlay.turnChange();
				auxiliaryGainWealth(gamePlay);

			} else {
				String move = in.next();
				in.nextLine();
				s.movement(move);
				x = s.getX();
				y = s.getY();
				if (gamePlay.outsidemap(s.getX(), s.getY())) { /** Se o soldado for para fora do mapa */
					s.moveBack(move);
					System.out.printf(IS_COWARD, s.getType(), k.getKingdomName());
					System.out.printf(COORDINATES, k.getKingdomName(), s.getType(), s.getX(), s.getY());
				} else if (k.samePos(x,
						y) > 1) {/** Se houver um soldado do mesmo reino no lugar para o qual queremos ir */
					System.out.printf(OTHER_PLACE, s.getType(), k.getKingdomName());
					s.moveBack(move);
					System.out.printf(COORDINATES, k.getKingdomName(), s.getType(), s.getX(), s.getY());

				} else if (!gamePlay.friendlySoldier(x, y)) {
					if (gamePlay.getAllieType(x, y).equals(LANCER)) {
						auxLancerFights(gamePlay, k, x, y);
						conquerCastles(gamePlay, k, s, x, y, k.getKingdomName());
						kingdomLose(gamePlay, k.getKingdomName(), s);
						if (k.samePos(x, y) == 1)
							System.out.printf(COORDINATES, k.getKingdomName(), s.getType(), s.getX(), s.getY());
					} else if (gamePlay.getAllieType(x, y).equals(SWORDSMAN)) {
						auxSwordsmanFights(gamePlay, k, x, y);
						conquerCastles(gamePlay, k, s, x, y, k.getKingdomName());
						kingdomLose(gamePlay, k.getKingdomName(), s);
						if (k.samePos(x, y) == 1)
							System.out.printf(COORDINATES, k.getKingdomName(), s.getType(), s.getX(), s.getY());
					} else {
						conquerCastles(gamePlay, k, s, x, y, k.getKingdomName());
						kingdomLose(gamePlay, k.getKingdomName(), s);
						if (k.samePos(x, y) == 1)
							System.out.printf(COORDINATES, k.getKingdomName(), s.getType(), s.getX(), s.getY());
					}
				} else {
					conquerCastles(gamePlay, k, s, x, y, k.getKingdomName());
					kingdomLose(gamePlay, k.getKingdomName(), s);
					System.out.printf(COORDINATES, k.getKingdomName(), s.getType(), s.getX(), s.getY());
				}
				gamePlay.turnChange();
				auxiliaryGainWealth(gamePlay);
			}

		}

	}

	/**
	 * Method that allows all castles to gain wealth.
	 * 
	 * @param gamePlay
	 *            - Game class object
	 */
	private static void auxiliaryGainWealth(Game gamePlay) {
		gamePlay.initialIteratorCastle();
		while (gamePlay.hasNextCastle()) {
			Castle c = gamePlay.nextCastle();
			c.gainWealth();
		}
	}

	/**
	 * Auxiliary method that removes a kingdom if it does not have castles or
	 * soldiers
	 * 
	 * @param gamePlay
	 *            - Game class object
	 * @param playingKing
	 *            - name of the kingdom that is playing
	 * @param soldier
	 *            - object that calls the class soldier
	 */
	private static void kingdomLose(Game gamePlay, String playingKing, Soldiers soldier) {
		gamePlay.isKingEmpty();

		int x = gamePlay.getKingdomIndex(playingKing);
		gamePlay.setTeamPlaying(x);
		if (gamePlay.getNumKingdoms() == 1) {
			gamePlay.resetTeamPlayingInt();
			System.out.printf(COORDINATES, playingKing, soldier.getType(), soldier.getX(), soldier.getY());
			System.out.printf(GLORIOUS_BATTLE, gamePlay.getKingdomName());
			gamePlay.gameOff();
		}
	}

	/**
	 * Auxiliary method that allows castle conquering of many kingdoms of the game
	 * 
	 * @param gamePlay
	 *            - Game class object
	 * @param k
	 *            - object that calls the kingdom that is playing
	 * @param soldier
	 *            - object that calls the soldier that is on position of castle who
	 *            wants to conquer
	 * @param x
	 *            - x position of the castle
	 * @param y
	 *            - y position of the castle
	 * @param playingKing
	 *            - name of the kingdom that is playing
	 */
	private static void conquerCastles(Game gamePlay, Kingdom k, Soldiers soldier, int x, int y, String playingKing) {
		if (!gamePlay.statusCastles(x, y) && k.samePos(x, y) == 1) {
			if (gamePlay.enemyCastle(x, y)) {

				Castle c = gamePlay.getPosCastles(x, y);
				gamePlay.removeCastles(x, y);
				k.conquerCastle(c);

				System.out.printf(NEW_CASTLE, soldier.getType(), k.getKingdomName(), c.getName());
			}
		}
	}

	/**
	 * Auxiliary method that allows the execution of combats between a knight and
	 * other soldiers
	 * 
	 * @param gamePlay
	 *            - Game class object
	 * @param k
	 *            - objects that calls class Kingdom
	 * @param x
	 *            - x position of the castle
	 * @param y
	 *            - y position of the castle
	 */
	private static void auxKnightFights(Game gamePlay, Kingdom k, int x, int y) {
		if (gamePlay.isEnemyKnight(x, y)) {
			gamePlay.killEnemySoldier(x, y);
			System.out.printf(WIN_BATTLE, k.getKingdomName(), KNIGHT);
		} else if (gamePlay.isEnemySwordsman(x, y)) {
			gamePlay.killEnemySoldier(x, y);
			System.out.printf(WIN_BATTLE, k.getKingdomName(), SWORDSMAN);
		} else if (gamePlay.isEnemyLancer(x, y)) {
			System.out.printf(LOSE_BATTLE, LANCER, gamePlay.getEnemyName(x, y));
			System.out.printf(DEAD_SOLDIER, k.getKingdomName(), gamePlay.getSoldier(x, y).getType());
			gamePlay.killAllieSoldier(x, y);
		}
	}

	/**
	 * Auxiliary method that allows the execution of combats between a lancer and
	 * other soldiers
	 * 
	 * @param gamePlay
	 *            - Game class object
	 * @param k
	 *            - objects that calls class Kingdom
	 * @param x
	 *            - x position of the castle
	 * @param y
	 *            - y position of the castle
	 */
	private static void auxLancerFights(Game gamePlay, Kingdom k, int x, int y) {
		if (gamePlay.isEnemyKnight(x, y)) {
			gamePlay.killEnemySoldier(x, y);
			System.out.printf(WIN_BATTLE, k.getKingdomName(), KNIGHT);
		} else if (gamePlay.isEnemySwordsman(x, y)) {
			System.out.printf(LOSE_BATTLE, SWORDSMAN, gamePlay.getEnemyName(x, y));
			System.out.printf(DEAD_SOLDIER, k.getKingdomName(), gamePlay.getSoldier(x, y).getType());
			gamePlay.killAllieSoldier(x, y);
		} else if (gamePlay.isEnemyLancer(x, y)) {
			gamePlay.killEnemySoldier(x, y);
			System.out.printf(WIN_BATTLE, k.getKingdomName(), LANCER);

		}
	}

	/**
	 * Auxiliary method that allows the execution of combats between a swordsman and
	 * other soldiers
	 * 
	 * @param gamePlay
	 *            - Game class object
	 * @param k
	 *            - objects that calls class Kingdom
	 * @param x
	 *            - x position of the castle
	 * @param y
	 *            - y position of the castle
	 */
	private static void auxSwordsmanFights(Game gamePlay, Kingdom k, int x, int y) {
		if (gamePlay.isEnemyKnight(x, y)) {
			System.out.printf(LOSE_BATTLE, KNIGHT, gamePlay.getEnemyName(x, y));
			System.out.printf(DEAD_SOLDIER, k.getKingdomName(), gamePlay.getSoldier(x, y).getType());
			gamePlay.killAllieSoldier(x, y);
		} else if (gamePlay.isEnemySwordsman(x, y)) {
			gamePlay.killEnemySoldier(x, y);
			System.out.printf(WIN_BATTLE, k.getKingdomName(), SWORDSMAN);
		} else if (gamePlay.isEnemyLancer(x, y)) {
			gamePlay.killEnemySoldier(x, y);
			System.out.printf(WIN_BATTLE, k.getKingdomName(), LANCER);
		}

	}

	/**
	 * Method that allows to recruit a soldier on a castle by inputting the
	 * soldier's type and the castle's position
	 * 
	 * @param in
	 *            - Scanner
	 * @param gamePlay
	 *            - Game class object
	 */
	private static void processRecruit(Scanner in, Game gamePlay) {
		Kingdom k = gamePlay.getTeamPlaying();
		String type = in.next();
		String castleName = in.nextLine().trim();
		if (k.invalidSoldier(type))
			System.out.println(INVALID_SOLDIER);
		else if (!gamePlay.getOwner(castleName).equals(k.getKingdomName()))
			System.out.println(ILLEGAL_INVASION);
		else {
			Castle c = gamePlay.getCastle(castleName);
			int valor = c.getWealth();
			valor -= k.getSoldierCost(type);
			if (valor < 0)
				System.out.println(INSUFFICIENT_WEALTH);
			else if (k.statusSoldier(c.getXCastle(), c.getYCastle()))
				System.out.println(NOT_FREE);
			else {

				String owner = k.getKingdomName();// ver se esta linha e necessaria
				k.createSoldier(c.getXCastle(), c.getYCastle(), type);
				gamePlay.getSoldier(c.getXCastle(), c.getYCastle()).setSoldierOwner(owner);
				System.out.printf(RECRUIT_SUCCESS, type, castleName, k.getKingdomName(), k.getSoldierCost(type));
				c.changeWealth(valor);

			}
		}
		gamePlay.turnChange();
		auxiliaryGainWealth(gamePlay);
	}

	/**
	 * Method that shows all game information
	 * 
	 * @param gamePlay
	 *            - Game class object
	 */
	private static void processMap(Game gamePlay) {
		System.out.printf(MAP_COORDINATES, gamePlay.getWidth(), gamePlay.getHeight());
		System.out.println(gamePlay.getKingdomCastles() + CASTLE);

		gamePlay.initialIteratorCastle();
		while (gamePlay.hasNextCastle()) {
			Castle c = gamePlay.nextCastle();
			if (c.getOwner() == "")
				c.abadonedCastle();
			System.out.printf(CASTLE_BIO, c.getName(), c.getOwner());
		}

		System.out.println(gamePlay.getNumKingdoms() + KINGDOM);

		gamePlay.initialIteratorKingdom();
		while (gamePlay.hasNextKingdom()) {
			Kingdom k = gamePlay.nextKingdom();
			if (gamePlay.hasNextKingdom())
				System.out.printf(KINGDOM_INFORMATION, k.getKingdomName());
			else
				System.out.println(k.getKingdomName());
		}

	}

	/**
	 * Method that shows all castle's information
	 * 
	 * @param gamePlay
	 *            - Game class object
	 */
	private static void processCastles(Game gamePlay) {
		Kingdom k = gamePlay.getTeamPlaying();
		if (k.getNumCastles() != 0) {
			System.out.println(k.getNumCastles() + CASTLE);

			k.initializeIterator();
			while (k.hasNext()) {
				Castle c = k.next();
				System.out.printf(WITH_RICHES, c.getName(), c.getWealth(), c.getXCastle(), c.getYCastle());
			}
		} else
			System.out.println(NO_CASTLES);

	}

	/**
	 * Method that shows game's information
	 * 
	 * @param gamePlay
	 *            - Game class object
	 */
	private static void processArmy(Game gamePlay) {
		Kingdom k = gamePlay.getTeamPlaying();
		if (k.getKingdomSoldiers() > 0) {
			System.out.println(k.getKingdomSoldiers() + SOLDIERS);

			k.initializeIteratorSoldiers();
			while (k.hasNextSoldier()) {
				Soldiers s = k.nextSoldier();
				System.out.printf(ON_POSITION, s.getType(), s.getX(), s.getY());
			}
		} else
			System.out.println(NO_ARMY);

	}

	/**
	 * Method that shows all kingdoms' information
	 * 
	 * @param gamePlay
	 *            - Game class object
	 */
	private static void processKingdoms(Game gamePlay) {
		int totalSum = 0;

		System.out.println(gamePlay.getNumKingdoms() + KINGDOM);

		gamePlay.initializeOrdIterator();
		while (gamePlay.hasNextOrd()) {
			Kingdom k = gamePlay.nextOrd();

			k.initializeIterator();
			while (k.hasNext()) {
				Castle c = k.next();
				totalSum += c.getWealth();
			}

			System.out.printf(OF_RICHES, k.getKingdomName(), k.getNumCastles(), k.getKingdomSoldiers(), totalSum);

			totalSum = 0;
		}
	}

	/**
	 * Method that allows the user to access the menu's commands
	 * 
	 * @param in
	 *            - Scanner
	 * @param gamePlay
	 *            - Game class object
	 */
	private static void menu(Scanner in, Game gamePlay) {
		String comm = "";
		listMenu();
		do {
			comm = getCommand(in, gamePlay);
			if (!comm.equals(QUIT) && gamePlay.gameStatus() == false)
				switch (comm) {
				case NEW_GAME:
					processNewGame(in, gamePlay);
					break;
				case HELP:
					processHelp(gamePlay);
					break;
				case SOLDIER:
					System.out.println(INACTIVE_COMMAND);
					break;
				case RECRUIT:
					System.out.println(INACTIVE_COMMAND);
					in.nextLine();
					break;
				case MAP:
					System.out.println(INACTIVE_COMMAND);
					break;
				case CASTLES:
					System.out.println(INACTIVE_COMMAND);
					break;
				case ARMY:
					System.out.println(INACTIVE_COMMAND);
					break;
				case KINGDOMS:
					System.out.println(INACTIVE_COMMAND);
					break;
				case QUIT:
					break;
				default:
					System.out.println(INEXISTENT_OPTION);
					in.nextLine();
					break;
				}
			else
				switch (comm) {
				case NEW_GAME:
					processNewGame(in, gamePlay);
					break;
				case SOLDIER:
					processSoldier(in, gamePlay);

					break;
				case RECRUIT:
					processRecruit(in, gamePlay);
					break;
				case MAP:
					processMap(gamePlay);
					break;
				case CASTLES:
					processCastles(gamePlay);
					break;
				case ARMY:
					processArmy(gamePlay);
					in.nextLine();
					break;
				case KINGDOMS:
					processKingdoms(gamePlay);
					break;
				case HELP:
					processHelp(gamePlay);
					break;
				case QUIT:
					break;
				default:
					System.out.println(INEXISTENT_OPTION);
					in.nextLine();
					break;
				}
		} while (!comm.equals(QUIT));
		System.out.println(BYE);
		in.close();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		Game gamePlay = new Game();
		menu(in, gamePlay);

	}

}
