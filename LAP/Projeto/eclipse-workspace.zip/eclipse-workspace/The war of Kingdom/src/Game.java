/**
 * 
 * @author Pedro Oliveira
 * @author Teresa Monteiro
 *
 */
public class Game {

	private Kingdoms k;
	private Castles c;
	private int width, height;
	private int numTotalKingdoms, numTotalCastles;
	private boolean isRunning;
	private int teamPlaying;

	/**
	 * Constructor of the class Game that defines a collection kingdoms, collection
	 * of castles, if the game is running or not and which kingdom start the game
	 */
	public Game() {
		k = new Kingdoms(numTotalKingdoms);
		c = new Castles(numTotalCastles);
		isRunning = false;
		teamPlaying = 0;
	}

	/**
	 * width limit
	 * 
	 * @return width
	 */
	public int getWidth() {
		return width;
	}

	/**
	 * height limit
	 * 
	 * @return height
	 */
	public int getHeight() {
		return height;
	}

	/**
	 * Method that allows to create Game
	 * 
	 * @param x
	 *            - width coordinate
	 * @param y
	 *            - height coordinate
	 * @param numTotalKingdoms
	 *            - total number of kingdoms
	 * @param numTotalCastles
	 *            - total number of castles
	 */
	public void createGame(int x, int y, int numTotalKingdoms, int numTotalCastles) {
		width = x;
		height = y;
		this.numTotalKingdoms = numTotalKingdoms;
		this.numTotalCastles = numTotalCastles;
		k = new Kingdoms(numTotalKingdoms);
		c = new Castles(numTotalCastles);

	}

	/**
	 * Method that allows to create kingdom
	 * 
	 * @param name
	 *            - kingdom name
	 * @param castle
	 *            - object that calls the castle that is playing
	 */
	public void createKingdom(String name, Castle castle) {
		k.addKingdom(name, numTotalCastles, castle);

	}

	/**
	 * Method that allows to create a castle
	 * 
	 * @param x
	 *            - x position of the castle
	 * @param y
	 *            - y position of the castle
	 * @param wealth
	 *            - castle's wealth
	 * @param name
	 *            - castle's name
	 */
	public void createCastle(int x, int y, int wealth, String name) {
		c.addCastle(new Castle(x, y, wealth, name));
	}

	/**
	 * Method that verifies if the game is running
	 * 
	 * @return is running
	 */
	public boolean gameStatus() {
		return isRunning;
	}

	/**
	 * Method that sets the game on
	 */
	public void gameOn() {
		isRunning = true;
	}

	/**
	 * Method that sets the game on
	 */

	public void gameOff() {
		isRunning = false;
		teamPlaying = 0;
	}

	/**
	 * Method that allows the game to change turns
	 */
	public void turnChange() {
		if (teamPlaying + 1 < k.numKingdoms())
			teamPlaying++;
		else {
			teamPlaying = 0;
		}
	}

	/**
	 * Method that allows identify the kingdom that is playing
	 * 
	 * @return kingdom is running
	 */
	public Kingdom getTeamPlaying() {
		return k.getKingdom(teamPlaying);
	}

	/**
	 * Method that allows the next team playing
	 */
	public void resetTeamPlayingInt() {
		teamPlaying = 0;
	}

	public void setTeamPlaying(int x) {
		teamPlaying = x;
	}

	public int getKingdomIndex(String name) {
		return k.searchKingdomName(name);
	}

	/**
	 * Method that allows identify the kingdom name that is playing
	 * 
	 * @return kingdom name is running
	 */
	public String getKingdomName() {
		return k.getKingdom(teamPlaying).getKingdomName();
	}

	public String getCastleOwner(int i) {
		return c.getCastle(i).getOwner();
	}

	public boolean nameExistsKingdoms(String name) {
		return k.hasKingdom(name);
	}

	public boolean nameExistsCastles(String name) {
		return c.hasCastle(name);
	}

	public int getNumKingdoms() {
		return k.numKingdoms();
	}

	public int getKingdomCastles() {
		return c.getNumCastles();
	}

	public Castle getCastle(String castleName) {
		return c.getCastle(c.searchIndex(castleName));
	}

	public Castle getPosCastles(int x, int y) {
		return c.getCastle(c.getCastlePos(x, y));
	}

	public void setOwner(String castleName, String owner) {
		c.setOwner(castleName, owner);
	}

	public String getOwner(String castleName) {
		return c.getSpecifiedOwner(castleName);
	}

	public String getOwner(int x, int y) {
		return c.getSpecifiedOwnerPos(x, y);
	}

	public void initialIteratorCastle() {
		c.initializeIterator();
	}

	public Castle nextCastle() {
		return c.next();
	}

	public boolean hasNextCastle() {
		return c.hasNext();
	}

	public void initialIteratorKingdom() {
		k.initializeIterator();
	}

	public Kingdom nextKingdom() {
		return k.next();
	}

	public boolean hasNextKingdom() {
		return k.hasNext();
	}

	public int getSpecifiedKingdomNumCastles() {
		return k.getKingdom(teamPlaying).getNumCastles();
	}

	public int getNumSoldiers(String castleName) {
		return c.getNumSoldiers(c.searchIndex(castleName));
	}

	public int getSpecifiedNumSoldiers() {
		return c.getCastle(getKingdomCastles()).getCastleSoldiers();
	}

	public void initializeOrdIterator() {
		k.initializeOrdIterator();
	}

	public boolean hasNextOrd() {
		return k.hasNextOrd();
	}

	public Kingdom nextOrd() {
		return k.nextOrd();
	}

	public int getSpecifiedWealth(String castleName) {
		return c.getCastle(c.searchIndex(castleName)).getWealth();
	}

	public int getSpecifiedCastleX(String castleName) {
		return c.getCastle(c.searchIndex(castleName)).getXCastle();
	}

	public int getSpecifiedCastleY(String castleName) {
		return c.getCastle(c.searchIndex(castleName)).getYCastle();
	}

	public boolean outsidemap(int x, int y) {
		boolean result = true;
		if (k.getKingdom(teamPlaying).getSpecifiedSoldierX(x, y) >= 1
				&& k.getKingdom(teamPlaying).getSpecifiedSoldierX(x, y) <= width
				&& k.getKingdom(teamPlaying).getSpecifiedSoldierY(x, y) >= 1
				&& k.getKingdom(teamPlaying).getSpecifiedSoldierY(x, y) <= height)
			result = false;
		return result;
	}

	public boolean statusCastles(int x, int y) {
		boolean result = true;
		if (c.searchCastle(x, y))
			result = false;
		return result;
	}

	public boolean enemyCastle(int x, int y) {
		boolean result = true;
		if (c.getSpecifiedOwnerPos(x, y).equals(k.getKingdom(teamPlaying).getKingdomName()))
			result = false;
		return result;
	}

	public void removeCastles(int x, int y) {
		boolean stop = false;
		for (int i = 0; i < k.numKingdoms() && !stop; i++) {
			if (k.hasCastle(i, x, y)) {
				stop = true;
				k.removeCastles(i, x, y);
			}
		}

	}

	public int getNumCastlesKingdom(int i) {
		return k.getNumCastles(i);
	}

	public void removeCastles(Kingdom kingdom, int x, int y) {
		kingdom.removeCastles(x, y);
	}

	public int getXCastlePos(int i) {
		return c.getXCastle(i);
	}

	public int getYCastlePos(int i) {
		return c.getYCastle(i);
	}

	public Soldiers getSoldier(int x, int y) {
		return k.getKingdom(teamPlaying).getSoldier(x, y);
	}

	public void killEnemySoldier(int x, int y) {
		for (int i = 0; i < k.numKingdoms(); i++) {
			if (k.getKingdom(i) != k.getKingdom(teamPlaying))
				for (int j = 0; j < k.getNumTotalSoldiers(i); j++)
					if (k.getXSoldier(i, j) == x && k.getYSoldier(i, j) == y)
						k.killSoldier(getPosEnemyKingdom(x, y), x, y);
		}

	}

	public void killAllieSoldier(int x, int y) {
		k.getKingdom(teamPlaying).killSoldier(x, y);
	}

	public int getPosEnemySoldier(int x, int y) {
		int result = -1;
		for (int i = 0; i < k.numKingdoms(); i++) {
			if (k.getKingdom(i) != k.getKingdom(teamPlaying))
				for (int j = 0; j < k.getNumTotalSoldiers(i); j++) {
					if (k.getXSoldier(i, j) == x && k.getYSoldier(i, j) == y)
						result = j;
				}
		}
		return result;

	}

	public int getPosEnemyKingdom(int x, int y) {
		int result = -1;
		for (int i = 0; i < k.numKingdoms(); i++)
			if (k.getKingdom(i) != k.getKingdom(teamPlaying)) {
				for (int j = 0; j < k.getNumTotalSoldiers(i); j++) {
					if (k.getXSoldier(i, j) == x && k.getYSoldier(i, j) == y)
						result = i;
				}
			}
		return result;
	}

	public boolean isEnemyKnight(int x, int y) {
		return k.isKnight(getPosEnemyKingdom(x, y), getPosEnemySoldier(x, y));
	}

	public boolean isEnemySwordsman(int x, int y) {
		return k.isSwordsman(getPosEnemyKingdom(x, y), getPosEnemySoldier(x, y));
	}

	public boolean isEnemyLancer(int x, int y) {
		return k.isLancer(getPosEnemyKingdom(x, y), getPosEnemySoldier(x, y));
	}

	public String getEnemyType(int x, int y) {
		return k.getType(getPosEnemyKingdom(x, y), getPosEnemySoldier(x, y));
	}

	public String getEnemyName(int x, int y) {
		return k.getKingdomName(getPosEnemyKingdom(x, y));
	}

	public String getAllieType(int x, int y) {
		return k.getKingdom(teamPlaying).getSoldier(x, y).getType();
	}

	public boolean friendlySoldier(int x, int y) {
		boolean result = true;
		if (getPosEnemySoldier(x, y) >= 0)
			result = false;
		return result;
	}

	public void isKingEmpty() {
		for (int i = 0; i < k.numKingdoms(); i++) {
			Kingdom kingdom = k.getKingdom(i);

			if (kingdom.getNumCastles() == 0 && kingdom.getTotalSoldiers() == 0) {
				removeKingdoms(kingdom.getKingdomName());
			}
		}

	}

	public void removeKingdoms(String lastOwner) {
		if (k.hasKingdom(lastOwner)) {
			k.removeKingdom(lastOwner);
		}
	}

	public void removeKingdom(String name) {
		k.removeKingdom(name);
	}
}
