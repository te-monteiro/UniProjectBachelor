/**
 * 
 * @author Pedro Oliveira
 * @author Teresa Monteiro
 *
 */
public class Castle {

	/**
	 * Constants that define a castle initial owner, and its owner when it is
	 * abandoned
	 */
	private static final String FIRST_OWNER = "";
	private static final String WITHOUT_OWNER = "sem dono";

	private int numSoldiers;
	private int x, y;
	private int wealth;
	private String name;
	private String owner;

	/**
	 * Constructor of the class Castle that defines the body of a castle, by having
	 * its owner initially as non-existent and
	 * 
	 * @param x
	 *            - x position of the castle
	 * @param y
	 *            - y position of the castle
	 * @param wealth
	 *            - initial wealth of the castle
	 * @param name
	 *            - castle's name
	 */
	public Castle(int x, int y, int wealth, String name) {
		this.x = x;
		this.y = y;
		this.wealth = wealth;
		this.name = name;
		owner = FIRST_OWNER;
		// numSoldiers = 0;
	}

	/**
	 * Method that returns the castle x position
	 * 
	 * @return x
	 */
	public int getXCastle() {
		return x;
	}

	/**
	 * Method that allows to return the castle y position
	 * 
	 * @return y
	 */
	public int getYCastle() {
		return y;
	}

	/**
	 * Method that allows to get the castle's wealth
	 * 
	 * @return wealth
	 */
	public int getWealth() {
		return wealth;
	}

	/**
	 * Method that allows a castle's wealth to go up by one
	 */
	public void gainWealth() {
		wealth++;
	}

	/**
	 * Method that returns the castle's name
	 * 
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Method that allows to set the castle's owner by using a string with the
	 * kingdom's name
	 * 
	 * @param owner
	 *            - name of the kingdom that got the castle
	 */
	public void setOwner(String owner) {
		this.owner = owner;
	}

	/**
	 * Method that allows to return its owner's name
	 * 
	 * @return owner
	 */
	public String getOwner() {
		return owner;
	}

	/**
	 * Method that compares the name
	 * 
	 * @param otherContact
	 * @return
	 */
	// public boolean equals(Castle otherContact) {
	// return name.equals(otherContact.getName());
	// }

	/**
	 * Method that sets the castle's owner as abandoned
	 */
	public void abadonedCastle() {
		owner = WITHOUT_OWNER;
	}

	/**
	 * Method that verifies if a castle has an owner
	 * 
	 * @return true if it has
	 */
	public boolean hasOwner() {
		boolean result = true;
		if (getOwner() == "")
			result = false;
		return result;
	}

	/**
	 * Method that returns the number of soldiers on the castle
	 * 
	 * @return numSoldiers
	 */
	public int getCastleSoldiers() {
		return numSoldiers;
	}

	/**
	 * Method that allows to change the castle's wealth by inputting a valor
	 * 
	 * @param valor
	 *            - valor
	 */
	public void changeWealth(int valor) {
		wealth = valor;
	}

}
