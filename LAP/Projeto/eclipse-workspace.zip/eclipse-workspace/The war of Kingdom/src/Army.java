/**
 * 
 * @author Pedro Oliveira
 * @author Teresa Monteiro
 *
 */
public class Army {

	/**
	 * Constants that represent the different soldier types
	 */
	private static final String KNIGHT = "cavaleiro";
	private static final String LANCER = "lanceiro";
	private static final String SWORDSMAN = "espadachim";

	/**
	 * Constants that define the default size of a array and that allows to resize
	 * if necessary
	 */
	private static final int DEFAULT_SIZE = 50;
	private static final int GROWTH_FACTOR = 2;

	private Soldiers[] soldiers;
	private int numTotalSoldiers, currentSoldiers;

	/**
	 * Constructor of the class Army that defines a collection of soldiers, its
	 * initial number and the current soldier
	 */
	public Army() {
		numTotalSoldiers = 0;
		soldiers = new Soldiers[DEFAULT_SIZE];
		currentSoldiers = -1;
	}

	/**
	 * Method that allows to select a soldier by inputting an index
	 * 
	 * @param i
	 *            - soldier index
	 * @return - soldier
	 */
	public Soldiers getSoldier(int i) {
		return soldiers[i];
	}

	/**
	 * Method that allows to add a soldier to the array
	 * 
	 * @param soldier
	 *            - soldier that the user wants to add
	 */
	public void recruitSoldier(Soldiers soldier) {
		if (isFull())
			resize();
		soldiers[numTotalSoldiers++] = soldier;
	}

	/**
	 * Method that verifies if the array is full
	 * 
	 * @return - true if is full
	 */
	private boolean isFull() {
		return numTotalSoldiers == soldiers.length;
	}

	/**
	 * Method that resizes the array if its full
	 */
	public void resize() {
		Soldiers[] tmp = new Soldiers[GROWTH_FACTOR * soldiers.length];
		for (int i = 0; i < numTotalSoldiers; i++)
			tmp[i] = soldiers[i];
		soldiers = tmp;
	}

	/**
	 * Method that allows to remove a soldier from the array, by searching that
	 * soldier using its coordinates
	 * 
	 * @param x
	 *            - x position of the soldier
	 * @param y
	 *            - y position of the soldier
	 */
	public void killSoldier(int x, int y) {
		soldiers[searchSoldier(x, y)] = soldiers[numTotalSoldiers - 1];
		numTotalSoldiers--;
	}

	/**
	 * Method that returns the number of soldiers in the array
	 * 
	 * @return - numTotalSoldiers
	 */
	public int getTotalSoldiers() {
		return numTotalSoldiers;
	}

	public void initializeIterator() {
		currentSoldiers = 0;
	}

	/**
	 * Method that returns the next soldier
	 * 
	 * @return - next soldier
	 */
	public Soldiers next() {
		return soldiers[currentSoldiers++];
	}

	/**
	 * Method that verifies if there is a next soldier
	 * 
	 * @return - true if there is a next soldier
	 */
	public boolean hasNext() {
		return ((currentSoldiers >= 0) && (currentSoldiers < numTotalSoldiers));
	}

	/**
	 * Method that allows to buy a soldier by inputting the type the user wants
	 * 
	 * @param type
	 *            - type of soldier
	 * @return - valor
	 */
	public int soldierCost(String type) {
		int valor = 0;
		type = type.toLowerCase();
		switch (type) {
		case KNIGHT:
			valor = 4;
			break;
		case LANCER:
			valor = 2;
			break;
		case SWORDSMAN:
			valor = 2;
			break;
		}
		return valor;
	}

	/**
	 * Method that verifies if the type that the user chose exists or not
	 * 
	 * @param type
	 *            - type of soldier
	 * @return - true if it is valid
	 */
	public boolean invalidSoldier(String type) {
		boolean result = true;
		if (type.equals(KNIGHT) || type.equals(LANCER) || type.equals(SWORDSMAN))
			result = false;
		return result;
	}

	/**
	 * Method that verifies if a soldier exists or not, by inputting its coordinates
	 * 
	 * @param x
	 *            - x position of the soldier
	 * @param y
	 *            - y position of the soldier
	 * @return - true if that soldier exists
	 */
	public boolean statusSoldier(int x, int y) {
		int i = 0;
		boolean found = false;
		while (i < numTotalSoldiers && !found) {
			if (soldiers[i].getX() == x && soldiers[i].getY() == y)
				found = true;
			else
				i++;
		}
		return found;
	}

	/**
	 * Method that allows to get the index of a soldier by inputting its coordinates
	 * 
	 * @param x
	 *            - x position of the soldier
	 * @param y
	 *            - y position of the soldier
	 * @return - result
	 */
	public int searchSoldier(int x, int y) {
		int i = 0;
		int result = -1;
		boolean found = false;
		while (i < numTotalSoldiers && !found) {
			if (soldiers[i].getX() == x && soldiers[i].getY() == y)
				found = true;
			else
				i++;
			if (found)
				result = i;
		}
		return result;
	}

	/**
	 * Method that verifies if there is another soldier of the same kingdom on the
	 * position to where the user wants to move to
	 * 
	 * @param x
	 *            - x position of the moved soldier
	 * @param y
	 *            - y position of the moved soldier
	 * @return - result
	 */
	public int samePosition(int x, int y) {
		int result = 0;

		for (int i = 0; i < numTotalSoldiers; i++) {
			if (soldiers[i].getX() == x && soldiers[i].getY() == y) {
				result++;
			}
		}
		return result;
	}

	/**
	 * Method that verifies if a soldier is a knight by inputting the soldier's
	 * index
	 * 
	 * @param i
	 *            - index of the soldier
	 * @return - true if it is a knight
	 */
	public boolean isKnight(int i) {
		return getSoldier(i).isKnight();
	}

	/**
	 * Method that verifies if a soldier is a swordsman by inputting the soldier's
	 * index
	 * 
	 * @param i
	 *            - index of the soldier
	 * @return - true if it is a swordsman
	 */
	public boolean isSwordsman(int i) {
		return getSoldier(i).isSwordsman();
	}

	/**
	 * Method that verifies if a soldier is a lancer by inputting the soldier's
	 * index
	 * 
	 * @param i
	 *            - index of the soldier
	 * @return - true if it is a lancer
	 */
	public boolean isLancer(int i) {
		return getSoldier(i).isLancer();
	}

	/**
	 * Method that returns the soldier type, by inputting its index
	 * 
	 * @param i
	 *            - index of the soldier
	 * @return - type
	 */
	public String getType(int i) {
		return getSoldier(i).getType();
	}

	/**
	 * Method that returns the x position of a soldier by inputting its index
	 * 
	 * @param i
	 *            - index of the soldier
	 * @return - x
	 */
	public int getXSoldier(int i) {
		return getSoldier(i).getX();
	}

	/**
	 * Method that returns the y position of a soldier by inputting its index
	 * 
	 * @param i
	 *            - index of the soldier
	 * @return - y
	 */
	public int getYSoldier(int i) {
		return getSoldier(i).getY();
	}

}
