/**
 * 
 * @author Pedro Oliveira
 * @author Teresa Monteiro
 *
 */

public class Soldiers {

	/**
	 * Constants that represents the different soldier types and the different
	 * directions that one can go
	 */
	private static final String KNIGHT = "cavaleiro";
	private static final String LANCER = "lanceiro";
	private static final String SWORDSMAN = "espadachim";
	private static final String SOUTH = "sul";
	private static final String NORTH = "norte";
	private static final String WEST = "oeste";
	private static final String EAST = "este";

	private int x, y;
	private String type, owner;

	/**
	 * Constructor of the class Soldiers that allows to form a soldier, by having a
	 * position (x, y) and a type
	 * 
	 * @param x
	 *            - x position of soldier
	 * @param y
	 *            - y position of soldier
	 * @param type
	 *            - type
	 */
	public Soldiers(int x, int y, String type) {
		this.type = type;
		this.x = x;
		this.y = y;
		owner = null;
	}

	/**
	 * Method that allows a soldier to move north, south, east or west
	 * 
	 * @param move
	 *            - direction
	 */
	public void movement(String move) {
		String direction = move.toLowerCase();
		switch (direction) {
		case EAST:
			x++;
			break;
		case WEST:
			x--;
			break;
		case NORTH:
			y++;
			break;
		case SOUTH:
			y--;
			break;
		}
	}

	/**
	 * Method that allows a soldier to move back if there's a problem on its path
	 * 
	 * @param move
	 *            - direction
	 */
	public void moveBack(String move) {
		String direction = move.toLowerCase();
		switch (direction) {
		case EAST:
			x--;
			break;
		case WEST:
			x++;
			break;
		case NORTH:
			y--;
			break;
		case SOUTH:
			y++;
			break;
		}
	}

	/**
	 * Method that returns x position of a soldier
	 * 
	 * @return - x
	 */
	public int getX() {
		return x;
	}

	/**
	 * Method that returns y position of a soldier
	 * 
	 * @return - y
	 */
	public int getY() {
		return y;
	}

	/**
	 * Method that returns soldier type
	 * 
	 * @return - type
	 */
	public String getType() {
		return type;
	}

	/**
	 * Method that allows to return the soldier owner
	 * 
	 * @return - owner
	 */
	public String getSoldierOwner() {
		return owner;
	}

	/**
	 * Method that allows to verify if a soldier is a knight
	 * 
	 * @return - result
	 */
	public boolean isKnight() {
		boolean result = true;
		if (type.equals(LANCER) || type.equals(SWORDSMAN))
			result = false;
		return result;
	}

	/**
	 * Method that allows to verify if a soldier is a swordsman
	 * 
	 * @return - result
	 */
	public boolean isSwordsman() {
		boolean result = true;
		if (type.equals(KNIGHT) || type.equals(LANCER))
			result = false;
		return result;
	}

	/**
	 * Method that allows to verify if a soldier is lancer
	 * 
	 * @return - result
	 */
	public boolean isLancer() {
		boolean result = true;
		if (type.equals(KNIGHT) || type.equals(SWORDSMAN))
			result = false;
		return result;
	}

	/**
	 * Method that allows to define the soldier owner
	 * 
	 * @param owner
	 *            - soldier's owner
	 */
	public void setSoldierOwner(String owner) {
		this.owner = owner;
	}
}
