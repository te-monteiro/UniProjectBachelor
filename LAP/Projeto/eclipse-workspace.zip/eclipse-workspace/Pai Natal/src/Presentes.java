
public class Presentes {
//	Variaveis
	private String descricao, nome;
	private int quantidade;
	private float precoUnitario;

//	Construtor
	/**Cria um novo presente com os argumentos:  
	  * @param descricao � Descri��o do presente  
	  * @param nome � Nome da pessoa que recebe o presente 
	  * @param quantidade � Quantidade de unidades do presente  
	  * @param precoUnitario � Pre�o de cada uma das unidades do presente  
	  * @pre quantidade > 0 && precoUnitario >= 0.0f 
	   */
	public Presentes(String descricao, String nome, int quantidade,float precoUnitario) {
		this.descricao = descricao;
		this.nome = nome;
		this.quantidade = quantidade;
		this.precoUnitario = precoUnitario;
	}
	 
	/**Devolve a descri��o do presente  
	 * @return � A descri��o do presente  
	  */
		public String devolveDescricao() {
			return descricao;
		}
	 
	/**Devolve o nome da pessoa que recebe o presente 
	  * @return � O nome da pessoa que recebe o presente  
	  */
			public String devolveNome() {
				return nome;
			}
	/**Devolve o valor total do presente  
	 * @return � O valor total do presente  
	 */ 
				public float devolveValorTotal() {
					return precoUnitario * quantidade;
				}
	 
	/**Acrescenta unidades ao presente.  
	 * @param n � n�mero de unidades a acrescentar ao presente  
	 * @pre n > 0 
	  */ 
				public void adicionaQuantidade(int n) {
					quantidade =+ n;
				}
	 
	/**Compara o objecto this com o argumento outro  
	 * @return true se todos os membros de this forem iguais aos do outro  
	 */ 
				public boolean equals(Presentes outro) {
					return (nome.equals(outro.nome) && descricao.equals(outro.descricao) && quantidade == outro.quantidade && precoUnitario == outro.precoUnitario);
				}
	
}
