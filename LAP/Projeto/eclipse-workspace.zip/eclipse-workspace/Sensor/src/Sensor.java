
public class Sensor {
	//Variaveis
	private boolean move;

	//Construtor
	public Sensor() {
		move = false;
	}
	// Metodos que permite a detecao do movimento
	public void move() {
		move = true;
	}
	
	public void stop() {
		move = false;
	}
	
	public boolean isMoving() {
		return move;
		
	}
}
