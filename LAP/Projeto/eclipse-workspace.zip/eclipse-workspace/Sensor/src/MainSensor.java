
public class MainSensor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sensor s1 = new Sensor();
		Sensor s2 = new Sensor();
		
		System.out.println(s1.isMoving());
		System.out.println(s2.isMoving());
		s1.move();
		System.out.println(s1.isMoving());
		System.out.println(s2.isMoving());
		s2.stop();
		System.out.println(s2.isMoving());
		s2.move();
		System.out.println(s2.isMoving());
		s2.stop();
		System.out.println(s2.isMoving());
		

	}

}
