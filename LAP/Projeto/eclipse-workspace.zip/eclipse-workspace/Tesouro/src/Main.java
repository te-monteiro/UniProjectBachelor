
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Tesouro map = new Tesouro(8,-4);
			
		map.walkNorth(1);
		map.walkWest(3);
		map.getYPos();
		System.out.println(map.getYPos());
		map.getXPos();
		System.out.println(map.getXPos());
		map.dig();
		System.out.println(map.dig());
		map.walkSouth(6);
		map.walkEast(10);
		map.walkNorth(1);
		map.walkEast(1);
		map.dig();
		System.out.println(map.dig());
		
	}

}
