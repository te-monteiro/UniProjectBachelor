
public class Tesouro {
	private int xpos;
	private int ypos;
	private int xtreasure;
	private int ytreasure;

	public Tesouro(int xtreasure, int ytreasure) {
		xpos = 0;
		ypos = 0;
		this.xtreasure = xtreasure;
		this.ytreasure = ytreasure;
	}

	public void walkNorth(int steps) {
		ypos = ypos + steps;
	}

	public void walkEast(int steps) {
		xpos = xpos + steps;
	}

	public void walkSouth(int steps) {
		ypos = ypos - steps;
	}

	public void walkWest(int steps) {
		xpos = xpos - steps;
	}

	public boolean dig() {
		return (xpos == xtreasure && ypos == ytreasure);
	}

	public int getXPos() {
		return xpos;
	}

	public int getYPos() {
		return ypos;
	}

}
