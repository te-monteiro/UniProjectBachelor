
public class Lamp {

	private boolean lampIsOn;

	public Lamp() {
		lampIsOn = false;
	}

	public void on() {
		lampIsOn = true;
	}

	public void off() {
		lampIsOn = false;
	}

	public boolean isOn() {
		return lampIsOn;
	}

}
