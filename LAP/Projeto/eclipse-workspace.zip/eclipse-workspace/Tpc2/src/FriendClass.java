/**
 * @author Ana Silva 52787 Teresa Monteiro 52597
 */

public class FriendClass implements Friend {

	private String name, email;

	public FriendClass(String name, String email) {
		this.name = name;
		this.email = email;
	}

	@Override
	public String getName() {

		return name;
	}

	@Override
	public String getEmail() {
		return email;
	}

}
