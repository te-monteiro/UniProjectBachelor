/**
 * @author Ana Silva 52787 Teresa Monteiro 52597
 */

public interface Friend {

	String getName();

	String getEmail();

}
