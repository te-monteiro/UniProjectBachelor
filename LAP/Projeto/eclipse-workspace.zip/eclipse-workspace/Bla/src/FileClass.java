
public class FileClass implements File {
	private String name, owner;
	private int size;

	public FileClass(String name, int size, String owner) {
		this.name = name;
		this.size = size;
		this.owner = owner;

	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public int getSize() {
		return size;
	}

	@Override
	public String getOwner() {
		return owner;
	}
}
