
public abstract class User {
	private String email, person;
	private File[] files;
	private int numberOfFiles;
	private int space;

	private static final int DEFAULT_SIZE = 10;

	public User(String email) {
		this.email = email;
		files = new File[DEFAULT_SIZE];
		numberOfFiles = 0;
		person = null;

	}

	public int getSpace() {

		Iterator<File> i = IteratorFiles();
		int size = 0;
		while (i.hasNext()) {
			size += i.next().getSize();
		}
		return space - size;
	}

	private void resize() {
		File[] tmp = new File[files.length * 2];
		for (int i = 0; i < numberOfFiles; i++) {
			tmp[i] = files[i];
		}
		files = tmp;

	}

	public String getEmail() {
		return email;
	}

	public void addFile(String filename, int size) {
		if (files.length == numberOfFiles)
			resize();

		files[numberOfFiles++] = new FileClass(filename, size, email);
	}

	public String getNameAccount() {
		return this.getClass().getName();
	}

	public void addFileShared(String owner, int size, String filename, String emailTo) {
		if (files.length == numberOfFiles) {
			resize();
		}

		person = emailTo;
		files[numberOfFiles++] = new FileClass(filename, size, owner);

	}

	public File compareOwner(String owner, String filename) {
		File file = null;
		for (int i = 0; i < numberOfFiles; i++) {
			if (files[i].getOwner().equals(owner) && files[i].getName().equals(filename)) {
				file = files[i];
			}

		}
		return file;
	}

	public int getSize(String filename) {
		int r = -1;
		for (int i = 0; i < numberOfFiles; i++) {
			if (files[i].getName().equalsIgnoreCase(filename)) {
				r = files[i].getSize();
			}

		}
		return r;
	}

	public boolean hasFileOwner(String name) {
		for (int i = 0; i < numberOfFiles; i++) {
			if (files[i].getName().equalsIgnoreCase(name)) {
				return true;
			}

		}
		return false;
	}

	public boolean hasFileShared(String filename, String emailTo) {
		for (int i = 0; i < numberOfFiles; i++) {
			if (files[i].getName().equalsIgnoreCase(filename) && (emailTo.equalsIgnoreCase(person))) {
				return true;
			}

		}
		return false;

	}

	public boolean hasSpace(int size) {
		return getSpace() >= size;
	}

	public Iterator<File> IteratorFiles() {
		return new IteratorClass<File>(files, numberOfFiles);
	}

	public void setSpace(int space) {
		this.space = space;
	}

}
