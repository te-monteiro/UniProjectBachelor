
public interface Cloud {

	void addAccount(String email, String typeAccount);

	boolean hasAccount(String email);

	void addFile(String email, String filename, int size);

	void addFileShared(String emailFrom, int size, String filename, String emailTo);

	public int getSize(String email, String filename);

	boolean hasFile(String email, String filename);


	String getNameAccount(String email);

	int getNumberOfUsers();

	boolean hasShared(String emailFrom, String filename, String emailTo);

	User minSpace();

	Iterator<User> IteratorUsers();

	Iterator<File> IteratorFiles(String email);


	boolean hasFreeSpace(String email, int size);

}


