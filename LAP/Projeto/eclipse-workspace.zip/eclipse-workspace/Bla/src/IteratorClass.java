
public class IteratorClass<E> implements Iterator<E> {
	private E[] elements;
	private int counter, current;

	public IteratorClass(E[] elements, int counter) {
		this.elements = elements;
		this.counter = counter;
		init();
	}

	public void init() {
		current = 0;
	}

	public boolean hasNext() {
		return current < counter;
	}

	public E next() {
		return elements[current++];
	}

}
