package tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import profiles.NormalClass;
import profiles.Profile;
import shows.Movie;
import shows.MovieClass;
import shows.Series;
import shows.SeriesClass;
import staff.Worker;
import staff.WorkerClass;

class RecentlySeenTest {

	@Test
	void testSeenShowsSize() {
		Profile p = new NormalClass(" ");
		List<Worker> cast = new ArrayList<>();
		Worker w = new WorkerClass(" ");
		cast.add(w);
		cast.add(w);
		Movie m = new MovieClass("title", "director", 1, 1, 1, "genre", cast);
		p.watch(m);
		p.watch(m);
		p.watch(m);
		p.watch(m);
		p.watch(m);
		p.watch(m);
		p.watch(m);
		p.watch(m);
		p.watch(m);
		p.watch(m);
		p.watch(m);
		assertEquals(10, p.getSeenShows().size());
	}

	@Test
	void testWasRecentlySeen() {
		Profile p = new NormalClass(" ");
		List<Worker> cast = new ArrayList<>();
		Worker w = new WorkerClass(" ");
		cast.add(w);
		cast.add(w);
		Movie m = new MovieClass("title", "director", 1, 1, 1, "genre", cast);
		p.watch(m);
		assertEquals(m, p.getSeenShows().get(0));
	}

	@Test
	void testRecentlySeenOrder() {
		Profile p = new NormalClass(" ");
		List<Worker> cast = new ArrayList<>();
		Worker w = new WorkerClass(" ");
		cast.add(w);
		cast.add(w);
		Movie m = new MovieClass("title", "director", 1, 1, 1, "genre", cast);
		Series s = new SeriesClass("title", "creator", 1, 1, 1, 1, "genre", cast);
		p.watch(m);
		p.watch(s);
		assertEquals(s, p.getSeenShows().get(0));
	}

}
