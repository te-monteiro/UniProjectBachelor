package accounts;

import java.util.ArrayList;
import java.util.List;

import memberships.Membership;
import profiles.Profile;

public class AccountClass implements Account {

	private String name;
	private String email;
	private String password;
	private Membership pacote;
	private List<Device> devices;
	private List<Profile> profiles;
	private boolean isOn;

	public AccountClass(String name, String email, String password, Membership pacote) {
		this.name = name;
		this.email = email;
		this.password = password;
		devices = new ArrayList<>(MAX_DEVICES);
		profiles = new ArrayList<>(MAX_PROFILES);
		isOn = false;
		this.pacote = pacote;
	}

	public String getName() {
		return name;
	}

	public String getEmail() {
		return email;
	}

	public String getPassword() {
		return password;
	}

	public void changePackage(Membership p) {
		pacote = p;
	}

	public List<Device> getDevices() {
		return devices;
	}

	public List<Profile> getProfiles() {
		return profiles;
	}

	public boolean tooMuchDevices() {
		return devices.size() == pacote.getNDevices();
	}

	public boolean tooMuchProfiles() {
		return profiles.size() == pacote.getNProfiles();
	}

	public String getMembership() {
		return pacote.getMembership();
	}

	public boolean canChangeMembership(Membership p) {
		return devices.size() <= p.getNDevices() && profiles.size() <= p.getNProfiles();
	}

	public void changeMembership(Membership p) {
		pacote = p;
	}

	public void addDevice(Device d) {
		if (this.getUsedDevice() != null)
			turnOffDevices();
		devices.add(d);
		d.use();
		isOn = true;
	}

	public void addProfile(Profile p) {
		if (this.getUsedProfile() != null)
			this.getUsedProfile().turnOff();
		profiles.add(p);
		p.turnOn();
	}

	public void selectProfile(String profileName) {
		if (this.getUsedProfile() != null)
			this.getUsedProfile().turnOff();
		for (int i = 0; i < profiles.size(); i++) {
			if (profiles.get(i).getName().equals(profileName)) {
				profiles.get(i).turnOn();
			}
		}
	}

	private void turnOffDevices() {
		for (int i = 0; i < devices.size(); i++) {
			if (devices.get(i).isBeingUsed())
				devices.get(i).turnOff();
		}
	}

	public void turnDeviceOn(String device) {
		isOn = true;
		for (int i = 0; i < devices.size(); i++) {
			if (devices.get(i).getName().equals(device)) {
				devices.get(i).use();
				return;
			}
		}
	}

	public void turnDeviceOff() {
		isOn = false;
		this.removeDevice();
	}

	public boolean isOn() {
		return isOn;
	}

	public Device getUsedDevice() {
		for (int i = 0; i < devices.size(); i++) {
			if (devices.get(i).isBeingUsed())
				return devices.get(i);
		}
		return null;
	}

	public Profile getUsedProfile() {
		for (int i = 0; i < profiles.size(); i++) {
			if (profiles.get(i).isOn())
				return profiles.get(i);
		}
		return null;
	}

	private void removeDevice() {
		for (int i = 0; i < devices.size(); i++) {
			if (devices.get(i).isBeingUsed()) {
				devices.remove(i);
				return;
			}
		}
	}

	public void logout() {
		isOn = false;
		if (this.getUsedProfile() != null)
			this.getUsedProfile().turnOff();
	}

	public boolean thereIsDevice(String name) {
		for (int i = 0; i < devices.size(); i++) {
			if (devices.get(i).getName().equals(name))
				return true;
		}
		return false;
	}

	public boolean thereIsProfile(String name) {
		for (int i = 0; i < profiles.size(); i++) {
			if (profiles.get(i).getName().equals(name))
				return true;
		}
		return false;
	}
}
