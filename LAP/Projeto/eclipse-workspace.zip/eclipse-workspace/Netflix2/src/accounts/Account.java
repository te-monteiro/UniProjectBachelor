package accounts;

import java.util.List;

import memberships.Membership;
import profiles.Profile;

public interface Account {

	static final int MAX_PROFILES = 2;
	static final int MAX_DEVICES = 1;

	/**
	 * Method that returns the name of the owner of the account
	 * 
	 * @returns name
	 */
	String getName();

	/**
	 * Method that returns the email of the owner of the account
	 * 
	 * @return email
	 */
	String getEmail();

	/**
	 * Method that returns the password of the owner of the account
	 * 
	 * @return password
	 */
	String getPassword();

	/**
	 * Method that returns all the devices associated to this account
	 * 
	 * @return all devices
	 */
	List<Device> getDevices();

	/**
	 * Method that returns all the profiles associated to this account
	 * 
	 * @return all profiles
	 */
	List<Profile> getProfiles();

	/**
	 * Method that add a device to account
	 * 
	 * @param d
	 *            - device to be added
	 */
	void addDevice(Device d);

	/**
	 * Method that add a profile to account
	 * 
	 * @param p
	 *            - profile to be added
	 */
	void addProfile(Profile p);

	/**
	 * Method that turns device off
	 */
	void turnDeviceOff();

	/**
	 * Method that turns device on
	 */
	void turnDeviceOn(String device);

	/**
	 * Method that checks if the account is on
	 * 
	 * @return isOn
	 */
	boolean isOn();

	/**
	 * Method that verifies if there is too much devices logged into an account
	 * 
	 * @return true if there is too much devices
	 */
	boolean tooMuchDevices();

	/**
	 * Method that verifies if there is too much profiles logged into an account
	 * 
	 * @return true if there is too much profiles
	 */
	boolean tooMuchProfiles();

	/**
	 * Method that verifies if it is possible change membership
	 * 
	 * @param p
	 * @return true if there is possible
	 */
	/**
	 * Method that returns membership type
	 * @return membership type
	 */
	String getMembership();
	
	boolean canChangeMembership(Membership p);
	/**
	 * Method that change profile membership
	 * @param p
	 */
	void changeMembership(Membership p);

	/**
	 * Method that returns the device that is online
	 * 
	 * @return device that is being used
	 */
	Device getUsedDevice();

	/**
	 * Method that ends the session but device keeps the acess to the service
	 */
	void logout();

	/**
	 * Method that verifies if the device is already associated to the account
	 * 
	 * @param name
	 *            - name of the device
	 * @return true if the device is already associated to the account
	 */
	boolean thereIsDevice(String name);

	/**
	 * Method that verifies if the profile is already associated to the account
	 * 
	 * @param name
	 *            - name of the profile
	 * @return true if the profile is already associated to the account
	 */
	boolean thereIsProfile(String name);

	void selectProfile(String profileName);

	Profile getUsedProfile();
}
