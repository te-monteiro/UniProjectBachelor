package exceptions;

@SuppressWarnings("serial")
public class ShowDoesntExistException extends RuntimeException {
	public ShowDoesntExistException() {
		super();
	}
}
