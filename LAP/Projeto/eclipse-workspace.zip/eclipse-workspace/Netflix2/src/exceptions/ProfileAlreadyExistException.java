package exceptions;

@SuppressWarnings("serial")
public class ProfileAlreadyExistException extends RuntimeException {

	public ProfileAlreadyExistException() {
		super();
	}
}
