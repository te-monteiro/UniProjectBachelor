package exceptions;

@SuppressWarnings("serial")
public class ShowAlreadyRatedException extends RuntimeException {

	public ShowAlreadyRatedException() {
		super();
	}
}
