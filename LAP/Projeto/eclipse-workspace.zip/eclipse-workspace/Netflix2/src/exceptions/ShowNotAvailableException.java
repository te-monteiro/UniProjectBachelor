package exceptions;

@SuppressWarnings("serial")
public class ShowNotAvailableException extends RuntimeException {

	public ShowNotAvailableException() {
		super();
	}

}
