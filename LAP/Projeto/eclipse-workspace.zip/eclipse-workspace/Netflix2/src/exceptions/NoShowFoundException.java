package exceptions;

@SuppressWarnings("serial")
public class NoShowFoundException extends RuntimeException {
	public NoShowFoundException() {
		super();
	}
}
