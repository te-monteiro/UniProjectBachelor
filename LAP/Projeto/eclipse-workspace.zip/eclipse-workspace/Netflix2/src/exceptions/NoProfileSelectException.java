package exceptions;

@SuppressWarnings("serial")
public class NoProfileSelectException extends RuntimeException {
	public NoProfileSelectException() {
		super();
	}
}
