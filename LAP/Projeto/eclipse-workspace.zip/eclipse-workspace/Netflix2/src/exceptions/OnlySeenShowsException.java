package exceptions;

@SuppressWarnings("serial")
public class OnlySeenShowsException extends RuntimeException {

	public OnlySeenShowsException() {
		super();
	}
}
