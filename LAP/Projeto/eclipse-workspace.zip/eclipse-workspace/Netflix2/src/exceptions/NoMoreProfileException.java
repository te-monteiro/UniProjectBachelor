package exceptions;

@SuppressWarnings("serial")
public class NoMoreProfileException extends RuntimeException {
	public NoMoreProfileException() {
		super();
	}

}
