/**
 * @author Teresa Monteiro 52597
 * @author Tiago Cotovio 52349
 */
package services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.List;

import accounts.Account;
import accounts.AccountClass;
import accounts.Device;
import accounts.DeviceClass;
import comparators.ComparatorByRate;
import comparators.ComparatorByTitle;
import exceptions.AccountDoesNotExistException;
import exceptions.AccountSameEmailException;
import exceptions.AlreadyOnException;
import exceptions.MembershipAlreadyExistException;
import exceptions.NoMoreMembershipException;
import exceptions.NoMoreProfileException;
import exceptions.NoProfileExistException;
import exceptions.NoProfileSelectException;
import exceptions.NoSessionOnException;
import exceptions.NoShowFoundException;
import exceptions.OnlySeenShowsException;
import exceptions.ProfileAlreadyExistException;
import exceptions.SessionIsOnException;
import exceptions.ShowAlreadyRatedException;
import exceptions.ShowDoesntExistException;
import exceptions.ShowNotAvailableException;
import exceptions.TooMuchDevicesException;
import exceptions.WrongPasswordException;
import memberships.BasicClass;
import memberships.Membership;
import memberships.PremiumClass;
import memberships.StandardClass;
import profiles.Child;
import profiles.ChildClass;
import profiles.NormalClass;
import profiles.Profile;
import shows.Movie;
import shows.MovieClass;
import shows.Series;
import shows.SeriesClass;
import shows.Show;
import staff.Worker;
import staff.WorkerClass;

public class NetflixClass implements Netflix {

	private static final String PREMIUM = "Premium";
	private static final String STANDARD = "Standard";
	private static final String BASIC = "Basic";

	private Map<String, SortedSet<Show>> showsByGenre;
	private SortedMap<String, Show> showsByName;
	private Map<String, Account> accounts;
	private Map<String, Worker> staff;
	private Membership basic, standard, premium;

	public NetflixClass() {
		showsByGenre = new HashMap<>();
		showsByName = new TreeMap<>();
		accounts = new HashMap<>(1);
		staff = new HashMap<>();
		basic = new BasicClass();
		standard = new StandardClass();
		premium = new PremiumClass();
	}

	public void addMovie(String title, String director, int duration, int age, int year, String genre, String[] cast) {
		// adding the cast to the database
		List<Worker> workers = new ArrayList<>();
		for (int i = 0; i < cast.length; i++) {
			Worker w = this.addWorker(cast[i]);
			workers.add(w);
		}

		Movie show = new MovieClass(title, director, duration, age, year, genre, workers);
		this.addWorker(director).addShow(show);
		this.addParticipatedShow(workers, show);

		// private Map<String, SortedSet<Show>> showsByGenre;
		SortedSet<Show> showsGenre = showsByGenre.get(genre);
		if (showsGenre == null)
			showsGenre = new TreeSet<Show>(new ComparatorByTitle());
		showsGenre.add(show);
		showsByGenre.put(genre, showsGenre);

		// private SortedSet<Show> showsByName;
		showsByName.put(show.getTitle(), show);

	}

	public void addParticipatedShow(List<Worker> workers, Show s) {
		for (int i = 0; i < workers.size(); i++) {
			workers.get(i).addShow(s);
		}
	}

	public Worker addWorker(String name) {
		if (staff.get(name) == null) {
			Worker w = new WorkerClass(name);
			staff.put(name, w);
			return w;
		}
		return staff.get(name);
	}

	public void addSeries(String title, String creator, int nSeason, int nEpisodes, int age, int year, String genre,
			String[] cast) {
		// adding the cast to the database
		List<Worker> workers = new ArrayList<>();
		for (int i = 0; i < cast.length; i++) {
			workers.add(this.addWorker(cast[i]));
		}

		Series show = new SeriesClass(title, creator, nSeason, nEpisodes, age, year, genre, workers);
		this.addWorker(creator).addShow(show);
		this.addParticipatedShow(workers, show);

		// private Map<String, SortedSet<Show>> showsByGenre;
		SortedSet<Show> showsGenre = showsByGenre.get(genre);
		if (showsGenre == null) {
			showsGenre = new TreeSet<Show>(new ComparatorByTitle());
		}
		showsGenre.add(show);
		showsByGenre.put(genre, showsGenre);

		// private SortedMap<String, Show> showsByName;
		showsByName.put(show.getTitle(), show);

	}

	public Iterator<Show> listShowsByName() {
		return showsByName.values().iterator();
	}

	public void addAccount(String name, String email, String password, String deviceName)
			throws SessionIsOnException, AccountSameEmailException {
		if (this.someoneOn())
			throw new SessionIsOnException();
		else if (this.sameEmail(email))
			throw new AccountSameEmailException();
		Account c = new AccountClass(name, email, password, basic);
		accounts.put(email, c);
		c.turnDeviceOn(deviceName);
		this.addDevice(email, deviceName);
	}

	public void addDevice(String accountEmail, String deviceName) {
		Account c = accounts.get(accountEmail);
		Device d = new DeviceClass(deviceName);
		c.addDevice(d);
	}

	private boolean someoneOn() {
		for (Map.Entry<String, Account> entry : accounts.entrySet()) {
			// entry = (string, account);
			if (entry.getValue().isOn())
				return true;
		}
		return false;
	}

	private boolean sameEmail(String email) {
		if (accounts.containsKey(email))
			return true;
		return false;
	}

	public void login(String email, String password, String device) throws AlreadyOnException, SessionIsOnException,
			AccountDoesNotExistException, WrongPasswordException, WrongPasswordException, TooMuchDevicesException {
		Account c = accounts.get(email);
		if (c != null && c.isOn()) {
			throw new AlreadyOnException();
		} else if (this.someoneOn()) {
			throw new SessionIsOnException();
		} else if (c == null) {
			throw new AccountDoesNotExistException();
		} else if (!c.getPassword().equals(password)) {
			throw new WrongPasswordException();
		} else if (!c.thereIsDevice(device) && c.tooMuchDevices()) {
			throw new TooMuchDevicesException();
		}
		if (c.thereIsDevice(device)) {
			c.getUsedDevice().turnOff();
			c.turnDeviceOn(device);
		} else {
			c.addDevice(new DeviceClass(device));
		}
	}

	public String getAccountName(String email) {
		Account c = accounts.get(email);
		return c.getName();
	}

	public Account getLoggedAccount() throws NoSessionOnException {
		for (Map.Entry<String, Account> entry : accounts.entrySet()) {
			// entry = (string, account);
			if (entry.getValue().isOn()) {
				return entry.getValue();
			}
		}
		throw new NoSessionOnException();
	}

	public void disconnect() throws NoSessionOnException {
		Account c = this.getLoggedAccount();
		if (c == null)
			throw new NoSessionOnException();
		c.turnDeviceOff();
	}

	public void logout() throws NoSessionOnException {
		Account c = this.getLoggedAccount();
		if (c == null)
			throw new NoSessionOnException();
		c.logout();
	}

	public String membership() throws NoSessionOnException {
		Account c = this.getLoggedAccount();
		if (c == null)
			throw new NoSessionOnException();
		return c.getMembership();
	}

	public void changeMembership(String newMembership)
			throws NoSessionOnException, MembershipAlreadyExistException, NoMoreMembershipException {
		Account c = this.getLoggedAccount();
		if (c == null)
			throw new NoSessionOnException();
		if (newMembership.equals(this.membership()))
			throw new MembershipAlreadyExistException();
		switch (newMembership) {
		case PREMIUM:
			if (!c.canChangeMembership(premium))
				throw new NoMoreMembershipException();
			c.changeMembership(premium);
			break;
		case STANDARD:
			if (!c.canChangeMembership(standard))
				throw new NoMoreMembershipException();
			c.changeMembership(standard);
			break;
		case BASIC:
			if (!c.canChangeMembership(basic))
				throw new NoMoreMembershipException();
			c.changeMembership(basic);
			break;
		}

	}

	public void addProfile(String profileName)
			throws NoSessionOnException, ProfileAlreadyExistException, NoMoreProfileException {
		Account c = this.getLoggedAccount();
		if (c == null)
			throw new NoSessionOnException();
		if (c.thereIsProfile(profileName))
			throw new ProfileAlreadyExistException();
		if (c.tooMuchProfiles())
			throw new NoMoreProfileException();
		Profile p = new NormalClass(profileName);
		c.addProfile(p);
	}

	public void addProfile(String profileName, int age)
			throws NoSessionOnException, ProfileAlreadyExistException, NoMoreProfileException {
		Account c = this.getLoggedAccount();
		if (c == null)
			throw new NoSessionOnException();
		if (c.thereIsProfile(profileName))
			throw new ProfileAlreadyExistException();
		if (c.tooMuchProfiles())
			throw new NoMoreProfileException();
		Profile p = new ChildClass(profileName, age);
		c.addProfile(p);
	}

	public void select(String profileName) throws NoSessionOnException, NoProfileExistException {
		Account c = this.getLoggedAccount();
		if (c == null)
			throw new NoSessionOnException();
		if (!c.thereIsProfile(profileName))
			throw new NoProfileExistException();
		c.selectProfile(profileName);
	}

	public void watch(String title)
			throws NoSessionOnException, NoProfileSelectException, ShowDoesntExistException, ShowNotAvailableException {
		Account c = this.getLoggedAccount();
		Show s = showsByName.get(title);
		if (c == null)
			throw new NoSessionOnException();
		if (c.getUsedProfile() == null)
			throw new NoProfileSelectException();
		if (s == null)
			throw new ShowDoesntExistException();
		if (c.getUsedProfile() instanceof Child) {
			Child profile = (Child) c.getUsedProfile();
			if (!profile.canWatch(s))
				throw new ShowNotAvailableException();
		}
		c.getUsedProfile().watch(s);
	}

	public void rate(String title, int rate) throws NoSessionOnException, NoProfileSelectException,
			ShowDoesntExistException, OnlySeenShowsException, ShowAlreadyRatedException {
		Account c = this.getLoggedAccount();
		Show s = showsByName.get(title);
		if (c == null)
			throw new NoSessionOnException();
		if (c.getUsedProfile() == null)
			throw new NoProfileSelectException();
		if (s == null)
			throw new ShowDoesntExistException();
		if (!c.getUsedProfile().wasRecentlySeen(s))
			throw new OnlySeenShowsException();
		if (c.getUsedProfile().hasRated(s))
			throw new ShowAlreadyRatedException();
		c.getUsedProfile().rate(s, rate);
	}

	public Iterator<Show> getShowsByGenre(String genre)
			throws NoSessionOnException, NoProfileSelectException, NoShowFoundException {
		Account c = this.getLoggedAccount();
		if (c == null)
			throw new NoSessionOnException();
		else if (c.getUsedProfile() == null)
			throw new NoProfileSelectException();
		else if (showsByGenre.get(genre) == null)
			throw new NoShowFoundException();
		return showsByGenre.get(genre).iterator();
	}

	public Iterator<Show> getShowsByName(String name)
			throws NoSessionOnException, NoProfileSelectException, NoShowFoundException {
		Account c = this.getLoggedAccount();
		if (c == null)
			throw new NoSessionOnException();
		else if (c.getUsedProfile() == null)
			throw new NoProfileSelectException();
		else if (staff.get(name) == null)
			throw new NoShowFoundException();
		return staff.get(name).getShows();
	}

	public Iterator<Show> getShowsByRate(int rate)
			throws NoSessionOnException, NoProfileSelectException, NoShowFoundException {
		Account c = this.getLoggedAccount();
		if (c == null)
			throw new NoSessionOnException();
		if (c.getUsedProfile() == null)
			throw new NoProfileSelectException();

		SortedSet<Show> showsByRate = new TreeSet<>(new ComparatorByRate());
		Iterator<Show> it = this.listShowsByName();
		while (it.hasNext()) {
			Show s = it.next();
			if (s.getRate() >= rate) {
				if (c.getUsedProfile() instanceof Child) {
					Child child = (Child) c.getUsedProfile();
					if (s.getAge() <= child.getAge())
						showsByRate.add(s);
				} else
					showsByRate.add(s);
			}
		}
		if (showsByRate.isEmpty())
			throw new NoShowFoundException();
		return showsByRate.iterator();

	}

}
