package memberships;

public interface Membership {

	/**
	 * Method that returns the number of devices allowed to the profile
	 * 
	 * @return nDevices
	 */
	int getNDevices();

	/**
	 * Method that returns the number of profiles allowed to the profile
	 * 
	 * @return nProfiles
	 */
	int getNProfiles();
	
	/**
	 * Method that returns membership type
	 * @return membership type
	 */
	String getMembership();

}
