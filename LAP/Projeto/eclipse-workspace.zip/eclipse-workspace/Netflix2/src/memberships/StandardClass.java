package memberships;

public class StandardClass extends AbstractMembership implements Standard {

	public StandardClass() {
		super(Standard.MAX_DEVICES, Standard.MAX_PROFILES, Standard.STANDARD);
	}

}
