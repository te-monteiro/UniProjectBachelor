package memberships;

public abstract class AbstractMembership implements Membership {

	private int nDevices;
	private int nProfiles;
	private String membership;

	public AbstractMembership(int nDevices, int nProfiles, String membership) {
		this.nDevices = nDevices;
		this.nProfiles = nProfiles;
		this.membership = membership;
	}

	public int getNDevices() {
		return nDevices;
	}

	public int getNProfiles() {
		return nProfiles;
	}

	public String getMembership() {
		return membership;
	}
}
