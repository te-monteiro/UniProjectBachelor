package memberships;

public class PremiumClass extends AbstractMembership implements Premium {

	public PremiumClass() {
		super(Premium.MAX_DEVICES, Premium.MAX_PROFILES, Premium.PREMIUM);
	}

}
