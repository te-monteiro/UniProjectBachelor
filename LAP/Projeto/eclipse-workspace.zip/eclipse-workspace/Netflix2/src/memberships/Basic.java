package memberships;

public interface Basic extends Membership {

	static final String BASIC = "Basic";
	static final int MAX_PROFILES = 2;
	static final int MAX_DEVICES = 1;

}
