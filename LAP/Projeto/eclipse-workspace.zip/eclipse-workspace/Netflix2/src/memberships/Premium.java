package memberships;

public interface Premium extends Membership {

	static final String PREMIUM = "Premium";
	static final int MAX_PROFILES = 5;
	static final int MAX_DEVICES = 4;
}
