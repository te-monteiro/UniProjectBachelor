package memberships;

public class BasicClass extends AbstractMembership implements Basic {

	public BasicClass() {
		super(Basic.MAX_DEVICES, Basic.MAX_PROFILES, Basic.BASIC);
	}

}
