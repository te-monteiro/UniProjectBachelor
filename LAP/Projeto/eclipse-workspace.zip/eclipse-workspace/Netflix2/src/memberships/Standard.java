package memberships;

public interface Standard extends Membership {

	static final String STANDARD = "Standard";
	static final int MAX_PROFILES = 5;
	static final int MAX_DEVICES = 2;
}
