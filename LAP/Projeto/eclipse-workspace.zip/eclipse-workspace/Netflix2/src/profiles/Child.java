/**
 * @author Teresa Monteiro 52597
 * @author Tiago Cotovio 52349
 */
package profiles;

import shows.Show;

public interface Child extends Profile {
	

	/**
	 * Method that returns the age of the owner of the profile
	 * 
	 * @return age
	 */
	int getAge();

	/**
	 * Method that verifies if the child can watch the show
	 * 
	 * @param s
	 *            - show to be watched
	 * @return true if the age rating of the show is less or equals to the age of
	 *         the child
	 */
	boolean canWatch(Show s);
}
