/**
 * @author Teresa Monteiro 52597
 * @author Tiago Cotovio 52349
 */
package profiles;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import shows.Show;

public abstract class AbstractProfile implements Profile {

	private String name;
	// recently watched shows
	private List<Show> shows;
	private List<Show> ratedShows;
	private Map<String, Integer> rates;
	private boolean isOn;

	public AbstractProfile(String name) {
		this.name = name;
		shows = new LinkedList<>();
		ratedShows = new ArrayList<>();
		rates = new HashMap<>();
		isOn = false;
	}

	@Override
	public String getName() {
		return name;
	}

	public void turnOn() {
		isOn = true;
	}

	public void turnOff() {
		isOn = false;
	}

	public boolean isOn() {
		return isOn;
	}

	public void watch(Show s) {
		if (shows.size() == MAX_LAST_SHOWS) {
			shows.remove(9);
			shows.add(0, s);
		} else
			shows.add(0, s);
	}

	public boolean wasRecentlySeen(Show s) {
		return shows.contains(s);
	}

	public void rate(Show s, int rate) {
		ratedShows.add(s);
		s.rate(rate);
		rates.put(s.getTitle(), rate);
	}

	public boolean hasRated(Show s) {
		return ratedShows.contains(s);
	}

	public List<Show> getSeenShows() {
		return shows;
	}

	public List<Show> getRatedShows() {
		return ratedShows;
	}

	public int getGivenRate(String title) {
		return rates.get(title);
	}

}
