/**
 * @author Teresa Monteiro 52597
 * @author Tiago Cotovio 52349
 */
package profiles;

import shows.Movie;
import shows.Show;

public class ChildClass extends AbstractProfile implements Child {

	private int age;

	public ChildClass(String name, int age) {
		super(name);
		assert age < 18 && age >= 5 : "nao e crianca"; 
		this.age = age;
	}

	public int getAge() {
		return age;
	}

	public boolean canWatch(Show s) {
		return s.getAge() <= age;
	}

	public void watch(Show s) {
		assert	this.canWatch(s) : "idade insuficente";
		super.watch(s);
	}

}
