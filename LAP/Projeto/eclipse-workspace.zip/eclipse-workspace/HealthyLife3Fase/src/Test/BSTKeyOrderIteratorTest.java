package Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;

import dataStructures.BinarySearchTree;
import dataStructures.Entry;
import dataStructures.Iterator;

class BSTKeyOrderIteratorTest {

	// @Test
	public void iteratorNormalBSTTest() {
		BinarySearchTree<Integer, Integer> bst = new BinarySearchTree<Integer, Integer>();

		assertTrue(bst.insert(5, 5) == null);
		assertTrue(bst.insert(10, 10) == null);
		assertTrue(bst.insert(11, 11) == null);
		assertTrue(bst.insert(1, 1) == null);
		assertTrue(bst.insert(-3, -3) == null);
		assertTrue(bst.insert(4, 4) == null);
		assertTrue(bst.insert(9, 9) == null);
		assertTrue(bst.insert(7, 77) == null);
		assertTrue(bst.insert(7, 7) == 77);

		assertEquals(bst.size(), 8);

		Iterator<Entry<Integer, Integer>> itEntries = bst.iterator();

		assertTrue(itEntries.hasNext());
		assertTrue(itEntries.next().getKey() == -3);
		assertTrue(itEntries.next().getKey() == 1);
		assertTrue(itEntries.next().getKey() == 4);
		assertTrue(itEntries.next().getKey() == 5);
		assertTrue(itEntries.next().getKey() == 7);
		assertTrue(itEntries.next().getKey() == 9);
		assertTrue(itEntries.next().getKey() == 10);
		assertTrue(itEntries.next().getKey() == 11);
		assertFalse(itEntries.hasNext());
	}

	// @Test
	public void iteratorNormalBST1Test() {
		BinarySearchTree<Integer, Integer> bst = new BinarySearchTree<Integer, Integer>();

		assertTrue(bst.insert(5, 5) == null);
		assertTrue(bst.insert(10, 10) == null);
		assertTrue(bst.insert(11, 11) == null);
		assertTrue(bst.insert(1, 1) == null);
		assertTrue(bst.insert(-3, -3) == null);
		assertTrue(bst.insert(4, 4) == null);
		assertTrue(bst.insert(3, 3) == null);
		assertTrue(bst.insert(2, 2) == null);
		assertTrue(bst.insert(9, 9) == null);
		assertTrue(bst.insert(7, 77) == null);
		assertTrue(bst.insert(7, 7) == 77);

		assertEquals(bst.size(), 10);

		Iterator<Entry<Integer, Integer>> itEntries = bst.iterator();

		assertTrue(itEntries.hasNext());
		assertTrue(itEntries.next().getKey() == -3);
		assertTrue(itEntries.next().getKey() == 1);
		assertTrue(itEntries.next().getKey() == 2);
		assertTrue(itEntries.next().getKey() == 3);
		assertTrue(itEntries.next().getKey() == 4);
		assertTrue(itEntries.next().getKey() == 5);
		assertTrue(itEntries.next().getKey() == 7);
		assertTrue(itEntries.next().getKey() == 9);
		assertTrue(itEntries.next().getKey() == 10);
		assertTrue(itEntries.next().getKey() == 11);
		assertFalse(itEntries.hasNext());
	}

	@Test
	public void iteratorJustRightBSTTest() {
		BinarySearchTree<Integer, Integer> bst = new BinarySearchTree<Integer, Integer>();

		assertTrue(bst.insert(5, 5) == null);
		assertTrue(bst.insert(10, 10) == null);
		assertTrue(bst.insert(11, 11) == null);
		assertTrue(bst.insert(12, 12) == null);
		assertTrue(bst.insert(13, 13) == null);
		assertTrue(bst.insert(14, 14) == null);
		assertTrue(bst.insert(19, 19) == null);
		assertTrue(bst.insert(27, 27) == null);

		assertEquals(bst.size(), 8);

		Iterator<Entry<Integer, Integer>> itEntries = bst.iterator();

		assertTrue(itEntries.hasNext());
		assertTrue(itEntries.next().getKey() == 5);
		assertTrue(itEntries.next().getKey() == 10);
		assertTrue(itEntries.next().getKey() == 11);
		assertTrue(itEntries.next().getKey() == 12);
		assertTrue(itEntries.next().getKey() == 13);
		assertTrue(itEntries.next().getKey() == 14);
		assertTrue(itEntries.next().getKey() == 19);
		assertTrue(itEntries.next().getKey() == 27);
		assertFalse(itEntries.hasNext());
	}

	// @Test
	public void iteratorJustLeftBSTTest() {
		BinarySearchTree<Integer, Integer> bst = new BinarySearchTree<Integer, Integer>();

		assertTrue(bst.insert(27, 27) == null);
		assertTrue(bst.insert(19, 19) == null);
		assertTrue(bst.insert(14, 14) == null);
		assertTrue(bst.insert(13, 13) == null);
		assertTrue(bst.insert(12, 12) == null);
		assertTrue(bst.insert(11, 11) == null);
		assertTrue(bst.insert(10, 10) == null);
		assertTrue(bst.insert(5, 5) == null);
		assertEquals(bst.size(), 8);

		Iterator<Entry<Integer, Integer>> itEntries = bst.iterator();

		assertTrue(itEntries.hasNext());
		assertTrue(itEntries.next().getKey() == 5);
		assertTrue(itEntries.next().getKey() == 10);
		assertTrue(itEntries.next().getKey() == 11);
		assertTrue(itEntries.next().getKey() == 12);
		assertTrue(itEntries.next().getKey() == 13);
		assertTrue(itEntries.next().getKey() == 14);
		assertTrue(itEntries.next().getKey() == 19);
		assertTrue(itEntries.next().getKey() == 27);
		assertFalse(itEntries.hasNext());
	}

}
