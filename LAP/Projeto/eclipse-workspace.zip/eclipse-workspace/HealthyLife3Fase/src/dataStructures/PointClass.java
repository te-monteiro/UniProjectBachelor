package dataStructures;

/**
 * 
 * @author Teresa Falcao de Campos Monteiro (52597)
 *         tfd.monteiro@campus.fct.unl.pt
 * @author Ana Filipa Santos Pereira Fernandes da Silva (52787)
 *         afsp.silva@campus.fct.unl.pt
 * 
 *
 */

public class PointClass implements Point {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected int point;

	public PointClass(int point) {
		this.point = point;
	}

	@Override
	public int compareTo(Point p) {
		return (point - p.getPoint()) * (-1);
	}

	@Override
	public int getPoint() {
		return point;
	}

}
