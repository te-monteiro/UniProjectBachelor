package dataStructures;

import java.io.Serializable;

/**
 * 
 * @author Teresa Falcao de Campos Monteiro (52597)
 *         tfd.monteiro@campus.fct.unl.pt
 * @author Ana Filipa Santos Pereira Fernandes da Silva (52787)
 *         afsp.silva@campus.fct.unl.pt
 * 
 *
 */

public interface Point extends Comparable<Point>, Serializable {

	/**
	 * Method that returns how many points there are
	 * 
	 * @return
	 */
	public int getPoint();

}
