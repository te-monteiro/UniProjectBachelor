package dataStructures;

/**
 * 
 * @author Teresa Falcao de Campos Monteiro (52597)
 *         tfd.monteiro@campus.fct.unl.pt
 * @author Ana Filipa Santos Pereira Fernandes da Silva (52787)
 *         afsp.silva@campus.fct.unl.pt
 * 
 *
 */

public class BSTIterator<K extends Comparable<K>, V> implements Iterator<Entry<K, V>> {

	private static final long serialVersionUID = 1L;

	private Stack<BSTNode<K, V>> stack;
	private BSTNode<K, V> root;

	public BSTIterator(BSTNode<K, V> root) {

		this.root = root;

		stack = new StackInList<BSTNode<K, V>>();
		rewind();
	}

	/**
	 * Method that returns if the iterator has next by checking if the stack is empty
	 */
	@Override
	public boolean hasNext() {
		return !stack.isEmpty();
	}

	/**
	 * Method that returns the next element in the iteration
	 * Firstly it pop the node of the stack
	 * Secondly it check if the pop node has right nodes and if there are it push all the left node into the stack
	 */
	@Override
	public Entry<K, V> next() throws NoSuchElementException {

		BSTNode<K, V> node = stack.pop();
		BSTNode<K, V> nodeRight = node.getRight();
		if (nodeRight != null) {
			stack.push(nodeRight);
			BSTNode<K, V> nodeLeft = nodeRight.getLeft();
			while (nodeLeft != null) {
				stack.push(nodeLeft);
				nodeLeft = nodeLeft.getLeft();
			}
		}

		return node.getEntry();
	}

	/**
	 * Method that restart the iteration by pushing all the left node
	 */
	@Override
	public void rewind() {
		BSTNode<K, V> node = root;
		stack.push(root);
		while (node.getLeft() != null) {
			stack.push(node.getLeft());
			node = node.getLeft();
		}

	}

}
