package dataStructures;

public class EmptyQueueException extends RuntimeException{                                     
    static final long serialVersionUID = 0L;
}
