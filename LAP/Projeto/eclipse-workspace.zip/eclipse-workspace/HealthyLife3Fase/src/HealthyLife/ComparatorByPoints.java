package HealthyLife;

import java.util.Comparator;

public class ComparatorByPoints implements Comparator<GetUser> {

	@Override
	public int compare(GetUser u1, GetUser u2) {
		
		if(u1.getPoints() < u2.getPoints()) {
			return 1;
		}
		return -1;
		
	}
	

}
