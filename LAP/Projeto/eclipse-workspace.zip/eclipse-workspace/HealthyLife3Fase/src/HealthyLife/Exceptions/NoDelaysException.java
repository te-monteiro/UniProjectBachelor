package HealthyLife.Exceptions;

public class NoDelaysException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
