package HealthyLife;

import HealthyLife.Exceptions.*;

import dataStructures.*;

/**
 * 
 * @author Teresa Falcao de Campos Monteiro (52597)
 *         tfd.monteiro@campus.fct.unl.pt
 * @author Ana Filipa Santos Pereira Fernandes da Silva (52787)
 *         afsp.silva@campus.fct.unl.pt
 * 
 *
 */

public class HealthyLifeClass implements HealthyLife {

	private static final long serialVersionUID = 1L;

	private ChainedHashTable<String, SetUser> users;
	private ChainedHashTable<String, SetBike> bikes;
	private ChainedHashTable<String, SetPark> parks;
	// classe integer diferente
	private OrderedDictionary<Point, DoublyLinkedList<GetUser>> delayedUsers;
	private OrderedDictionary<String, GetPark> favoriteParks;
	int currentMaxPickups;

	public HealthyLifeClass() {
		this.users = new ChainedHashTable<String, SetUser>();
		this.bikes = new ChainedHashTable<String, SetBike>();
		this.parks = new ChainedHashTable<String, SetPark>();
		delayedUsers = new BinarySearchTree<Point, DoublyLinkedList<GetUser>>();
		favoriteParks = new BinarySearchTree<String, GetPark>();
		currentMaxPickups = 0;
	}

	/**
	 * Method that checks if the user already exists
	 * 
	 * @param idUser
	 * @return - true if the user already exists
	 */

	private boolean doesUserExist(String idUser) {
		return !users.isEmpty() && findUser(idUser) != null;

	}

	/**
	 * Method that returns the user independently of its form (lower or upper casa)
	 * 
	 * @param idUser
	 * @return - the user
	 */
	private SetUser findUser(String idUser) {

		return users.find(idUser.toLowerCase());

	}

	private SetPark findPark(String idPark) {
		return parks.find(idPark);
	}

	private SetBike findBike(String idBike) {
		return bikes.find(idBike.toLowerCase());
	}

	/**
	 * Checks if the user has done pickups
	 * 
	 * @return - true if the user has done pickups
	 */
	private boolean hasUserDonePickups(String idUser) {

		return findUser(idUser).hasPickups();
	}

	/**
	 * Checks if the bike has done pickups
	 * 
	 * @return - true if the bike has not done pickups
	 */
	private boolean doesBikeHasPickups(String idBike) {
		return findBike(idBike).hasPickups();
	}

	/**
	 * Method that checks if the park already exists
	 * 
	 * @param idPark
	 * @return - true if the park already exists
	 */
	private boolean doesParkExist(String idPark) {
		return !parks.isEmpty() && findPark(idPark.toLowerCase()) != null;
	}

	/**
	 * Method that checks if the bike already exists
	 * 
	 * @param idPark
	 * @return - true if the bike already exists
	 */
	private boolean doesBikeExist(String idBike) {
		return !bikes.isEmpty() && findBike(idBike.toLowerCase()) != null;
	}

	/**
	 * Method that checks if the minutes put as an input are valid
	 * 
	 * @param minutes
	 * @return - true if the minutes are valid
	 */
	private boolean areMinutesValid(int minutes) {
		return minutes > 0;
	}

	/**
	 * Method that checks if the bike is at the park
	 * 
	 * @return - true if the bike is at the park
	 */

	private boolean isBikeAtPark(String idBike) {
		SetBike bike = findBike(idBike);
		return bike.getPark() != null;
	}

	/**
	 * Method that checks if have been pickups made in the park
	 * 
	 * @return - true if have been pickups made in the park
	 */
	private boolean hasParkPickups(String idPark) {
		GetPark park = this.findPark(idPark);
		return park.getNumPickup() > 0;
	}

	/**
	 * Method that checks if the bike is moving
	 * 
	 * @param idBike
	 * @return - true if the bike is moving
	 */
	private boolean isBikeMoving(String idBike) {
		return findBike(idBike).isMoving();
	}

	/**
	 * 
	 * @param idBike
	 * @return
	 */
	private boolean IsBikeAtFirstPickup(String idBike) {
		return findBike(idBike).isFirstPickupMoving();
	}

	/**
	 * Method that checks if the user is moving
	 * 
	 * @param idUser
	 * @return - true if the user is moving
	 */
	private boolean isUserMoving(String idUser) {
		return findUser(idUser).isMoving();
	}

	/**
	 * Method that checks if the user has enough money to do a pickup
	 * 
	 * @param idUser
	 * @return - true if the user has enough money
	 */
	private boolean doesUserHasMoney(String idUser) {
		return !findUser(idUser).hasMoney();
	}

	/**
	 * Method that checks if the first pickup of the user is not done yet
	 * 
	 * @param idUser
	 * @return - true if the first pickup is still moving
	 */
	private boolean isUserAtFirstPickup(String idUser) {
		SetUser user = findUser(idUser);
		return user.isFirstPickupMoving();
	}

	@Override
	public void addUser(String idUser, String nif, String email, String phone, String name, String address)
			throws UserAlreadyExistsException {
		if (doesUserExist(idUser)) {
			throw new UserAlreadyExistsException();
		} else {
			users.insert(idUser.toLowerCase(), new UserClass(idUser, nif, email, phone, name, address));
		}

	}

	@Override
	public void removeUser(String idUser) throws NoUserException, PickupsAlreadyDoneException {
		if (!doesUserExist(idUser)) {
			throw new NoUserException();
		} else if (!hasUserDonePickups(idUser)) {
			throw new PickupsAlreadyDoneException();
		} else {
			users.remove(idUser.toLowerCase());
		}

	}

	@Override
	public GetUser getUser(String idUser) throws NoUserException {
		if (!doesUserExist(idUser)) {
			throw new NoUserException();
		}
		return findUser(idUser);
	}

	@Override
	public void addPark(String idPark, String name, String address) throws ParkAlreadyExistsException {
		if (doesParkExist(idPark)) {
			throw new ParkAlreadyExistsException();
		} else {
			SetPark park = new ParkClass(idPark, name, address);
			parks.insert(idPark.toLowerCase(), park);

		}
	}

	@Override
	public void addBike(String idBike, String idPark, String plate) throws BikeAlreadyExistsException, NoParkException {
		if (doesBikeExist(idBike)) {
			throw new BikeAlreadyExistsException();
		} else if (!doesParkExist(idPark)) {
			throw new NoParkException();
		} else {
			SetPark park = this.findPark(idPark.toLowerCase());
			SetBike bike = new BikeClass(idBike, park, plate);
			bikes.insert(idBike.toLowerCase(), bike);
			// muda para getBike automaticamente acho
			park.addBike(bike);
		}

	}

	@Override
	public GetPark getPark(String idPark) throws NoParkException {
		if (!doesParkExist(idPark)) {
			throw new NoParkException();
		}
		return this.findPark(idPark.toLowerCase());
	}

	@Override
	public void removeBike(String idBike) throws PickupsAlreadyDoneException, NoBikeException {
		if (!doesBikeExist(idBike)) {
			throw new NoBikeException();
		} else if (!doesBikeHasPickups(idBike)) {
			throw new PickupsAlreadyDoneException();
		} else {
			SetBike bike = this.findBike(idBike.toLowerCase());
			SetPark park = (SetPark) bike.getPark();
			bikes.remove(idBike.toLowerCase());
			park.removeBike();
		}

	}

	@Override
	public void pickup(String idBike, String idUser)
			throws NoUserException, NoBikeException, MovingBikeException, NoMoneyException, MovingUserException {

		if (!doesBikeExist(idBike)) {
			throw new NoBikeException();
		}

		else if (isBikeMoving(idBike)) {
			throw new MovingBikeException();
		}

		else if (!doesUserExist(idUser)) {
			throw new NoUserException();
		}

		else if (isUserMoving(idUser)) {
			throw new MovingUserException();
		}

		else if (doesUserHasMoney(idUser)) {
			throw new NoMoneyException();
		}

		else {
			SetBike bike = findBike(idBike);
			SetUser user = findUser(idUser);
			SetPark park = (SetPark) bike.getPark();
			SetPickup pickup = new PickupClass(park, user, bike);
			bike.addPickup(pickup);
			user.addPickup(pickup);
			park.pickupChanges();
			if (currentMaxPickups != 0 && park.getNumPickup() == this.currentMaxPickups) {
				favoriteParks.insert(park.getName(), park);
			}

			else if (park.getNumPickup() > this.currentMaxPickups) {
				currentMaxPickups = park.getNumPickup();
				favoriteParks = new BinarySearchTree<String, GetPark>();
				favoriteParks.insert(park.getName(), park);

			}

		}
	}

	@Override
	public GetUser pickdown(String idBike, String idPark, int minutes)
			throws NoBikeException, BikeStopException, NoParkException, InvalidDataException {
		if (!doesBikeExist(idBike)) {
			throw new NoBikeException();
		} else if (!isBikeMoving(idBike)) {
			throw new BikeStopException();
		} else if (!doesParkExist(idPark)) {
			throw new NoParkException();
		} else if (!areMinutesValid(minutes)) {
			throw new InvalidDataException();
		} else {
			SetBike bike = findBike(idBike);
			SetPark park = this.findPark(idPark.toLowerCase());
			bike.addPickdown(minutes, park);
			SetUser user = ((SetUser) bike.getLastUser());
			
			int oldPoints = user.getPoints();
			Point oldPointsP = new PointClass(user.getPoints());
			
			user.addPickdown(minutes, park);
			
			
			Point newPointsP = new PointClass(user.getPoints());
			int newPoints = user.getPoints();

			if (newPoints != 0 && newPoints != oldPoints) {

				if (oldPoints == 0) {
					DoublyLinkedList<GetUser> list = delayedUsers.find(newPointsP);
					if (list == null) {
						list = new DoublyLinkedList<GetUser>();
						list.addLast(user);
						delayedUsers.insert(new PointClass(newPoints), list);
					} else {
						list.addLast(user);
					}
				}

				else if (newPoints > oldPoints) {

					DoublyLinkedList<GetUser> list = delayedUsers.find(oldPointsP);
					list.remove(user);
					DoublyLinkedList<GetUser> newList = delayedUsers.find(newPointsP);
					if (newList == null) {
						newList = new DoublyLinkedList<GetUser>();
						newList.addLast(user);
						delayedUsers.insert(new PointClass(newPoints), newList);
					} else {
						newList.addLast(user);

					}

				}

			}

			park.addBike(bike);
			return bike.getLastUser();
		}

	}

	@Override
	public void chargeUser(String idUser, int value) throws NoUserException, NegativeValueException {
		if (!doesUserExist(idUser)) {
			throw new NoUserException();
		} else if (!areMinutesValid(value)) {
			throw new NegativeValueException();
		} else {

			SetUser user = findUser(idUser);
			user.setBalance(value);

		}

	}

	@Override
	public Iterator<GetPickup> getBikePickupsIterator(String idBike)
			throws NoBikeException, NoPickupsException, FirstPickupStillMovingException {

		if (!doesBikeExist(idBike)) {
			throw new NoBikeException();
		} else if (this.doesBikeHavePick(idBike)) {
			throw new NoPickupsException();
		} else if (IsBikeAtFirstPickup(idBike)) {
			throw new FirstPickupStillMovingException();
		}
		SetBike bike = findBike(idBike);
		return bike.getPickupsIterator();
	}

	private boolean doesBikeHavePick(String idBike) {
		return this.findBike(idBike).hasPickups() && !findBike(idBike).isMoving();
	}

	@Override
	public void parkedBike(String idBike, String idPark)
			throws NoBikeException, NoParkException, BikeIsNotAtParkException {
		if (!doesBikeExist(idBike)) {
			throw new NoBikeException();
		} else if (!doesParkExist(idPark)) {
			throw new NoParkException();
		} else if (!isBikeAtPark(idBike)) {
			throw new BikeIsNotAtParkException();
		}

	}

	@Override
	public Iterator<GetPickup> getUserPickupsIterator(String idUser)
			throws NoUserException, NoPickupsException, FirstPickupStillMovingException {

		if (!doesUserExist(idUser)) {
			throw new NoUserException();
		} else if (this.hasUserDonePick(idUser)) {
			throw new NoPickupsException();
		} else if (isUserAtFirstPickup(idUser)) {
			throw new FirstPickupStillMovingException();
		}
		SetUser user = findUser(idUser);
		return user.getPickupsIterator();
	}

	private boolean hasUserDonePick(String idUser) {
		return findUser(idUser).hasPickups() && !findUser(idUser).isMoving();
	}

	@Override
	public Iterator<Entry<String, GetPark>> getFavoriteParksIterator() throws NoPickupsException {
		if (favoriteParks.isEmpty()) {
			throw new NoPickupsException();
		}

		return favoriteParks.iterator();
	}

	@Override
	public Iterator<Entry<Point, DoublyLinkedList<GetUser>>> getDelayedUsersIterator() throws NoDelaysException {

		if (delayedUsers.isEmpty()) {
			throw new NoDelaysException();
		}

		return delayedUsers.iterator();

	}

}