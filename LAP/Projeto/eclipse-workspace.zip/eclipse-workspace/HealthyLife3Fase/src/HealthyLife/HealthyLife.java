package HealthyLife;

import HealthyLife.Exceptions.*;

import java.io.Serializable;

import dataStructures.*;

/**
 * 
 * @author Teresa Falcao de Campos Monteiro (52597)
 *         tfd.monteiro@campus.fct.unl.pt
 * @author Ana Filipa Santos Pereira Fernandes da Silva (52787)
 *         afsp.silva@campus.fct.unl.pt
 * 
 *
 */
public interface HealthyLife extends Serializable {

	/**
	 * Method that creates a new User
	 * 
	 * @param idUser
	 *            - int: id of the user
	 * @param nif
	 *            - String: nif of the user
	 * @param email
	 *            - String: email of the user
	 * @param phone
	 *            - String: phone of the user
	 * @param name
	 *            - String: name of the user
	 * @param address
	 *            - String: name of the user
	 * @throws UserAlreadyExistsException
	 *             - Exception that is thrown when the user already exists
	 * 
	 *             Pre-condition: user==null
	 */

	void addUser(String idUser, String nif, String email, String phone, String name, String address)
			throws UserAlreadyExistsException;

	/**
	 * Method that removes an user
	 * 
	 * @param idUser
	 *            - int: id of the user
	 * @throws NoUserException
	 *             - Exception that is thrown when the user does not exist
	 * @throws PickupsAlreadyDoneException
	 *             - Exception that is thrown if the user already done at least one
	 *             pickup
	 * 
	 *             Pre-condition: user!= null
	 */
	void removeUser(String idUser) throws NoUserException, PickupsAlreadyDoneException;

	/**
	 * Method that returns the user through its id
	 * 
	 * @param idUser
	 *            - int: id of the user
	 * @return user - GetUser
	 * @throws NoUserException
	 *             - Exception that is thrown when the user does not exist
	 * 
	 *             Pre-condition: user!= null
	 */
	GetUser getUser(String idUser) throws NoUserException;

	/**
	 * Method that adds a park
	 * 
	 * @param idPark
	 *            - String: id of the park
	 * @param name
	 *            - String: name of the park
	 * @param address
	 *            - String: address of the park
	 * @throws ParkAlreadyExistsException
	 *             - Exception that is thrown when the park already exists
	 * 
	 *             Pre-condition: park == null
	 */
	void addPark(String idPark, String name, String address) throws ParkAlreadyExistsException;

	/**
	 * Method that adds a bike. Adds the park in which the bike is parked, to the
	 * bike. Adds the bike to the mentioned park
	 * 
	 * 
	 * 
	 * @param idBike
	 *            - String: id of the bike
	 * @param idPark
	 *            - String: id of the park
	 * @param plate
	 *            - String: plate of the bike
	 * @throws BikeAlreadyExistsException
	 *             - Exception that is thrown when the bike already exists
	 * @throws NoParkException
	 *             - Exception that is thrown if the park does not exist
	 * 
	 *             Pre-condition: bike == null
	 */
	void addBike(String idBike, String idPark, String plate) throws BikeAlreadyExistsException, NoParkException;

	/**
	 * Method that gets the information of the park
	 * 
	 * @param idPark
	 *            - String: id of the park
	 * @return park - GetPark
	 * @throws NoParkException
	 *             - Exception that is thrown when the park does not exist
	 * 
	 *             Pre-condition: park != null
	 */
	GetPark getPark(String idPark) throws NoParkException;

	/**
	 * Method that removes a bike. Removes the bike from the park in which the bike
	 * was parked
	 * 
	 * @param idBike
	 *            - String: id of the bike
	 * @throws PickupsAlreadyDoneException
	 *             - Exception that is thrown if the user has done at least one
	 *             pickup
	 * @throws NoBikeException
	 *             - Exception that is thrown if the bike does not exist
	 * 
	 *             Pre-condition: bike != null
	 */
	void removeBike(String idBike) throws PickupsAlreadyDoneException, NoBikeException;

	/**
	 * Method that does a pickup. Adds a pickup to the user and to the bike.
	 * Increases the number of pickups within the park. Removes the bike from the
	 * park. Removes the park from the bike.
	 * 
	 * @param idBike
	 *            - String: id of the bike
	 * @param idUser
	 *            - String: id of the user
	 * @throws NoUserException
	 *             - Exception that is thrown if the user does not exist
	 * @throws NoBikeException
	 *             - Exception that is thrown if the bike does not exist
	 * @throws MovingBikeException
	 *             - Exception that is thrown if the bike is moving
	 * @throws NoMoneyException
	 *             - Exception that is thrown if the user does not have enough money
	 * @throws MovingUserException
	 *             - Exception that is thrown if the user is moving
	 * 
	 *             Pre-condition: user!= null && park!= null && bike!= null
	 */
	void pickup(String idBike, String idUser)
			throws NoUserException, NoBikeException, MovingBikeException, NoMoneyException, MovingUserException;

	/**
	 * /** Method that does a pickDown. Within the user and the bike, it updates the
	 * information of the pickup. Such as the final park, the duration, the delay
	 * and the amount of money the user has to pay. The balance and the points of
	 * the user is update. The pickDown is added to the list of pickDowns, which can
	 * be found witch the user and the bike. The park in which the bike was parked
	 * as final destination is updated, both at the bike and at the park
	 * 
	 * @param idBike
	 *            - String: id of the bike
	 * @param idPark
	 *            - String: id of the park
	 * @param minutes
	 *            - int: duration of the pickDown
	 * @throws NoBikeException
	 *             - Exception that is thrown if the bike does not exist
	 * @throws BikeStopException
	 *             - Exception that is thrown if the bike is stopped
	 * @throws NoParkException
	 *             - Exception that is thrown when the park does not exist
	 * @throws InvalidDataException
	 *             - Exception that is thrown when the data is invalid
	 * 
	 *             Pre-condition: user!=null && park!= null && bike!=null &&
	 *             minutes>0
	 */
	GetUser pickdown(String idBike, String idPark, int minutes)
			throws NoBikeException, BikeStopException, NoParkException, InvalidDataException;

	/**
	 * /** Method that changes the balance of the user
	 * 
	 * @param idUser
	 *            - String: id of the user
	 * @param value
	 *            - int: value that the user has to pay
	 * @throws NoUserException
	 *             - Exception that is thrown if the user does not exist
	 * @throws NegativeValueException
	 *             - Exception that is thrown when the value is negative
	 * 
	 *             Pre-condition: user!=null && value>0
	 */
	void chargeUser(String idUser, int value) throws NoUserException, NegativeValueException;

	/**
	 * /** Method that returns the bikes pickups Iterator
	 * 
	 * @param idBike
	 *            - String: id of the bike
	 * @return Iterator<GetPickup>
	 * @throws NoBikeException
	 *             - Exception that is thrown if the bike does not exist
	 * @throws NoPickupsException
	 *             - Exception that is thrown if there are no pickups done
	 * @throws FirstPickupStillMovingException
	 *             - Exception that is thrown when the first pickup is not done
	 * 
	 *             Pre-condition: bike!=null
	 */
	Iterator<GetPickup> getBikePickupsIterator(String idBike)
			throws NoBikeException, NoPickupsException, FirstPickupStillMovingException;

	/**
	 * Checks if the bike is at a park. Both are recognized trough its ids
	 * 
	 * @param idPark
	 *            - String: id of the park
	 * @throws NoBikeException
	 *             - Exception that is thrown if the bike does not exist
	 * @throws NoParkException
	 *             - Exception that is thrown if the park does not exist
	 * @throws BikeIsNotAtParkException
	 *             -Exception that is thrown if the bike is not park
	 * 
	 *             Pre-condition: bike!=null && park!=null
	 */
	void parkedBike(String idBike, String idPark) throws NoBikeException, NoParkException, BikeIsNotAtParkException;

	/**
	 * /** Method that returns the user pickups iterator
	 * 
	 * @param idUser
	 *            - String: id of user
	 * @return Iterator<GetPickup>
	 * @throws NoUserException
	 *             - Exception that is thrown if the user does not exist
	 * @throws NoPickupsException
	 *             - Exception that is thrown if the pickups does not exist
	 * @throws FirstPickupStillMovingException
	 *             - Exception that is thrown when the first pickup is not done
	 * 
	 *             Pre-condition:user!=null
	 */
	Iterator<GetPickup> getUserPickupsIterator(String idUser)
			throws NoUserException, NoPickupsException, FirstPickupStillMovingException;

	Iterator<Entry<String, GetPark>> getFavoriteParksIterator();
	
	Iterator<Entry<Point, DoublyLinkedList<GetUser>>> getDelayedUsersIterator()
	throws NoDelaysException;

	

}
