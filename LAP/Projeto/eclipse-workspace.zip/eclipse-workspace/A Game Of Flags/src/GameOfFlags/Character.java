package GameOfFlags;

public class Character {
	private static final String SUL = "SUL";
	private static final String NORTE = "NORTE";
	private static final String OESTE = "OESTE";
	private static final String ESTE = "ESTE";
	private boolean life;
	private int x, y;
	private String tipo;

	// Construtor recebe as posicoes na qual a personagem se vai encontra e o seu tipo
	public Character(int x, int y,String tipo) {
		this.tipo = tipo;
		this.x = x;
		this.y = y;
		life = true;
	}

	//Consoanto o argumento que recebe a personagem vai se deslocar num dos 4 pontos cardeais
	public void movement(String direction) {
		String direcao = direction.toUpperCase();
		switch (direcao) {
		case ESTE:
			x++;
			break;
		case OESTE:
			x--;
			break;
		case NORTE:
			y++;
			break;
		case SUL:
			y--;
		}
	}

	//retorna a posicao x da personagem
	public int getX() {
		return x;
	}

	//retorna a posicao y da personagem
	public int getY() {
		return y;
	}

	//retorna o estado da personagem
	public boolean getLife() {
		return life;
	}

	//passa o estado da personagem para falso
	public void matar() {
		life = false;
	}

	//retorna o tipo da personagem
	public String getType() {
		return tipo;
	}
	
}
