package GameOfFlags;

public class Team {

	private static final String CAVALEIRO = "CAVALEIRO";
	private static final String LANCEIRO = "LANCEIRO";
	private static final String ESPADACHIM = "ESPADACHIM";
	private int xFlag, yFlag;
	Character cavaleiro;
	Character lanceiro;
	Character espadachim;
	private String teamName;

	//recebe o nome da equipa e a posicao das bandeiras
	public Team(String teamName, int xFlag, int yFlag) {
		this.xFlag = xFlag;
		this.yFlag = yFlag;
		this.teamName = teamName;
		cavaleiro = new Character(xFlag, yFlag + 1,"cavaleiro");
		lanceiro = new Character(xFlag, yFlag -1,"lanceiro");
		espadachim = new Character(xFlag +1 , yFlag,"espadachim");
	}

	//retorna o nome da equipa
	public String getTeamName() {
		return teamName;
	}

	//retorna a posicao x da bandeira da equipa
	public int getxFlag() {
		return xFlag;
	}

	//retorna a posicao y da bandeira da equipa
	public int getyFlag() {
		return yFlag;
	}

	//retorna a personagem da equipa consoanto o tipo que recebe como argumento
	public Character getCharacter(String tipo){
		String type = tipo.toUpperCase();
		switch(type){
		case CAVALEIRO:
			return cavaleiro;
		case LANCEIRO:
			return lanceiro;
		case ESPADACHIM:
			return espadachim;
		default: 
			return cavaleiro;
		}
	}
}
