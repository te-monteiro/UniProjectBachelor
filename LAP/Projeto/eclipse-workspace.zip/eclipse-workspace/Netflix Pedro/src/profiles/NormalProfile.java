
/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

package profiles;

public interface NormalProfile extends AbstractProfile {

}
