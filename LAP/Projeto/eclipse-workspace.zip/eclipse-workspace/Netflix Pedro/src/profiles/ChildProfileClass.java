
/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

package profiles;

public class ChildProfileClass extends AbstractProfileClass implements ChildProfile {

	private int childAge;

	public ChildProfileClass(String profileName, int childAge) {
		super(profileName);
		this.childAge = childAge;
		assert childAge > 5 && childAge < 18: "Chidlren' age not permitted.";
	}

	public int getChildAge() {
		return childAge;
	}

}
