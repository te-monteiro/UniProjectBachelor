
/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

package profiles;

public class NormalProfileClass extends AbstractProfileClass implements NormalProfile {

	public NormalProfileClass(String profileName) {
		super(profileName);
	}

}
