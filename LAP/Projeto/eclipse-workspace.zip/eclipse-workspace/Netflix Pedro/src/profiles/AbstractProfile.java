
/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

package profiles;

import java.util.Iterator;

import exceptions.NotRecentlySeenException;
import exceptions.ShowAlreadyRatedException;
import record.AbstractRecord;

public interface AbstractProfile {

	/**
	 * 
	 * Method that returns the profile's name
	 * 
	 * @return profile's name
	 * 
	 */
	String getProfileName();

	/**
	 * 
	 * Method that allows the user to watch a show
	 * 
	 * @param e
	 *            show that the user wants to watch
	 * 
	 */
	void watchShow(AbstractRecord e);

	/**
	 * 
	 * Method that allows the user to rate the show that he/she has recently watched
	 * 
	 * @param show
	 *            show recently watched
	 * @param rate
	 *            rating of the show
	 * @throws NotRecentlySeenException
	 *             if the chosen show wasn't recently watched
	 * @throws ShowAlreadyRatedException
	 *             if the chosen show was already rated
	 * 
	 */
	void rateShow(AbstractRecord show, int rate) throws NotRecentlySeenException, ShowAlreadyRatedException;

	/**
	 * 
	 * Method that allows to see if the user has seen any show
	 * 
	 * @return true if he/she hasn't and false if he/she has
	 * 
	 */
	boolean recentShowsIsEmpty();

	/**
	 * 
	 * Method that lists recently seen shows
	 * 
	 * @return iterator of recently seen shows
	 * 
	 */
	Iterator<AbstractRecord> listSeenShows();

	/**
	 * 
	 * Method that lists all rated shows
	 * 
	 * @return iterator of rated shows
	 * 
	 */
	Iterator<AbstractRecord> listRatedShows();

	/**
	 * 
	 * Method that returns the rating of a show
	 * 
	 * @param showName
	 *            show's name
	 * @return rating
	 * 
	 */
	int getShowRate(String showName);

}
