
/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

package profiles;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import exceptions.NotRecentlySeenException;
import exceptions.ShowAlreadyRatedException;
import record.AbstractRecord;

public class AbstractProfileClass implements AbstractProfile {

	private List<AbstractRecord> recentShows;
	private List<AbstractRecord> ratedShows;
	private Map<String, Integer> showsByRate;

	private String profileName;

	public AbstractProfileClass(String profileName) {
		recentShows = new LinkedList<AbstractRecord>();
		ratedShows = new ArrayList<AbstractRecord>();
		showsByRate = new HashMap<String, Integer>();
		this.profileName = profileName;
	}

	public String getProfileName() {
		return profileName;
	}

	public void watchShow(AbstractRecord e) {
		recentShows.add(0, e);
		if (recentShows.size() == 11)
			recentShows.remove(10);
	}

	public void rateShow(AbstractRecord show, int rate) throws NotRecentlySeenException, ShowAlreadyRatedException {
		if (!recentShows.contains(show))
			throw new NotRecentlySeenException();
		else if (ratedShows.contains(show))
			throw new ShowAlreadyRatedException();
		else {
			showsByRate.put(show.getTitle(), rate);
			ratedShows.add(show);
		}
	}

	public boolean recentShowsIsEmpty() {
		return recentShows.isEmpty();
	}

	public Iterator<AbstractRecord> listSeenShows() {
		return recentShows.iterator();
	}

	public Iterator<AbstractRecord> listRatedShows() {
		return ratedShows.iterator();
	}

	public int getShowRate(String showName) {
		return showsByRate.get(showName);

	}

}
