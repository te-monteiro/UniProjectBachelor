
/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

package packages;

public class PremiumPackageClass extends AbstractPackageClass implements PremiumPackage {

	public PremiumPackageClass() {
		super();
		numDevices = 4;
		numProfiles = 5;
	}

}
