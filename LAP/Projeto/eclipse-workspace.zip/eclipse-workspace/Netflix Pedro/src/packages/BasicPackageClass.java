
/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

package packages;

public class BasicPackageClass extends AbstractPackageClass implements BasicPackage {

	public BasicPackageClass() {
		super();
		numDevices = 1;
		numProfiles = 2;
	}

}
