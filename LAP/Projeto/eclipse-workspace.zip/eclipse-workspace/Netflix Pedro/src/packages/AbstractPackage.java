
/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

package packages;

public interface AbstractPackage {

	int getNumDevices();

	int getNumProfiles();

}
