
/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

package packages;

public abstract class AbstractPackageClass implements AbstractPackage {

	protected int numDevices;
	protected int numProfiles;

	public AbstractPackageClass() {
	}

	public int getNumDevices() {
		return numDevices;
	}

	public int getNumProfiles() {
		return numProfiles;
	}

}
