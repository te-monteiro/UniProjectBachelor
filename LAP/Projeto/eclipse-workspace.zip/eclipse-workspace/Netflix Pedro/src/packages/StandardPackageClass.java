
/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

package packages;

public class StandardPackageClass extends AbstractPackageClass implements StandardPackage {

	public StandardPackageClass() {
		super();
		numDevices = 2;
		numProfiles = 5;
	}

}
