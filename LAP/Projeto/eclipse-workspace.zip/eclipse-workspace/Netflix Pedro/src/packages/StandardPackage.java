
/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

package packages;

import utilities.Util;

public interface StandardPackage extends AbstractPackage {

	static final String TYPE = Util.STANDARDTYPE;

}
