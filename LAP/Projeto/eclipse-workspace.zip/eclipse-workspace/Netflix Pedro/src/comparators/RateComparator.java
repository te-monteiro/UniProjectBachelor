
/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

package comparators;

import java.util.Comparator;

import record.AbstractRecord;

public class RateComparator implements Comparator<AbstractRecord> {

	@Override
	public int compare(AbstractRecord o1, AbstractRecord o2) {
		if (o1.getRate() > o2.getRate())
			return -1;
		else if (o1.getRate() < o2.getRate())
			return 1;
		else
			return o1.getTitle().compareTo(o2.getTitle());

	}

}
