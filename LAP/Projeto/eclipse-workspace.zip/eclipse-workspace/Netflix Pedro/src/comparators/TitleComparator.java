
/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

package comparators;

import java.util.Comparator;

import record.AbstractRecord;

public class TitleComparator implements Comparator<AbstractRecord> {

	@Override
	public int compare(AbstractRecord rec1, AbstractRecord rec2) {
		return rec1.getTitle().compareTo(rec2.getTitle());

	}

}
