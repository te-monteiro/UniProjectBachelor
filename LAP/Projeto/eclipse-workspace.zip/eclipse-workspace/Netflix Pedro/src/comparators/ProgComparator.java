
/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

package comparators;

import java.util.Comparator;

import record.AbstractRecord;

public class ProgComparator implements Comparator<AbstractRecord> {

	public int compare(AbstractRecord rec1, AbstractRecord rec2) {
		int comparation = rec1.getRelYear() - rec2.getRelYear();

		if (comparation == 0)
			return rec1.getTitle().compareTo(rec2.getTitle());
		return comparation;

	}

}
