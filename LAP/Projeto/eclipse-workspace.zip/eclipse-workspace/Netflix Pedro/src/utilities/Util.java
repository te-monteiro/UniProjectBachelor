
/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

package utilities;

public class Util {

	/**
	 * Constants that represents all the possible inputs
	 */
	public static final String UPLOAD = "upload";
	public static final String EXIT = "exit";
	public static final String REGISTER = "register";
	public static final String LOGIN = "login";
	public static final String DISCONNECT = "disconnect";
	public static final String LOGOUT = "logout";
	public static final String MEMBERSHIP = "membership";
	public static final String PROFILE = "profile";
	public static final String SELECT = "select";
	public static final String WATCH = "watch";
	public static final String RATE = "rate";
	public static final String INFOACCOUNT = "infoAccount";
	public static final String SEARCHBYGENRE = "searchByGenre";
	public static final String SEARCHBYNAME = "searchByName";
	public static final String SEARCHBYRATE = "searchByRate";

	/**
	 * Constants that represent successful actions
	 */
	public static final String EXITMESSAGE = "Exiting...\n";
	public static final String DATABASEUPDATED = "Database was updated:";
	public static final String WELCOME = "Welcome %s (%s).\n\n";
	public static final String WELCOME2 = "Welcome %s.\n\n";
	public static final String DISCONNECTED = "Goodbye %s (%s was disconnected).\n\n";
	public static final String LOGGEDOUT = "Goodbye %s (%s still connected).\n\n";
	public static final String MEMBERSHIPCHANGED = "Membership plan was changed from %s to %s.\n\n";
	public static final String PROFILEADDED = "New profile added.\n";
	public static final String WATCHSHOW = "Loading %s...\n\n";
	public static final String SHOWRATED = "Thank you for rating %s.\n\n";

	/**
	 * Constants that represent errors
	 */
	public static final String UNKOWNCOM = "Unknown command.\n";
	public static final String SAMEEMAIL = "There is another account with email %s.\n\n";
	public static final String DEVICESEXCEEDED = "Not possible to connect more devices.\n";
	public static final String ALREADYLOGGED = "Client already logged in.\n";
	public static final String ANOTHERCLIENT = "Another client is logged in.\n";
	public static final String WRONGPASSWORD = "Wrong password.\n";
	public static final String INEXISTENTACCOUNT = "Account does not exist.\n";
	public static final String NOCLIENTLOGGED = "No client is logged in.\n";
	public static final String SAMEMEMBERSHIP = "No membership plan change.\n";
	public static final String CANTDOWNGRADE = "Cannot downgrade membership plan at the moment.\n";
	public static final String PROFILEEXISTS = "There is already a profile %s.\n\n";
	public static final String PROFILESEXCEEDED = "Not possible to add more profiles.\n";
	public static final String NOPROFILE = "Profile does not exist.\n";
	public static final String NOPROFILESELECTED = "No profile is selected.\n";
	public static final String INEXISTENTSHOW = "Show does not exist.\n";
	public static final String LOWERAGE = "Show not available.\n";
	public static final String SHOWNOTWATCHED = "Can only rate recently seen shows.\n";
	public static final String SHOWALREADYRATED = "Show already rated.\n";

	/**
	 * Constants that represent the different package types
	 */
	public static final String BASICTYPE = "Basic";
	public static final String STANDARDTYPE = "Standard";
	public static final String PREMIUMTYPE = "Premium";

	/**
	 * Constants that represent the different profile types
	 */
	public static final String NORMALPROFILE = "NORMAL";
	public static final String CHILDPROFILE = "CHILDREN";

	/**
	 * Constant used on Upload command
	 */
	public static final String MOVIEDETAILS1 = "%s; %s; %d; %s; %d; %s; ";
	public static final String SERIEDETAILS1 = "%s; %s; %d; %d; %s; %d; %s; ";
	public static final String SEMICOLON = "; ";
	public static final String DOT = ".";

	/**
	 * Constants used on infoAccount command
	 */
	public static final String NAMEDETAILS = "%s:\n";
	public static final String DETAILS = "%s (";
	public static final String DETAILS2 = "%s;";
	public static final String DETAILS3 = "%s";
	public static final String DETAILS4 = ").";
	public static final String DETAILS5 = "%s.\n";
	public static final String PROFILEDETAILS = "Profile: %s\n";
	public static final String PROFILEDETAILSCHILD = "Profile: %s (%d)\n";
	public static final String INEXISTENTPROFILES = "No profiles defined.";
	public static final String INEXISTENTSHOWSSEEN = "Empty list of recently seen shows.";
	public static final String RATEDETAILS1 = "%s (%d);";
	public static final String RATEDETAILS2 = "%s (%d).\n";
	public static final String EMPTY = " ";

	/**
	 * Constants used on searchByGenre, searchByName and searchByRate commands
	 */
	public static final String MOVIEDETAILS = "%s; %s; %d; %s; %d; %s;";
	public static final String CAST = " %s;";
	public static final String FINALCAST = " %s.";
	public static final String SERIEDETAILS = "%s; %s; %d; %d; %s; %d; %s;";
	public static final String NOSHOWFOUND = "No show found.\n";
	public static final String RATES = " [%.1f]";

}
