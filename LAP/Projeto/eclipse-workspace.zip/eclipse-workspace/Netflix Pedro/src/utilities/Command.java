
/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

package utilities;

public enum Command {

	UPLOAD(Util.UPLOAD),
    EXIT(Util.EXIT),
    REGISTER(Util.REGISTER),
    LOGIN(Util.LOGIN),
    DISCONNECT(Util.DISCONNECT),
    LOGOUT(Util.LOGOUT),
    MEMBERSHIP(Util.MEMBERSHIP),
    PROFILE(Util.PROFILE),
    SELECT(Util.SELECT),
    WATCH(Util.WATCH),
    RATE(Util.RATE),
    INFOACCOUNT(Util.INFOACCOUNT),
    SEARCHBYGENRE(Util.SEARCHBYGENRE),
    SEARCHBYNAME(Util.SEARCHBYNAME),
    SEARCHBYRATE(Util.SEARCHBYRATE);
	
	private String input;

	/**
	 * Enumerator constructor
	 * 
	 * @param input:
	 *            String that corresponds to commands that the user is allowed to do
	 */
	private Command(String input) {
		this.input = input;
	}

	/**
	 * Returns the input string
	 * 
	 * @return String of input
	 */
	public String getInput() {
		return input;
	}

	/**
	 * Interprets the command chosen
	 * 
	 * @param command:
	 *            Introduced command
	 * @return: the input associated to the command
	 */
	public static Command getValue(String command) {
		for (Command c : Command.values()) {
			if (c.getInput().equalsIgnoreCase(command))
				return c;
		}
		return null;

	}

}
