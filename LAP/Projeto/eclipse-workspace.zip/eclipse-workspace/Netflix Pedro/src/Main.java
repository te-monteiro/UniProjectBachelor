
/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import netflix.*;

import exceptions.AlreadyLoggedException;
import exceptions.CannotDowngradeException;
import exceptions.ImpossibleLoginException;
import exceptions.InexistentAccountException;
import exceptions.InexistentProfileException;
import exceptions.InsufficientAgeException;
import exceptions.NoClientLoggedInException;
import exceptions.NoProfileSelectedException;
import exceptions.NoShowFoundException;
import exceptions.NotRecentlySeenException;
import exceptions.ProfileAlreadyExistsException;
import exceptions.SameEmailException;
import exceptions.SameMembershipException;
import exceptions.ShowAlreadyRatedException;
import exceptions.StringMissMatchException;
import exceptions.TooManyDevicesException;
import exceptions.TooManyProfilesException;
import profiles.AbstractProfile;
import record.AbstractRecord;
import record.Movie;
import record.Serie;
import utilities.Command;
import utilities.Util;

public class Main {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		Netflix net = new NetflixClass();

		processMenu(in, net);

	}

	/**
	 * Menu is processed by using this private method
	 * 
	 * @param in
	 *            Scanner class is used by this method
	 * 
	 * @param net
	 *            Netflix class is used by this method
	 * 
	 */
	private static void processMenu(Scanner in, Netflix net) {

		Command comm = null;

		do {
			comm = getCommand(in);
			switch (comm) {
			case UPLOAD:
				processUpload(in, net);
				break;
			case REGISTER:
				processRegister(in, net);
				break;
			case LOGIN:
				processLogin(in, net);
				break;
			case DISCONNECT:
				processDisconnect(in, net);
				break;
			case LOGOUT:
				processLogout(in, net);
				break;
			case MEMBERSHIP:
				processMemberShip(in, net);
				break;
			case PROFILE:
				processProfile(in, net);
				break;
			case SELECT:
				processSelect(in, net);
				break;
			case WATCH:
				processWatch(in, net);
				break;
			case RATE:
				processRate(in, net);
				break;
			case INFOACCOUNT:
				processInfoAccount(net);
				break;
			case SEARCHBYGENRE:
				processSearchByGenre(in, net);
				break;
			case SEARCHBYNAME:
				proccessSearchByName(in, net);
				break;
			case SEARCHBYRATE:
				processSearchByRate(in, net);
				break;
			case EXIT:
				break;
			default:
				System.out.println(Util.UNKOWNCOM);
				break;
			}
		} while (!comm.equals(Command.EXIT));
		System.out.print(Util.EXITMESSAGE);
		in.close();
	}

	/**
	 * Reads a command introduced by the user
	 * 
	 * @param in:
	 *            Scanner class is used in this method
	 * @return command introduced by the user
	 */
	private static Command getCommand(Scanner in) {
		Command c = Command.getValue(in.next());
		if (c == null) {
			return Command.EXIT;
		} else
			return c;
	}

	/**
	 * Private method that receives an int as a parameter and returns it
	 * 
	 * @param in
	 *            Scanner class is used by this method
	 * @return i
	 */
	private static int getInt(Scanner in) {
		int i = in.nextInt();
		in.nextLine();
		return i;
	}

	/**
	 * 
	 * Upload command is processed by this method
	 * 
	 * @param in
	 *            Scanner class is used by this method
	 * @param net
	 *            Netflix class is used by this method
	 * 
	 */
	private static void processUpload(Scanner in, Netflix net) {

		auxMakeMovie(in, net);
		auxMakeSerie(in, net);

		Iterator<AbstractRecord> records = net.recordListByTitle();

		System.out.println(Util.DATABASEUPDATED);

		while (records.hasNext()) {
			AbstractRecord record = records.next();
			auxListDatabase(net, record);
		}
		System.out.println();
	}

	private static void processRegister(Scanner in, Netflix net) {
		in.nextLine();
		String name = in.nextLine();
		String email = in.nextLine();
		String password = in.nextLine();
		String devices = in.nextLine();

		try {
			net.addUser(name, email, password, devices);
			System.out.printf(Util.WELCOME, name, devices);
		} catch (SameEmailException e) {
			System.out.printf(Util.SAMEEMAIL, email);
		} catch (ImpossibleLoginException e) {
			System.out.println(Util.ANOTHERCLIENT);
		}

	}

	/**
	 * 
	 * Login command is processed by this private method
	 * 
	 * @param in
	 *            Scanner class is used by this method
	 * 
	 * @param net
	 *            Netflix class is used by this method
	 * 
	 */
	private static void processLogin(Scanner in, Netflix net) {
		in.nextLine();
		String email = in.nextLine();
		String password = in.nextLine();
		String dev = in.nextLine();

		try {
			net.processLogin(email, password, dev);
			String name = net.getActLoginAcc();
			System.out.printf(Util.WELCOME, name, dev);
		} catch (AlreadyLoggedException e) {
			System.out.println(Util.ALREADYLOGGED);
		} catch (ImpossibleLoginException e) {
			System.out.println(Util.ANOTHERCLIENT);
		} catch (InexistentAccountException e) {
			System.out.println(Util.INEXISTENTACCOUNT);
		} catch (StringMissMatchException e) {
			System.out.println(Util.WRONGPASSWORD);
		} catch (TooManyDevicesException e) {
			System.out.println(Util.DEVICESEXCEEDED);
		} catch (NoClientLoggedInException e) {
			System.out.println(Util.NOCLIENTLOGGED);
		}
	}

	/**
	 * 
	 * Disconnect command is processed by this method
	 * 
	 * @param in
	 *            Scanner class is used by this method
	 * @param net
	 *            Netflix class is used by this method
	 * 
	 */
	private static void processDisconnect(Scanner in, Netflix net) {
		try {
			String correntDevice = net.getCurrentDevice();
			String correntLogin = net.getActLoginAcc();
			net.processDisconnect();

			System.out.printf(Util.DISCONNECTED, correntLogin, correntDevice);
		} catch (NoClientLoggedInException e) {
			System.out.println(Util.NOCLIENTLOGGED);
		}
	}

	private static void processLogout(Scanner in, Netflix net) {
		try {
			String correntDevice = net.getCurrentDevice();
			String correntLogin = net.getActLoginAcc();
			net.processLogout();

			System.out.printf(Util.LOGGEDOUT, correntLogin, correntDevice);
		} catch (NoClientLoggedInException e) {
			System.out.println(Util.NOCLIENTLOGGED);
		}
	}

	/**
	 * 
	 * Membership command is processsed by this method
	 * 
	 * @param in
	 *            Scanner class is used by this method
	 * 
	 * @param net
	 *            Netflix class is used by this method
	 * 
	 */
	private static void processMemberShip(Scanner in, Netflix net) {
		in.nextLine();
		String packageName = in.nextLine();
		try {
			String oldMembershipType = net.getMembershipType();
			net.membership(packageName);
			System.out.printf(Util.MEMBERSHIPCHANGED, oldMembershipType, packageName);
		} catch (NoClientLoggedInException e) {
			System.out.println(Util.NOCLIENTLOGGED);
		} catch (SameMembershipException e) {
			System.out.println(Util.SAMEMEMBERSHIP);
		} catch (CannotDowngradeException e) {
			System.out.println(Util.CANTDOWNGRADE);
		}

	}

	/**
	 * 
	 * Profile command is processed by this private method
	 * 
	 * @param in
	 *            Scanner class is used by this method
	 * @param net
	 *            Netflix class is used by this method
	 * 
	 */
	private static void processProfile(Scanner in, Netflix net) {
		in.nextLine();
		String profileName = in.nextLine();
		String profileType = in.nextLine();
		int childAge = 0;
		if (profileType.equals(Util.CHILDPROFILE))
			childAge = in.nextInt();
		try {
			net.addProfile(profileName, profileType, childAge);
			System.out.println(Util.PROFILEADDED);
		} catch (NoClientLoggedInException e) {
			System.out.println(Util.NOCLIENTLOGGED);
		} catch (ProfileAlreadyExistsException e) {
			System.out.printf(Util.PROFILEEXISTS, profileName);
		} catch (TooManyProfilesException e) {
			System.out.println(Util.PROFILESEXCEEDED);
		}

	}

	/**
	 * 
	 * Select command is processed by this method
	 * 
	 * @param in
	 *            Scanner class is used by this method
	 * @param net
	 *            Netflix class is used by this method
	 * 
	 */
	private static void processSelect(Scanner in, Netflix net) {
		in.nextLine();
		String profileName = in.nextLine();
		try {
			net.selectProfile(profileName);
			System.out.printf(Util.WELCOME2, profileName);
		} catch (NoClientLoggedInException e) {
			System.out.println(Util.NOCLIENTLOGGED);
		} catch (InexistentProfileException e) {
			System.out.println(Util.NOPROFILE);
		}
	}

	/**
	 * 
	 * Watch command is processed by this method
	 * 
	 * @param in
	 *            Scanner class is used by this method
	 * @param net
	 *            Netflix class is used by this method
	 * 
	 */
	private static void processWatch(Scanner in, Netflix net) {
		in.nextLine();
		String showTitle = in.nextLine();

		try {
			net.watchShow(showTitle);
			System.out.printf(Util.WATCHSHOW, showTitle);
		} catch (NoClientLoggedInException e) {
			System.out.println(Util.NOCLIENTLOGGED);
		} catch (NoProfileSelectedException e) {
			System.out.println(Util.NOPROFILESELECTED);
		} catch (NoShowFoundException e) {
			System.out.println(Util.INEXISTENTSHOW);
		} catch (InsufficientAgeException e) {
			System.out.println(Util.LOWERAGE);
		}
	}

	/**
	 * 
	 * Rate command processed by this method
	 * 
	 * @param in
	 *            Scanner class is used by this method
	 * @param net
	 *            Netflix class is used by this method
	 * 
	 */
	private static void processRate(Scanner in, Netflix net) {
		in.nextLine();
		String showTitle = in.nextLine();
		int rate = in.nextInt();

		try {
			net.rateShow(showTitle, rate);
			System.out.printf(Util.SHOWRATED, showTitle);
		} catch (NoClientLoggedInException e) {
			System.out.println(Util.NOCLIENTLOGGED);
		} catch (NoProfileSelectedException e) {
			System.out.println(Util.NOPROFILESELECTED);
		} catch (NoShowFoundException e) {
			System.out.println(Util.INEXISTENTSHOW);
		} catch (NotRecentlySeenException e) {
			System.out.println(Util.SHOWNOTWATCHED);
		} catch (ShowAlreadyRatedException e) {
			System.out.println(Util.SHOWALREADYRATED);
		}

	}

	/**
	 * 
	 * InfoAccount command is processed by this method
	 * 
	 * @param net
	 *            Netflix class is used by this method
	 * 
	 */
	private static void processInfoAccount(Netflix net) {
		try {
			System.out.printf(Util.NAMEDETAILS, net.getActLoginAcc());
			System.out.printf(Util.DETAILS, net.getMembershipType());
			auxListDevices(net);
			auxListProfilesInformation(net);
		} catch (NoClientLoggedInException e) {
			System.out.println(Util.NOCLIENTLOGGED);
		}
	}

	/**
	 * 
	 * SearchByGenre command is processed by this method
	 * 
	 * @param in
	 *            Scanner class is used by this method
	 * @param net
	 *            Netflix class is used by this method
	 * 
	 */
	private static void processSearchByGenre(Scanner in, Netflix net) {
		in.nextLine();
		String genre = in.nextLine();

		try {
			Iterator<AbstractRecord> it = net.listByGenre(genre);
			while (it.hasNext()) {
				AbstractRecord show = it.next();
				auxSearch(show);
				System.out.println();
			}
			System.out.println();
		} catch (NoClientLoggedInException e) {
			System.out.println(Util.NOCLIENTLOGGED);
		} catch (NoProfileSelectedException e) {
			System.out.println(Util.NOPROFILESELECTED);
		} catch (NoShowFoundException e) {
			System.out.println(Util.NOSHOWFOUND);
		}
	}

	/**
	 * 
	 * SearchByName command is processed by this method
	 * 
	 * @param in
	 *            Scanner class is used by this method
	 * @param net
	 *            Netflix class is used by this method
	 * 
	 */
	private static void proccessSearchByName(Scanner in, Netflix net) {
		in.nextLine();
		String personName = in.nextLine();

		try {
			Iterator<AbstractRecord> it = net.listByName(personName);
			while (it.hasNext()) {
				AbstractRecord show = it.next();
				auxSearch(show);
				System.out.println();
			}
			System.out.println();

		} catch (NoClientLoggedInException e) {
			System.out.println(Util.NOCLIENTLOGGED);
		} catch (NoProfileSelectedException e) {
			System.out.println(Util.NOPROFILESELECTED);
		} catch (NoShowFoundException e) {
			System.out.println(Util.NOSHOWFOUND);
		}
	}

	/**
	 * 
	 * SearchByRate command is processed by this method
	 * 
	 * @param in
	 *            Scanner class is used by this method
	 * @param net
	 *            Netflix class is used by this method
	 * 
	 */
	private static void processSearchByRate(Scanner in, Netflix net) {
		in.nextLine();
		int rate = in.nextInt();

		try {
			Iterator<AbstractRecord> it = net.listRatedRecords(rate);
			while (it.hasNext()) {
				AbstractRecord show = it.next();
				if (show.getRate() >= rate && net.showIsForChild(show)) {
					auxSearch(show);
					System.out.printf(Util.RATES, show.getRate());
					System.out.println();
				}
			}
			System.out.println();
		} catch (NoClientLoggedInException e) {
			System.out.println(Util.NOCLIENTLOGGED);
		} catch (NoProfileSelectedException e) {
			System.out.println(Util.NOPROFILESELECTED);
		} catch (NoShowFoundException e) {
			System.out.println(Util.NOSHOWFOUND);
		}
	}

	/**
	 * 
	 * Auxiliar method used by Upload command that allows to make a movie
	 * 
	 * @param in
	 *            Scanner class is used by this method
	 * @param net
	 *            Netflix class is used by this method
	 * 
	 */
	private static void auxMakeMovie(Scanner in, Netflix net) {
		int nbMovies = getInt(in);

		for (int i = 0; i < nbMovies; i++) {
			String title = in.nextLine();
			String director = in.nextLine();
			int duration = getInt(in);
			String ageRate = in.nextLine();
			int relYear = getInt(in);
			String gender = in.nextLine();
			int nbCast = getInt(in);

			List<String> cast = new ArrayList<String>(nbCast);

			for (int j = 0; j < nbCast; j++) {
				String name = in.nextLine();
				cast.add(name);
			}

			net.uploadMovie(title, director, duration, ageRate, relYear, gender, nbCast, cast);
		}

	}

	/**
	 * 
	 * Auxiliar method that is used by Upload command that allows to make a serie
	 * 
	 * @param in
	 *            Scanner class is used by this method
	 * @param net
	 *            Netflix class is used by this method
	 * 
	 */
	private static void auxMakeSerie(Scanner in, Netflix net) {
		int nbSerie = getInt(in);

		for (int i = 0; i < nbSerie; i++) {
			String title = in.nextLine();
			String creator = in.nextLine();
			int nbSeason = getInt(in);
			int nbEpisodes = getInt(in);
			String ageRate = in.nextLine();
			int relYear = getInt(in);
			String genre = in.nextLine();
			int nbCast = getInt(in);

			List<String> cast = new ArrayList<String>(nbCast);

			for (int j = 0; j < nbCast; j++) {
				String name = in.nextLine();
				cast.add(name);
			}

			net.uploadSerie(title, creator, nbSeason, nbEpisodes, ageRate, relYear, genre, nbCast, cast);
		}
	}

	/**
	 * 
	 * Auxiliar method that is used by the Upload command to print all the shows uploaded
	 * 
	 * @param net Netflix class is used by this method
	 * @param record 
	 */
	private static void auxListDatabase(Netflix net, AbstractRecord record) {

		if (record instanceof Movie) {
			System.out.printf(Util.MOVIEDETAILS1, record.getTitle(), ((Movie) record).getDirector(),
					((Movie) record).getDuration(), record.getAgeRate(), record.getRelYear(), record.getGenre());
			Iterator<String> iterator = record.getCast().iterator();
			for (int i = 0; i < 3 && iterator.hasNext(); i++) {
				System.out.print(iterator.next());
				if (iterator.hasNext() && i < 2)
					System.out.print(Util.SEMICOLON);
				else
					System.out.print(Util.DOT);
			}
		} else if (record instanceof Serie) {
			System.out.printf(Util.SERIEDETAILS1, record.getTitle(), ((Serie) record).getCreator(),
					((Serie) record).getNumSeasons(), ((Serie) record).getNumEpisodes(), record.getAgeRate(),
					record.getRelYear(), record.getGenre());
			Iterator<String> iterator = record.getCast().iterator();
			for (int i = 0; i < 3 && iterator.hasNext(); i++) {
				System.out.print(iterator.next());
				if (iterator.hasNext() && i < 2)
					System.out.print(Util.SEMICOLON);
				else
					System.out.print(Util.DOT);
			}
		}
		System.out.println();
	}

	private static void auxListDevices(Netflix net) {
		Iterator<String> it = net.listDevices();
		while (it.hasNext()) {
			String device = it.next();
			if (!it.hasNext())
				System.out.printf(Util.DETAILS3, device);
			else
				System.out.printf(Util.DETAILS2, device);
		}
		System.out.println(Util.DETAILS4);
	}

	private static void auxListProfilesInformation(Netflix net) {
		if (net.noProfiles())
			System.out.println(Util.INEXISTENTPROFILES);
		else {
			Iterator<AbstractProfile> it2 = net.listProfiles();
			while (it2.hasNext()) {
				AbstractProfile profile = it2.next();
				String profileName = profile.getProfileName();
				if (net.isChild(profile))
					System.out.printf(Util.PROFILEDETAILSCHILD, profileName, net.getChildAge(profile));
				else
					System.out.printf(Util.PROFILEDETAILS, profileName);
				if (net.noShowsWatched(profileName))
					System.out.println(Util.INEXISTENTSHOWSSEEN);
				else {
					auxListSeenShows(net, profileName);
					auxListRatedShows(net, profileName);

				}

			}

		}
		System.out.println();

	}

	public static void auxListSeenShows(Netflix net, String profileName) {
		Iterator<AbstractRecord> it3 = net.listSeenShows(profileName);
		while (it3.hasNext()) {
			AbstractRecord show = it3.next();
			if (!it3.hasNext())
				System.out.printf(Util.DETAILS5, show.getTitle());
			else {
				System.out.printf(Util.DETAILS2, show.getTitle());
				System.out.printf(Util.EMPTY);
			}
		}
	}

	private static void auxListRatedShows(Netflix net, String profileName) {
		Iterator<AbstractRecord> it4 = net.listRatedShows(profileName);
		while (it4.hasNext()) {
			AbstractRecord record = it4.next();
			if (!it4.hasNext())
				System.out.printf(Util.RATEDETAILS2, record.getTitle(),
						net.getShowRate(profileName, record.getTitle()));
			else {
				System.out.printf(Util.RATEDETAILS1, record.getTitle(),
						net.getShowRate(profileName, record.getTitle()));
				System.out.printf(Util.EMPTY);

			}
		}
	}

	private static void auxSearch(AbstractRecord show) {

		if (show instanceof Movie) {
			Movie movie = (Movie) show;
			System.out.printf(Util.MOVIEDETAILS, show.getTitle(), movie.getDirector(), movie.getDuration(),
					show.getAgeRate(), show.getRelYear(), show.getGenre());
			Iterator<String> it2 = show.getCast().iterator();
			while (it2.hasNext()) {
				String person = it2.next();
				if (!it2.hasNext())
					System.out.printf(Util.FINALCAST, person);
				else
					System.out.printf(Util.CAST, person);
			}
		} else {
			Serie serie = (Serie) show;
			System.out.printf(Util.SERIEDETAILS, show.getTitle(), serie.getCreator(), serie.getNumSeasons(),
					serie.getNumEpisodes(), show.getAgeRate(), show.getRelYear(), show.getGenre());
			Iterator<String> it3 = show.getCast().iterator();
			while (it3.hasNext()) {
				String person = it3.next();
				if (!it3.hasNext())
					System.out.printf(Util.FINALCAST, person);
				else
					System.out.printf(Util.CAST, person);
			}
		}
	}

}
