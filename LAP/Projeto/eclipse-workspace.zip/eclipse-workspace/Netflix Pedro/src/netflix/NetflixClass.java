package netflix;

/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import comparators.ProgComparator;
import comparators.RateComparator;
import comparators.TitleComparator;
import exceptions.AlreadyLoggedException;
import exceptions.CannotDowngradeException;
import exceptions.ImpossibleLoginException;
import exceptions.InexistentAccountException;
import exceptions.InexistentProfileException;
import exceptions.InsufficientAgeException;
import exceptions.NoClientLoggedInException;
import exceptions.NoProfileSelectedException;
import exceptions.NoShowFoundException;
import exceptions.NotRecentlySeenException;
import exceptions.ProfileAlreadyExistsException;
import exceptions.SameEmailException;
import exceptions.SameMembershipException;
import exceptions.ShowAlreadyRatedException;
import exceptions.StringMissMatchException;
import exceptions.TooManyDevicesException;
import exceptions.TooManyProfilesException;
import packages.BasicPackage;
import packages.BasicPackageClass;
import packages.PremiumPackage;
import packages.PremiumPackageClass;
import packages.StandardPackage;
import packages.StandardPackageClass;
import profiles.AbstractProfile;
import profiles.ChildProfile;
import record.AbstractRecord;
import record.MovieClass;
import record.SerieClass;
import user.User;
import user.UserClass;
import utilities.Util;

public class NetflixClass implements Netflix {

	private List<AbstractRecord> database;
	private Map<String, SortedSet<AbstractRecord>> recordsByGenre;
	private Map<String, SortedSet<AbstractRecord>> recordsByName;
	private Map<String, AbstractRecord> recordsByTitle;
	private Map<String, User> usersByEmail;
	private Set<AbstractRecord> recordsRated;

	private String currentUser;
	private String currentDevice;
	private String currentProfile;

	public BasicPackage basic;
	public StandardPackage standard;
	public PremiumPackage premium;

	public NetflixClass() {
		database = new LinkedList<AbstractRecord>();
		recordsByGenre = new HashMap<String, SortedSet<AbstractRecord>>();
		recordsByName = new HashMap<String, SortedSet<AbstractRecord>>();
		recordsByTitle = new HashMap<String, AbstractRecord>();
		usersByEmail = new HashMap<String, User>();
		recordsRated = new TreeSet<>(new RateComparator());
		basic = new BasicPackageClass();
		standard = new StandardPackageClass();
		premium = new PremiumPackageClass();
		currentUser = "";
		currentDevice = "";
		currentProfile = "";
	}

	public void uploadMovie(String title, String director, int duration, String ageRate, int relYear, String genre,
			int nbCast, List<String> cast) {
		AbstractRecord movie = new MovieClass(title, ageRate, genre, relYear, cast, director, duration);

		uploadRecord(movie, genre, title, director, cast);
	}

	public void uploadSerie(String title, String creator, int nbSeason, int nbEpisodes, String ageRate, int relYear,
			String genre, int nbCast, List<String> cast) {

		AbstractRecord serie = new SerieClass(title, ageRate, genre, relYear, cast, creator, nbSeason, nbEpisodes);

		uploadRecord(serie, genre, title, creator, cast);
	}

	/**
	 * 
	 * Method that adds a show to all lists, sets and maps created~
	 * 
	 * @param record
	 *            the show
	 * @param genre
	 *            show's genre
	 * @param title
	 *            show's title
	 * @param directorCreator
	 *            show's director or creator
	 * @param cast
	 *            show's cast
	 * 
	 */
	private void uploadRecord(AbstractRecord record, String genre, String title, String directorCreator,
			List<String> cast) {

		database.add(record);

		addRecordsToMap(record, directorCreator, cast);

		SortedSet<AbstractRecord> auxRecords1 = recordsByGenre.get(genre);
		if (auxRecords1 == null)
			auxRecords1 = new TreeSet<AbstractRecord>(new TitleComparator());
		auxRecords1.add(record);
		recordsByGenre.put(genre, auxRecords1);

		recordsByTitle.put(title, record);

	}

	/**
	 * 
	 * Method that adds a show to the recordsByName map
	 * 
	 * @param record
	 *            the show
	 * @param directorCreator
	 *            director or creator's name
	 * @param cast
	 *            all members of the cast
	 * 
	 */
	private void addRecordsToMap(AbstractRecord record, String directorCreator, List<String> cast) {
		SortedSet<AbstractRecord> records1 = recordsByName.get(directorCreator);
		if (records1 == null)
			records1 = new TreeSet<AbstractRecord>(new ProgComparator());
		records1.add(record);
		recordsByName.put(directorCreator, records1);
		for (String member : cast) {
			SortedSet<AbstractRecord> records2 = recordsByName.get(member);
			if (records2 == null)
				records2 = new TreeSet<AbstractRecord>(new ProgComparator());
			records2.add(record);
			recordsByName.put(member, records2);

		}
	}

	public Iterator<AbstractRecord> recordListByTitle() {
		TitleComparator titleComparator = new TitleComparator();
		Collections.sort(database, titleComparator);
		return database.iterator();

	}

	@Override
	public void addUser(String name, String email, String password, String device)
			throws SameEmailException, ImpossibleLoginException {

		if (usersByEmail.containsKey(email)) {
			throw new SameEmailException(email);
		}
		if (!currentUser.equals("")) {
			throw new ImpossibleLoginException();
		}
		User newUser = new UserClass(name, email, password, device);

		usersByEmail.put(email, newUser);
		currentUser = email;
		currentDevice = device;

	}

	@Override
	public String processLogin(String email, String password, String dev) throws StringMissMatchException,
			ImpossibleLoginException, TooManyDevicesException, AlreadyLoggedException, InexistentAccountException {
		User user = usersByEmail.get(email);

		if (currentUser.equals(email)) {
			throw new AlreadyLoggedException();
		} else if (!currentUser.equals(email) && !currentUser.equals("")) {
			throw new ImpossibleLoginException();
		} else if (!usersByEmail.containsKey(email)) {
			throw new InexistentAccountException();
		} else if (!user.getPassword().equals(password)) {
			throw new StringMissMatchException();
		}

		if (!user.devIsOpen(dev)) {
			user.openDevice(dev);
		}

		currentDevice = dev;
		currentUser = email;

		return user.getName();
	}

	@Override
	public void processDisconnect() throws NoClientLoggedInException {

		if (currentUser.equals("")) {
			throw new NoClientLoggedInException();
		}

		usersByEmail.get(currentUser).closeDevice(currentDevice);
		currentUser = "";

	}

	@Override
	public String getActLoginAcc() throws NoClientLoggedInException {

		if (currentUser.equals("")) {
			throw new NoClientLoggedInException();
		}

		return usersByEmail.get(currentUser).getName();
	}

	public String getCurrentDevice() {
		return currentDevice;
	}

	public void processLogout() throws NoClientLoggedInException {
		if (currentUser.equals("")) {
			throw new NoClientLoggedInException();
		}

		currentUser = "";
	}

	public void membership(String packageName)
			throws NoClientLoggedInException, SameMembershipException, CannotDowngradeException {

		if (currentUser.equals(""))
			throw new NoClientLoggedInException();

		if (packageName.equals(Util.BASICTYPE))
			usersByEmail.get(currentUser).changeMembership(packageName, basic);
		else if (packageName.equals((Util.STANDARDTYPE)))
			usersByEmail.get(currentUser).changeMembership(packageName, standard);
		else
			usersByEmail.get(currentUser).changeMembership(packageName, premium);

	}

	public String getMembershipType() throws NoClientLoggedInException {
		if (currentUser.equals(""))
			throw new NoClientLoggedInException();
		return usersByEmail.get(currentUser).getMembershipType();
	}

	public void addProfile(String profileName, String profileType, int childAge)
			throws NoClientLoggedInException, ProfileAlreadyExistsException, TooManyProfilesException {
		if (currentUser.equals(""))
			throw new NoClientLoggedInException();
		User person = usersByEmail.get(currentUser);
		if (person.getProfile(profileName) != null)
			throw new ProfileAlreadyExistsException();
		else {
			person.addProfile(profileName, profileType, childAge);

		}

	}

	public void selectProfile(String profileName) throws NoClientLoggedInException, InexistentProfileException {

		if (currentUser.equals(""))
			throw new NoClientLoggedInException();
		else if (usersByEmail.get(currentUser).getProfile(profileName) == null)
			throw new InexistentProfileException();
		else
			currentProfile = profileName;

	}

	public void watchShow(String showTitle) throws NoClientLoggedInException, NoProfileSelectedException,
			NoShowFoundException, InsufficientAgeException {

		if (currentUser.equals(""))
			throw new NoClientLoggedInException();
		else if (currentProfile.equals(""))
			throw new NoProfileSelectedException();
		else if (!recordsByTitle.containsKey(showTitle))
			throw new NoShowFoundException();
		else if (usersByEmail.get(currentUser).getProfile(currentProfile) instanceof ChildProfile) {
			ChildProfile profile = (ChildProfile) usersByEmail.get(currentUser).getProfile(currentProfile);
			if (profile.getChildAge() < convertShowAge(profile, getShow(showTitle)))
				throw new InsufficientAgeException();
			AbstractRecord show = getShow(showTitle);
			profile.watchShow(show);
		} else {
			AbstractRecord show = getShow(showTitle);
			usersByEmail.get(currentUser).getProfile(currentProfile).watchShow(show);
		}

	}

	/**
	 * 
	 * Method that searches a show by using its name
	 * 
	 * @param showTitle
	 *            show's name
	 * @return show with that given name
	 * 
	 */
	private AbstractRecord getShow(String showTitle) {
		Iterator<AbstractRecord> it = database.iterator();
		while (it.hasNext()) {
			AbstractRecord record = it.next();
			if (record.getTitle().equals(showTitle))
				return record;
		}
		return null;
	}

	public void rateShow(String showTitle, int rate) throws NoClientLoggedInException, NoProfileSelectedException,
			NoShowFoundException, NotRecentlySeenException, ShowAlreadyRatedException {

		if (currentUser.equals(""))
			throw new NoClientLoggedInException();
		else if (currentProfile.equals(""))
			throw new NoProfileSelectedException();
		else if (!recordsByTitle.containsKey(showTitle))
			throw new NoShowFoundException();
		else {
			AbstractRecord show = getShow(showTitle);
			usersByEmail.get(currentUser).getProfile(currentProfile).rateShow(show, rate);

			if (getRatedShow(show.getTitle()) != null) {
				recordsRated.remove(show);
				show.calculateRate(rate);
				recordsRated.add(show);
			} else {
				show.calculateRate(rate);
				recordsRated.add(show);
			}

		}
	}

	/**
	 * 
	 * Method that returns a rated show by giving it's title
	 * 
	 * @param showTitle
	 *            show's title
	 * @return show or null if there is no show with the given name
	 * 
	 */
	private AbstractRecord getRatedShow(String showTitle) {
		Iterator<AbstractRecord> it = recordsRated.iterator();
		while (it.hasNext()) {
			AbstractRecord record = it.next();
			if (record.getTitle().equals(showTitle))
				return record;
		}
		return null;
	}

	public Iterator<String> listDevices() {
		return usersByEmail.get(currentUser).listDevices();
	}

	public String getCurrentProfile() {
		return currentProfile;
	}

	public boolean noShowsWatched(String profileName) {
		return usersByEmail.get(currentUser).getProfile(profileName).recentShowsIsEmpty();
	}

	public boolean noProfiles() {
		return usersByEmail.get(currentUser).noProfiles();
	}

	public Iterator<AbstractProfile> listProfiles() {
		return usersByEmail.get(currentUser).listProfiles();
	}

	public Iterator<AbstractRecord> listSeenShows(String profileName) {
		return usersByEmail.get(currentUser).getProfile(profileName).listSeenShows();
	}

	public boolean isChild(AbstractProfile profile) {
		return profile instanceof ChildProfile;
	}

	public int getChildAge(AbstractProfile profile) {
		return ((ChildProfile) profile).getChildAge();
	}

	public Iterator<AbstractRecord> listRatedShows(String profileName) {
		return usersByEmail.get(currentUser).getProfile(profileName).listRatedShows();
	}

	public int getShowRate(String profileName, String showName) {
		return usersByEmail.get(currentUser).getProfile(profileName).getShowRate(showName);
	}

	public Iterator<AbstractRecord> listByGenre(String genre)
			throws NoClientLoggedInException, NoProfileSelectedException, NoShowFoundException {

		if (currentUser.equals(""))
			throw new NoClientLoggedInException();
		else if (currentProfile.equals(""))
			throw new NoProfileSelectedException();
		else {
			SortedSet<AbstractRecord> records = recordsByGenre.get(genre);
			if (records == null)
				throw new NoShowFoundException();
			return records.iterator();
		}

	}

	public Iterator<AbstractRecord> listByName(String title)
			throws NoClientLoggedInException, NoProfileSelectedException, NoShowFoundException {

		if (currentUser.equals(""))
			throw new NoClientLoggedInException();
		else if (currentProfile.equals(""))
			throw new NoProfileSelectedException();
		else {
			SortedSet<AbstractRecord> records = recordsByName.get(title);
			if (records == null)
				throw new NoShowFoundException();
			return records.iterator();
		}
	}

	public Iterator<AbstractRecord> listRatedRecords(int rate)
			throws NoClientLoggedInException, NoProfileSelectedException, NoShowFoundException {
		if (currentUser.equals(""))
			throw new NoClientLoggedInException();
		else if (currentProfile.equals(""))
			throw new NoProfileSelectedException();
		else {
			noShowsAboveRate(rate);
			return recordsRated.iterator();
		}
	}

	public boolean showIsForChild(AbstractRecord show) {
		AbstractProfile profile = usersByEmail.get(currentUser).getProfile(currentProfile);
		if (profile instanceof ChildProfile) {
			if (((ChildProfile) profile).getChildAge() >= convertShowAge(profile, show))
				return true;
			else
				return false;
		}
		return true;
	}

	/**
	 * 
	 * Method that allows to check if there is any show with a rating above the
	 * given one
	 * 
	 * @param rate
	 *            given rate
	 * @throws NoShowFoundException
	 *             if there is no show
	 * 
	 */
	private void noShowsAboveRate(int rate) throws NoShowFoundException {
		boolean noShows = false;
		Iterator<AbstractRecord> it = recordsRated.iterator();
		while (it.hasNext()) {
			AbstractRecord record = it.next();
			if (showIsForChild(record)) {
				if (record.getRate() >= rate)
					noShows = true;
			}

		}
		if (!noShows)
			throw new NoShowFoundException();
	}

	/**
	 * 
	 * Private method that converts a show's age range ,that is on a string, to an
	 * int
	 * 
	 * @param profile
	 *            profile being used
	 * @param show
	 *            chosen show
	 * @return show's age range
	 * 
	 */
	private int convertShowAge(AbstractProfile profile, AbstractRecord show) {
		profile = ((ChildProfile) profile);
		String showAge = show.getAgeRate();
		showAge = showAge.replace("+", "");
		int showAgeInteger = Integer.parseInt(showAge);

		return showAgeInteger;
	}

}
