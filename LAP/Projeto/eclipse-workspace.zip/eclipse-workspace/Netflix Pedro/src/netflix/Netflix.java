package netflix;

/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

import java.util.Iterator;
import java.util.List;

import exceptions.AlreadyLoggedException;
import exceptions.CannotDowngradeException;
import exceptions.ImpossibleLoginException;
import exceptions.InexistentAccountException;
import exceptions.InexistentProfileException;
import exceptions.InsufficientAgeException;
import exceptions.NoClientLoggedInException;
import exceptions.NoProfileSelectedException;
import exceptions.NoShowFoundException;
import exceptions.NotRecentlySeenException;
import exceptions.ProfileAlreadyExistsException;
import exceptions.SameEmailException;
import exceptions.SameMembershipException;
import exceptions.ShowAlreadyRatedException;
import exceptions.StringMissMatchException;
import exceptions.TooManyDevicesException;
import exceptions.TooManyProfilesException;
import profiles.AbstractProfile;
import record.AbstractRecord;

public interface Netflix {

	/**
	 * Upload movie in Netflix platform
	 * 
	 * @param title:
	 *            title of the movie
	 * @param director:
	 *            director of the movie
	 * @param duration:
	 *            duration of the movie
	 * @param ageRate:
	 *            age rate of the movie
	 * @param relYear:reliese
	 *            date of the movie
	 * @param genre:
	 *            genre of the movie
	 * @param nbCast:
	 *            numer of actors of the movie
	 * @param cast:
	 *            actors of the movie
	 */
	void uploadMovie(String title, String director, int duration, String ageRate, int relYear, String genre, int nbCast,
			List<String> cast);

	/**
	 * Upload Serie in Netflix platform
	 * 
	 * @param title:
	 *            title of the serie
	 * @param criator:
	 *            criator of the serie
	 * @param nbSeason:
	 *            number of seasons of the serie
	 * @param nbEpisodes:
	 *            number of episodes of the serie
	 * @param ageRate:
	 *            age rate of of the serie
	 * @param relYear:
	 *            release date of the serie
	 * @param genre:
	 *            genre of the serie
	 * @param nbCast:
	 *            number of actors of the serie
	 * @param cast:
	 *            actors of the serie
	 */
	void uploadSerie(String title, String criator, int nbSeason, int nbEpisodes, String ageRate, int relYear,
			String genre, int nbCast, List<String> cast);

	Iterator<AbstractRecord> recordListByTitle();

	/**
	 * Method that returns an iterator of records by choosing an genre
	 * 
	 * @param genre
	 *            of the records that the user wants to see
	 * 
	 * @return iterator of a collection of records with that genre
	 * 
	 * @throws NoShowFoundException
	 *             if there's no records with that genre
	 * @throws NoProfileSelectedException
	 *             if there is no profile selected
	 * @throws NoClientLoggedInException
	 *             if there is no account logged in
	 * 
	 */
	Iterator<AbstractRecord> listByGenre(String genre)
			throws NoShowFoundException, NoClientLoggedInException, NoProfileSelectedException;

	/**
	 * Method that returns an iterator of records by choosing an title
	 * 
	 * @param title
	 * @return iterator
	 * @throws NoShowFoundException
	 *             if there is no show with the given actor
	 * @throws NoProfileSelectedException
	 *             if there is no profile selected
	 * @throws NoClientLoggedInException
	 *             if there is no account logged in
	 */
	Iterator<AbstractRecord> listByName(String title)
			throws NoShowFoundException, NoClientLoggedInException, NoProfileSelectedException;

	/**
	 * Create new user
	 * 
	 * @param name:
	 *            name of the new user
	 * @param email:
	 *            email of the new user
	 * @param password:
	 *            password of the new user
	 * @param device:
	 *            device of the new user
	 */
	void addUser(String name, String email, String password, String device)
			throws SameEmailException, ImpossibleLoginException;

	/**
	 * 
	 * @param email
	 * @param password
	 * @param dev
	 * @return
	 * @throws LoginException
	 * @throws StringMissMatchException
	 * @throws ImpossibleLoginException
	 * @throws TooManyDevicesException
	 * @throws AlreadyLoggedException
	 * @throws InexistentAccountException
	 */
	String processLogin(String email, String password, String dev) throws StringMissMatchException,
			ImpossibleLoginException, TooManyDevicesException, AlreadyLoggedException, InexistentAccountException;

	/**
	 * Disconnect the current user from the platform (device not active)
	 * 
	 * @throws NoClientLoggedInException
	 */
	void processDisconnect() throws NoClientLoggedInException;

	/**
	 * Make logout of the user from the platform (device still active)
	 * 
	 * @throws NoClientLoggedInException
	 */
	void processLogout() throws NoClientLoggedInException;

	/**
	 * 
	 * Method that returns the user's name
	 * 
	 * @return user's name
	 * @throws NoClientLoggedInException
	 *             if there is no account logged in
	 * 
	 */
	String getActLoginAcc() throws NoClientLoggedInException;

	/**
	 * 
	 * Method that returns the device being used at the curent time
	 * 
	 * @return device's name
	 * 
	 */
	String getCurrentDevice();

	/**
	 * 
	 * Method that allows the user to change his/her account's membership
	 * 
	 * @param packageName
	 *            type of the package
	 * @throws NoClientLoggedInException
	 *             if there's no user logged in
	 * @throws SameMembershipException
	 *             if the user tries to change to the same package
	 * @throws CannotDowngradeException
	 *             if the user tries to downgrade with more devices online than the
	 *             chosen package allows to
	 * 
	 */
	void membership(String packageName) throws NoClientLoggedInException, SameMembershipException, CannotDowngradeException;

	/**
	 * 
	 * Method that returns the name of the package that the user is using
	 * 
	 * @return name of the package
	 * @throws NoClientLoggedInException
	 *             if there is no user logged in
	 * 
	 */
	String getMembershipType() throws NoClientLoggedInException;

	/**
	 * 
	 * Method that allows the user to add a profile to his/hers account
	 * 
	 * @param profileName
	 *            name of the profile added
	 * @param profileType
	 *            type of the profile chosen
	 * @param childAge
	 *            in case of being a children profile, the user needs to choose the
	 *            age rating
	 * @throws NoClientLoggedInException
	 *             if there is no account logged in
	 * @throws ProfileAlreadyExistsException
	 *             if the profile that the user wants to create already exists
	 * @throws TooManyProfilesException
	 *             if the capacity of profiles that the account can hold is full
	 */
	void addProfile(String profileName, String profileType, int childAge)
			throws NoClientLoggedInException, ProfileAlreadyExistsException, TooManyProfilesException;

	/**
	 * 
	 * Method that allows the user to select the profile that he/she wants to use
	 * 
	 * @param profileName
	 *            name of the profile chosen
	 * @throws NoClientLoggedInException
	 *             if there is no account logged in
	 * @throws InexistentProfileException
	 *             if there is no profile with the name given
	 */
	void selectProfile(String profileName) throws NoClientLoggedInException, InexistentProfileException;

	/**
	 * 
	 * Method that allows the user to watch a show with a given title
	 * 
	 * @param showTitle
	 *            show's title
	 * @throws NoClientLoggedInException
	 *             if there is no current user logged in
	 * @throws NoProfileSelectedException
	 *             if there is no profile chosen
	 * @throws NoShowFoundException
	 *             if there is no show with the given name
	 * @throws InsufficientAgeException
	 *             if the child is too young to watch that show
	 */
	void watchShow(String showTitle)
			throws NoClientLoggedInException, NoProfileSelectedException, NoShowFoundException, InsufficientAgeException;

	/**
	 * 
	 * Method that allows the user to rate a recently watched show
	 * 
	 * @param showTitle
	 *            show's title
	 * @param rate
	 *            show's rating
	 * @throws NoClientLoggedInException
	 *             if there is no account logged in
	 * @throws NoProfileSelectedException
	 *             if there is no profile selected
	 * @throws NoShowFoundException
	 *             if there is no show with the given name
	 * @throws NotRecentlySeenException
	 *             if the chosen show wasn't recently watched
	 * @throws ShowAlreadyRatedException
	 *             if the chosen show was already rated
	 */
	void rateShow(String showTitle, int rate) throws NoClientLoggedInException, NoProfileSelectedException, NoShowFoundException,
			NotRecentlySeenException, ShowAlreadyRatedException;

	/**
	 * 
	 * Method that lists all the devices of the current user
	 * 
	 * @return iterator of those devices
	 * 
	 */
	Iterator<String> listDevices();

	/**
	 * 
	 * Method that returns the name of the current profile
	 * 
	 * @return current profile's name
	 * 
	 */
	String getCurrentProfile();

	/**
	 * 
	 * Method that allows to see if the user has seen any show
	 * 
	 * @param profileName
	 *            profile's name
	 * @return true if he/she hasn't and false if he/she has
	 * 
	 */
	boolean noShowsWatched(String profileName);

	/**
	 * 
	 * Method that checks if there's no profiles created
	 * 
	 * @return true if there isn't and false if there is
	 * 
	 */
	boolean noProfiles();

	/**
	 * 
	 * Method that lists all the profiles created by the current user
	 * 
	 * @return iterator of the profiles
	 * 
	 */
	Iterator<AbstractProfile> listProfiles();

	/**
	 * 
	 * Method that lists recently seen shows
	 * 
	 * @param profileName
	 *            profile's name
	 * @return iterator of recently seen shows
	 * 
	 */
	Iterator<AbstractRecord> listSeenShows(String profileName);

	/**
	 * 
	 * Method that verifies if the chosen profile is for a child or not
	 * 
	 * @param profile
	 *            chosen profile
	 * @return true if it is and false if it isn't
	 * 
	 */
	boolean isChild(AbstractProfile profile);

	/**
	 * 
	 * Method that returns the child's age
	 * 
	 * @pre profile instanceof ChildProfile
	 * @param profile
	 *            chosen profile
	 * @return child's age
	 * 
	 */
	int getChildAge(AbstractProfile profile);

	/**
	 * Method that lists all rated shows
	 * 
	 * @param profileName
	 *            profile's name
	 * @return iterator
	 * 
	 */
	Iterator<AbstractRecord> listRatedShows(String profileName);

	/**
	 * 
	 * Method that returns a show's rating
	 * 
	 * @param profileName
	 *            profile's name
	 * @param showName
	 *            show's name
	 * @return rating
	 * 
	 */
	int getShowRate(String profileName, String showName);

	/**
	 * 
	 * Method that returns an iterator that allows to list all rated shows
	 * 
	 * @param rate
	 *            given rate
	 * @return iterator
	 * @throws NoClientLoggedInException
	 *             if there is no user logged in
	 * @throws NoProfileSelectedException
	 *             if there is no profile selected
	 * @throws NoShowFoundException
	 *             if there is no show with a rating above the given one
	 * 
	 */
	Iterator<AbstractRecord> listRatedRecords(int rate)
			throws NoClientLoggedInException, NoProfileSelectedException, NoShowFoundException;

	/**
	 * 
	 * Method that verifies if a show is for a child or not
	 * 
	 * @param show
	 *            the chosen show
	 * @return true if it is or if the profile isn't a children's one and false if
	 *         it isn't
	 */
	boolean showIsForChild(AbstractRecord show);

}
