
/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

package user;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import exceptions.CannotDowngradeException;
import exceptions.NotRecentlySeenException;
import exceptions.SameMembershipException;
import exceptions.ShowAlreadyRatedException;
import exceptions.TooManyDevicesException;
import exceptions.TooManyProfilesException;
import packages.AbstractPackage;
import packages.BasicPackage;
import packages.BasicPackageClass;
import packages.PremiumPackage;
import packages.StandardPackage;
import profiles.AbstractProfile;
import profiles.AbstractProfileClass;
import profiles.ChildProfile;
import profiles.ChildProfileClass;
import profiles.NormalProfileClass;
import record.AbstractRecord;
import utilities.Util;

public class UserClass implements User {

	private String name;
	private String email;
	private String password;
	private List<String> devices;
	private AbstractPackage packageType;
	private List<AbstractProfile> profiles;

	public UserClass(String name, String email, String password, String device) {
		this.name = name;
		this.email = email;
		this.password = password;
		devices = new LinkedList<>();
		devices.add(device);
		packageType = new BasicPackageClass();
		profiles = new ArrayList<>();
	}

	public String getName() {
		return name;
	}

	public String getEmail() {
		return email;
	}

	public String getPassword() {
		return password;
	}

	public AbstractPackage getPackageType() {
		return packageType;
	}

	public void openDevice(String name) throws TooManyDevicesException {
		if (devices.size() >= packageType.getNumDevices())
			throw new TooManyDevicesException();
		devices.add(0, name);
	}

	@Override
	public void closeDevice(String name) {
		devices.remove(name);
	}

	@Override
	public void closeAllDevices() {
		devices.clear();
	}

	@Override
	public void addProfile(String profileName, String profileType, int childAge) throws TooManyProfilesException {
		if (profiles.size() >= packageType.getNumProfiles())
			throw new TooManyProfilesException();
		AbstractProfile profile = new AbstractProfileClass(profileName);
		if (profileType.equals(Util.NORMALPROFILE)) {
			profile = new NormalProfileClass(profileName);
		} else
			profile = new ChildProfileClass(profileName, childAge);
		profiles.add(profile);

	}

	protected int nbDevicesConnected() {
		return devices.size();
	}

	public boolean devIsOpen(String dev) {
		return devices.contains(dev);
	}

	public void changeMembership(String packageName, AbstractPackage packageType)
			throws SameMembershipException, CannotDowngradeException {
		if (this.packageType.getClass().equals(packageType.getClass()))
			throw new SameMembershipException();
		else if ((devices.size() > packageType.getNumDevices()))
			throw new CannotDowngradeException();
		else
			this.packageType = packageType;

	}

	public String getMembershipType() {
		if (packageType instanceof StandardPackage)
			return StandardPackage.TYPE;
		else if (packageType instanceof PremiumPackage)
			return PremiumPackage.TYPE;
		else
			return BasicPackage.TYPE;

	}

	public AbstractProfile getProfile(String profileName) {
		Iterator<AbstractProfile> it = profiles.iterator();
		while (it.hasNext()) {
			AbstractProfile profile = it.next();
			if (profile.getProfileName().equals(profileName)) {
				return profile;
			}

		}
		return null;
	}

	public void watchShow(String profileName, AbstractRecord e) {
		AbstractProfile profile = getProfile(profileName);
		profile.watchShow(e);
		assert isChildShow(profile, e) : "Show's not acceptable for children' current age.";

	}

	public void rateShow(String profileName, AbstractRecord show, int rate)
			throws NotRecentlySeenException, ShowAlreadyRatedException {
		AbstractProfile profile = getProfile(profileName);
		profile.rateShow(show, rate);
	}

	public Iterator<String> listDevices() {
		return devices.iterator();
	}

	public boolean noProfiles() {
		return profiles.isEmpty();
	}

	public Iterator<AbstractProfile> listProfiles() {
		return profiles.iterator();
	}

	/**
	 * 
	 * Private method created to check if the show added is suitable for a child if
	 * the profile is a children' one. (Only used on an assert)
	 * 
	 * @param profile
	 *            profile being used
	 * @param e
	 *            chosen show
	 * @return true if the show is suitable or if the profile isn't a children' one
	 *         and false if the show isn't suitable
	 * 
	 */
	private boolean isChildShow(AbstractProfile profile, AbstractRecord e) {
		if (profile instanceof ChildProfile) {
			String showAge = e.getAgeRate();
			showAge = showAge.replace("+", "");
			int showAgeInteger = Integer.parseInt(showAge);
			if (((ChildProfile) profile).getChildAge() < showAgeInteger)
				return false;
			else
				return true;
		}
		return true;
	}

}
