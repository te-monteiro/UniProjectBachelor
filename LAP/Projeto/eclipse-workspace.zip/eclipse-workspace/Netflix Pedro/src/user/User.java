
/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

package user;

import java.util.Iterator;

import exceptions.CannotDowngradeException;
import exceptions.NotRecentlySeenException;
import exceptions.SameMembershipException;
import exceptions.ShowAlreadyRatedException;
import exceptions.TooManyDevicesException;
import exceptions.TooManyProfilesException;
import packages.AbstractPackage;
import profiles.AbstractProfile;
import record.AbstractRecord;

public interface User {

	/**
	 * 
	 * Method that returns the user's name
	 * 
	 * @return user's name
	 * 
	 */
	String getName();

	/**
	 * 
	 * Method that returns the user's email
	 * 
	 * @return user's email
	 * 
	 */
	String getEmail();

	/**
	 * 
	 * Method that returns the user's password
	 * 
	 * @return user's password
	 * 
	 */
	String getPassword();

	/**
	 * 
	 * Method that returns the user's package type
	 * 
	 * @return user's package type
	 * 
	 */
	AbstractPackage getPackageType();

	/**
	 * 
	 * Method that allows the user to open a device by giving a name
	 * 
	 * @param name
	 *            device's name
	 * @throws TooManyDevicesException
	 *             if the user has already reached full capacity of devices
	 * 
	 */
	void openDevice(String name) throws TooManyDevicesException;

	/**
	 * 
	 * Method that allows the user to close a device by giving its name
	 * 
	 * @param name
	 *            device's name
	 * 
	 */
	void closeDevice(String name);

	/**
	 * 
	 * Method that closes all devices
	 * 
	 */
	void closeAllDevices();

	/**
	 * 
	 * Method that verifies if a device is open or not
	 * 
	 * @param dev
	 *            device's name
	 * @return true if it's open and false if not
	 * 
	 */
	boolean devIsOpen(String dev);

	/**
	 * 
	 * Method that allows the user to change his/her account's membership
	 * 
	 * @param packageName
	 *            type of the package
	 * @param packageType
	 *            object that represents the package chosen
	 * @throws SameMembershipException
	 *             if the user tries to change to the same package
	 * @throws CannotDowngradeException
	 *             if the user tries to downgrade with more devices online than the
	 *             chosen package allows to
	 * 
	 */
	void changeMembership(String packageName, AbstractPackage packageType)
			throws SameMembershipException, CannotDowngradeException;

	/**
	 * 
	 * Method that returns the name of the package that the user is using
	 * 
	 * @return name of the package
	 * 
	 */
	String getMembershipType();

	/**
	 * 
	 * Method that allows the user to add a profile to his/her account
	 * 
	 * @param profileName
	 *            name of the new profile
	 * @param profileType
	 *            profile's type
	 * @param childAge
	 *            in case of being a children profile, the child's age
	 * @throws TooManyProfilesException
	 *             if the capacity of profiles on that account is already full
	 * 
	 */
	void addProfile(String profileName, String profileType, int childAge) throws TooManyProfilesException;

	/**
	 * 
	 * Method that returns a profile from a certain user
	 * 
	 * @param profileName
	 *            name of the profile
	 * @return profile with that name
	 */
	AbstractProfile getProfile(String profileName);

	/**
	 * 
	 * Method that allows the user to watch a show
	 * 
	 * @param profileName
	 *            profile's name
	 * @param e
	 *            show that the user wants to watch
	 * 
	 */
	void watchShow(String profileName, AbstractRecord e);

	/**
	 * 
	 * Method that allows the user to rate the show that he/she has recently watched
	 * 
	 * @param profileName
	 *            profile's name
	 * @param show
	 *            show recently watched
	 * @param rate
	 *            rating of the show
	 * @throws NotRecentlySeenException
	 *             if the chosen show wasn't recently watched
	 * @throws ShowAlreadyRatedException
	 *             if the chosen show was already rated
	 * 
	 */
	void rateShow(String profileName, AbstractRecord show, int rate)
			throws NotRecentlySeenException, ShowAlreadyRatedException;

	/**
	 * 
	 * Method that lists all the devices
	 * 
	 * @return iterator of the devices
	 * 
	 */
	Iterator<String> listDevices();

	/**
	 * 
	 * Method that checks if there is no profile created
	 * 
	 * @return true if there isn't and false if there is
	 * 
	 */
	boolean noProfiles();

	/**
	 * 
	 * Method that lists all profiles created
	 * 
	 * @return iterator of the profiles
	 * 
	 */
	Iterator<AbstractProfile> listProfiles();

}
