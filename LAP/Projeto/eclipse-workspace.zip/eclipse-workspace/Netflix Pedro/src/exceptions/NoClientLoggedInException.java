
/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

package exceptions;

@SuppressWarnings("serial")
public class NoClientLoggedInException extends Exception {

	public NoClientLoggedInException() {
		super();
	}
}
