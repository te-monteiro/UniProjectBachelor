package unitests;

//import static org.junit.jupiter.api.Assertions.*;

//import org.junit.jupiter.api.Test;

import exceptions.TooManyProfilesException;
import profiles.AbstractProfile;
import user.User;
import user.UserClass;

class FirstTest {

	/**
	 * Test that verifies if when created a profile, either a Normal or Children
	 * one, the recentShows list is empty
	 * 
	 * @throws TooManyProfilesException
	 */
//	@Test
	void testIfListIsEmpty() throws TooManyProfilesException {
		User user = new UserClass("eu", "eu@gmail.com", "tu", "ola");
		user.addProfile("Maria", "NORMAL", 0);
		user.addProfile("Eve", "CHILDREN", 10);
		AbstractProfile mariaProfile = user.getProfile("Maria");
		AbstractProfile eveProfile = user.getProfile("Eve");
	//	assertEquals(true, mariaProfile.recentShowsIsEmpty());
//		assertEquals(true, eveProfile.recentShowsIsEmpty());

	}

}
