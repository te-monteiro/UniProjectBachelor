package unitests;

//import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

//import org.junit.jupiter.api.Test;

import exceptions.TooManyProfilesException;
import profiles.AbstractProfile;
import record.AbstractRecord;
import record.Movie;
import record.MovieClass;
import user.User;
import user.UserClass;

class SecondTest {

	/**
	 * Test to verify if when added more than 10 shows, the recentShows list removes
	 * the first show inserted and adds the one that we want in the right order
	 * 
	 * @throws TooManyProfilesException
	 */
	//@Test
	void testResizeOfRecentShowsList() throws TooManyProfilesException {
		User user = new UserClass("eu", "eu@gmail.com", "tu", "ola");
		user.addProfile("Maria", "NORMAL", 0);
		AbstractProfile mariaProfile = user.getProfile("Maria");
		List<String> cast = new ArrayList<String>();
		cast.add("ola");
		cast.add("adeus");

		Movie show = new MovieClass("ola", "5+", "drama", 2018, cast, "adeus", 100);
		Movie show1 = new MovieClass("ola1", "5+", "drama", 2018, cast, "adeus", 100);
		Movie show2 = new MovieClass("ola2", "5+", "drama", 2018, cast, "adeus", 100);
		Movie show3 = new MovieClass("ola3", "5+", "drama", 2018, cast, "adeus", 100);
		Movie show4 = new MovieClass("ola4", "5+", "drama", 2018, cast, "adeus", 100);
		Movie show5 = new MovieClass("ola5", "5+", "drama", 2018, cast, "adeus", 100);
		Movie show6 = new MovieClass("ola6", "5+", "drama", 2018, cast, "adeus", 100);
		Movie show7 = new MovieClass("ola7", "5+", "drama", 2018, cast, "adeus", 100);
		Movie show8 = new MovieClass("ola8", "5+", "drama", 2018, cast, "adeus", 100);
		Movie show9 = new MovieClass("ola9", "5+", "drama", 2018, cast, "adeus", 100);
		Movie show10 = new MovieClass("ola10", "5+", "drama", 2018, cast, "adeus", 100);

		mariaProfile.watchShow(show);
		mariaProfile.watchShow(show1);
		mariaProfile.watchShow(show2);
		mariaProfile.watchShow(show3);
		mariaProfile.watchShow(show4);
		mariaProfile.watchShow(show5);
		mariaProfile.watchShow(show6);
		mariaProfile.watchShow(show7);
		mariaProfile.watchShow(show8);
		mariaProfile.watchShow(show9);
		mariaProfile.watchShow(show10);

		Iterator<AbstractRecord> it2 = mariaProfile.listSeenShows();
//		assertEquals(show10, it2.next());
//		assertEquals(show9, it2.next());
//		assertEquals(show8, it2.next());
//		assertEquals(show7, it2.next());
//		assertEquals(show6, it2.next());
//		assertEquals(show5, it2.next());
//		assertEquals(show4, it2.next());
//		assertEquals(show3, it2.next());
//		assertEquals(show2, it2.next());
//		assertEquals(show1, it2.next());

		boolean found = false;
		int showsCounter = 0;
		Iterator<AbstractRecord> it = mariaProfile.listSeenShows();
		while (it.hasNext()) {
			AbstractRecord record = it.next();
			if (record.getTitle().equals(show.getTitle()))
				found = true;
			showsCounter++;
		//	if (showsCounter == 10)
//				assertEquals(false, it.hasNext());
		}
	//	assertEquals(false, found);

	}

}
