
/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

package record;

import java.util.List;

public class SerieClass extends AbstractRecordClass implements Serie {

	private String creator;

	private int numSeasons;

	private int numEpisodes;

	public SerieClass(String title, String ageRate, String genre, int relYear, List<String> cast, String creator,
			int numSeasons, int nbEpisodes) {
		super(title, ageRate, genre, relYear, cast);
		this.creator = creator;
		this.numSeasons = numSeasons;
		this.numEpisodes = nbEpisodes;

	}

	public String getCreator() {
		return creator;
	}

	public int getNumSeasons() {
		return numSeasons;
	}

	public int getNumEpisodes() {
		return numEpisodes;
	}

}
