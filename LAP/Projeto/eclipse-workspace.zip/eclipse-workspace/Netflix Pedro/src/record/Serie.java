
/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

package record;

public interface Serie extends AbstractRecord {

	/**
	 * Method that returns the serie's creator
	 * 
	 * @return serie's creator
	 * 
	 */
	String getCreator();

	/**
	 * Method that returns the number of seasons of the serie's
	 * 
	 * @return number of seasons of the serie's
	 * 
	 */
	int getNumSeasons();

	/**
	 * Method that returns the number of episodes per season of the serie's
	 * 
	 * @return number of episodes per season of the serie's
	 * 
	 */
	int getNumEpisodes();

}
