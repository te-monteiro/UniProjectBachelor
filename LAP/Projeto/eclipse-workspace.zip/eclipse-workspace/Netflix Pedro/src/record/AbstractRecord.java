
/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

package record;

import java.util.List;

public interface AbstractRecord {

	/**
	 * Method that returns the record's title
	 * 
	 * @return record's title
	 * 
	 */
	String getTitle();

	/**
	 * Method that returns the record's age rating
	 * 
	 * @return record's age rating
	 * 
	 */
	String getAgeRate();

	/**
	 * Method that returns the record's genre
	 * 
	 * @return record's genre
	 * 
	 */
	String getGenre();

	/**
	 * Method that returns the record's release year
	 * 
	 * @return record's release year
	 * 
	 */
	int getRelYear();

	/**
	 * Method that returns the record's cast
	 * 
	 * @return record's cast
	 * 
	 */
	List<String> getCast();

	/**
	 * 
	 * Method that adds the given rate to the general one and increments the number
	 * of rates given by one
	 * 
	 * @param rate
	 *            given rate
	 * 
	 */
	void calculateRate(int rate);

	/**
	 * 
	 * Method that returns the final rate by dividing the general one by the integer
	 * that incremented each time calculateRate(integer rate) was used
	 * 
	 * @return final rate
	 * 
	 */
	double getRate();

}
