
/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

package record;

public interface Movie extends AbstractRecord {

	/**
	 * Method that returns the movie's director
	 * 
	 * @return movie's director
	 * 
	 */
	String getDirector();

	/**
	 * Method that returns the movie's duration
	 * 
	 * @return movie's duration
	 * 
	 */
	int getDuration();

}
