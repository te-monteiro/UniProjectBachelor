
/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

package record;

import java.util.List;

public class MovieClass extends AbstractRecordClass implements Movie {

	private String director;

	private int duration;

	public MovieClass(String title, String ageRate, String genre, int relYear, List<String> cast, String director,
			int duration) {
		super(title, ageRate, genre, relYear, cast);
		this.director = director;
		this.duration = duration;

	}

	public String getDirector() {
		return director;
	}

	public int getDuration() {
		return duration;
	}

}
