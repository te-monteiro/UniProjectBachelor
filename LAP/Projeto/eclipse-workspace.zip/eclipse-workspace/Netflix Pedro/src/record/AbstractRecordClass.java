
/**
 * 
 * @author Pedro Oliveira 52967
 * @author Vicente Cruz   52862
 * 
 */

package record;

import java.util.List;

public abstract class AbstractRecordClass implements AbstractRecord {

	private String title;
	private String genre;
	private String ageRate;
	private double rate;
	private int i;

	private int relYear;

	private List<String> cast;

	public AbstractRecordClass(String title, String ageRate, String genre, int relYear, List<String> cast) {
		this.title = title;
		this.ageRate = ageRate;
		this.genre = genre;
		this.relYear = relYear;
		this.cast = cast;
		rate = 0;
		i = 0;

	}

	public String getTitle() {
		return title;
	}

	public String getAgeRate() {
		return ageRate;
	}

	public String getGenre() {
		return genre;
	}

	public int getRelYear() {
		return relYear;
	}

	public List<String> getCast() {
		return cast;
	}

	public void calculateRate(int singleRate) {
		rate += singleRate;
		i++;
	}

	public double getRate() {
		double finalRate = rate;
		finalRate /= i;
		return finalRate;
	}

}
