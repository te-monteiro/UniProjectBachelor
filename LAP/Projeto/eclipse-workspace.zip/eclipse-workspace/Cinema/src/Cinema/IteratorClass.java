package Cinema;

public class IteratorClass<E> implements Iterator<E> {
	
	private E[] elems;
	private int counter, current;
	
	
	public IteratorClass (E[] elems, int counter) {
		this.elems = elems;
		this.counter = counter;
		this.init();
		
	}

	public void init() {
		this.current = 0;
	}
	
	public boolean hasNext() {
		return current < counter;
		
	}
	
	public E next() {
		return elems[current ++];
		
	}
	
	public boolean isEmpty() {
		return counter <= 0;
	}
}
