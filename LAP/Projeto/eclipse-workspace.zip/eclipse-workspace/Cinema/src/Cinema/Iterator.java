package Cinema;

public interface Iterator<E> {
	
	boolean hasNext();
	boolean isEmpty();
	void init();
	E next();

}
