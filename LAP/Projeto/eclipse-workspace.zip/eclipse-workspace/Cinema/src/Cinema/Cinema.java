package Cinema;

public interface Cinema {

	int searchIndexColab(String nome);

	void registar(String tipo, String notoriedade, int custo, String nome);


}
