package Cinema;

public class CinemaClass implements Cinema {

	private VetorGenerico<Colaborador> colab;

	public CinemaClass() {
		this.colab = new VetorGenericoClass<Colaborador>();

	}

	@Override
	public void registar(String tipo, String notoriedade, int custo, String nome) {
		switch(tipo) {
		case SENIOR:
			
			break;
		case PRODUTOR:
		}
		
		
		
	}
	
	
	
	
	@Override
	public int searchIndexColab(String nome) {
		Iterator<Colaborador> it = this.iteratorColab(nome);
		int result = -1;
		int counter = 0;
		if (!it.isEmpty()) {
			if (it.next().equals(nome))
				result = 0;
			else
				counter++;
			while (it.hasNext()) {
				if (it.next().equals(nome))
					result = counter;
			}
			counter++;
		} else
			result = -1;

		return result;

	}

	private Iterator<Colaborador> iteratorColab(String nome) {
		return colab.iterator();
	}


}
