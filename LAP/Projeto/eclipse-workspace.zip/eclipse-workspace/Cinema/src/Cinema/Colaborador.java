package Cinema;

public interface Colaborador {

}
