package Cinema;

public class ColaboradorClass implements Colaborador {

}
