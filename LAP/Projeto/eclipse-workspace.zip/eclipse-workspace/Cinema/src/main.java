import java.util.Scanner;

import Cinema.*;

public class main {

	private static final Object SAIR = "SAIR";
	private static final String HELP = "AJUDA";
	private static final String REGISTAR = "REGISTA";
	private static final String ATOR = "ATOR";
	private static final String REALIZADOR = "REALIZADOR";
	private static final String TECNICO = "TECNICO";
	private static final String SENIOR = "SENIOR";
	private static final String JUNIOR = "JUNIOR";
	private static final String VEDETA = "VEDETA";
	private static final String NORMAL = "NORMAL";

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);

		Cinema c = new CinemaClass();

		String comm = getCommand(in);

		while (!comm.equals(SAIR)) {
			switch (comm) {
			case HELP:
				ajuda();
				break;
			case REGISTAR:
				registar(in, c);
				break;

			default:
				System.out.println("TENS UM ERRO!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
			}
			comm = getCommand(in);
		}
		System.out.println("Ate a proxima.");
		in.close();
	}

	private static void registar(Scanner in, Cinema c) {
		String tipo = in.nextLine();
		String notoriedade = in.nextLine();
		int custo = in.nextInt();
		String nome = in.next().trim();
		if( c.searchIndexColab(nome) >= 0) {
			System.out.println("Ja existe um colaborador com o mesmo nome.");
		}else if(!tipo.equals(ATOR) && !tipo.equals(REALIZADOR) && !tipo.equals(JUNIOR) && !tipo.equals(TECNICO) && !tipo.equals(SENIOR)) {
			System.out.println("Tipo de colaborador desconhecido.");
		}else if(!notoriedade.equals(NORMAL) && !notoriedade.equals(VEDETA)) {
			System.out.println("Notoriedade invalida.");
		}else if(custo < 0 ) {
			System.out.println("Acha mesmo que este colaborador vai pagar para trabalhar?");
		}else {
			c.registar(tipo,notoriedade, custo, nome);
		}
			
		
		
		
	}

	private static void ajuda() {
		System.out.println("regista - regista um novo colaborador");
		System.out.println("staff - lista os colaboradores registados");
		System.out.println("cenario - regista um novo local para gravacoes");
		System.out.println("cenarios - lista os locais para gravacoes registados");
		System.out.println("marca - marca uma nova gravacao");
		System.out.println("amua - vedeta deixa de trabalhar com colaborador");
		System.out.println("reconcilia - vedeta faz as pazes com colaborador");
		System.out.println("realizadas - lista as gravacoes realizadas");
		System.out.println("previstas - lista as gravacoes previstas");
		System.out.println("local - lista as gravacoes previstas para um local");
		System.out.println("colaborador - lista as gravacoes previstas para um colaborador");
		System.out.println("grava - executa a proxima gravacao agendada");
		System.out.println("amuancos - lista os colaboradores com quem uma vedeta esta amuada");
		System.out.println("ajuda - Mostra a ajuda");
		System.out.println("sai - Termina a execucao do programa");

	}

	private static String getCommand(Scanner in) {
		String input;
		System.out.println();
		input = in.next().toUpperCase();

		return input;
	}

}
