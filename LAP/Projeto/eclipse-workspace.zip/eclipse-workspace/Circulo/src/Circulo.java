
public class Circulo {
	// variaveis
	// dx corresponde ao diametro do circulo no eixxo dos xx e o dy no eixo dos yy
	private double dx, dy, raio;
	// constante
	private static final int FACTOR = 2;
	private static final float PI = 3.14f;

	// construtor
	public Circulo() {
		dx = 0;
		dy = 0;
		raio = 1;
	}
	public Circulo(double cx, double cy, double raio) {
		dx = cx;
		dy = cy;
		this.raio = raio;
	}

	public double getPerimeter() {
		return (FACTOR * raio * PI);
	}

	public double getArea() {
		return (PI * raio * raio);
	}

	public double getRadius() {
		return raio;
	}

	public double getXCenter() {
		return dx;
	}

	public double getYCenter() {
		return dy;
	}

	public boolean ptinCircule(double x, double y) {
		boolean in = false;
		if (x < dx && y < dy) {
			in = true;
		}
		return in;
	}

	//public void translate(double dx, double dy) {
		

	
}
