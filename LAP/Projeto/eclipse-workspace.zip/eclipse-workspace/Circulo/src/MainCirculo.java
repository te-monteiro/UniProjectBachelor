
public class MainCirculo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Circulo c = new Circulo();
		double x = 0;
		double y = 0;
		System.out.println(c.getRadius());
		System.out.println(c.getArea());
		System.out.println(c.ptinCircule(x,y));
		System.out.println(c.getXCenter());
		System.out.println(c.getYCenter());

	}

}
