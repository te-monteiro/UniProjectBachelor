import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
	
		int amount;
		System.out.println("Saldo inicial em centimos:");
		amount = in.nextInt();
		in.nextLine();
		
		String option;
		
		if (amount >= 0) {
			Safe account = new Safe(amount);
			System.out.println("Conta criada com sucesso");
			option = readOption(in);
			switch (option) {
			case "L":
				processDeposit(account, in);
				break;
			case "D":
				processWithdraw(account, in);
				break;
			case "AJA":
				processApplyInterest(account);
				break;
			case "Y":
				processHowManySavingYears(account, in);
				break;
			case "S":
				break;
			}
			System.out.println("Saldo Conta");
			System.out.println(account.getBalance() + "C�ntimos");
		} else {
			System.out.println("Montante deve ser nao negativo");
		}
	}

	private static String readOption(Scanner in) {
		String option;
		System.out.println("L - Levantar");
		System.out.println("D - Depositar");
		System.out.println("Y - Anos de Poupan�a");
		System.out.println("S - Sair");
		option = in.nextLine();
		return option;
	}

	private static void processDeposit(Safe account, Scanner in) {
		System.out.println(("Montante a depositar"));
		int ammount = in.nextInt();
		in.nextLine();
		if (ammount > 0) {
			account.deposit(ammount);
			System.out.println("Deposito efectuado");
		} else {
			System.out.println("Deposito nao efectuado");
		}
	}

	private static void processWithdraw(Safe account, Scanner in) {
		System.out.println("Montante a levantar");
		int ammount = in.nextInt();
		in.nextLine();
		if (ammount > 0) {
			account.withdraw(ammount);
			System.out.println("Levantamento efectuado");
		} else {
			System.out.println("Levantamento nao efectuado");
		}
	}

	private static void processApplyInterest(Safe account) {
		account.applyInterest();

	}

	private static void processHowManySavingYears(Safe account, Scanner in) {
		int years = 0;
		Safe auxAccount = new Safe(account.getBalance());
		//while (auxAccount.getBalance() <= target) {
		//	years++;
	//		auxAccount.applyInterest();
	//	}
	}

}
