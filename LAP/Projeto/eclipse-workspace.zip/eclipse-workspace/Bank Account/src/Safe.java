
public class Safe {
		private int balance;
		public static final int FINE = 200;
		public static final int CAT1 = 1000000;
		public static final int CAT2 = 200000;
		public static final float RATECAT1 = 0.03f;
		public static final float RATECAT2 = 0.02f;
		public static final float RATECAT3 = 0.01f;
		public Safe (int balance) {
			this. balance = balance;
		}
		public void deposit (int amount) {
			balance = balance + amount;
		}
		public void withdraw (int amount) {
			if (amount <= balance)
				balance = balance - amount;
			else balance = balance - FINE;
		}
		public int getBalance() {
			return balance;
		}
		public boolean isInRedZone() {
			return balance < 0;
		}
		public int computeInterest() {
			float interestRate ;
			if (balance > 1000000)
				interestRate = RATECAT1;
			else if (balance > 200000)
				interestRate = RATECAT2;
			else interestRate = RATECAT3;
			return Math.round(balance * interestRate);
		}
		public void applyInterest () {
			balance = balance + this.computeInterest();
		}	
	


}
