
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub	
		System.out.println(dias("Feb"));
	}
	
	public static int dias(String mes) {
		int dias;
		switch (mes) {
		case "Feb" : dias = 28; break;
		case "Abr" :
		case "Jun" :
		case "Aug" :
		case "Set" :
		case "Nov" : dias = 30; break;
		    default: dias = 31;
		}
		return dias;
	}

}
