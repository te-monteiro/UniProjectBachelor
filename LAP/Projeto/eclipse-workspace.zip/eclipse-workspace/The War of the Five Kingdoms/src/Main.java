import java.util.Scanner;
public class Main {
	private static final String NOVO = "NOVO";
	private static final String AJUDA = "AJUDA";
	private static final String MAPA = "MAPA";
	private static final String SAI = "SAI";
	private static final String OBRIGADA_POR_JOGAR_ATE_A_PROXIMA = "Obrigado por jogar. Ate a proxima.";

	private static String getComand(Scanner in) {
		String input = "";
		System.out.println(">");
		input = in.nextLine().toLowerCase();
		return input;
		}
	
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		Game game = new Game();
		String option = "";
		//Enquando nao for a opcao sair ele permanece a espera de comandos
		while (!option.equals(SAI)) {
			prompt(game);
			option = in.next().toUpperCase();
			switch (option) {
			case NOVO:
				New(in, game);
				break;
			case AJUDA:
				comandosDisponiveis(game);
				break;
			case MAPA:
				descreverMap(game);
				break;
			case SAI:
				System.out.println(OBRIGADA_POR_JOGAR_ATE_A_PROXIMA);
				break;
			default:
				System.out.println(OPCAO_INEXISTENTE);
			}
		}
		in.close();
	}
	private static void descreverMap(Game game) {
		// TODO Auto-generated method stub
		
	}

	private static void comandosDisponiveis(Game game) {
		// TODO Auto-generated method stub
		
	}

	private static void New(Scanner in, Game game) {
		// TODO Auto-generated method stub
		
	}

	private static void prompt(Game game){
		int equipa = getCurrentTeamNumber(game);
		if(game.gameIsRuning()){
			System.out.print(game.getNameEquipa(equipa) + " " + SETINHA);
		} else 
			System.out.print(SETINHA);
	}
}


