
public class Castle {

}
