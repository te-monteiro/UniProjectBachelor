
public class Kingdom {

}
