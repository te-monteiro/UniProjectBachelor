
public class Soldier {

}
