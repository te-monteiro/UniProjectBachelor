
public class Semaforo {
	// variaveis
	private int luz;
	// constates
	public static final int RED = 1;
	public static final int GREEN = 2;
	public static final int YELLOW = 3;

	// construtor
	public Semaforo() {
		luz = RED;
	}

	public boolean isRed() {
		return (luz == RED);
	}

	public boolean isGreen() {
		return (luz == GREEN);
	}

	public boolean isYellow() {
		return (luz == YELLOW);
	}

	public boolean pass() {
		return (luz == GREEN) || (luz == YELLOW);
	}

	public boolean stop() {
		return (luz == RED);
	}

	public void changeColor() {
		if (luz == RED) {
			luz = GREEN;
		}else if (luz == GREEN) {
			luz = YELLOW;
		}else 
			luz = RED;
	}

}
