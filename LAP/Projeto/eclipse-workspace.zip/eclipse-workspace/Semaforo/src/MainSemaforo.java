
public class MainSemaforo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Semaforo s = new Semaforo();
		
		System.out.println(s.isGreen());
		System.out.println(s.isRed());
		System.out.println(s.pass());
		System.out.println(s.stop());
		s.changeColor();
		System.out.println(s.isYellow());
		System.out.println(s.pass());
		s.changeColor();
		System.out.println(s.isGreen());
		System.out.println(s.isYellow());
		System.out.println(s.pass());
		s.changeColor();
		System.out.println(s.pass());

	}

}
