
public class Milhoes {

	private boolean on;
	private int accumulateValue;
	
	public Milhoes() {
		on = true;
		accumulateValue = 0;
	}
	
	
	public boolean gameIsRuning() {
		return on;
	}


	public int getAccumulateValue() {
		return accumulateValue;
	}

}
