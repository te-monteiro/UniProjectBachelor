import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);

		Milhoes ricos = new Milhoes();

		String comm = "";


		while (!comm.equals("sai")) {
			comm = in.next().toUpperCase();
			prompt(ricos);
			switch (comm) {
			case "sai":
				System.out.printf("Valor acumulado: %d Euros. Ate a proxima.",ricos.getAccumulateValue());
				break;
			case "ajuda":
				getHelp(ricos);
				break;
			case "novo":
				getNew()

			default:
				System.out.println("Comando inexistente.");
			}
		}
		in.close();

	}

	private static void getHelp(Milhoes ricos) {
		if (!ricos.gameIsRuning()) {
			System.out.println("novo - Novo jogo dando um valor inicial");
			System.out.println("sai - Termina a execucao do programa");
			System.out.println("ajuda - Mostra os comandos existentes");
		} else {
			System.out.println("joga - Simula uma aposta, dando uma chave");
			System.out.println("fim - Termina o jogo em curso");
			System.out.println("ajuda - Mostra os comandos existentes");
		}

	}

	private static void prompt(Milhoes ricos) {
		if (ricos.gameIsRuning())
			System.out.println("FCTMILHOES>");
		else
			System.out.println(">");

	}

}
