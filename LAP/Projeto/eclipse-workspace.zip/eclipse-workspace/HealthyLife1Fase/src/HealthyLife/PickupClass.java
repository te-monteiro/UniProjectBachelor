package HealthyLife;

/**
 * 
 * @author Teresa Falcao de Campos Monteiro (52597)
 *         tfd.monteiro@campus.fct.unl.pt
 * @author Ana Filipa Santos Pereira Fernandes da Silva (52787)
 *         afsp.silva@campus.fct.unl.pt
 * 
 *
 */

class PickupClass implements SetPickup {

	private static final long serialVersionUID = 1L;
	private static final int ZERO = 0;

	GetPark initialPark, finalPark;
	GetUser user;
	GetBike bike;
	int minutes, value, delay;

	public PickupClass(GetPark initialPark, GetUser user, GetBike bike) {
		this.initialPark = initialPark;
		this.finalPark = null;
		this.delay = ZERO;
		this.minutes = ZERO;
		this.value = ZERO;
		this.bike = bike;
		this.user = user;
	}

	@Override
	public GetPark getInitialPark() {
		return initialPark;
	}

	@Override
	public GetPark getFinalPark() {
		return finalPark;
	}

	@Override
	public int getMinutes() {
		return minutes;
	}

	@Override
	public int getDelay() {
		return delay;
	}

	@Override
	public int getValue() {
		return value;
	}

	@Override
	public GetUser getUser() {
		return user;
	}

	@Override
	public GetBike getBike() {
		return bike;
	}

	@Override
	public String getFinalIdPark() {
		return finalPark.getIdPark();
	}

	@Override
	public String getIdUser() {
		return user.getIdUser();
	}

	@Override
	public String getInitialIdPark() {
		return initialPark.getIdPark();
	}

	@Override
	public String getIdBike() {
		return bike.getIdBike();
	}

	@Override
	public int returnValue(int minutes) {
		return value;
	}

	@Override
	public void setPickdownInfo(GetPark park, int minutes) {
		this.finalPark = park;
		this.minutes = minutes;

	}

}
