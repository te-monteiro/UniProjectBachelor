package HealthyLife;

/**
 * 
 * @author Teresa Falcao de Campos Monteiro (52597)
 *         tfd.monteiro@campus.fct.unl.pt
 * @author Ana Filipa Santos Pereira Fernandes da Silva (52787)
 *         afsp.silva@campus.fct.unl.pt
 * 
 *
 */


import dataStructures.Iterator;

interface SetUser extends GetUser {

	/**
	 * Method that returns if the user is moving
	 * 
	 * @return - true if the user is moving
	 */
	boolean isMoving();

	/**
	 * Method that returns if the user has enough money to do a pickup
	 * 
	 * @return - true if the user has money
	 */
	boolean hasMoney();

	/**
	 * Method that adds a pickup to the user
	 * 
	 * @param SetPickup
	 */
	void addPickup(SetPickup pickup);

	/**
	 * Method that adds a pickdown to the user
	 * 
	 * @param minutes
	 *            - int: duration of the pickdown
	 * @param idPark
	 *            - String: id of the park
	 */
	void addPickdown(int minutes, GetPark park);

	/**
	 * Method that sets the balance
	 * 
	 * @param value
	 *            - int: quantity of money that the user wants to add to its account
	 */
	void setBalance(int value);

	/**
	 * Method that checks if the user has done pickups
	 * 
	 * @return - true if the user has pickups
	 */
	boolean hasPickups();

	/**
	 * Method that checks if the first pickup is not done yet
	 * 
	 * @return - true if the first pickup is still moving
	 */
	boolean isFirstPickupMoving();

	/**
	 * Method that returns the Iterator of the pickups
	 * 
	 * @return - Iterator<GetPickup>
	 */
	Iterator<GetPickup> getPickupsIterator();
	
	

}
