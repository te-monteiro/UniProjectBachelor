package HealthyLife;

import HealthyLife.Exceptions.*;

import dataStructures.Iterator;

/**
 * 
 * @author Teresa Falcao de Campos Monteiro (52597)
 *         tfd.monteiro@campus.fct.unl.pt
 * @author Ana Filipa Santos Pereira Fernandes da Silva (52787)
 *         afsp.silva@campus.fct.unl.pt
 * 
 *
 */

interface SetBike extends GetBike {

	/**
	 * Method that returns if the bike is moving
	 * 
	 * @return - true if is moving
	 */
	boolean isMoving();

	/**
	 * Method that adds a pickup to the bike
	 * 
	 * @param pickup
	 *            - SetPickup
	 */
	void addPickup(SetPickup pickup);

	/**
	 * Method that adds a pickdown to the bike
	 * 
	 * @param minutes
	 *            - int: duration of the pickup
	 * @param idPark
	 *            - String: id of the park
	 */
	void addPickdown(int minutes, GetPark park);

	/**
	 * Method that checks if the first pickup is still at movement
	 * 
	 * @return - true if the first is still at movement
	 */
	boolean isFirstPickupMoving();

	/**
	 * Method that returns the id of the park
	 * 
	 * @return idPark - String: id the park
	 */

	String getIdPark();

	/**
	 * Method that returns the plate of the bike
	 * 
	 * @return plate - String: plate of the bike
	 */

	String getPlate();

	/**
	 * Method that checks if the bike has done pickups
	 * 
	 * @return - true if the bike has done pickups
	 */
	boolean hasPickups();

	/**
	 * Method that returns the moving user
	 * 
	 * @return - GetUser
	 */
	GetUser getLastUser() throws NoPickupsException;

	/**
	 * Method that returns the iterator of bikes pickups
	 * 
	 * @return - Iterator <GetPickup>
	 */
	Iterator<GetPickup> getPickupsIterator();

	/**
	 * Method that returns the park in which the bike is parked
	 * 
	 * @return - GetPark
	 */
	GetPark getPark();

}
