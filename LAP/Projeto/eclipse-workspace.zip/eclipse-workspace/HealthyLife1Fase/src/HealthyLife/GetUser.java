package HealthyLife;

import java.io.Serializable;

/**
 * 
 * @author Teresa Falcao de Campos Monteiro (52597)
 *         tfd.monteiro@campus.fct.unl.pt
 * @author Ana Filipa Santos Pereira Fernandes da Silva (52787)
 *         afsp.silva@campus.fct.unl.pt
 * 
 *
 */

public interface GetUser extends Serializable {

	/**
	 * Method that returns the nif of the user
	 * 
	 * @return - String: nif of the user
	 */
	String getNif();

	/**
	 * Method that returns the email of the user
	 * 
	 * @return - String: email of the user
	 */

	String getEmail();

	/**
	 * Method that returns the phone of the user
	 * 
	 * @return - String: phone of the user
	 */

	String getPhone();

	/**
	 * Method that returns the name of the user
	 * 
	 * @return - String: name of the user
	 */
	String getName();

	/**
	 * Method that returns the id of the user
	 * 
	 * @return - String: id of the user
	 */

	String getIdUser();

	/**
	 * Method that returns the address of the user
	 * 
	 * @return - String: address of the user
	 */
	String getAddress();

	/**
	 * Method that returns the balance of the user
	 * 
	 * @return - int: balance of the user
	 */
	int getBalance();

	/**
	 * Method that returns the points of the user
	 * 
	 * @return - int : points of the user
	 */
	int getPoints();

}
