package HealthyLife;

import HealthyLife.Exceptions.*;
import dataStructures.*;

/**
 * 
 * @author Teresa Falcao de Campos Monteiro (52597)
 *         tfd.monteiro@campus.fct.unl.pt
 * @author Ana Filipa Santos Pereira Fernandes da Silva (52787)
 *         afsp.silva@campus.fct.unl.pt
 * 
 *
 */

class BikeClass implements SetBike {

	private static final long serialVersionUID = 1L;

	private String idBike, plate;
	private SetPickup pickup;
	private GetPark park;
	private List<GetPickup> pickdowns;

	public BikeClass(String idBike, GetPark park, String plate) {
		this.idBike = idBike;
		this.park = park;
		this.plate = plate;
		pickdowns = new DoublyLinkedList<GetPickup>();
		pickup = null;
	}

	@Override
	public String getIdBike() {
		return idBike;
	}

	@Override
	public String getIdPark() {
		return park.getIdPark();
	}

	@Override
	public String getPlate() {
		return plate;
	}

	@Override
	public boolean hasPickups() {
		return pickdowns.isEmpty();
	}

	@Override
	public boolean isMoving() {

		if (pickup == null) {
			return false;
		}
		return true;
	}

	@Override
	public void addPickup(SetPickup pickup) {
		this.pickup = pickup;
		park = null;
	}

	@Override
	public void addPickdown(int minutes, GetPark park) {
		pickup.setPickdownInfo(park, minutes);
		pickdowns.addLast(pickup);
		pickup = null;
		this.park = park;

	}

	@Override
	public GetUser getLastUser() throws NoPickupsException {
		if (pickdowns.isEmpty()) {
			throw new NoPickupsException();
		} else {
			return pickdowns.getLast().getUser();

		}
	}

	@Override
	public Iterator<GetPickup> getPickupsIterator() {
		return pickdowns.iterator();
	}

	@Override
	public boolean isFirstPickupMoving() {
		if (pickdowns.isEmpty() && pickup != null) {
			return true;
		}
		return false;
	}

	@Override
	public GetPark getPark() {
		return park;
	}

}
