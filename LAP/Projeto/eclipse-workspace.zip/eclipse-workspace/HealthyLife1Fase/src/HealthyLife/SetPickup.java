package HealthyLife;

/**
 * 
 * @author Teresa Falcao de Campos Monteiro (52597)
 *         tfd.monteiro@campus.fct.unl.pt
 * @author Ana Filipa Santos Pereira Fernandes da Silva (52787)
 *         afsp.silva@campus.fct.unl.pt
 * 
 *
 */

interface SetPickup extends GetPickup {

	/**
	 * Method that gets the initial Park
	 * 
	 * @return GetPark
	 */
	GetPark getInitialPark();

	/**
	 * Method that gets the final Park
	 * 
	 * @return GetPark
	 */
	GetPark getFinalPark();

	/**
	 * Method that gets the bike of the pickup
	 * 
	 * @return GetBike
	 */
	GetBike getBike();

	/**
	 * Method that returns how much the user is obligated to pay
	 * 
	 * @param minutes
	 *            - int: duration of the pickup
	 * @return - how much the user has too pay
	 */
	int returnValue(int minutes);

	/**
	 * Method that updates the information of the pickdown
	 * 
	 * @param park
	 *            - GetPark: final park
	 * @param minutes
	 *            - int: duration of the pickdwon
	 */
	void setPickdownInfo(GetPark park, int minutes);

}
