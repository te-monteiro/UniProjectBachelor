package HealthyLife.Exceptions;

/**
 * 
 * @author Teresa Falcao de Campos Monteiro (52597)
 *         tfd.monteiro@campus.fct.unl.pt
 * @author Ana Filipa Santos Pereira Fernandes da Silva (52787)
 *         afsp.silva@campus.fct.unl.pt
 * 
 *
 */

public class PickupsAlreadyDoneException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
