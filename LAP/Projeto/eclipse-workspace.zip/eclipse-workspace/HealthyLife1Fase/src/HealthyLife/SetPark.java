package HealthyLife;

/**
 * 
 * @author Teresa Falcao de Campos Monteiro (52597)
 *         tfd.monteiro@campus.fct.unl.pt
 * @author Ana Filipa Santos Pereira Fernandes da Silva (52787)
 *         afsp.silva@campus.fct.unl.pt
 * 
 *
 */


interface SetPark extends GetPark {

	/**
	 * Method that adds a bike
	 * 
	 * @param SetBike
	 */
	void addBike(SetBike bike);

	/**
	 * Method that removes a bike
	 */
	void removeBike();

	/**
	 * Method that does certain changes to the park, when a pickup is done. Such as
	 * increasing the number of pickups and removing the bike of the park
	 */
	void pickupChanges();

}
