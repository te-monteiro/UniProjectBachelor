package HealthyLife;

import HealthyLife.Exceptions.*;


import dataStructures.*;

/**
 * 
 * @author Teresa Falcao de Campos Monteiro (52597)
 *         tfd.monteiro@campus.fct.unl.pt
 * @author Ana Filipa Santos Pereira Fernandes da Silva (52787)
 *         afsp.silva@campus.fct.unl.pt
 * 
 *
 */

public class HealthyLifeClass implements HealthyLife {

	private static final long serialVersionUID = 1L;

	private SetUser user;
	private SetPark park;
	private SetBike bike;

	public HealthyLifeClass() {
		this.user = null;
		this.park = null;
		this.bike = null;
	}

	/**
	 * Method that checks if the user already exists
	 * 
	 * @param idUser
	 * @return - true if the user already exists
	 */

	private boolean doesUserExist(String idUser) {
		return user != null && user.getIdUser().equalsIgnoreCase(idUser);
	}

	/**
	 * Checks if the user has done pickups
	 * 
	 * @return - true if the user has done pickups
	 */
	private boolean hasUserDonePickups() {
		return !user.hasPickups();
	}

	/**
	 * Method that checks if the park already exists
	 * 
	 * @param idPark
	 * @return - true if the park already exists
	 */
	private boolean doesParkExist(String idPark) {
		return park != null && park.getIdPark().equalsIgnoreCase(idPark);
	}

	/**
	 * Method that checks if the bike already exists
	 * 
	 * @param idPark
	 * @return - true if the bike already exists
	 */
	private boolean doesBikeExist(String idBike) {
		return bike != null && bike.getIdBike().equalsIgnoreCase(idBike);
	}

	/**
	 * Method that checks if the minutes put as an input are valid
	 * 
	 * @param minutes
	 * @return - true if the minutes are valid
	 */
	private boolean areMinutesValid(int minutes) {
		return minutes > 0;
	}

	/**
	 * Method that checks if the bike is at the park
	 * 
	 * @return - true if the bike is at the park
	 */

	private boolean isBikeAtPark() {
		return bike.getPark() != null;
	}

	/**
	 * Method that checks if have been pickups made in the park
	 * 
	 * @return - true if have been pickups made in the park
	 */
	private boolean hasParkPickups() {
		return park.getNumPickup() > 0;
	}

	@Override
	public void addUser(String idUser, String nif, String email, String phone, String name, String address)
			throws UserAlreadyExistsException {
		if (doesUserExist(idUser)) {
			throw new UserAlreadyExistsException();
		} else {
			user = new UserClass(idUser, nif, email, phone, name, address);
		}

	}

	@Override
	public void removeUser(String idUser) throws NoUserException, PickupsAlreadyDoneException {
		if (!doesUserExist(idUser)) {
			throw new NoUserException();
		} else if (hasUserDonePickups()) {
			throw new PickupsAlreadyDoneException();
		} else {
			user = null;
		}

	}

	@Override
	public GetUser getUser(String idUser) throws NoUserException {
		if (!doesUserExist(idUser)) {
			throw new NoUserException();
		}
		return user;
	}

	@Override
	public void addPark(String idPark, String name, String address) throws ParkAlreadyExistsException {
		if (doesParkExist(idPark)) {
			throw new ParkAlreadyExistsException();
		} else {
			park = new ParkClass(idPark, name, address);

		}
	}

	@Override
	public void addBike(String idBike, String idPark, String plate) throws BikeAlreadyExistsException, NoParkException {
		if (doesBikeExist(idBike)) {
			throw new BikeAlreadyExistsException();
		} else if (!doesParkExist(idPark)) {
			throw new NoParkException();
		} else {
			bike = new BikeClass(idBike, park, plate);
			park.addBike(bike);
		}

	}

	@Override
	public GetPark getPark(String idPark) throws NoParkException {
		if (!doesParkExist(idPark)) {
			throw new NoParkException();
		}
		return park;
	}

	@Override
	public void removeBike(String idBike) throws PickupsAlreadyDoneException, NoBikeException {
		if (!doesBikeExist(idBike)) {
			throw new NoBikeException();
		} else if (!bike.hasPickups()) {
			throw new PickupsAlreadyDoneException();
		} else {
			bike = null;
			park.removeBike();
		}

	}

	@Override
	public void pickup(String idBike, String idUser)
			throws NoUserException, NoBikeException, MovingBikeException, NoMoneyException, MovingUserException {

		if (!doesBikeExist(idBike)) {
			throw new NoBikeException();
		}

		else if (bike.isMoving()) {
			throw new MovingBikeException();
		}

		else if (!doesUserExist(idUser)) {
			throw new NoUserException();
		}

		else if (user.isMoving()) {
			throw new MovingUserException();
		}

		else if (!user.hasMoney()) {
			throw new NoMoneyException();
		}

		else {
			SetPickup pickup = new PickupClass(park, user, bike);
			bike.addPickup(pickup);
			user.addPickup(pickup);
			park.pickupChanges();

		}
	}

	@Override
	public GetUser pickdown(String idBike, String idPark, int minutes)
			throws NoBikeException, BikeStopException, NoParkException, InvalidDataException {
		if (!doesBikeExist(idBike)) {
			throw new NoBikeException();
		} else if (!bike.isMoving()) {
			throw new BikeStopException();
		} else if (!doesParkExist(idPark)) {
			throw new NoParkException();
		} else if (!areMinutesValid(minutes)) {
			throw new InvalidDataException();
		} else {
			user.addPickdown(minutes, park);
			bike.addPickdown(minutes, park);
			park.addBike(bike);
			return bike.getLastUser();
		}
	}

	@Override
	public void chargeUser(String idUser, int value) throws NoUserException, NegativeValueException {
		if (!doesUserExist(idUser)) {
			throw new NoUserException();
		} else if (!areMinutesValid(value)) {
			throw new NegativeValueException();
		} else {

			user.setBalance(value);

		}

	}

	@Override
	public Iterator<GetPickup> getBikePickupsIterator(String idBike)
			throws NoBikeException, NoPickupsException, FirstPickupStillMovingException {

		if (!doesBikeExist(idBike)) {
			throw new NoBikeException();
		} else if (bike.hasPickups()) {
			throw new NoPickupsException();
		} else if (bike.isFirstPickupMoving()) {
			throw new FirstPickupStillMovingException();
		}
		return bike.getPickupsIterator();
	}

	@Override
	public void isBikeAtPark(String idBike, String idPark)
			throws NoBikeException, NoParkException, BikeIsNotAtParkException {
		if (!doesBikeExist(idBike)) {
			throw new NoBikeException();
		} else if (!doesParkExist(idPark)) {
			throw new NoParkException();
		} else if (!isBikeAtPark()) {
			throw new BikeIsNotAtParkException();
		}

	}

	@Override
	public Iterator<GetPickup> getUserPickupsIterator(String idUser)
			throws NoUserException, NoPickupsException, FirstPickupStillMovingException {

		if (!doesUserExist(idUser)) {
			throw new NoUserException();
		} else if (user.hasPickups()) {
			throw new NoPickupsException();
		} else if (user.isFirstPickupMoving()) {
			throw new FirstPickupStillMovingException();
		}
		return user.getPickupsIterator();
	}

	@Override
	public GetPark getParkIfHasPickups() throws NoParkException, NoPickupsException {

		if (park == null) {
			throw new NoParkException();
		}

		else if (!hasParkPickups()) {
			throw new NoPickupsException();
		}
		return park;
	}

}