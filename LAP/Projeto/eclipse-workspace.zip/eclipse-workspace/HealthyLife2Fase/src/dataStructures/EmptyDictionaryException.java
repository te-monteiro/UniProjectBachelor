package dataStructures;

public class EmptyDictionaryException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
