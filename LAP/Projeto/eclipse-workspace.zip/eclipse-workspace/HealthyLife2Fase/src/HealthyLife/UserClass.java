package HealthyLife;

import dataStructures.*;

/**
 * 
 * @author Teresa Falcao de Campos Monteiro (52597)
 *         tfd.monteiro@campus.fct.unl.pt
 * @author Ana Filipa Santos Pereira Fernandes da Silva (52787)
 *         afsp.silva@campus.fct.unl.pt
 * 
 *
 */

class UserClass implements SetUser {

	private static final int INITIAL_BALANCE = 5;
	private static final long serialVersionUID = 1L;
	private String idUser, nif, email, phone, name, address;
	private List<GetPickup> pickdowns;
	private int balance, points;
	private SetPickup pickup;

	public UserClass(String idUser, String nif, String email, String phone, String name, String address) {
		this.idUser = idUser;
		this.nif = nif;
		this.email = email;
		this.phone = phone;
		this.name = name;
		this.address = address;
		this.balance = INITIAL_BALANCE;
		this.points = 0;
		pickup = null;

		pickdowns = new DoublyLinkedList<GetPickup>();
	}

	@Override
	public String getNif() {
		return nif;
	}

	@Override
	public String getEmail() {
		return email;
	}

	@Override
	public String getPhone() {
		return phone;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public String getIdUser() {
		return idUser;
	}

	@Override
	public String getAddress() {
		return address;
	}

	@Override
	public boolean hasPickups() {
		return pickdowns.isEmpty();
	}

	@Override
	public int getBalance() {
		return balance;
	}

	@Override
	public int getPoints() {
		return points;
	}

	@Override
	public boolean isMoving() {
		if (pickup == null) {

			return false;
		}
		return true;
	}

	@Override
	public boolean hasMoney() {
		if (balance < INITIAL_BALANCE)
			return false;
		return true;
	}

	@Override
	public void addPickup(SetPickup pickup) {
		this.pickup = pickup;
	}

	@Override
	public void addPickdown(int minutes, GetPark park) {
		pickup.setPickdownInfo(park, minutes);
		pickdowns.addLast(pickup);
		pickup = null;

	}

	@Override
	public void setBalance(int value) {
		balance += value;
	}

	@Override
	public boolean isFirstPickupMoving() {
		if (pickdowns.isEmpty() && pickup != null) {
			return true;
		}
		return false;
	}

	@Override
	public Iterator<GetPickup> getPickupsIterator() {
		return pickdowns.iterator();
	}

}
