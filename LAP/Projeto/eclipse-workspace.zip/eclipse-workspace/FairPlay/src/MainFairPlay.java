
public class MainFairPlay {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		FairPlay fp = new FairPlay();
		
		System.out.println(fp.isHappy());
		fp.weLost();
		System.out.println(fp.isHappy());
		fp.theyLost();
		System.out.println(fp.isHappy());
		fp.weLost();
		System.out.println(fp.isHappy());
		fp.weDrew();
		System.out.println(fp.isHappy());
		fp.theyDrew();
		System.out.println(fp.isHappy());
		

	}

}
