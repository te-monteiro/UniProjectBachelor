
public class FairPlay {
	//variaveis
	private boolean feliz;
	
	//construtor
	public FairPlay() {
		feliz = true;
		
	}

	public boolean isHappy() {
		return feliz;
	}
	
	public void weWon() {
		feliz = true;
	}
	public void weLost() {
		feliz = false;
	}
	public void weDrew() {
		feliz = false;
	}
	public void theyWon() {
		feliz = false;
	}
	public void theyDrew() {
		feliz = true;
	}
	public void theyLost() {
		feliz = true;
	}
}
