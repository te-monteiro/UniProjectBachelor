#include <string.h> 
#include <stdio.h> 
#include <stdlib.h>


#define ARGVMAX 100
#define LINESIZE 1024

int makeargv(char *s, char* argv[ARGVMAX]) {
  // in: s points a text string with words
  // out: argv[] points to all words in the string s (*s is modified!)
  // pre: argv is predefined as char *argv[ARGVMAX]
  // return: number of words pointed to by the elements in argv (or -1 in case of error) 

  int ntokens;
	
  if ( s==NULL || argv==NULL || ARGVMAX==0) 
    return -1;

  ntokens = 0;
  argv[ntokens]=strtok(s, " \t\n");
  while ( (argv[ntokens]!= NULL) && (ntokens<ARGVMAX) ) {
    ntokens++;
    argv[ntokens]=strtok(NULL, " \t\n"); 
  }
  argv[ntokens] = NULL; // it must terminate with NULL
  return ntokens; 
}


void runcommand(char* argv[]) {
	int cPid;
	int backRun=0;
	for(int i=0; argv[i] != NULL;i++) {
		if(strcmp(argv[i],"&")==0){
			backRun=1; argv[i] = NULL; 
		}
	}	
	switch (cPid=fork()) {
	case -1: perror("fork"); exit(1);
	case 0:	execvp(argv[0],argv);
		exit(0);
	default: if(backRun==1)
		printf("%s %d %s\n","Process",cPid,"is being run in the backround");
		else waitLoop(cPid); // wait for child exit	
	}
}

void waitLoop(int cPid) {
	int status;
	int pid=wait(&status);
	while(pid != cPid) {
		pid=wait(&status); printf("%s %d %s %d\n","Process",pid,"has concluded its execution with status",status);
	}
}

int main() {
  char line[LINESIZE];
  char* av[ARGVMAX];
	
  printf("> "); fflush(stdout); //writes the prompt on the standard output 
  while ( fgets( line, LINESIZE, stdin ) != NULL ) {
  	int tokens = makeargv( line, av);
    if (tokens > 0 ) {
      int i,counter, j = 0;
      while(i != tokens){ 
      	j = i;
      	for(i = j; strcmp(av[i], ";") != 0 && i != tokens;i++){
      	}
      	if(strcmp(av[i], ";") == 0) {
			counter++; av[i] = NULL;
		}
		if(counter == 0)  runcommand( av );
      	if(counter == 1){
      	runcommand(av); runcommand(av+i+1);
        } else if(counter > 1 && i != tokens)
        runcommand(av+i);	
      }
    }
    printf("> "); fflush(stdout);
  }

  return 0;
}

