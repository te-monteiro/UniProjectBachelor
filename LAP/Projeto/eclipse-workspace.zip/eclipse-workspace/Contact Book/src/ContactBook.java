
public class ContactBook {
	private static final int MAX_CONTACTS = 50;
	private int counter;
	private Contact[] contact;
	private int currentContact;

	public ContactBook() {

	}

	private boolean hasNext() {
		return false;

	}

	public Contact next() {
		return contact[currentContact++];
	}

}
