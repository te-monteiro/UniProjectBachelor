
public class Contact {

	private String name;
	private int phone;
	private String email;

	public Contact(String name, int phone, String email) {
		name = "";
		phone = 0;
		email = "";
	}

	private String getEmail() {
		return email;
	}

	private String getName() {
		return name;
	}

	private int getPhone() {
		return phone;
	}

	private void setName(String newName) {
		name = newName;
	}

	private void setPhone(int newPhone) {
		phone = newPhone;
	}

	private void setEmail(String newEmail) {
		email = newEmail;

	}

}
