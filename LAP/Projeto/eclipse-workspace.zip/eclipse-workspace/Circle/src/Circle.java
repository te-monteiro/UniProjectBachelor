
public class Circle {
	private double x, y, Radius;

	public Circle() {
		x = 0.0;
		y = 0.0;
		Radius = 1.0;
	}

	public Circle(double x, double y, double Radius) {
		this.x = x;
		this.y = y;
		this.Radius = Radius;
	}

}
