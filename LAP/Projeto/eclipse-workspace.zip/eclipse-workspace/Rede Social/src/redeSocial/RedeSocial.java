package redeSocial;
public interface RedeSocial {

	int searchIndex(String name); 

	void regista(String name, String email, String status);

	boolean existPerson(String name);

	boolean hasFriend(String amigo1, String amigo2);

	void addFriend(String amigo1, String amigo2);

	Person getPessoas(String name);

	void changeStatus(String name, String status);

	String getStatus(String name);

	boolean hasPeople();

	Iterator listPerson();

	Iterator listAmizade(String name);

}
