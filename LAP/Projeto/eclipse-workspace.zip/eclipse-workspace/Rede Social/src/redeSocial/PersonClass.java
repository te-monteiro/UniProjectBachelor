package redeSocial;
public class PersonClass implements Person {

	private static final int DEFAULT = 50;
	private String name, email, status;
	private Person[] friend;
	private int counter;

	public PersonClass(String name, String email, String status) {
		this.name = name;
		this.email = email;
		this.status = status;
		friend = new Person[DEFAULT];
		counter = 0;

	}

	public int getCounter() {
		return counter;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public String getEmail() {
		return email;
	}

	@Override
	public String getStatus() {
		return status;
	}

	@Override
	public Iterator listFriend() {
		return new IteratorClass(friend, counter);
	}
	
	

	@Override
	public boolean hasFriend(String amigo2) {
		return searchIndex(amigo2) != -1;
	}

	private int searchIndex(String amigo2) {
		int i = 0;
		int result = -1;
		boolean found = false;
		while (i < counter && !found) {
			if (friend[i].getName().equals(amigo2)) {
				found = true;
			} else
				i++;
		}
		if (found)
			result = i;
		return result;
	}

	@Override
	public void addFriend(Person person) {
		if (isFull())
			resize();
		else
			friend[counter++] = person;
	}

	private void resize() {
		Person[] aux = new Person[counter * 2];
		for (int i = 0; i < counter; i++)
			aux[i] = friend[i];

		aux = friend;

	}

	private boolean isFull() {
		boolean found = false;
		if (counter == friend.length)
			found = true;
		return found;
	}

	@Override
	public void changeStatus(String status) {
		this.status = status;
		
	}

	
	

}
