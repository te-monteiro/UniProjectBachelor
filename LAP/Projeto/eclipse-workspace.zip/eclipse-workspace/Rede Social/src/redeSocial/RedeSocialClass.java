package redeSocial;
public class RedeSocialClass implements RedeSocial {

	private static final int DEFAULT = 500;
	private int counter;
	private Person[] pessoas;

	public RedeSocialClass() {
		this.counter = 0;
		this.pessoas = new Person[DEFAULT];

	}

	@Override
	public int searchIndex(String name) {
		int i = 0;
		int result = -1;
		while (i < counter && result == -1) {
			if (pessoas[i].getName().equals(name))
				result = i;
			else
				i++;
		}

		return result;
	}

	@Override
	public void regista(String name, String email, String status) {
		pessoas[counter] = new PersonClass(name, email, status);
		counter++;

	}

	@Override
	public boolean existPerson(String name) {
		boolean exist = false;
		if (this.searchIndex(name) != -1)
			exist = true;
		return exist;
	}

	@Override
	public boolean hasFriend(String amigo1, String amigo2) {
		int f = this.searchIndex(amigo1);
		return (pessoas[f].hasFriend(amigo2));
	}

	@Override
	public void addFriend(String amigo1, String amigo2) {
		int f1 = this.searchIndex(amigo1);
		int f2 = this.searchIndex(amigo2);
		pessoas[f1].addFriend(pessoas[f2]);
		pessoas[f2].addFriend(pessoas[f1]);

	}

	@Override
	public Person getPessoas(String name) {
		int n = this.searchIndex(name);
		return pessoas[n];
	}

	@Override
	public void changeStatus(String name, String status) {
		int n = this.searchIndex(name);
		pessoas[n].changeStatus(status);
		
	}

	@Override
	public String getStatus(String name) {
		int n = this.searchIndex(name);
		return pessoas[n].getStatus();
	}

	@Override
	public boolean hasPeople() {
		boolean result = false;
		if(counter != 0)
			result = true;
		return result;
	}
	
	public Iterator listPerson() {
		return new IteratorClass(pessoas, counter);
	}
	
	public Iterator listAmizade(String name) {
		int n = this.searchIndex(name);
		return pessoas[n].listFriend();
	}

}
