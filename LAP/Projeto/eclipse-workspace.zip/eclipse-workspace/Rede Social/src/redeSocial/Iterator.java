package redeSocial;

/**
 * 
 * @author Teresa
 *
 */
public interface Iterator {

	boolean hasNext();

	Person next();

	void startIterator();

}
