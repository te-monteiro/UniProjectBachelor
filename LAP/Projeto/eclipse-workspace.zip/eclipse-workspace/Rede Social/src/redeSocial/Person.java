package redeSocial;
/**
 * 
 * @author Teresa
 *
 */
public interface Person {

	/**
	 * Metodo que devolve o nome da pessoa
	 * 
	 * @return nome da pessoa
	 */
	String getName();

	/**
	 * Metodo que devolve o email da pessoa
	 * 
	 * @return nome da pessoa
	 */
	String getEmail();

	/**
	 * Metodo que devolve o estado da pessoa
	 * 
	 * @return estado da pessoa
	 */
	String getStatus();

	Iterator listFriend();

	boolean hasFriend(String amigo2);

	void addFriend(Person person);

	void changeStatus(String status);

}
