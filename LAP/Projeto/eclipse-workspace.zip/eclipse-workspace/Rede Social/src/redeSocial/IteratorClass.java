package redeSocial;

/**
 * 
 * @author Teresa
 *
 */
public class IteratorClass implements Iterator {
	
	private Person[] elems;
	private int current, counter;
	
	public IteratorClass(Person[] elems, int counter) {
		this.counter = counter;
		this.elems = elems;
	}

	@Override
	public boolean hasNext() {
		return current < counter;
	}

	@Override
	public Person next() {
		return elems[current++];
	}

	@Override
	public void startIterator() {
		this.current = 0;
	}

}
