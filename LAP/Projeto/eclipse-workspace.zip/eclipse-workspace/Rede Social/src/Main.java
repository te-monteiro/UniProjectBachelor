import java.util.Scanner;

import redeSocial.Iterator;
import redeSocial.Person;
import redeSocial.RedeSocial;
import redeSocial.RedeSocialClass;

public class Main {

	private static final Object SAIR = "SAIR";
	private static final String CONSULTA_PESSOA = "CONSULTAPESSOA";
	private static final String REGISTA = "REGISTA";
	private static final String CONSULTA_AMIZADE = "CONSULTAAMIZADE";
	private static final String AMIGOS = "AMIGOS";
	private static final String CONSULTA_AMIGOS = "CONSULTAAMIGOS";
	private static final String NOVO_ESTADO = "NOVOESTADO";
	private static final String CONSULTA_ESTADO = "CONSULTAESTADO";
	private static final String PESSOAS = "PESSOAS";

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		RedeSocial r = new RedeSocialClass();
		String comm = getCommand(in);

		while (!comm.equals(SAIR)) {
			switch (comm) {
			case CONSULTA_PESSOA:
				consultaPessoa(in, r);
				break;
			case REGISTA:
				regista(in, r);
				break;
			case CONSULTA_AMIZADE:
				consultaAmizade(in, r);
				break;
			case AMIGOS:
				amigos(in, r);
				break;
			case CONSULTA_AMIGOS:
				consultaAmigo(in, r);
				break;
			case NOVO_ESTADO:
				newStatus(in, r);
				break;
			case CONSULTA_ESTADO:
				consultaEstado(in, r);
				break;
			case PESSOAS:
				pessoas(r);
				break;
			default:
				System.out.println("ERRO");
			}
			System.out.println();
			comm = getCommand(in);
		}
		System.out.println("Adeus.");
		System.out.println();
		in.close();
	}

	private static void pessoas(RedeSocial r) {
		if (r.hasPeople()) {
			Iterator it = r.listPerson();
			System.out.println("Lista de pessoas registadas:");
			while (it.hasNext()) {
				Person pessoas = it.next();
				System.out.println(pessoas.getName() + "; " + pessoas.getEmail());
			}
		} else
			System.out.println("Rede Social vazia.");
	}

	private static void consultaEstado(Scanner in, RedeSocial r) {
		String name = in.nextLine();
		if (!r.existPerson(name))
			System.out.println("Sem registo.");
		else {
			System.out.println(r.getStatus(name));
		}
	}

	private static void newStatus(Scanner in, RedeSocial r) {
		String name = in.nextLine();
		String status = in.nextLine();
		if (!r.existPerson(name))
			System.out.println("Sem registo.");
		else {
			r.changeStatus(name, status);
			System.out.println("Estado alterado.");
		}
	}

	private static void consultaAmigo(Scanner in, RedeSocial r) {
		String name = in.nextLine();
		Iterator it = r.listAmizade(name);

		if (!r.existPerson(name))
			System.out.println("Sem registo.");
		else if (!it.hasNext())
			System.out.println("Nao tem amigos registados.");
		else {
			System.out.println("Lista de amigos:");

			while (it.hasNext()) {
				Person pessoa = it.next();
				System.out.println(pessoa.getName() + "; " + pessoa.getEmail());

			}
		}
	}

	private static void amigos(Scanner in, RedeSocial r) {
		String amigo1 = in.nextLine();
		String amigo2 = in.nextLine();
		if (!r.existPerson(amigo1) || !r.existPerson(amigo2)) {
			System.out.println("Sem registo.");
		} else if (r.hasFriend(amigo1, amigo2))
			System.out.println("Amizade existente.");
		else if (amigo1.equals(amigo2))
			System.out.println("Amizade invalida.");
		else {
			r.addFriend(amigo1, amigo2);
			System.out.println("Amizade criada.");
		}

	}

	private static void consultaAmizade(Scanner in, RedeSocial r) {
		String amigo1 = in.nextLine();
		String amigo2 = in.nextLine();
		if (r.existPerson(amigo1) && r.existPerson(amigo2)) {
			if (r.hasFriend(amigo1, amigo2)) {
				System.out.println("Amizade existente.");
			} else {
				System.out.println("Amizade inexistente.");
			}
		} else
			System.out.println("Amizade inexistente.");

	}

	private static void regista(Scanner in, RedeSocial r) {
		String name = in.nextLine();
		String email = in.nextLine();
		String status = in.nextLine();
		if (r.searchIndex(name) != -1)
			System.out.println("Pessoa registada.");
		else {
			r.regista(name, email, status);
			System.out.println("Pessoa registada com sucesso.");
		}
	}

	private static void consultaPessoa(Scanner in, RedeSocial r) {
		String name = in.nextLine();
		if (r.existPerson(name))
			System.out.println("Pessoa registada.");
		else
			System.out.println("Sem registo.");

	}

	private static String getCommand(Scanner in) {
		String input;

		input = in.nextLine().toUpperCase();
		return input;
	}

}
