/**
 * @author Teresa Monteiro 52597
 * @author Tiago Cotovio 52349
 */
package staff;

import java.util.Iterator;

import shows.Show;

public interface Worker {

	/**
	 * Method that returns the name of a worker
	 * 
	 * @return name
	 */
	String getName();

	/**
	 * Method that adds the program to the list of programs in which the worker
	 * participates
	 * 
	 * @param s
	 *            - show to be added
	 */
	void addShow(Show s);

	/**
	 * Method that returns the iterator of the list of programs in which the worker
	 * participates
	 * 
	 * @return iterator
	 */
	Iterator<Show> getShows();
}
