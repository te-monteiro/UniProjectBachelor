/**
 * @author Teresa Monteiro 52597
 * @author Tiago Cotovio 52349
 */
package staff;

import java.util.Iterator;
import java.util.SortedSet;
import java.util.TreeSet;

import comparators.ComparatorByDate;
import shows.Show;

public class WorkerClass implements Worker {

	private String name;
	private SortedSet<Show> shows;

	public WorkerClass(String name) {
		this.name = name;
		shows = new TreeSet<>(new ComparatorByDate());
	}

	public String getName() {
		return name;
	}

	public void addShow(Show s) {
		shows.add(s);
	}

	public Iterator<Show> getShows() {
		return shows.iterator();
	}
}
