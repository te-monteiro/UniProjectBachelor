/**
 * @author Teresa Monteiro 52597
 * @author Tiago Cotovio 52349
 */
package services;

import java.util.Iterator;
import java.util.List;

import accounts.Account;
import exceptions.AccountDoesNotExistException;
import exceptions.AccountSameEmailException;
import exceptions.AlreadyOnException;
import exceptions.MembershipAlreadyExistException;
import exceptions.NoMoreMembershipException;
import exceptions.NoMoreProfileException;
import exceptions.NoProfileExistException;
import exceptions.NoProfileSelectException;
import exceptions.NoSessionOnException;
import exceptions.NoShowFoundException;
import exceptions.OnlySeenShowsException;
import exceptions.ProfileAlreadyExistException;
import exceptions.SessionIsOnException;
import exceptions.ShowAlreadyRatedException;
import exceptions.ShowDoesntExistException;
import exceptions.ShowNotAvailableException;
import exceptions.TooMuchDevicesException;
import exceptions.WrongPasswordException;
import shows.Show;
import staff.Worker;

public interface Netflix {

	/**
	 * Method that add movies
	 */
	void addMovie(String title, String director, int duration, int age, int year, String genre, String[] cast);

	/**
	 * Method that adds the movie the worker has already participated in
	 * 
	 * @param workers
	 * @param s
	 */
	void addParticipatedShow(List<Worker> workers, Show s);

	/**
	 * Method that add series
	 */
	void addSeries(String title, String creator, int nSeason, int nEpisodes, int age, int year, String genre,
			String[] cast);

	/**
	 * Method that register the person who participates in some movie or serie
	 * 
	 * @param name
	 *            - name of the worker
	 * @return worker that was added
	 */
	Worker addWorker(String name);

	/**
	 * Method that returns the object that iterates all shows ordered by name
	 * 
	 * @return iterator of the shows
	 */
	Iterator<Show> listShowsByName();

	/**
	 * Method that create an accounts
	 * 
	 * @param name
	 * @param email
	 * @param password
	 * @param deviceName
	 */
	void addAccount(String name, String email, String password, String deviceName)
			throws SessionIsOnException, AccountSameEmailException;

	/**
	 * Method that add devices to account
	 * 
	 * @param accountEmail
	 * @param deviceName
	 */
	void addDevice(String accountEmail, String deviceName);

	/**
	 * Method that start the session
	 * 
	 * @param email
	 * @param password
	 * @param devices
	 */
	void login(String email, String password, String devices) throws AlreadyOnException, SessionIsOnException,
			AccountDoesNotExistException, WrongPasswordException, WrongPasswordException, TooMuchDevicesException;

	/**
	 * Method that returns the name of an account
	 * 
	 * @param email
	 *            - email of the account
	 * @return name
	 */
	String getAccountName(String email) throws NoSessionOnException;

	/**
	 * Method that disconnect the account that is being use
	 */
	void disconnect() throws NoSessionOnException;

	/**
	 * Method that returns the account is on
	 * 
	 * @return account which is on
	 */
	Account getLoggedAccount();

	/**
	 * Method that ends the session but keeping the device with access to the
	 * service
	 */
	void logout() throws NoSessionOnException;

	/**
	 * Method that checks which membership is it
	 * 
	 * @return membership
	 */
	String membership() throws NoSessionOnException;

	/**
	 * Method that allows to change membership
	 * 
	 * @param newMembership
	 */
	void changeMembership(String newMembership)
			throws NoSessionOnException, MembershipAlreadyExistException, NoMoreMembershipException;

	/**
	 * Method that add normal profile
	 * 
	 * @param profileName
	 * @throws NoSessionOnException
	 * @throws ProfileAlreadyExistException
	 * @throws NoMoreProfileException
	 */
	void addProfile(String profileName)
			throws NoSessionOnException, ProfileAlreadyExistException, NoMoreProfileException;

	/**
	 * Method that add children profile
	 * 
	 * @param profileName
	 * @throws NoSessionOnException
	 * @throws ProfileAlreadyExistException
	 * @throws NoMoreProfileException
	 */
	void addProfile(String profileName, int age)
			throws NoSessionOnException, ProfileAlreadyExistException, NoMoreProfileException;

	/**
	 * Method that select a profile from the account
	 * 
	 * @param profileName
	 *            - name of the profile to be selected
	 */
	void select(String profileName) throws NoSessionOnException, NoProfileExistException;

	/**
	 * Method that add the show to the recently viewed shows of the online profile
	 * 
	 * @param name
	 * @throws NoSessionOnException
	 * @throws NoProfileSelectException
	 * @throws ShowDoesntExistException
	 * @throws ShowNotAvailableException
	 */
	void watch(String name)
			throws NoSessionOnException, NoProfileSelectException, ShowDoesntExistException, ShowNotAvailableException;

	/**
	 * Method that rates a show
	 * 
	 * @param title
	 * @param rate
	 * @throws NoSessionOnException
	 * @throws NoProfileSelectException
	 * @throws ShowDoesntExistException
	 * @throws OnlySeenShowsException
	 * @throws ShowAlreadyRatedException
	 */
	void rate(String title, int rate) throws NoSessionOnException, NoProfileSelectException, ShowDoesntExistException,
			OnlySeenShowsException, ShowAlreadyRatedException;

	/**
	 * Method that lists all the movies and series by genre in alphabetical order
	 * 
	 * @param genre
	 *            - genre to be searched
	 * @return all movies and series by genre
	 * @throws NoSessionOnException
	 * @throws NoProfileSelectException
	 * @throws NoShowFoundException
	 */
	Iterator<Show> getShowsByGenre(String genre)
			throws NoSessionOnException, NoProfileSelectException, NoShowFoundException;

	/**
	 * Method that lists all the shows in which the worker with name
	 * <code>name</code> participates
	 * 
	 * @param name
	 *            - name to be searched
	 * @return all the shows in which the worker with name
	 * @throws NoSessionOnException
	 * @throws NoProfileSelectException
	 * @throws NoShowFoundException
	 */
	Iterator<Show> getShowsByName(String name)
			throws NoSessionOnException, NoProfileSelectException, NoShowFoundException;

	/**
	 * Method that lists the television series with a rating equal to or greater than the given value
	 * @param rate
	 * @return the television series with a rating equal to or greater than the given value
	 * @throws NoSessionOnException
	 * @throws NoProfileSelectException
	 * @throws NoShowFoundException
	 */
	Iterator<Show> getShowsByRate(int rate) throws NoSessionOnException, NoProfileSelectException, NoShowFoundException;
}
