/**
 * @author Teresa Monteiro 52597
 * @author Tiago Cotovio 52349
 */
package profiles;

import java.util.List;

import shows.Show;

public interface Profile {

	static final int MAX_LAST_SHOWS = 10;

	/**
	 * Method that returns the name of the owner of the profile
	 * 
	 * @return name
	 */
	String getName();

	/**
	 * Method that turns profile on
	 */
	void turnOn();

	/**
	 * Method that turns profile off
	 */
	void turnOff();

	/**
	 * Method that verifies if the profile is on
	 * 
	 * @return true - if profile is on
	 */
	boolean isOn();
	
	/**
	 * Method that adds the show to the recently seen shows array
	 * 
	 * @param s
	 *            - seen show
	 */
	void watch(Show s);

	/**
	 * Method that verifies if the show was recently seen
	 * 
	 * @param s
	 *            - show to be verified
	 * @return true if the show was recently seen
	 */
	boolean wasRecentlySeen(Show s);

	/**
	 * Method that verifies if the profile has rated show s
	 * 
	 * @param s
	 *            - show to be verified
	 * @return true if the profile has already rated the show
	 */
	boolean hasRated(Show s);

	/**
	 * Method that rates a show
	 * 
	 * @param s
	 *            - show to be rated
	 * @param rate
	 *            - rate to give to the show
	 */
	void rate(Show s, int rate);

	/**
	 * Method that returns the list of recently seen shows
	 * 
	 * @return list of seen shows
	 */
	List<Show> getSeenShows();

	/**
	 * Method that returns the list of rated shows
	 * 
	 * @return list of rated shows
	 */
	List<Show> getRatedShows();
	/**
	 * Method that will give the rate of a specific movie
	 * @param title
	 * @return movie rate
	 */
	int getGivenRate(String title);
}
