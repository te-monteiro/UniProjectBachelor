/**
 * @author Teresa Monteiro 52597
 * @author Tiago Cotovio 52349
 */
package profiles;

public class NormalClass extends AbstractProfile implements Normal {

	public NormalClass(String name) {
		super(name);
	}

}
