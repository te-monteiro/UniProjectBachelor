/**
 * @author Teresa Monteiro 52597
 * @author Tiago Cotovio 52349
 */
package profiles;

public class ChildClass extends AbstractProfile implements Child {

	private int age;

	public ChildClass(String name, int age) {
		super(name);
		this.age = age;
	}

	public int getAge() {
		return age;
	}

}
