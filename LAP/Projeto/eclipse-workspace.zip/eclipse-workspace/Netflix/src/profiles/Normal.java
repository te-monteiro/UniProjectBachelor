/**
 * @author Teresa Monteiro 52597
 * @author Tiago Cotovio 52349
 */
package profiles;

public interface Normal extends Profile{

}
