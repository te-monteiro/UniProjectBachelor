/**
 * @author Teresa Monteiro 52597
 * @author Tiago Cotovio 52349
 */
package shows;

public interface Movie extends Show {

	/**
	 * Method that returns director
	 * 
	 * @return director
	 */
	String getDirector();

	/**
	 * Method that returns duration
	 * 
	 * @return duration
	 */
	int getDuration();

}
