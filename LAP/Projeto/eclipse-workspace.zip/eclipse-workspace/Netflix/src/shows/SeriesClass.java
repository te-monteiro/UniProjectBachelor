/**
 * @author Teresa Monteiro 52597
 * @author Tiago Cotovio 52349
 */
package shows;

import java.util.List;
import staff.Worker;

public class SeriesClass extends AbstractShow implements Series {
	private String creator;
	private int nSeasons, nEpisodes;

	public SeriesClass(String title, String creator, int nSeasons, int nEpisodes, int age, int year, String genre,
			List<Worker> cast) {
		super(title, age, year, genre, cast);
		this.creator = creator;
		this.nSeasons = nSeasons;
		this.nEpisodes = nEpisodes;
	}

	@Override
	public String getCreator() {
		return creator;
	}

	@Override
	public int getNSeaons() {
		return nSeasons;
	}

	@Override
	public int getNEpisodes() {
		return nEpisodes;
	}

}
