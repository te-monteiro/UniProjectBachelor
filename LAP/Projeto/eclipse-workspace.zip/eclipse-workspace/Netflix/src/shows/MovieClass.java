/**
 * @author Teresa Monteiro 52597
 * @author Tiago Cotovio 52349
 */
package shows;

import java.util.List;

import staff.Worker;

public class MovieClass extends AbstractShow implements Movie {
	private String director;
	private int duration;

	public MovieClass(String title, String director, int duration, int age, int year, String genre, List<Worker> cast) {
		super(title, age, year, genre, cast);
		this.director = director;
		this.duration = duration;
	}

	@Override
	public String getDirector() {
		return director;
	}

	@Override
	public int getDuration() {
		return duration;
	}

}
