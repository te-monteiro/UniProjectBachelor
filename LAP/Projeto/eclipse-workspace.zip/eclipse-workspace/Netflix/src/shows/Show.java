/**
 * @author Teresa Monteiro 52597
 * @author Tiago Cotovio 52349
 */
package shows;

import java.util.List;

import staff.Worker;

public interface Show {

	/**
	 * Method that returns title of the show
	 * 
	 * @return title
	 */
	String getTitle();

	/**
	 * Method that returns age rating of a show
	 * 
	 * @return age
	 */
	int getAge();

	/**
	 * Method that returns release year of the show
	 * 
	 * @return year
	 */
	int getYear();

	/**
	 * Method that returns genre of the show
	 * 
	 * @return genre
	 */
	String getGenre();

	/**
	 * Method that returns cast of the show
	 * 
	 * @return cast
	 */
	List<Worker> getCast();

	/**
	 * Method that rates a program
	 * 
	 * @param rate
	 *            - rate to be given to the show
	 */
	void rate(int rate);

	/**
	 * Method that returns the rate of the show
	 * 
	 * @return the average rate of the show
	 */
	double getRate();

}
