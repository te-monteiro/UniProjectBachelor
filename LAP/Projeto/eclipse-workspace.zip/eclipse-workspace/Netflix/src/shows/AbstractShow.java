/**
 * @author Teresa Monteiro 52597
 * @author Tiago Cotovio 52349
 */
package shows;

import java.util.List;

import staff.Worker;

public abstract class AbstractShow implements Show {

	private String title;
	private int age;
	private int year;
	private String genre;
	private List<Worker> cast;
	private int rates, nRates;

	public AbstractShow(String title, int age, int year, String genre, List<Worker> cast) {
		this.title = title;
		this.age = age;
		this.year = year;
		this.genre = genre;
		this.cast = cast;
		rates = 0;
		nRates = 0;

	}

	@Override
	public String getTitle() {
		return title;
	}

	@Override
	public int getAge() {
		return age;
	}

	@Override
	public int getYear() {
		return year;
	}

	@Override
	public String getGenre() {
		return genre;
	}

	@Override
	public List<Worker> getCast() {
		return cast;
	}

	public void rate(int rate) {
		this.rates += rate;
		nRates++;
	}

	public double getRate() {
		if (nRates == 0) {
			return 0;
		} else {
			Double d = (double) rates / nRates;
			Double d1 = (double) Math.round(d * 10d) / 10d;
			return d1;
		}
	}

}
