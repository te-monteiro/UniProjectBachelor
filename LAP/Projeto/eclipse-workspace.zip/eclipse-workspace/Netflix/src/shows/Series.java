/**
 * @author Teresa Monteiro 52597
 * @author Tiago Cotovio 52349
 */
package shows;

public interface Series extends Show {


	/**
	 * Method that returns creator
	 * 
	 * @return creator
	 */
	String getCreator();

	/**
	 * Method that returns number of seasons
	 * 
	 * @return nSeasons
	 */
	int getNSeaons();

	/**
	 * Method that returns number of episodes
	 * 
	 * @return nEpisodes
	 */
	int getNEpisodes();

	
}
