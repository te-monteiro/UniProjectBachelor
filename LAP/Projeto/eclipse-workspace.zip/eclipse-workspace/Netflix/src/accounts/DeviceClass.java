package accounts;

public class DeviceClass implements Device {

	private String name;
	private boolean beingUsed;

	public DeviceClass(String name) {
		this.name = name;
		beingUsed = false;
	}

	public String getName() {
		return name;
	}

	public void use() {
		beingUsed = true;
	}

	public void turnOff() {
		beingUsed = false;
	}

	public boolean isBeingUsed() {
		return beingUsed;
	}
}
