package accounts;

public interface Standard extends Account {

	static final int MAX_PROFILES = 5;
	static final int MAX_DEVICES = 2;

	/**
	 * Method that verifies if there is too much devices logged into an account
	 * 
	 * @return true if there is too much devices
	 */
	boolean tooMuchDevices();
}
