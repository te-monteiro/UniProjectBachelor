package accounts;

import java.util.ArrayList;
import java.util.List;

import profiles.Profile;

public class PremiumClass extends StandardClass implements Premium {

	private List<Device> devices;
	private List<Profile> profiles;

	public PremiumClass(String name, String email, String password) {
		super(name, email, password);
		devices = new ArrayList<>(Premium.MAX_DEVICES);
		profiles = new ArrayList<>(Premium.MAX_PROFILES);
	}

	public PremiumClass(Account a) {
		super(a);
		devices = a.getDevices();
		profiles = a.getProfiles();
	}

	public boolean tooMuchDevices() {
		return devices.size() == Premium.MAX_DEVICES;
	}

	public boolean tooMuchProfiles() {
		return profiles.size() == Premium.MAX_PROFILES;
	}
}
