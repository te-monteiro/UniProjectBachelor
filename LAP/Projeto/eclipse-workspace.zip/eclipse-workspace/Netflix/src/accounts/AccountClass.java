package accounts;

import java.util.ArrayList;
import java.util.List;

import profiles.Profile;

public class AccountClass implements Account {

	private String name;
	private String email;
	private String password;
	private List<Device> devices;
	private List<Profile> profiles;
	private boolean isOn;

	public AccountClass(String name, String email, String password) {
		this.name = name;
		this.email = email;
		this.password = password;
		devices = new ArrayList<>(MAX_DEVICES);
		profiles = new ArrayList<>(MAX_PROFILES);
		isOn = false;
	}

	public AccountClass(Account a) {
		name = a.getName();
		email = a.getEmail();
		password = a.getPassword();
		devices = a.getDevices();
		profiles = a.getProfiles();
		isOn = a.isOn();
	}

	public String getName() {
		return name;
	}

	public String getEmail() {
		return email;
	}

	public String getPassword() {
		return password;
	}

	public List<Device> getDevices() {
		return devices;
	}

	public List<Profile> getProfiles() {
		return profiles;
	}

	public void addDevice(Device d) {
		if (this.getUsedDevice() != null)
			turnOffDevices();
		devices.add(d);
		d.use();
		isOn = true;
	}

	public void addProfile(Profile p) {
		this.turnOffProfiles();
		profiles.add(p);
		p.turnOn();
	}

	public void selectProfile(String profileName) {
		this.turnOffProfiles();
		for (int i = 0; i < profiles.size(); i++) {
			if (profiles.get(i).getName().equals(profileName)) {
				profiles.get(i).turnOn();
			}
		}
	}

	private void turnOffDevices() {
		for (int i = 0; i < devices.size(); i++) {
			if (devices.get(i).isBeingUsed())
				devices.get(i).turnOff();
		}
	}

	private void turnOffProfiles() {
		for (int i = 0; i < profiles.size(); i++) {
			if (profiles.get(i).isOn())
				profiles.get(i).turnOff();
		}
	}

	public void turnDeviceOn(String device) {
		isOn = true;
		for (int i = 0; i < devices.size(); i++) {
			if (devices.get(i).getName().equals(device)) {
				devices.get(i).use();
				return;
			}
		}
	}

	public void turnDeviceOff() {
		isOn = false;
		this.removeDevice();
	}

	public boolean isOn() {
		return isOn;
	}

	public Device getUsedDevice() {
		for (int i = 0; i < devices.size(); i++) {
			if (devices.get(i).isBeingUsed())
				return devices.get(i);
		}
		return null;
	}

	public Profile getUsedProfile() {
		for (int i = 0; i < profiles.size(); i++) {
			if (profiles.get(i).isOn())
				return profiles.get(i);
		}
		return null;
	}

	public boolean tooMuchDevices() {
		return devices.size() == Account.MAX_DEVICES;
	}

	public boolean tooMuchProfiles() {
		return profiles.size() == Account.MAX_PROFILES;
	}

	private void removeDevice() {
		for (int i = 0; i < devices.size(); i++) {
			if (devices.get(i).isBeingUsed()) {
				devices.remove(i);
				return;
			}
		}
	}

	public void logout() {
		isOn = false;
		this.getUsedProfile().turnOff();
	}

	public boolean thereIsDevice(String name) {
		for (int i = 0; i < devices.size(); i++) {
			if (devices.get(i).getName().equals(name))
				return true;
		}
		return false;
	}

	public boolean thereIsProfile(String name) {
		for (int i = 0; i < profiles.size(); i++) {
			if (profiles.get(i).getName().equals(name))
				return true;
		}
		return false;
	}
}
