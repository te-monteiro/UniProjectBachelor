package accounts;

import java.util.ArrayList;
import java.util.List;

import profiles.Profile;

public class StandardClass extends AccountClass implements Standard {

	private List<Device> devices;
	private List<Profile> profiles;

	public StandardClass(String name, String email, String password) {
		super(name, email, password);
		devices = new ArrayList<>(Standard.MAX_DEVICES);
		profiles = new ArrayList<>(Standard.MAX_PROFILES);
	}

	public StandardClass(Account a) {
		super(a);
		devices = a.getDevices();
		profiles = a.getProfiles();
	}

	public boolean tooMuchDevices() {
		return devices.size() == Standard.MAX_DEVICES;
	}

	public boolean tooMuchProfiles() {
		return profiles.size() == Standard.MAX_PROFILES;
	}

}
