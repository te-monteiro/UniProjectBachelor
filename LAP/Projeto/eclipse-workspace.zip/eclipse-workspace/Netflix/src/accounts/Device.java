package accounts;

public interface Device {

	/**
	 * Method that returns the name of the device
	 * 
	 * @return name
	 */
	String getName();
	
	/**
	 * Method that say which device is being use
	 */
	void use();
	
	/**
	 * Method that remove which device is being use
	 */
	void turnOff();
	
	/**
	 * Method that check if the device is being use or not
	 * @return
	 */
	boolean isBeingUsed();
}
