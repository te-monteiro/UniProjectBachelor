package comparators;

import java.util.Comparator;

import shows.Show;

public class ComparatorByRate implements Comparator<Show> {

	public int compare(Show s1, Show s2) {
		if (s2.getRate() > s1.getRate()) {
			return 1;
		} else if (s1.getRate() > s2.getRate())
			return -1;
		return s1.getTitle().compareTo(s2.getTitle());
	}

}
