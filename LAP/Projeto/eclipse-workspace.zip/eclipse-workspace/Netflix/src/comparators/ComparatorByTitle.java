package comparators;

import java.util.Comparator;

import shows.Show;

public class ComparatorByTitle implements Comparator<Show> {

	public int compare(Show s1, Show s2) {
		return s1.getTitle().compareTo(s2.getTitle());
	}

}
