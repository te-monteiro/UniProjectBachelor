package comparators;

import java.util.Comparator;
import shows.Show;

public class ComparatorByDate implements Comparator<Show> {

	public int compare(Show s1, Show s2) {
		int year1 = s1.getYear();
		int year2 = s2.getYear();
		if (year2 - year1 > 0)
			return -1;
		else if (year1 - year2 > 0)
			return 1;
		else {
			return s1.getTitle().compareTo(s2.getTitle());
		}
	}
}
