package exceptions;

public class NoShowFoundException extends RuntimeException {
	public NoShowFoundException() {
		super();
	}
}
