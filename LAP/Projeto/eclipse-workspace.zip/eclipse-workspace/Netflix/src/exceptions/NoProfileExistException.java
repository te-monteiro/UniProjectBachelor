package exceptions;

@SuppressWarnings("serial")
public class NoProfileExistException extends RuntimeException {

	public NoProfileExistException() {
		super();
	}

}
