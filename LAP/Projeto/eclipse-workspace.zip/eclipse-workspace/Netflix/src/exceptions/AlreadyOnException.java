package exceptions;

@SuppressWarnings("serial")
public class AlreadyOnException extends RuntimeException {

	public AlreadyOnException() {
		super();
	}
}
