package exceptions;

public class ShowAlreadyRatedException extends RuntimeException {

	public ShowAlreadyRatedException() {
		super();
	}
}
