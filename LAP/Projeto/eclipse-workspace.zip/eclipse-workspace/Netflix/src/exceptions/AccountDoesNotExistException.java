package exceptions;

@SuppressWarnings("serial")
public class AccountDoesNotExistException extends RuntimeException {

	public AccountDoesNotExistException() {
		super();
	}

}
