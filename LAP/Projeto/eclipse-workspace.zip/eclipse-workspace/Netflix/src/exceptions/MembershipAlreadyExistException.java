package exceptions;

@SuppressWarnings("serial")
public class MembershipAlreadyExistException extends RuntimeException {
	
	public MembershipAlreadyExistException() {
		super();
	}

}
