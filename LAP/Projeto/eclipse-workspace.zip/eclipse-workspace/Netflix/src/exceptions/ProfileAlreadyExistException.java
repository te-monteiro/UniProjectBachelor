package exceptions;

public class ProfileAlreadyExistException extends RuntimeException {

	public ProfileAlreadyExistException() {
		super();
	}
}
