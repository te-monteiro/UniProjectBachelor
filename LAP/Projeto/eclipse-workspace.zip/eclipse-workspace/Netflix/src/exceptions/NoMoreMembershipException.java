package exceptions;

@SuppressWarnings("serial")
public class NoMoreMembershipException extends RuntimeException {
	
	public NoMoreMembershipException() {
		super();
	}

}
