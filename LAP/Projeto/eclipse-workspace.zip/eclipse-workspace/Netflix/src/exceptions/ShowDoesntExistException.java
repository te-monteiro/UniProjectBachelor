package exceptions;

public class ShowDoesntExistException extends RuntimeException {
	public ShowDoesntExistException() {
		super();
	}
}
