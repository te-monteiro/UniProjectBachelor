package exceptions;

@SuppressWarnings("serial")
public class WrongPasswordException extends RuntimeException{
	
	public WrongPasswordException() {
		super();
	}

}
