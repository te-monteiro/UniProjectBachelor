package exceptions;

@SuppressWarnings("serial")
public class SessionIsOnException extends RuntimeException {

	public SessionIsOnException() {
		super();
	}
}
