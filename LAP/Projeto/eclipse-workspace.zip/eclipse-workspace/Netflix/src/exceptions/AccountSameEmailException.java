package exceptions;

@SuppressWarnings("serial")
public class AccountSameEmailException extends RuntimeException {

	public AccountSameEmailException() {
		super();
	}
}
