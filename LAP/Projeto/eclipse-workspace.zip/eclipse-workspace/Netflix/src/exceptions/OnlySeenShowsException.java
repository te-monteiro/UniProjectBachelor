package exceptions;

public class OnlySeenShowsException extends RuntimeException {

	public OnlySeenShowsException() {
		super();
	}
}
