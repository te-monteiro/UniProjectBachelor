package exceptions;

public class NoMoreProfileException extends RuntimeException {
	public NoMoreProfileException() {
		super();
	}

}
