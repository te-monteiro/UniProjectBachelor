package exceptions;

public class ShowNotAvailableException extends RuntimeException {

	public ShowNotAvailableException() {
		super();
	}

}
