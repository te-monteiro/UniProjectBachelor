package exceptions;

@SuppressWarnings("serial")
public class NoSessionOnException extends RuntimeException {
	
	public NoSessionOnException() {
		super();
	}

}
