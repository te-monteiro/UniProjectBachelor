package exceptions;

@SuppressWarnings("serial")
public class TooMuchDevicesException extends RuntimeException {

	public TooMuchDevicesException() {
		super();
	}
}
