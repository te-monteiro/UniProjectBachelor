package exceptions;

public class NoProfileSelectException extends RuntimeException {
	public NoProfileSelectException() {
		super();
	}
}
