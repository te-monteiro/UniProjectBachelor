
/**
 * @author Teresa Monteiro 52597
 * @author Tiago Cotovio 52349
 */

import java.util.Iterator;
import java.util.Scanner;

import accounts.Account;
import accounts.Device;
import exceptions.AccountDoesNotExistException;
import exceptions.AccountSameEmailException;
import exceptions.AlreadyOnException;
import exceptions.MembershipAlreadyExistException;
import exceptions.NoMoreMembershipException;
import exceptions.NoMoreProfileException;
import exceptions.NoProfileExistException;
import exceptions.NoProfileSelectException;
import exceptions.NoSessionOnException;
import exceptions.NoShowFoundException;
import exceptions.OnlySeenShowsException;
import exceptions.ProfileAlreadyExistException;
import exceptions.SessionIsOnException;
import exceptions.ShowAlreadyRatedException;
import exceptions.ShowDoesntExistException;
import exceptions.ShowNotAvailableException;
import exceptions.TooMuchDevicesException;
import exceptions.WrongPasswordException;
import profiles.Child;
import profiles.Profile;
import services.Netflix;
import services.NetflixClass;
import shows.Movie;
import shows.Series;
import shows.Show;

public class Main {

	private static final String NO_SHOW_FOUND = "No show found.";
	private static final String NO_PROFILES_DEFINED = "No profiles defined.";
	// Error messages
	private static final String LAST_CAST_FORMAT = "%s.\n";
	private static final String CAST_FORMAT = "%s; ";
	private static final String SERIES_FORMAT = "%s; %s; %d; %d; %d+; %d; %s; ";
	private static final String MOVIE_FORMAT = "%s; %s; %d; %d+; %d; %s; ";
	private static final String DATABASE_WAS_UPDATED = "Database was updated:";
	private static final String NOT_POSSIBLE_TO_CONNECT_MORE_DEVICES = "Not possible to connect more devices.";
	private static final String WRONG_PASSWORD = "Wrong password.";
	private static final String ACCOUNT_DOES_NOT_EXIST = "Account does not exist.";
	private static final String ANOTHER_CLIENT_IS_LOGGED_IN2 = "Another client is logged in.";
	private static final String CLIENT_ALREADY_LOGGED_IN = "Client already logged in.";
	private static final String GOODBYE_WAS_DISCONNECTED = "Goodbye %s (%s was disconnected).\n";
	private static final String GOODBYE_STILL_CONNECTED = "Goodbye %s (%s still connected).\n";
	private static final String CANNOT_DOWNGRADE_MEMBERSHIP = "Cannot downgrade membership plan at the moment.";
	private static final String NO_MEMBERSHIP_PLAN_CHANGE = "No membership plan change.";
	private static final String MEMBERSHIP_CHANGED = "Membership plan was changed from %s to %s.\n";
	private static final String NOT_POSSIBLE_TO_ADD_MORE_PROFILES = "Not possible to add more profiles.";
	private static final String THERE_IS_ALREADY_A_PROFILE = "There is already a profile %s.\n";
	private static final String NEW_PROFILE_ADDED = "New profile added.";
	private static final String CHILDREN = "CHILDREN";
	private static final String PROFILE_DOES_NOT_EXIST = "Profile does not exist.";
	private static final String WELCOME_NAME = "Welcome %s.\n";
	private static final String SHOW_NOT_AVAILABLE = "Show not available.";
	private static final String LOADING = "Loading %s...\n";
	private static final String SHOW_ALREADY_RATED = "Show already rated.";
	private static final String RECENTLY_SEEN_SHOWS = "Can only rate recently seen shows.";
	private static final String SHOW_DOES_NOT_EXIST = "Show does not exist.";
	private static final String NO_PROFILE_IS_SELECTED = "No profile is selected.";
	private static final String NO_LOGGED_IN = "No client is logged in.";
	private static final String THANK_YOU_FOR_RATING = "Thank you for rating %s.\n";
	private static final String SAME_EMAIL = "There is another account with email %s.\n";
	// messages
	private static final String ANOTHER_CLIENT_IS_LOGGED_IN = "Another client is logged in.";
	private static final String WELCOME = "Welcome %s (%s).\n";
	// Commands
	private static final String SEARCH_BY_RATE = "searchbyrate";
	private static final String SEARCH_BY_NAME = "searchbyname";
	private static final String SEARCH_BY_GENRE = "searchbygenre";
	private static final String INFO_ACCOUNT = "infoaccount";
	private static final String RATE = "rate";
	private static final String WATCH = "watch";
	private static final String SELECT = "select";
	private static final String PROFILE = "profile";
	private static final String MEMBERSHIP = "membership";
	private static final String LOGOUT = "logout";
	private static final String DISCONNECT = "disconnect";
	private static final String LOGIN = "login";
	private static final String UPLOAD = "upload";
	private static final String REGISTER = "register";
	private static final String EXIT = "exit";
	private static final String UNKNOWN = "unknow command.";

	// Variable messages
	private static final String GOODBYE = "Exiting...";

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);

		Netflix n = new NetflixClass();

		String comm = getCommand(in);

		while (!comm.equals(EXIT)) {
			switch (comm) {
			case UPLOAD:
				upload(in, n);
				break;
			case REGISTER:
				register(in, n);
				break;
			case LOGIN:
				login(in, n);
				break;
			case DISCONNECT:
				disconnect(n);
				break;
			case LOGOUT:
				logout(n);
				break;
			case MEMBERSHIP:
				changeMembership(in, n);
				break;
			case PROFILE:
				addProfile(in, n);
				break;
			case SELECT:
				select(in, n);
				break;
			case WATCH:
				watch(in, n);
				break;
			case RATE:
				rate(in, n);
				break;
			case INFO_ACCOUNT:
				infoAccount(n);
				break;
			case SEARCH_BY_GENRE:
				searchByGenre(in, n);
				break;
			case SEARCH_BY_NAME:
				searchByName(in, n);
				break;
			case SEARCH_BY_RATE:
				try {
					int rate = in.nextInt();
					in.nextLine();
					Iterator<Show> it = n.getShowsByRate(rate);
					while (it.hasNext()) {
						Show s = it.next();
						if (s instanceof Movie) {
							System.out.printf("%s; %s; %d; %d+; %d; %s; ", s.getTitle(), ((Movie) s).getDirector(),
									((Movie) s).getDuration(), s.getAge(), s.getYear(), s.getGenre());
						} else if (s instanceof Series) {
							System.out.printf("%s; %s; %d; %d; %d+; %d; %s; ", s.getTitle(), ((Series) s).getCreator(),
									((Series) s).getNSeaons(), ((Series) s).getNEpisodes(), s.getAge(), s.getYear(),
									s.getGenre());
						}
						for (int i = 0; i < s.getCast().size(); i++) {
							if (i == s.getCast().size() - 1)
								System.out.printf("%s. ", s.getCast().get(i).getName());
							else
								System.out.printf("%s; ", s.getCast().get(i).getName());
						}
						System.out.printf("[%s]\n", s.getRate());
					}
				} catch (NoSessionOnException except) {
					System.out.println(NO_LOGGED_IN);
				} catch (NoProfileSelectException except) {
					System.out.println(NO_PROFILE_IS_SELECTED);
				} catch (NoShowFoundException except) {
					System.out.println(NO_SHOW_FOUND);
				}
				break;
			default:
				System.out.println(UNKNOWN);
			}
			System.out.println();
			comm = getCommand(in);
		}
		System.out.println(GOODBYE);
		in.close();

	}

	private static void searchByName(Scanner in, Netflix n) {
		try {
			String name = in.nextLine();
			Iterator<Show> it = n.getShowsByName(name);
			while (it.hasNext()) {
				Show s = it.next();
				if (s instanceof Movie) {
					System.out.printf("%s; %s; %d; %d+; %d; %s; ", s.getTitle(), ((Movie) s).getDirector(),
							((Movie) s).getDuration(), s.getAge(), s.getYear(), s.getGenre());
				} else if (s instanceof Series) {
					System.out.printf("%s; %s; %d; %d; %d+; %d; %s; ", s.getTitle(), ((Series) s).getCreator(),
							((Series) s).getNSeaons(), ((Series) s).getNEpisodes(), s.getAge(), s.getYear(),
							s.getGenre());
				}
				for (int i = 0; i < s.getCast().size(); i++) {
					if (i == s.getCast().size() - 1)
						System.out.printf("%s.\n", s.getCast().get(i).getName());
					else
						System.out.printf("%s; ", s.getCast().get(i).getName());
				}
			}
		} catch (NoSessionOnException except) {
			System.out.println(NO_LOGGED_IN);
		} catch (NoProfileSelectException except) {
			System.out.println(NO_PROFILE_IS_SELECTED);
		} catch (NoShowFoundException except) {
			System.out.println(NO_SHOW_FOUND);
		}
	}

	private static void searchByGenre(Scanner in, Netflix n) {
		try {
			String genre = in.nextLine();
			Iterator<Show> it = n.getShowsByGenre(genre);
			while (it.hasNext()) {
				Show s = it.next();
				if (s instanceof Movie) {
					System.out.printf("%s; %s; %d; %d+; %d; %s; ", s.getTitle(), ((Movie) s).getDirector(),
							((Movie) s).getDuration(), s.getAge(), s.getYear(), s.getGenre());
				} else if (s instanceof Series) {
					System.out.printf("%s; %s; %d; %d; %d+; %d; %s; ", s.getTitle(), ((Series) s).getCreator(),
							((Series) s).getNSeaons(), ((Series) s).getNEpisodes(), s.getAge(), s.getYear(),
							s.getGenre());
				}
				for (int i = 0; i < s.getCast().size(); i++) {
					if (i == s.getCast().size() - 1)
						System.out.printf("%s.\n", s.getCast().get(i).getName());
					else
						System.out.printf("%s; ", s.getCast().get(i).getName());
				}
			}
		} catch (NoSessionOnException except) {
			System.out.println(NO_LOGGED_IN);
		} catch (NoProfileSelectException except) {
			System.out.println(NO_PROFILE_IS_SELECTED);
		} catch (NoShowFoundException except) {
			System.out.println(NO_SHOW_FOUND);
		}
	}

	private static void infoAccount(Netflix n) {
		try {
			System.out.printf("%s:\n", n.getLoggedAccount().getName());

			// Membership and devices info
			membershipInfo(n);

			// Profile info
			profileInfo(n);
		} catch (NoSessionOnException except) {
			System.out.println(NO_LOGGED_IN);
		}
	}

	private static void profileInfo(Netflix n) {
		Iterator<Profile> itP = n.getLoggedAccount().getProfiles().iterator();
		if (!n.getLoggedAccount().getProfiles().isEmpty()) {
			while (itP.hasNext()) {
				Profile p = itP.next();
				if (p instanceof Child) {
					Child p1 = (Child) p;
					System.out.printf("Profile: %s (%d)\n", p.getName(), p1.getAge());
				} else
					System.out.printf("Profile: %s\n", p.getName());
				iteraRecentlySeenShows(p);
			}
		} else {
			System.out.println(NO_PROFILES_DEFINED);
		}
	}

	private static void iteraRecentlySeenShows(Profile p) {
		if (!p.getSeenShows().isEmpty()) {
			Iterator<Show> it = p.getSeenShows().iterator();
			while (it.hasNext()) {
				Show s = it.next();
				if (p.getSeenShows().indexOf(s) == p.getSeenShows().size() - 1)
					System.out.printf("%s.\n", s.getTitle());
				else
					System.out.printf("%s; ", s.getTitle());
			}
			Iterator<Show> it1 = p.getRatedShows().iterator();
			while (it1.hasNext()) {
				Show s = it1.next();
				if (p.getRatedShows().indexOf(s) == p.getRatedShows().size() - 1)
					System.out.printf("%s (%d).\n", s.getTitle(), p.getGivenRate(s.getTitle()));
				else
					System.out.printf("%s (%d); ", s.getTitle(), p.getGivenRate(s.getTitle()));
			}
		} else
			System.out.println("Empty list of recently seen shows.");
	}

	private static void membershipInfo(Netflix n) {
		System.out.printf("%s ", n.membership());
		Iterator<Device> itD = n.getLoggedAccount().getDevices().iterator();
		System.out.printf("(");
		while (itD.hasNext()) {
			Device d = itD.next();
			if (n.getLoggedAccount().getDevices().indexOf(d) == n.getLoggedAccount().getDevices().size() - 1)
				System.out.printf("%s", d.getName().trim());
			else
				System.out.printf("%s", d.getName());
		}
		System.out.println(").");
	}

	private static void rate(Scanner in, Netflix n) {
		String title = in.nextLine();
		int rate = in.nextInt();
		in.nextLine();
		try {
			n.rate(title, rate);
			System.out.printf(THANK_YOU_FOR_RATING, title);
		} catch (NoSessionOnException except) {
			System.out.println(NO_LOGGED_IN);
		} catch (NoProfileSelectException except) {
			System.out.println(NO_PROFILE_IS_SELECTED);
		} catch (ShowDoesntExistException except) {
			System.out.println(SHOW_DOES_NOT_EXIST);
		} catch (OnlySeenShowsException except) {
			System.out.println(RECENTLY_SEEN_SHOWS);
		} catch (ShowAlreadyRatedException except) {
			System.out.println(SHOW_ALREADY_RATED);
		}
	}

	private static void watch(Scanner in, Netflix n) {
		String title = in.nextLine();
		try {
			n.watch(title);
			System.out.printf(LOADING, title);
		} catch (NoSessionOnException except) {
			System.out.println(NO_LOGGED_IN);
		} catch (NoProfileSelectException except) {
			System.out.println(NO_PROFILE_IS_SELECTED);
		} catch (ShowDoesntExistException except) {
			System.out.println(SHOW_DOES_NOT_EXIST);
		} catch (ShowNotAvailableException except) {
			System.out.println(SHOW_NOT_AVAILABLE);
		}
	}

	private static void select(Scanner in, Netflix n) {
		String profileName = in.nextLine();
		try {
			n.select(profileName);
			System.out.printf(WELCOME_NAME, n.getLoggedAccount().getUsedProfile().getName());
		} catch (NoSessionOnException except) {
			System.out.println(NO_LOGGED_IN);
		} catch (NoProfileExistException except) {
			System.out.println(PROFILE_DOES_NOT_EXIST);
		}
	}

	private static void addProfile(Scanner in, Netflix n) {
		String profileName = in.nextLine();
		String type = in.nextLine();
		try {
			if (type.equals(CHILDREN)) {
				int age = in.nextInt();
				in.nextLine();
				n.addProfile(profileName, age);
			} else
				n.addProfile(profileName);
			System.out.println(NEW_PROFILE_ADDED);
		} catch (NoSessionOnException except) {
			System.out.println(NO_LOGGED_IN);
		} catch (ProfileAlreadyExistException except) {
			System.out.printf(THERE_IS_ALREADY_A_PROFILE, profileName);
		} catch (NoMoreProfileException except) {
			System.out.println(NOT_POSSIBLE_TO_ADD_MORE_PROFILES);
		}
	}

	private static void changeMembership(Scanner in, Netflix n) {
		String newMembership = in.nextLine();
		try {
			String oldMembership = n.membership();
			newMembership = newMembership.substring(0, 1).toUpperCase() + newMembership.substring(1).toLowerCase();
			n.changeMembership(newMembership);
			System.out.printf(MEMBERSHIP_CHANGED, oldMembership, newMembership);
		} catch (NoSessionOnException except) {
			System.out.println(NO_LOGGED_IN);
		} catch (MembershipAlreadyExistException except) {
			System.out.println(NO_MEMBERSHIP_PLAN_CHANGE);
		} catch (NoMoreMembershipException except) {
			System.out.println(CANNOT_DOWNGRADE_MEMBERSHIP);
		}
	}

	private static void logout(Netflix n) {
		try {
			Account c = n.getLoggedAccount();
			n.logout();
			System.out.printf(GOODBYE_STILL_CONNECTED, c.getName(), c.getUsedDevice().getName());
		} catch (NoSessionOnException except) {
			System.out.println(NO_LOGGED_IN);
		}
	}

	private static void disconnect(Netflix n) {
		try {
			Account c = n.getLoggedAccount();
			Device device = c.getUsedDevice();
			n.disconnect();
			System.out.printf(GOODBYE_WAS_DISCONNECTED, c.getName(), device.getName());
		} catch (NoSessionOnException except) {
			System.out.println(NO_LOGGED_IN);
		}
	}

	private static void login(Scanner in, Netflix n) {
		String email = in.nextLine();
		String password = in.nextLine();
		String device = in.nextLine();
		try {
			n.login(email, password, device);
			System.out.printf(WELCOME, n.getAccountName(email), device);

		} catch (AlreadyOnException except) {
			System.out.println(CLIENT_ALREADY_LOGGED_IN);
		} catch (SessionIsOnException except) {
			System.out.println(ANOTHER_CLIENT_IS_LOGGED_IN2);
		} catch (AccountDoesNotExistException except) {
			System.out.println(ACCOUNT_DOES_NOT_EXIST);
		} catch (WrongPasswordException except) {
			System.out.println(WRONG_PASSWORD);
		} catch (TooMuchDevicesException except) {
			System.out.println(NOT_POSSIBLE_TO_CONNECT_MORE_DEVICES);
		}
	}

	private static void register(Scanner in, Netflix n) {
		String name = in.nextLine();
		String email = in.nextLine();
		String password = in.nextLine();
		String device = in.nextLine();
		try {
			n.addAccount(name, email, password, device);
			System.out.printf(WELCOME, name, device);
		} catch (SessionIsOnException except) {
			System.out.println(ANOTHER_CLIENT_IS_LOGGED_IN);
		} catch (AccountSameEmailException except) {
			System.out.printf(SAME_EMAIL, email);
		}
	}

	private static void upload(Scanner in, Netflix n) {
		// adding movies to the database
		readMovies(in, n);

		// adding series to the database
		readSeries(in, n);

		Iterator<Show> it = n.listShowsByName();
		System.out.println(DATABASE_WAS_UPDATED);
		while (it.hasNext()) {
			Show s = it.next();
			if (s instanceof Movie) {
				System.out.printf(MOVIE_FORMAT, s.getTitle(), ((Movie) s).getDirector(), ((Movie) s).getDuration(),
						s.getAge(), s.getYear(), s.getGenre());
			} else {
				System.out.printf(SERIES_FORMAT, s.getTitle(), ((Series) s).getCreator(), ((Series) s).getNSeaons(),
						((Series) s).getNEpisodes(), s.getAge(), s.getYear(), s.getGenre());
			}
			for (int i = 0; i < s.getCast().size() && i < 3; i++) {
				if (i == 2 || i == s.getCast().size() - 1)
					System.out.printf(LAST_CAST_FORMAT, s.getCast().get(i).getName());
				else
					System.out.printf(CAST_FORMAT, s.getCast().get(i).getName());

			}

		}
	}

	private static void readSeries(Scanner in, Netflix n) {
		int nSeries = in.nextInt();
		in.nextLine();
		for (int i = 0; i < nSeries; i++) {
			String title = in.nextLine();
			String creator = in.nextLine();
			int nSeason = in.nextInt();
			in.nextLine();
			int nEpisodes = in.nextInt();
			in.nextLine();
			String ageRate = in.nextLine();
			int age = Integer.parseInt(ageRate.substring(0, ageRate.length() - 1));
			int year = in.nextInt();
			in.nextLine();
			String genre = in.nextLine();
			int nCast = in.nextInt();
			in.nextLine();
			String cast[] = new String[nCast];
			for (int j = 0; j < nCast; j++) {
				cast[j] = in.nextLine();
			}
			n.addSeries(title, creator, nSeason, nEpisodes, age, year, genre, cast);
		}
	}

	private static void readMovies(Scanner in, Netflix n) {
		int nMovies = in.nextInt();
		in.nextLine();
		for (int i = 0; i < nMovies; i++) {
			String title = in.nextLine();
			String director = in.nextLine();
			int duration = in.nextInt();
			in.nextLine();
			String ageRate = in.nextLine();
			int age = Integer.parseInt(ageRate.substring(0, ageRate.length() - 1));
			int year = in.nextInt();
			in.nextLine();
			String genre = in.nextLine();
			int nCast = in.nextInt();
			in.nextLine();
			String cast[] = new String[nCast];
			for (int j = 0; j < nCast; j++) {
				cast[j] = in.nextLine();
			}
			n.addMovie(title, director, duration, age, year, genre, cast);
		}
	}

	private static String getCommand(Scanner in) {
		String input = in.nextLine().toLowerCase();
		return input;
	}

}
