//exercicios teorica

class ola {

    var x = 5;
var z = 7;

constructor(x) {
    this.x = this.current = x;

}

f(x) {
    console.log(x);
    console.log(y);
    thix.x = 1;
    var y = 2;
    console.log(x);
    console.log(y);
    console.log(z);
    return x;

}

f(6);
}