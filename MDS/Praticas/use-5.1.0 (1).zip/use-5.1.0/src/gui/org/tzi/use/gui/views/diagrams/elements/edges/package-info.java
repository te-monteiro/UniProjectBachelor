/**
 * This package provides edge classes used inside
 * diagrams. 
 * @author Lars Hamann
 *
 */
package org.tzi.use.gui.views.diagrams.elements.edges;